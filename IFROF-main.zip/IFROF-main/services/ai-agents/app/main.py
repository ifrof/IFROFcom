from fastapi import FastAPI

from app.routes.content import router as content_router
from app.routes.outreach import router as outreach_router
from app.routes.product_decision import router as product_decision_router
from app.routes.support import router as support_router
from app.routes.trade_news import router as trade_news_router

app = FastAPI(title="IFROF AI Agents Service", version="0.1.0")


@app.get("/health")
def healthcheck():
    return {"status": "ok"}


app.include_router(support_router)
app.include_router(content_router)
app.include_router(trade_news_router)
app.include_router(product_decision_router)
app.include_router(outreach_router)
