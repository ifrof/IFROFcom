from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml
from crewai import Agent, Crew, LLM, Process, Task

BASE_DIR = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"


def _load_yaml(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


AGENTS_CONFIG = _load_yaml(CONFIG_DIR / "agents.yaml")
TASKS_CONFIG = _load_yaml(CONFIG_DIR / "tasks.yaml")


def build_llm() -> LLM:
    model = os.getenv("OLLAMA_MODEL", "qwen3:8b")
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    return LLM(model=f"ollama/{model}", base_url=base_url)


class IFROFCrewFactory:
    def __init__(self) -> None:
        self.llm = build_llm()

    def _agent(self, key: str) -> Agent:
        cfg = AGENTS_CONFIG[key]
        return Agent(
            role=cfg["role"],
            goal=cfg["goal"],
            backstory=cfg["backstory"],
            verbose=cfg.get("verbose", True),
            allow_delegation=cfg.get("allow_delegation", False),
            llm=self.llm,
        )

    def _task(self, key: str, agent: Agent, inputs: Dict[str, Any]) -> Task:
        cfg = TASKS_CONFIG[key]
        description = cfg["description"].format(**inputs)
        return Task(
            description=description,
            expected_output=cfg["expected_output"],
            agent=agent,
        )

    def _run(self, agent_key: str, task_key: str, inputs: Dict[str, Any]) -> str:
        agent = self._agent(agent_key)
        task = self._task(task_key, agent, inputs)
        crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=True)
        return str(crew.kickoff())

    def run_support_reply(self, inputs: Dict[str, Any]) -> str:
        return self._run("support_agent", "support_reply_task", inputs)

    def run_blog_writer(self, inputs: Dict[str, Any]) -> str:
        return self._run("content_agent", "content_blog_task", inputs)

    def run_trade_news(self, inputs: Dict[str, Any]) -> str:
        return self._run("trade_news_agent", "trade_news_task", inputs)

    def run_product_decision(self, inputs: Dict[str, Any]) -> str:
        return self._run("product_decision_agent", "product_decision_task", inputs)

    def run_marketing_strategy(self, inputs: Dict[str, Any]) -> str:
        return self._run("marketing_agent", "marketing_strategy_task", inputs)

    def run_outreach(self, inputs: Dict[str, Any]) -> str:
        return self._run("outreach_agent", "outreach_message_task", inputs)
