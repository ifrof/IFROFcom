from app.tools.rag import build_context


def enrich_prompt_with_kb(user_query: str) -> str:
    context = build_context(user_query)
    if not context:
        return user_query

    return f"Knowledge Context:\n{context}\n\nUser Question:\n{user_query}"
