import os
from pathlib import Path
from typing import List, Dict

KNOWLEDGE_DIR = Path(os.getenv("KNOWLEDGE_DIR", "./knowledge"))
MAX_CHUNKS = int(os.getenv("MAX_RAG_CHUNKS", "5"))


def load_documents() -> List[Dict[str, str]]:
    docs: List[Dict[str, str]] = []
    if not KNOWLEDGE_DIR.exists():
        return docs

    for file in KNOWLEDGE_DIR.glob("**/*.txt"):
        try:
            content = file.read_text(encoding="utf-8")
            docs.append({"name": file.name, "content": content})
        except Exception:
            continue
    return docs


def simple_search(query: str) -> List[str]:
    docs = load_documents()
    scored = []

    for doc in docs:
        score = doc["content"].lower().count(query.lower())
        if score > 0:
            scored.append((score, f"Source: {doc['name']}\n{doc['content']}"))

    scored.sort(reverse=True, key=lambda x: x[0])
    return [content for _, content in scored[:MAX_CHUNKS]]


def build_context(query: str) -> str:
    chunks = simple_search(query)
    if not chunks:
        return ""
    return "\n\n---\n\n".join(chunks)
