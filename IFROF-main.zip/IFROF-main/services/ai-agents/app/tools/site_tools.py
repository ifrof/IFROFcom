from typing import Dict


def build_publish_payload(title: str, body: str, author: str = "IFROF AI Desk") -> Dict[str, str]:
    return {
        "title": title,
        "body": body,
        "author": author,
        "status": "draft",
    }
