from typing import Any, Dict


def get_default_business_context() -> Dict[str, Any]:
    return {
        "company_name": "IFROF",
        "services": [
            "sourcing support",
            "product validation",
            "supplier coordination",
            "import/export content and advisory",
        ],
        "tone": "professional, practical, friendly",
        "language": "Arabic-first",
    }
