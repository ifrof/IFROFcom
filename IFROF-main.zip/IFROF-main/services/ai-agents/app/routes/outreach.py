from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel

from app.crew import IFROFCrewFactory

router = APIRouter(prefix="/outreach", tags=["outreach"])
crew_factory = IFROFCrewFactory()


class OutreachRequest(BaseModel):
    target_name: str
    target_company: str
    purpose: str
    tone: Optional[str] = "professional"


class OutreachResponse(BaseModel):
    subject: str
    body: str


@router.post("/draft", response_model=OutreachResponse)
def draft_outreach(payload: OutreachRequest):
    inputs = {
        "lead_type": "Cold Lead",
        "lead_background": f"{payload.target_name} from {payload.target_company}",
        "offer": payload.purpose,
        "tone": payload.tone,
    }
    result = str(crew_factory.run_outreach(inputs)).strip()

    lines = [line.strip() for line in result.split("\n") if line.strip()]
    subject = lines[0] if lines else f"Partnership with {payload.target_company}"
    body = "\n".join(lines[1:]).strip() if len(lines) > 1 else result

    return OutreachResponse(subject=subject, body=body)
