from typing import List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.crew import IFROFCrewFactory

router = APIRouter(prefix="/content", tags=["content"])
crew_factory = IFROFCrewFactory()


class BlogRequest(BaseModel):
    topic: str
    keywords: Optional[List[str]] = Field(default_factory=list)


class BlogResponse(BaseModel):
    title: str
    content: str
    seoTags: List[str]


@router.post("/blog/generate", response_model=BlogResponse)
def generate_blog(payload: BlogRequest):
    inputs = {
        "topic": payload.topic,
        "audience": "Arabic-speaking import/export audience",
        "length": "1200 words",
        "seo_keyword": payload.keywords[0] if payload.keywords else "الاستيراد من الصين",
    }
    result = str(crew_factory.run_blog_writer(inputs)).strip()

    lines = [line.strip() for line in result.split("\n") if line.strip()]
    title = lines[0] if lines else f"{payload.topic} - IFROF Guide"
    content = "\n".join(lines[1:]).strip() if len(lines) > 1 else result

    return BlogResponse(
        title=title,
        content=content,
        seoTags=payload.keywords or [payload.topic],
    )
