from typing import Any, Dict, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.crew import IFROFCrewFactory
from app.tools.kb_tool import enrich_prompt_with_kb

router = APIRouter(prefix="/support", tags=["support"])
crew_factory = IFROFCrewFactory()


class SupportRequest(BaseModel):
    customer_message: str
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)


class SupportResponse(BaseModel):
    reply: str


@router.post("/reply", response_model=SupportResponse)
def support_reply(payload: SupportRequest):
    enriched = enrich_prompt_with_kb(payload.customer_message)
    context_str = f"\nContext: {payload.context}" if payload.context else ""
    result = crew_factory.run_support_reply(
        {
            "message": enriched + context_str,
            "business_context": "Use company knowledge if available",
        }
    )
    return SupportResponse(reply=str(result).strip())
