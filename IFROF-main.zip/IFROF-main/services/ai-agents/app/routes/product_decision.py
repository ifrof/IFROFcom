from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.crew import IFROFCrewFactory

router = APIRouter(prefix="/product-decision", tags=["product-decision"])
crew_factory = IFROFCrewFactory()


class ProductDecisionRequest(BaseModel):
    query: str
    preferences: Optional[Dict[str, Any]] = Field(default_factory=dict)


class ProductDecisionResponse(BaseModel):
    productName: str
    supplier: str
    price: float
    profitEstimate: float
    confidence: int
    reasons: List[str]
    risks: List[str]
    description: str


@router.post("/run", response_model=ProductDecisionResponse)
def run_product_decision(payload: ProductDecisionRequest):
    max_price = float((payload.preferences or {}).get("maxPrice", 10.0))
    inputs = {
        "product_name": payload.query,
        "product_cost": max_price,
        "shipping_cost": 5.0,
        "sale_price": max_price * 2,
        "market_notes": f"Search Query: {payload.query}. Preferences: {payload.preferences}",
    }
    result = crew_factory.run_product_decision(inputs)

    return ProductDecisionResponse(
        productName=payload.query,
        supplier="Verified Supplier",
        price=inputs["sale_price"],
        profitEstimate=inputs["sale_price"] - inputs["product_cost"] - inputs["shipping_cost"],
        confidence=85,
        reasons=["Strong market demand", "Good profit margin"],
        risks=["Shipping delays", "Competition"],
        description=str(result).strip(),
    )
