from typing import List, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from app.crew import IFROFCrewFactory

router = APIRouter(prefix="/trade-news", tags=["trade-news"])
crew_factory = IFROFCrewFactory()


class TradeNewsRequest(BaseModel):
    news_url: str
    industry: Optional[str] = ""


class TradeNewsResponse(BaseModel):
    summary: str
    keyPoints: List[str]
    sentiment: str


@router.post("/summarize", response_model=TradeNewsResponse)
def summarize_trade_news(payload: TradeNewsRequest):
    inputs = {
        "raw_news": f"Summarize key developments from {payload.news_url}. Industry: {payload.industry or 'general trade'}.",
    }
    result = str(crew_factory.run_trade_news(inputs)).strip()

    key_points = [line.strip("-• ") for line in result.split("\n") if line.strip()][:5]
    if not key_points:
        key_points = ["No explicit bullet points detected in model response."]

    return TradeNewsResponse(
        summary=result,
        keyPoints=key_points,
        sentiment="Neutral",
    )
