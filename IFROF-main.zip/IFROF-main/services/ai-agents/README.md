# IFROF AI Agents Service

CrewAI + FastAPI + Ollama starter pack for IFROF.

## Features

- Support agent
- Blog/content agent
- China trade news summarizer
- Product decision agent
- Marketing strategy agent
- Outreach draft agent
- Simple local RAG using `.txt` files in `knowledge/`

## Run locally

1. Install Ollama and pull a model:

```bash
ollama pull qwen3:8b
```

2. Create venv and install requirements:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

3. Copy env file:

```bash
cp .env.example .env
```

4. Start server:

```bash
# Unified port: 8000
uvicorn app.main:app --reload --port 8000
```

## API Contracts (Aligned with Node.js Client)

### 1. Support Reply
**POST** `/support/reply`
- **Request**: `{"customer_message": "string", "context": {}}`
- **Response**: `{"reply": "string"}`

### 2. Product Decision
**POST** `/product-decision/run`
- **Request**: `{"query": "string", "preferences": {}}`
- **Response**: `{"productName": "string", "supplier": "string", "price": number, "profitEstimate": number, "confidence": number, "reasons": [], "risks": [], "description": "string"}`

### 3. Blog Generation
**POST** `/content/blog/generate`
- **Request**: `{"topic": "string", "keywords": []}`
- **Response**: `{"title": "string", "content": "string", "seoTags": []}`

### 4. Outreach Draft
**POST** `/outreach/draft`
- **Request**: `{"target_name": "string", "target_company": "string", "purpose": "string", "tone": "string"}`
- **Response**: `{"subject": "string", "body": "string"}`

### 5. Trade News Summary
**POST** `/trade-news/summarize`
- **Request**: `{"news_url": "string", "industry": "string"}`
- **Response**: `{"summary": "string", "keyPoints": [], "sentiment": "string"}`

## Knowledge base

Put `.txt` files into `knowledge/`.
The support route enriches the prompt with matching knowledge automatically.

## Integration Path

This service is located in `services/ai-agents/` and is called from the Node.js backend via the `ai-service-client.ts` helper.
