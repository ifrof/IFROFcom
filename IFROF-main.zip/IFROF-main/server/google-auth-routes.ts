/**
 * Google OAuth Express Routes
 * Handles /api/auth/google and /api/auth/google/callback
 */
import type { Express, Request, Response } from "express";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import * as db from "./db";
import { ENV } from "./_core/env";

const GOOGLE_CLIENT_ID = ENV.googleClientId;
const GOOGLE_CLIENT_SECRET = ENV.googleClientSecret;

function getGoogleRedirectUri(req: Request): string {
  // Build redirect URI dynamically from request
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000';
  return `${proto}://${host}/api/auth/google/callback`;
}

export function registerGoogleOAuthRoutes(app: Express) {
  /**
   * GET /api/auth/google — Redirect user to Google consent screen
   */
  app.get("/api/auth/google", (req: Request, res: Response) => {
    if (!GOOGLE_CLIENT_ID) {
      res.status(500).json({ error: "Google OAuth not configured" });
      return;
    }

    const redirectUri = getGoogleRedirectUri(req);
    const scopes = [
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/userinfo.profile',
    ];

    const params = new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: scopes.join(' '),
      access_type: 'offline',
      prompt: 'consent',
    });

    res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
  });

  /**
   * GET /api/auth/google/callback — Handle Google OAuth callback
   */
  app.get("/api/auth/google/callback", async (req: Request, res: Response) => {
    const code = typeof req.query.code === 'string' ? req.query.code : '';
    const error = typeof req.query.error === 'string' ? req.query.error : '';

    if (error) {
      console.error('[Google OAuth] Error:', error);
      res.redirect('/login?error=google_denied');
      return;
    }

    if (!code) {
      res.redirect('/login?error=no_code');
      return;
    }

    try {
      const redirectUri = getGoogleRedirectUri(req);

      // Exchange code for tokens
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          client_id: GOOGLE_CLIENT_ID,
          client_secret: GOOGLE_CLIENT_SECRET,
          redirect_uri: redirectUri,
          grant_type: 'authorization_code',
        }),
      });

      if (!tokenRes.ok) {
        const errData = await tokenRes.text();
        console.error('[Google OAuth] Token exchange failed:', errData);
        res.redirect('/login?error=token_exchange');
        return;
      }

      const tokens = await tokenRes.json() as { access_token?: string };

      if (!tokens.access_token) {
        res.redirect('/login?error=no_access_token');
        return;
      }

      // Get user info from Google
      const userInfoRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });

      if (!userInfoRes.ok) {
        res.redirect('/login?error=user_info_failed');
        return;
      }

      const googleUser = await userInfoRes.json() as {
        id?: string;
        name?: string;
        email?: string;
        picture?: string;
      };

      if (!googleUser.id) {
        res.redirect('/login?error=no_google_id');
        return;
      }

      // Optionally restrict to Gmail only (if REQUIRE_GMAIL_ONLY env is set)
      if (ENV.requireGmailOnly && googleUser.email) {
        const domain = googleUser.email.split('@')[1];
        if (domain !== 'gmail.com') {
          res.redirect('/login?error=gmail_only');
          return;
        }
      }

      // Use Google user ID as openId (prefixed for namespace clarity)
      const openId = `google:${googleUser.id}`;

      // Upsert user
      await db.upsertUser({
        openId,
        name: googleUser.name || (googleUser.email ? googleUser.email.split('@')[0] : 'User'),
        email: googleUser.email || null,
        loginMethod: 'google',
        lastSignedIn: new Date(),
      });

      // Retrieve the upserted user
      const user = await db.getUserByOpenId(openId);

      if (!user) {
        res.redirect('/login?error=user_creation_failed');
        return;
      }

      // Create a JWT session token
      const sessionToken = await sdk.createSessionToken(openId, {
        name: user.name || '',
        expiresInMs: ONE_YEAR_MS,
      });

      // Set session cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      // Redirect to home page
      res.redirect(302, '/');
    } catch (err) {
      console.error('[Google OAuth] Callback error:', err);
      res.redirect('/login?error=callback_failed');
    }
  });
}
