/**
 * Blog Seed Script — inserts 100 SEO-optimised articles (EN/AR/ZH) into the database.
 * Run: npx tsx server/seed-blog.ts
 *
 * The script:
 *  1. Creates 10 blog categories (sourcing, quality, logistics, etc.)
 *  2. Ensures an admin author exists (openId = "seed_admin_author")
 *  3. Parses the 6 markdown source files and inserts each article
 *     using onDuplicateKeyUpdate so it is safe to run multiple times.
 */

import { drizzle } from "drizzle-orm/mysql2";
import { blogArticles, blogCategories, users } from "../drizzle/schema";
import { sql } from "drizzle-orm";
import * as fs from "fs";
import * as path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── helpers ────────────────────────────────────────────────────────────────

function parseArticleFile(filePath: string): ArticleData[] {
  const raw = fs.readFileSync(filePath, "utf-8");
  // Split on the separator line that starts a new article block
  const blocks = raw.split(/\n---\n/).map((b) => b.trim()).filter(Boolean);
  const articles: ArticleData[] = [];

  for (const block of blocks) {
    const lines = block.split("\n");
    const meta: Record<string, string> = {};
    let contentLines: string[] = [];
    let inContent = false;

    for (const line of lines) {
      if (inContent) {
        contentLines.push(line);
        continue;
      }
      const metaMatch = line.match(/^_([A-Z_]+)_=(.*)$/);
      if (metaMatch) {
        meta[metaMatch[1]] = metaMatch[2].trim();
        continue;
      }
      // _CONTENT_= line (value may be empty — content starts on next line)
      if (line.startsWith("_CONTENT_=")) {
        inContent = true;
        const inline = line.replace("_CONTENT_=", "").trim();
        if (inline) contentLines.push(inline);
        continue;
      }
      // Multi-line meta values (e.g. _TAGS_=[...])
      if (line.startsWith("_TAGS_=")) {
        // collect until closing ]
        let tagVal = line.replace("_TAGS_=", "").trim();
        // tags are already on one line in our files
        meta["TAGS"] = tagVal;
        continue;
      }
    }

    if (!meta["TITLE"] || !meta["SLUG"]) continue;

    // Parse tags JSON
    let tags: string[] = [];
    try {
      tags = JSON.parse(meta["TAGS"] || "[]");
    } catch {
      tags = [];
    }

    articles.push({
      categoryId: parseInt(meta["CATEGORY_ID"] || "1", 10),
      authorId: parseInt(meta["AUTHOR_ID"] || "1", 10),
      status: (meta["STATUS"] || "published") as "draft" | "published" | "archived",
      featured: parseInt(meta["FEATURED"] || "0", 10),
      readTime: parseInt(meta["READ_TIME"] || "5", 10),
      coverImage: meta["COVER_IMAGE"] || null,
      tags,
      title: meta["TITLE"],
      slug: meta["SLUG"],
      excerpt: meta["EXCERPT"] || null,
      content: contentLines.join("\n").trim(),
    });
  }

  return articles;
}

interface ArticleData {
  categoryId: number;
  authorId: number;
  status: "draft" | "published" | "archived";
  featured: number;
  readTime: number;
  coverImage: string | null;
  tags: string[];
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
}

// ─── main ────────────────────────────────────────────────────────────────────

async function seedBlog() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.error("DATABASE_URL not set. Skipping seed.");
    process.exit(1);
  }

  const db = drizzle(dbUrl);
  console.log("[BlogSeed] Connected to database");

  // ── 1. Blog categories ──────────────────────────────────────────────────
  const categoryData = [
    { id: 1,  name: "Sourcing & Procurement",   slug: "sourcing-procurement",   description: "How to find, vet and work with suppliers",          icon: "Search"       },
    { id: 2,  name: "Quality Control",           slug: "quality-control",        description: "Inspections, AQL, defect management",               icon: "ShieldCheck"  },
    { id: 3,  name: "Supplier Relations",        slug: "supplier-relations",     description: "Negotiations, MOQ, long-term partnerships",         icon: "Handshake"    },
    { id: 4,  name: "Product Development",       slug: "product-development",    description: "Specs, prototypes, manufacturing processes",        icon: "Layers"       },
    { id: 5,  name: "Shipping & Logistics",      slug: "shipping-logistics",     description: "Incoterms, freight, customs clearance",             icon: "Truck"        },
    { id: 6,  name: "Manufacturing Insights",    slug: "manufacturing-insights", description: "Factory processes, materials, and technologies",    icon: "Factory"      },
    { id: 7,  name: "Payments & Finance",        slug: "payments-finance",       description: "Payment methods, trade finance, risk management",   icon: "CreditCard"   },
    { id: 8,  name: "Innovation & Technology",   slug: "innovation-technology",  description: "3D printing, CNC, automation, and new materials",   icon: "Cpu"          },
    { id: 9,  name: "E-commerce & Selling",      slug: "ecommerce-selling",      description: "Amazon FBA, Shopify, product research, SEO",        icon: "ShoppingCart" },
    { id: 10, name: "Industry Knowledge",        slug: "industry-knowledge",     description: "Solar, electronics, textiles, and sector guides",   icon: "BookOpen"     },
  ];

  console.log("[BlogSeed] Upserting 10 blog categories...");
  for (const cat of categoryData) {
    await db.insert(blogCategories).values({
      name: cat.name,
      slug: cat.slug,
      description: cat.description,
      icon: cat.icon,
    }).onDuplicateKeyUpdate({ set: { name: cat.name } });
  }

  // Fetch real category IDs (auto-increment may differ from our logical IDs)
  const catRows = await db.select({ id: blogCategories.id, slug: blogCategories.slug }).from(blogCategories);
  const catSlugToId: Record<string, number> = {};
  for (const row of catRows) catSlugToId[row.slug] = row.id;

  // Build a map from our logical 1-10 IDs to real DB IDs
  const logicalToReal: Record<number, number> = {};
  for (let i = 0; i < categoryData.length; i++) {
    const realId = catSlugToId[categoryData[i].slug];
    if (realId) logicalToReal[categoryData[i].id] = realId;
  }

  // ── 2. Admin author ──────────────────────────────────────────────────────
  const adminOpenId = "seed_admin_author";
  await db.insert(users).values({
    openId: adminOpenId,
    name: "IFROF Editorial Team",
    email: "editorial@ifrof.com",
    loginMethod: "seed",
    role: "admin",
    plan: "pro",
  }).onDuplicateKeyUpdate({ set: { name: "IFROF Editorial Team" } });

  const [adminRow] = await db
    .select({ id: users.id })
    .from(users)
    .where(sql`${users.openId} = ${adminOpenId}`)
    .limit(1);

  const authorId = adminRow.id;
  console.log(`[BlogSeed] Author ID: ${authorId}`);

  // ── 3. Parse all article files ───────────────────────────────────────────
  const dir = path.join(__dirname);
  const sourceFiles = [
    "seed-blog-en-1.md",
    "seed-blog-en-2.md",
    "seed-blog-en-3.md",
    "seed-blog-ar-1.md",
    "seed-blog-ar-2.md",
    "seed-blog-ar-3.md",
    "seed-blog-ar-china-1.md",
    "seed-blog-ar-china-2.md",
    "seed-blog-ar-china-3.md",
    "seed-blog-ar-china-4.md",
    "seed-blog-zh-1.md",
    "seed-blog-zh-2.md",
    "seed-blog-zh-3.md",
  ];

  let allArticles: ArticleData[] = [];
  for (const file of sourceFiles) {
    const filePath = path.join(dir, file);
    if (!fs.existsSync(filePath)) {
      console.warn(`[BlogSeed] File not found, skipping: ${file}`);
      continue;
    }
    const parsed = parseArticleFile(filePath);
    console.log(`[BlogSeed] Parsed ${parsed.length} articles from ${file}`);
    allArticles = allArticles.concat(parsed);
  }

  console.log(`[BlogSeed] Total articles to insert: ${allArticles.length}`);

  // ── 4. Insert articles ───────────────────────────────────────────────────
  let inserted = 0;
  let skipped = 0;

  for (const article of allArticles) {
    const realCategoryId = logicalToReal[article.categoryId] ?? Object.values(logicalToReal)[0];

    try {
      await db.insert(blogArticles).values({
        authorId,
        categoryId: realCategoryId,
        title: article.title,
        slug: article.slug,
        excerpt: article.excerpt ?? undefined,
        content: article.content,
        coverImage: article.coverImage ?? undefined,
        tags: JSON.stringify(article.tags),
        status: article.status,
        views: Math.floor(Math.random() * 800) + 50,
        readTime: article.readTime,
        featured: article.featured,
        publishedAt: new Date(),
      }).onDuplicateKeyUpdate({
        set: {
          title: article.title,
          excerpt: article.excerpt ?? undefined,
          content: article.content,
          tags: JSON.stringify(article.tags),
          status: article.status,
          readTime: article.readTime,
          featured: article.featured,
        },
      });
      inserted++;
    } catch (err: any) {
      console.warn(`[BlogSeed] Skipped "${article.slug}": ${err.message}`);
      skipped++;
    }
  }

  console.log(`[BlogSeed] Done! Inserted/updated: ${inserted}, skipped: ${skipped}`);
  process.exit(0);
}

seedBlog().catch((err) => {
  console.error("[BlogSeed] Fatal error:", err);
  process.exit(1);
});
