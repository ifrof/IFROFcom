import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { adminProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { rfqs, analyticsEvents, agentQuotes, users, notifications } from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { sendRfqConfirmation, sendAdminNewRfqAlert } from "./email";

/**
 * RFQ Router - Managed Sourcing Agent Model
 * Supplier/factory data is NEVER returned to the buyer.
 */
export const rfqRouter = router({

  create: protectedProcedure
    .input(z.object({
      productName: z.string().min(1).max(255),
      specifications: z.string().optional(),
      quantity: z.number().min(1).optional(),
      targetPrice: z.number().optional(),
      destinationCountry: z.string().optional(),
      imageUrl: z.string().optional(),
      shippingPreference: z.enum(["sea", "air", "express"]).default("sea"),
      certificationsRequired: z.array(z.string()).optional(),
      customizationNeeded: z.enum(["yes", "no"]).default("no"),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = await db.insert(rfqs).values({
        userId: ctx.user.id,
        productName: input.productName,
        specifications: input.specifications ?? null,
        quantity: input.quantity ?? null,
        targetPrice: input.targetPrice ?? null,
        destinationCountry: input.destinationCountry ?? null,
        imageUrl: input.imageUrl ?? null,
        shippingPreference: input.shippingPreference,
        certificationsRequired: input.certificationsRequired ? JSON.stringify(input.certificationsRequired) : null,
        customizationNeeded: input.customizationNeeded,
        status: "submitted",
      }).$returningId();
      const rfqId = result[0].id;
      await db.insert(analyticsEvents).values({
        userId: ctx.user.id,
        event: "rfq_created",
        properties: JSON.stringify({ rfqId, productName: input.productName }),
      });
      await db.insert(notifications).values({
        userId: ctx.user.id,
        type: "order_update",
        title: "Sourcing Request Received",
        message: `Your request for "${input.productName}" has been received. Our team will review it and send you a quote within 24 hours.`,
      });
      // Send email notifications (non-blocking)
      const user = ctx.user;
      if (user.email) {
        sendRfqConfirmation(user.email, user.name || "Valued Customer", {
          id: rfqId,
          productName: input.productName,
          quantity: input.quantity ?? 1,
          unit: "units",
          targetPrice: input.targetPrice ? `$${input.targetPrice}` : undefined,
        }).catch(() => {});
      }
      sendAdminNewRfqAlert({
        id: rfqId,
        productName: input.productName,
        quantity: input.quantity ?? 1,
        unit: "units",
        userName: user.name || "Unknown",
        userEmail: user.email || "N/A",
        country: input.destinationCountry,
      }).catch(() => {});
      return { success: true, rfqId };
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    const result = await db.select().from(rfqs).where(eq(rfqs.userId, ctx.user.id)).orderBy(desc(rfqs.createdAt));
    return result.map(r => ({
      id: r.id,
      productName: r.productName,
      specifications: r.specifications,
      quantity: r.quantity,
      targetPrice: r.targetPrice,
      destinationCountry: r.destinationCountry,
      imageUrl: r.imageUrl,
      shippingPreference: r.shippingPreference,
      certificationsRequired: r.certificationsRequired ? JSON.parse(r.certificationsRequired) : [],
      customizationNeeded: r.customizationNeeded,
      status: r.status,
      createdAt: r.createdAt,
    }));
  }),

  getWithQuote: protectedProcedure
    .input(z.object({ rfqId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const rfqResult = await db.select().from(rfqs).where(eq(rfqs.id, input.rfqId)).limit(1);
      if (rfqResult.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
      if (rfqResult[0].userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      const rfq = rfqResult[0];
      const quoteResult = await db
        .select({
          id: agentQuotes.id,
          unitPrice: agentQuotes.unitPrice,
          quantity: agentQuotes.quantity,
          totalAmount: agentQuotes.totalAmount,
          currency: agentQuotes.currency,
          leadTimeDays: agentQuotes.leadTimeDays,
          shippingMethod: agentQuotes.shippingMethod,
          shippingCost: agentQuotes.shippingCost,
          validUntil: agentQuotes.validUntil,
          notes: agentQuotes.notes,
          status: agentQuotes.status,
          createdAt: agentQuotes.createdAt,
        })
        .from(agentQuotes)
        .where(and(eq(agentQuotes.rfqId, input.rfqId), eq(agentQuotes.buyerId, ctx.user.id), eq(agentQuotes.status, "sent")))
        .orderBy(desc(agentQuotes.createdAt))
        .limit(1);
      return {
        rfq: {
          id: rfq.id, productName: rfq.productName, specifications: rfq.specifications,
          quantity: rfq.quantity, targetPrice: rfq.targetPrice, destinationCountry: rfq.destinationCountry,
          imageUrl: rfq.imageUrl, shippingPreference: rfq.shippingPreference,
          certificationsRequired: rfq.certificationsRequired ? JSON.parse(rfq.certificationsRequired) : [],
          customizationNeeded: rfq.customizationNeeded, status: rfq.status, createdAt: rfq.createdAt,
        },
        quote: quoteResult[0] ?? null,
      };
    }),

  respondToQuote: protectedProcedure
    .input(z.object({ quoteId: z.number(), action: z.enum(["accept", "reject"]) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const quote = await db.select().from(agentQuotes).where(and(eq(agentQuotes.id, input.quoteId), eq(agentQuotes.buyerId, ctx.user.id))).limit(1);
      if (quote.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
      if (quote[0].status !== "sent") throw new TRPCError({ code: "BAD_REQUEST", message: "Quote is no longer active" });
      await db.update(agentQuotes).set({
        status: input.action === "accept" ? "accepted" : "rejected",
        acceptedAt: input.action === "accept" ? new Date() : null,
        rejectedAt: input.action === "reject" ? new Date() : null,
      }).where(eq(agentQuotes.id, input.quoteId));
      await db.update(rfqs).set({ status: input.action === "accept" ? "matched" : "submitted" }).where(eq(rfqs.id, quote[0].rfqId));
      await db.insert(notifications).values({
        userId: ctx.user.id,
        type: "order_update",
        title: input.action === "accept" ? "Quote Accepted" : "Quote Rejected",
        message: input.action === "accept"
          ? "You accepted the quote. Our team will contact you to arrange payment and escrow."
          : "You rejected the quote. We will review your request and send a revised offer.",
      });
      await db.insert(analyticsEvents).values({
        userId: ctx.user.id,
        event: `quote_${input.action}ed`,
        properties: JSON.stringify({ quoteId: input.quoteId }),
      });
      return { success: true };
    }),

  adminListAll: adminProcedure
    .input(z.object({
      status: z.enum(["submitted", "matched", "completed", "cancelled", "all"]).default("all"),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = input.status === "all"
        ? await db.select({ rfq: rfqs, buyer: { id: users.id, name: users.name, email: users.email } }).from(rfqs).leftJoin(users, eq(rfqs.userId, users.id)).orderBy(desc(rfqs.createdAt)).limit(input.limit).offset(input.offset)
        : await db.select({ rfq: rfqs, buyer: { id: users.id, name: users.name, email: users.email } }).from(rfqs).leftJoin(users, eq(rfqs.userId, users.id)).where(eq(rfqs.status, input.status as any)).orderBy(desc(rfqs.createdAt)).limit(input.limit).offset(input.offset);
      return result.map(r => ({
        ...r.rfq,
        certificationsRequired: r.rfq.certificationsRequired ? JSON.parse(r.rfq.certificationsRequired) : [],
        buyer: r.buyer,
      }));
    }),

  adminCreateQuote: adminProcedure
    .input(z.object({
      rfqId: z.number(),
      buyerId: z.number(),
      supplierId: z.number().optional(),
      supplierName: z.string().optional(),
      supplierUnitCost: z.number().optional(),
      agentMarginPct: z.number().optional(),
      internalNotes: z.string().optional(),
      unitPrice: z.number(),
      quantity: z.number(),
      shippingMethod: z.enum(["sea", "air", "rail", "express"]).default("sea"),
      shippingCost: z.number().default(0),
      leadTimeDays: z.number().optional(),
      validUntil: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const totalAmount = input.unitPrice * input.quantity + input.shippingCost;
      const result = await db.insert(agentQuotes).values({
        rfqId: input.rfqId, buyerId: input.buyerId, agentId: ctx.user.id,
        supplierId: input.supplierId ?? null, supplierName: input.supplierName ?? null,
        supplierUnitCost: input.supplierUnitCost ?? null, agentMarginPct: input.agentMarginPct ?? null,
        internalNotes: input.internalNotes ?? null, unitPrice: input.unitPrice,
        quantity: input.quantity, totalAmount, shippingMethod: input.shippingMethod,
        shippingCost: input.shippingCost, leadTimeDays: input.leadTimeDays ?? null,
        validUntil: input.validUntil ? new Date(input.validUntil) : null,
        notes: input.notes ?? null, status: "draft",
      }).$returningId();
      return { success: true, quoteId: result[0].id };
    }),

  adminSendQuote: adminProcedure
    .input(z.object({ quoteId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const quote = await db.select().from(agentQuotes).where(eq(agentQuotes.id, input.quoteId)).limit(1);
      if (quote.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
      await db.update(agentQuotes).set({ status: "sent" }).where(eq(agentQuotes.id, input.quoteId));
      await db.update(rfqs).set({ status: "matched", matchedAt: new Date() }).where(eq(rfqs.id, quote[0].rfqId));
      const rfqData = await db.select().from(rfqs).where(eq(rfqs.id, quote[0].rfqId)).limit(1);
      await db.insert(notifications).values({
        userId: quote[0].buyerId,
        type: "order_update",
        title: "You Have a New Quote",
        message: `We have prepared a quote for your request "${rfqData[0]?.productName ?? "your product"}". Review it now.`,
      });
      return { success: true };
    }),

  adminListQuotes: adminProcedure
    .input(z.object({
      status: z.enum(["draft", "sent", "accepted", "rejected", "expired", "all"]).default("all"),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = await db
        .select({ quote: agentQuotes, buyer: { id: users.id, name: users.name, email: users.email } })
        .from(agentQuotes)
        .leftJoin(users, eq(agentQuotes.buyerId, users.id))
        .orderBy(desc(agentQuotes.createdAt));
      const filtered = input.status === "all" ? result : result.filter(r => r.quote.status === input.status);
      return filtered.map(r => ({
        ...r.quote,
        buyer: r.buyer,
        marginAmount: r.quote.supplierUnitCost
          ? (r.quote.unitPrice - r.quote.supplierUnitCost) * r.quote.quantity
          : null,
      }));
    }),
});
