import { z } from "zod";
import { adminProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  factories, factoryDocuments, verificationLogs, riskFlags,
  verificationRequests, protectedOrders, escrowStatuses, users,
  conversations, messages, suppliers, orders, products, productQuoteRequests,
} from "../drizzle/schema";
import { eq, desc, sql } from "drizzle-orm";

export const adminRouter = router({
  /** List all verification requests */
  listVerificationRequests: adminProcedure
    .input(z.object({
      status: z.enum(["pending", "in_progress", "completed", "rejected"]).optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let query = db
        .select({
          request: verificationRequests,
          factory: { id: factories.id, name: factories.name, verificationLevel: factories.verificationLevel },
          requester: { id: users.id, name: users.name, email: users.email },
        })
        .from(verificationRequests)
        .leftJoin(factories, eq(verificationRequests.factoryId, factories.id))
        .leftJoin(users, eq(verificationRequests.requesterId, users.id))
        .$dynamic();

      if (input?.status) {
        query = query.where(eq(verificationRequests.status, input.status));
      }

      return await query.orderBy(desc(verificationRequests.createdAt));
    }),

  /** Update factory verification level */
  updateVerificationLevel: adminProcedure
    .input(z.object({
      factoryId: z.number(),
      verificationLevel: z.number().min(0).max(3),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(factories).set({
        verificationLevel: input.verificationLevel,
        lastVerifiedAt: new Date(),
      }).where(eq(factories.id, input.factoryId));

      await db.insert(verificationLogs).values({
        factoryId: input.factoryId,
        action: "level_upgraded",
        notes: input.notes ?? `Level set to ${input.verificationLevel}`,
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

  /** List all users (buyers) — for CRM tab */
  listUsers: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    return await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        plan: users.plan,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));
  }),
  /** List all internal suppliers */
  listSuppliers: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    return await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
  }),
  /** Create a new internal supplier */
  createSupplier: adminProcedure
    .input(z.object({
      name: z.string().min(2),
      country: z.string().optional(),
      city: z.string().optional(),
      category: z.string().optional(),
      contactName: z.string().optional(),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
      website: z.string().optional(),
      minOrderUsd: z.number().optional(),
      leadTimeDays: z.number().optional(),
      certifications: z.array(z.string()).optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db.insert(suppliers).values({
        name: input.name,
        country: input.country ?? "China",
        city: input.city ?? null,
        contactName: input.contactName ?? null,
        contactEmail: input.contactEmail ?? null,
        qualityCerts: input.certifications ? JSON.stringify(input.certifications) : null,
        moq: input.minOrderUsd ? String(input.minOrderUsd) : null,
        leadTimeDays: input.leadTimeDays ?? null,
        notes: input.notes ?? null,
        status: "active",
      });
      return { success: true };
    }),

  /** Upload/attach a document to a factory */
  addFactoryDocument: adminProcedure
    .input(z.object({
      factoryId: z.number(),
      type: z.enum(["business_license", "social_credit_code", "certification", "export_license", "other"]),
      label: z.string().optional(),
      fileUrl: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(factoryDocuments).values({
        factoryId: input.factoryId,
        type: input.type,
        label: input.label ?? null,
        fileUrl: input.fileUrl,
        verifiedStatus: "pending",
      }).$returningId();

      await db.insert(verificationLogs).values({
        factoryId: input.factoryId,
        action: "doc_uploaded",
        notes: `Document type: ${input.type}`,
        createdBy: ctx.user.id,
      });

      return { success: true, documentId: result[0].id };
    }),

  /** Mark a document as verified */
  verifyDocument: adminProcedure
    .input(z.object({
      documentId: z.number(),
      status: z.enum(["verified", "rejected"]),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const doc = await db.select().from(factoryDocuments).where(eq(factoryDocuments.id, input.documentId)).limit(1);
      if (doc.length === 0) throw new Error("Document not found");

      await db.update(factoryDocuments).set({
        verifiedStatus: input.status,
        verifiedAt: new Date(),
        verifiedBy: ctx.user.id,
      }).where(eq(factoryDocuments.id, input.documentId));

      await db.insert(verificationLogs).values({
        factoryId: doc[0].factoryId,
        action: `doc_${input.status}`,
        notes: `Document #${input.documentId} ${input.status}`,
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

  /** Add/remove risk flags */
  addRiskFlag: adminProcedure
    .input(z.object({
      factoryId: z.number(),
      description: z.string().min(5),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(riskFlags).values({
        factoryId: input.factoryId,
        type: "admin_flag",
        description: input.description,
        status: "open",
        createdBy: ctx.user.id,
      });

      await db.insert(verificationLogs).values({
        factoryId: input.factoryId,
        action: "risk_added",
        notes: input.description,
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

  /** Resolve a risk flag */
  resolveRiskFlag: adminProcedure
    .input(z.object({
      flagId: z.number(),
      status: z.enum(["resolved", "dismissed"]),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(riskFlags).set({ status: input.status }).where(eq(riskFlags.id, input.flagId));
      return { success: true };
    }),

  /** Update verification request status */
  updateVerificationRequest: adminProcedure
    .input(z.object({
      requestId: z.number(),
      status: z.enum(["in_progress", "completed", "rejected"]),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(verificationRequests).set({ status: input.status }).where(eq(verificationRequests.id, input.requestId));
      return { success: true };
    }),

  /** List protected order requests */
  listProtectedOrders: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db
      .select({
        order: protectedOrders,
        buyer: { id: users.id, name: users.name, email: users.email },
      })
      .from(protectedOrders)
      .leftJoin(users, eq(protectedOrders.buyerId, users.id))
      .orderBy(desc(protectedOrders.createdAt));
  }),

  /** Update protected order status */
  updateProtectedOrderStatus: adminProcedure
    .input(z.object({
      orderId: z.number(),
      status: z.enum(["reviewed", "approved", "paid", "held", "released", "disputed", "cancelled"]),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(protectedOrders).set({ status: input.status }).where(eq(protectedOrders.id, input.orderId));

      await db.insert(escrowStatuses).values({
        protectedOrderId: input.orderId,
        status: input.status,
        notes: input.notes ?? null,
        updatedBy: ctx.user.id,
      });

      return { success: true };
    }),

  /** Admin can reply to conversations as "admin" sender type */
  sendAdminMessage: adminProcedure
    .input(z.object({
      conversationId: z.number(),
      body: z.string().min(1),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(messages).values({
        conversationId: input.conversationId,
        senderType: "admin",
        senderId: ctx.user.id,
        body: input.body,
      });

      await db.update(conversations).set({ lastMessageAt: new Date() }).where(eq(conversations.id, input.conversationId));

      return { success: true };
    }),

  /** List all factories for admin management */
  listFactories: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    return await db.select({
      id: factories.id,
      name: factories.name,
      verified: factories.verified,
      verificationLevel: factories.verificationLevel,
      trustScore: factories.trustScore,
      country: factories.country,
      city: factories.city,
      createdAt: factories.createdAt,
    }).from(factories).orderBy(desc(factories.createdAt));
  }),

  /** Update factory verified status */
  updateFactoryStatus: adminProcedure
    .input(z.object({
      factoryId: z.number(),
      verified: z.enum(['pending', 'verified', 'rejected']),
      trustScore: z.number().min(0).max(100).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db.update(factories).set({
        verified: input.verified,
        ...(input.trustScore !== undefined ? { trustScore: input.trustScore } : {}),
        lastVerifiedAt: new Date(),
      }).where(eq(factories.id, input.factoryId));
      await db.insert(verificationLogs).values({
        factoryId: input.factoryId,
        action: `factory_${input.verified}`,
        notes: `Admin updated status to ${input.verified}`,
        createdBy: ctx.user.id,
      });
      return { success: true };
    }),

  /** Run AI trust analysis on a factory */
  runTrustAnalysis: adminProcedure
    .input(z.object({
      factoryId: z.number(),
      factoryName: z.string(),
      website: z.string().optional(),
      country: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const { invokeLLM } = await import('./_core/llm');

      const result = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: 'You are a B2B trade verification expert. Analyze factories and return a JSON trust assessment.',
          },
          {
            role: 'user',
            content: `Analyze this factory for B2B trustworthiness:
Name: ${input.factoryName}
Website: ${input.website || 'Not provided'}
Country: ${input.country || 'China'}

Return ONLY valid JSON:
{
  "trustScore": 75,
  "riskLevel": "low|medium|high",
  "flags": ["concern1", "concern2"],
  "positives": ["positive1", "positive2"],
  "recommendation": "Brief recommendation",
  "isLikelyFactory": true
}`,
          },
        ],
      });

      const content = result.choices[0]?.message?.content ?? '{}';
      let analysis: any = { trustScore: 50, riskLevel: 'medium', flags: [], positives: [], recommendation: 'Unable to analyze', isLikelyFactory: true };
      try {
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) analysis = JSON.parse(jsonMatch[0]);
      } catch {}

      // Update factory trust score
      await db.update(factories).set({ trustScore: analysis.trustScore ?? 50 }).where(eq(factories.id, input.factoryId));

      // Log the verification
      await db.insert(verificationLogs).values({
        factoryId: input.factoryId,
        action: 'ai_trust_analysis',
        notes: `AI Score: ${analysis.trustScore}/100 | Risk: ${analysis.riskLevel} | ${analysis.recommendation}`,
        createdBy: ctx.user.id,
      });

      return analysis;
    }),

  /** Dashboard stats */
  getStats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const [
      [factoryCount], [userCount], [pendingRequests], [openRisks],
      [orderCount], [activeOrderCount], [revenueRow], [productCount], [quoteCount],
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(factories),
      db.select({ count: sql<number>`count(*)` }).from(users),
      db.select({ count: sql<number>`count(*)` }).from(verificationRequests).where(eq(verificationRequests.status, "pending")),
      db.select({ count: sql<number>`count(*)` }).from(riskFlags).where(eq(riskFlags.status, "open")),
      db.select({ count: sql<number>`count(*)` }).from(orders),
      db.select({ count: sql<number>`count(*)` }).from(orders).where(sql`status NOT IN ('delivered','cancelled')`),
      db.select({ total: sql<number>`COALESCE(SUM(totalAmount),0)` }).from(orders).where(sql`paymentStatus = 'paid'`),
      db.select({ count: sql<number>`count(*)` }).from(products),
      db.select({ count: sql<number>`count(*)` }).from(productQuoteRequests).where(eq(productQuoteRequests.status, 'pending')),
    ]);

    return {
      factories: Number(factoryCount.count),
      users: Number(userCount.count),
      pendingVerifications: Number(pendingRequests.count),
      openRiskFlags: Number(openRisks.count),
      totalOrders: Number(orderCount.count),
      activeOrders: Number(activeOrderCount.count),
      totalRevenue: Number(revenueRow.total) / 100,
      totalProducts: Number(productCount.count),
      pendingQuotes: Number(quoteCount.count),
    };
  }),
});
