import { COOKIE_NAME } from "@shared/const";
import type { Request, Response } from "express";
import { getSessionCookieOptions } from "../_core/cookies";

export function clearSessionCookie(req: Request, res: Response) {
  const cookieOptions = getSessionCookieOptions(req);
  res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
}
