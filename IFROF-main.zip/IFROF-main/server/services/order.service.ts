import * as db from "../db";
import { sendOrderConfirmation, sendOrderStatusUpdate } from "../email";

export type CreateOrderInput = {
  userId: number;
  userEmail?: string | null;
  userName?: string | null;
  items: Array<{ productId: number; quantity: number; price: number }>;
  shippingAddress: {
    fullName: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
    phone: string;
  };
  shippingMethod: string;
  shippingCost: number;
  totalAmount: number;
  paymentMethod: string;
};

export async function createOrderWithNotifications(input: CreateOrderInput) {
  const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).slice(2, 11).toUpperCase()}`;

  const orderId = await db.createOrder(
    {
      userId: input.userId,
      orderNumber,
      totalAmount: input.totalAmount,
      shippingAddress: JSON.stringify(input.shippingAddress),
      shippingMethod: input.shippingMethod,
      shippingCost: input.shippingCost,
      paymentMethod: input.paymentMethod,
      status: "pending",
      paymentStatus: "pending",
    },
    input.items,
  );

  await db.clearCart(input.userId);

  await db.createNotification({
    userId: input.userId,
    type: "order_created",
    title: "Order Created",
    message: `Your order ${orderNumber} has been created successfully.`,
    link: `/orders/${orderId}`,
  });

  if (input.userEmail) {
    sendOrderConfirmation(input.userEmail, input.userName || "Valued Customer", {
      orderNumber,
      id: orderId,
      totalAmount: input.totalAmount,
      items: input.items.map(i => ({ name: `Product #${i.productId}`, quantity: i.quantity, price: i.price })),
      shippingMethod: input.shippingMethod,
    }).catch(() => {});
  }

  return { orderId, orderNumber };
}

export async function updateOrderStatusWithNotifications(orderId: number, status: string) {
  await db.updateOrderStatus(orderId, status);
  const orderData = await db.getOrderById(orderId);
  if (!orderData) return;

  await db.createNotification({
    userId: orderData.order.userId,
    type: "order_update",
    title: "Order Status Updated",
    message: `Your order ${orderData.order.orderNumber} status has been updated to: ${status}`,
    link: `/orders/${orderId}`,
  });

  const orderUser = await db.getUserById(orderData.order.userId);
  if (orderUser?.email) {
    sendOrderStatusUpdate(orderUser.email, orderUser.name || "Valued Customer", {
      orderNumber: orderData.order.orderNumber,
      id: orderId,
      status,
    }).catch(() => {});
  }
}
