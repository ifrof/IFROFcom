/**
 * StorageService - AWS S3 & Cloudflare CDN Integration
 * Handles file uploads, CDN distribution, and image optimization
 */

import { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
// @ts-ignore - sharp is a native module not always available
import sharp from 'sharp';

import { ENV } from '../_core/env';

const s3Client = new S3Client({
  region: ENV.aws.region,
  credentials: {
    accessKeyId: ENV.aws.accessKeyId,
    secretAccessKey: ENV.aws.secretAccessKey,
  },
});

const BUCKET_NAME = ENV.aws.bucketName;
const CDN_URL = ENV.aws.cdnUrl;

export interface UploadOptions {
  folder: 'products' | 'factories' | 'inspections' | 'avatars';
  filename: string;
  mimeType: string;
  buffer: Buffer;
  optimize?: boolean;
}

export interface UploadResult {
  url: string;
  cdnUrl: string;
  key: string;
  size: number;
}

export class StorageService {
  /**
   * Upload file to S3 with optional image optimization
   */
  async uploadFile(options: UploadOptions): Promise<UploadResult> {
    try {
      let buffer = options.buffer;

      // Optimize images
      if (options.optimize && options.mimeType.startsWith('image/')) {
        buffer = await this.optimizeImage(buffer, options.mimeType);
      }

      const key = `${options.folder}/${Date.now()}-${options.filename}`;

      const command = new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
        Body: buffer,
        ContentType: options.mimeType,
        CacheControl: 'max-age=31536000', // 1 year for versioned assets
        Metadata: {
          'uploaded-at': new Date().toISOString(),
        },
      });

      await s3Client.send(command);

      const s3Url = `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;
      const cdnUrl = `${CDN_URL}/${key}`;

      return {
        url: s3Url,
        cdnUrl,
        key,
        size: buffer.length,
      };
    } catch (error) {
      console.error('Upload failed:', error);
      throw new Error('Failed to upload file to S3');
    }
  }

  /**
   * Upload product images with multiple sizes for responsive design
   */
  async uploadProductImages(
    buffer: Buffer,
    productId: number,
    mimeType: string
  ): Promise<{ original: UploadResult; thumbnail: UploadResult; medium: UploadResult }> {
    try {
      // Original
      const original = await this.uploadFile({
        folder: 'products',
        filename: `product-${productId}-original.jpg`,
        mimeType: 'image/jpeg',
        buffer,
        optimize: true,
      });

      // Thumbnail (200x200)
      const thumbnailBuffer = await sharp(buffer)
        .resize(200, 200, { fit: 'cover' })
        .jpeg({ quality: 80 })
        .toBuffer();

      const thumbnail = await this.uploadFile({
        folder: 'products',
        filename: `product-${productId}-thumb.jpg`,
        mimeType: 'image/jpeg',
        buffer: thumbnailBuffer,
      });

      // Medium (600x600)
      const mediumBuffer = await sharp(buffer)
        .resize(600, 600, { fit: 'cover' })
        .jpeg({ quality: 85 })
        .toBuffer();

      const medium = await this.uploadFile({
        folder: 'products',
        filename: `product-${productId}-medium.jpg`,
        mimeType: 'image/jpeg',
        buffer: mediumBuffer,
      });

      return { original, thumbnail, medium };
    } catch (error) {
      console.error('Product image upload failed:', error);
      throw error;
    }
  }

  /**
   * Optimize image for web
   */
  private async optimizeImage(buffer: Buffer, mimeType: string): Promise<Buffer> {
    try {
      let pipeline = sharp(buffer);

      if (mimeType === 'image/jpeg') {
        return await pipeline.jpeg({ quality: 85, progressive: true }).toBuffer();
      } else if (mimeType === 'image/png') {
        return await pipeline.png({ compressionLevel: 9 }).toBuffer();
      } else if (mimeType === 'image/webp') {
        return await pipeline.webp({ quality: 85 }).toBuffer();
      }

      return buffer;
    } catch (error) {
      console.error('Image optimization failed:', error);
      return buffer; // Return original if optimization fails
    }
  }

  /**
   * Delete file from S3
   */
  async deleteFile(key: string): Promise<void> {
    try {
      const command = new DeleteObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
      });

      await s3Client.send(command);
    } catch (error) {
      console.error('Delete failed:', error);
      throw new Error('Failed to delete file from S3');
    }
  }

  /**
   * Generate signed URL for private file access
   */
  async getSignedDownloadUrl(key: string, expiresIn = 3600): Promise<string> {
    try {
      const command = new GetObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
      });

      return await getSignedUrl(s3Client, command, { expiresIn });
    } catch (error) {
      console.error('Failed to generate signed URL:', error);
      throw error;
    }
  }

  /**
   * Get public CDN URL
   */
  getCdnUrl(key: string): string {
    return `${CDN_URL}/${key}`;
  }

  /**
   * Get S3 URL
   */
  getS3Url(key: string): string {
    return `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;
  }
}

export const storageService = new StorageService();
