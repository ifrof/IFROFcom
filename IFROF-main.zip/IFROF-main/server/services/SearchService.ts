/**
 * SearchService - Meilisearch Integration
 * Handles all product search, filtering, and indexing operations
 */

import { ENV } from '../_core/env';
type SearchResponse = {
  hits: unknown[];
  nbHits: number;
};

type SearchIndex = {
  updateSearchableAttributes(attributes: string[]): Promise<unknown>;
  updateFilterableAttributes(attributes: string[]): Promise<unknown>;
  updateSortableAttributes(attributes: string[]): Promise<unknown>;
  updateRankingRules(rules: string[]): Promise<unknown>;
  addDocuments(documents: unknown[], options: { primaryKey: string }): Promise<unknown>;
  search(
    query: string,
    options?: {
      filter?: string[];
      sort?: string[];
      limit?: number;
      offset?: number;
      attributesToHighlight?: string[];
    }
  ): Promise<SearchResponse>;
  getStats(): Promise<unknown>;
  deleteDocument(productId: number): Promise<unknown>;
  deleteAllDocuments(): Promise<unknown>;
};

type SearchClient = {
  index(indexName: string): SearchIndex;
};

const emptyResponse: SearchResponse = { hits: [], nbHits: 0 };

function getFallbackClient(): SearchClient {
  const fallbackIndex: SearchIndex = {
    updateSearchableAttributes: async () => undefined,
    updateFilterableAttributes: async () => undefined,
    updateSortableAttributes: async () => undefined,
    updateRankingRules: async () => undefined,
    addDocuments: async () => undefined,
    search: async () => emptyResponse,
    getStats: async () => ({ isPlaceholder: true }),
    deleteDocument: async () => undefined,
    deleteAllDocuments: async () => undefined,
  };

  return {
    index: () => fallbackIndex,
  };
}

async function createSearchClient(): Promise<SearchClient> {
  try {
    const moduleName = 'meilisearch';
    const meiliModule = await import(moduleName);
    const MeiliSearch = meiliModule.MeiliSearch;

    return new MeiliSearch({
      host: ENV.meilisearch.host,
      apiKey: ENV.meilisearch.apiKey || 'masterKey',
    }) as SearchClient;
  } catch (error) {
    console.warn('Meilisearch client unavailable, SearchService is running in fallback mode.');
    console.warn(error);
    return getFallbackClient();
  }
}

export interface SearchableProduct {
  id: number;
  name: string;
  description: string;
  category: string;
  price: number;
  rating: number;
  stock: number;
  supplier: string;
  country: string;
  certifications: string[];
  tags: string[];
}

export class SearchService {
  private indexName = 'products';
  private clientPromise: Promise<SearchClient>;

  constructor() {
    this.clientPromise = createSearchClient();
  }

  private async getIndex() {
    const client = await this.clientPromise;
    return client.index(this.indexName);
  }

  /**
   * Initialize Meilisearch index with settings
   */
  async initializeIndex() {
    try {
      const index = await this.getIndex();
      
      // Configure searchable attributes
      await index.updateSearchableAttributes([
        'name',
        'description',
        'category',
        'supplier',
        'country',
        'tags',
      ]);

      // Configure filterable attributes
      await index.updateFilterableAttributes([
        'category',
        'price',
        'rating',
        'stock',
        'country',
        'certifications',
      ]);

      // Configure sortable attributes
      await index.updateSortableAttributes([
        'price',
        'rating',
        'stock',
        'createdAt',
      ]);

      // Configure ranking rules
      await index.updateRankingRules([
        'sort',
        'words',
        'typo',
        'proximity',
        'attribute',
        'exactness',
        'rating:desc',
      ]);

      console.log('✓ Meilisearch index initialized');
    } catch (error) {
      console.error('Failed to initialize Meilisearch index:', error);
    }
  }

  /**
   * Index a single product
   */
  async indexProduct(product: SearchableProduct) {
    try {
      const index = await this.getIndex();
      await index.addDocuments([product], { primaryKey: 'id' });
    } catch (error) {
      console.error('Failed to index product:', error);
    }
  }

  /**
   * Index multiple products in batch
   */
  async indexProducts(products: SearchableProduct[]) {
    try {
      const index = await this.getIndex();
      await index.addDocuments(products, { primaryKey: 'id' });
      console.log(`✓ Indexed ${products.length} products`);
    } catch (error) {
      console.error('Failed to batch index products:', error);
    }
  }

  /**
   * Search products with full-text search
   */
  async search(query: string, limit = 20, offset = 0) {
    try {
      const index = await this.getIndex();
      const results = await index.search(query, {
        limit,
        offset,
        attributesToHighlight: ['name', 'description'],
      });
      return results;
    } catch (error) {
      console.error('Search failed:', error);
      return emptyResponse;
    }
  }

  /**
   * Advanced filtering with Meilisearch filter syntax
   */
  async filter(options: {
    minPrice?: number;
    maxPrice?: number;
    categories?: string[];
    minRating?: number;
    inStock?: boolean;
    countries?: string[];
    certifications?: string[];
    sortBy?: 'price_asc' | 'price_desc' | 'rating' | 'newest';
    limit?: number;
    offset?: number;
  }) {
    try {
      const index = await this.getIndex();
      const filters: string[] = [];

      if (options.minPrice !== undefined) {
        filters.push(`price >= ${options.minPrice}`);
      }
      if (options.maxPrice !== undefined) {
        filters.push(`price <= ${options.maxPrice}`);
      }
      if (options.categories && options.categories.length > 0) {
        const cats = options.categories.map(c => `'${c}'`).join(',');
        filters.push(`category IN [${cats}]`);
      }
      if (options.minRating !== undefined) {
        filters.push(`rating >= ${options.minRating}`);
      }
      if (options.inStock) {
        filters.push('stock > 0');
      }
      if (options.countries && options.countries.length > 0) {
        const countries = options.countries.map(c => `'${c}'`).join(',');
        filters.push(`country IN [${countries}]`);
      }

      const sortMap = {
        price_asc: 'price:asc',
        price_desc: 'price:desc',
        rating: 'rating:desc',
        newest: 'createdAt:desc',
      };

      const results = await index.search('', {
        filter: filters.length > 0 ? filters : undefined,
        sort: options.sortBy ? [sortMap[options.sortBy]] : undefined,
        limit: options.limit || 20,
        offset: options.offset || 0,
      });

      return results;
    } catch (error) {
      console.error('Filter failed:', error);
      return emptyResponse;
    }
  }

  /**
   * Get facets for filtering UI
   */
  async getFacets() {
    try {
      const index = await this.getIndex();
      const stats = await index.getStats();
      return stats;
    } catch (error) {
      console.error('Failed to get facets:', error);
      return null;
    }
  }

  /**
   * Delete a product from index
   */
  async deleteProduct(productId: number) {
    try {
      const index = await this.getIndex();
      await index.deleteDocument(productId);
    } catch (error) {
      console.error('Failed to delete product:', error);
    }
  }

  /**
   * Clear entire index
   */
  async clearIndex() {
    try {
      const index = await this.getIndex();
      await index.deleteAllDocuments();
      console.log('✓ Index cleared');
    } catch (error) {
      console.error('Failed to clear index:', error);
    }
  }
}

export const searchService = new SearchService();
