/**
 * Rate Limiting Middleware with Redis Support
 * Redis store is applied lazily after connection is confirmed ready.
 */

import rateLimit, { type Options, type Store } from "express-rate-limit";
import RedisStore from "rate-limit-redis";
import Redis from "ioredis";
import { ENV } from "./_core/env";

// ─── Redis setup ─────────────────────────────────────────────────────────────
let redisStore: Store | undefined;

export async function initRateLimitRedis(): Promise<void> {
  if (!ENV.redisUrl) {
    console.log("[RateLimit] REDIS_URL not set — using in-process memory store");
    return;
  }
  const client = new Redis(ENV.redisUrl, {
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
    lazyConnect: true,
  });

  client.on("error", (err) =>
    console.error("[RateLimit] Redis error:", err.message)
  );

  await client.connect();
  await client.ping(); // confirm it is truly ready

  redisStore = new RedisStore({
    sendCommand: (...args: string[]) =>
      client.call(args[0], ...args.slice(1)) as any,
    prefix: "rl:",
  });
  console.log("[RateLimit] Redis store ready — distributed rate limiting active");

  process.on("SIGTERM", () => client.quit());
  process.on("SIGINT", () => client.quit());
}

// ─── Factory ──────────────────────────────────────────────────────────────────
function make(opts: Partial<Options>) {
  return rateLimit({
    standardHeaders: true,
    legacyHeaders: false,
    // store is resolved at request time — by then Redis is ready
    get store() {
      return redisStore;
    },
    ...opts,
  });
}

// ─── Limiters ─────────────────────────────────────────────────────────────────
/** 100 req / min / IP — general */
export const globalRateLimiter = make({
  windowMs: 60_000,
  max: 100,
  message: "Too many requests, please try again later.",
});

/** 5 req / min / IP — login / register / forgot-password */
export const authRateLimiter = make({
  windowMs: 60_000,
  max: 5,
  message: "Too many authentication attempts, please try again later.",
  skipSuccessfulRequests: true,
});

/** 300 req / min / IP — general API */
export const apiRateLimiter = make({
  windowMs: 60_000,
  max: 300,
  message: "API rate limit exceeded, please slow down.",
});

/** 20 req / min / IP — factory / AI search */
export const searchRateLimiter = make({
  windowMs: 60_000,
  max: 20,
  message: "Too many search requests, please try again later.",
});

/** 10 req / min / IP — Stripe checkout / payment intent */
export const paymentRateLimiter = make({
  windowMs: 60_000,
  max: 10,
  message: "Too many payment requests, please try again later.",
});

/** 10 req / min / IP — file uploads */
export const uploadRateLimiter = make({
  windowMs: 60_000,
  max: 10,
  message: "Too many file uploads, please try again later.",
});
