/**
 * Group Container Shipping Router
 * Allows multiple importers to share a container from China to reduce shipping costs.
 * 
 * Business logic:
 * - Admin creates group shipments with capacity (CBM), price per CBM, cutoff date
 * - Any user can browse open shipments and request to join
 * - CBM is stored as integer tenths (e.g., 15 = 1.5 CBM) for precision
 * - Booking reference is auto-generated on join
 * - Admin confirms/cancels participants
 */

import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { drizzle } from "drizzle-orm/mysql2";
import { eq, and, desc, sql } from "drizzle-orm";
import { ENV } from "./_core/env";
import {
  groupShipments,
  groupShipmentParticipants,
  groupShipmentUpdates,
} from "../drizzle/schema";
import mysql from "mysql2/promise";

function getDb() {
  const dbUrl = ENV.databaseUrl;
  if (!dbUrl) throw new Error("DATABASE_URL not set");
  const pool = mysql.createPool(dbUrl);
  return drizzle(pool);
}

function generateBookingRef(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let ref = "GS-";
  for (let i = 0; i < 8; i++) ref += chars[Math.floor(Math.random() * chars.length)];
  return ref;
}

export const groupShippingRouter = router({
  // ── PUBLIC: List open/filling shipments ──────────────────────────────────
  listShipments: publicProcedure
    .input(
      z.object({
        destinationCountry: z.string().optional(),
        status: z.enum(["open", "filling", "full", "departed", "arrived", "closed"]).optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      let query = db
        .select()
        .from(groupShipments)
        .orderBy(desc(groupShipments.estimatedDeparture))
        .limit(input?.limit ?? 20)
        .offset(input?.offset ?? 0);

      const rows = await query;

      // Filter in JS for simplicity (small dataset)
      let filtered = rows;
      if (input?.destinationCountry) {
        filtered = filtered.filter(
          (r) => r.destinationCountry.toLowerCase() === input.destinationCountry!.toLowerCase()
        );
      }
      if (input?.status) {
        filtered = filtered.filter((r) => r.status === input.status);
      }

      return filtered.map((s) => ({
        ...s,
        availableCbm: s.totalCbm - s.usedCbm,
        fillPercent: Math.round((s.usedCbm / s.totalCbm) * 100),
        pricePerCbmUsd: (s.pricePerCbm / 100).toFixed(0),
        minCbm: ((s.minCbmPerParticipant ?? 10) / 10).toFixed(1),
        maxCbm: ((s.maxCbmPerParticipant ?? 200) / 10).toFixed(1),
        includedServicesList: (() => {
          try { return JSON.parse(s.includedServices ?? "[]"); } catch { return []; }
        })(),
      }));
    }),

  // ── PUBLIC: Get single shipment detail ───────────────────────────────────
  getShipment: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [shipment] = await db
        .select()
        .from(groupShipments)
        .where(eq(groupShipments.id, input.id))
        .limit(1);

      if (!shipment) throw new TRPCError({ code: "NOT_FOUND", message: "Shipment not found" });

      // Get updates for this shipment
      const updates = await db
        .select()
        .from(groupShipmentUpdates)
        .where(eq(groupShipmentUpdates.shipmentId, input.id))
        .orderBy(desc(groupShipmentUpdates.createdAt));

      return {
        ...shipment,
        availableCbm: shipment.totalCbm - shipment.usedCbm,
        fillPercent: Math.round((shipment.usedCbm / shipment.totalCbm) * 100),
        pricePerCbmUsd: (shipment.pricePerCbm / 100).toFixed(0),
        minCbm: ((shipment.minCbmPerParticipant ?? 10) / 10).toFixed(1),
        maxCbm: ((shipment.maxCbmPerParticipant ?? 200) / 10).toFixed(1),
        includedServicesList: (() => {
          try { return JSON.parse(shipment.includedServices ?? "[]"); } catch { return []; }
        })(),
        updates,
      };
    }),

  // ── PUBLIC: Get updates for a shipment ───────────────────────────────────
  getShipmentUpdates: publicProcedure
    .input(z.object({ shipmentId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return await db
        .select()
        .from(groupShipmentUpdates)
        .where(eq(groupShipmentUpdates.shipmentId, input.shipmentId))
        .orderBy(desc(groupShipmentUpdates.createdAt));
    }),

  // ── PROTECTED: Join a group shipment ─────────────────────────────────────
  joinShipment: protectedProcedure
    .input(
      z.object({
        shipmentId: z.number(),
        cbmNeeded: z.number().min(0.1).max(30), // CBM as decimal (e.g. 1.5)
        productDescription: z.string().min(5).max(500),
        productCategory: z.string().optional(),
        estimatedWeightKg: z.number().optional(),
        specialRequirements: z.string().optional(),
        contactName: z.string().min(2),
        contactEmail: z.string().email(),
        contactPhone: z.string().optional(),
        companyName: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Load shipment
      const [shipment] = await db
        .select()
        .from(groupShipments)
        .where(eq(groupShipments.id, input.shipmentId))
        .limit(1);

      if (!shipment) throw new TRPCError({ code: "NOT_FOUND", message: "Shipment not found" });
      if (shipment.status === "full" || shipment.status === "departed" || shipment.status === "arrived" || shipment.status === "closed") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This shipment is no longer accepting bookings" });
      }
      if (new Date() > new Date(shipment.cutoffDate)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "The booking cutoff date has passed" });
      }

      // Convert CBM to tenths integer
      const cbmTenths = Math.round(input.cbmNeeded * 10);
      const minCbm = shipment.minCbmPerParticipant ?? 10;
      const maxCbm = shipment.maxCbmPerParticipant ?? 200;

      if (cbmTenths < minCbm) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Minimum booking is ${(minCbm / 10).toFixed(1)} CBM`,
        });
      }
      if (cbmTenths > maxCbm) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Maximum booking is ${(maxCbm / 10).toFixed(1)} CBM per participant`,
        });
      }

      const availableCbm = shipment.totalCbm - shipment.usedCbm;
      if (cbmTenths > availableCbm) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Only ${(availableCbm / 10).toFixed(1)} CBM remaining`,
        });
      }

      // Check if user already joined this shipment
      const [existing] = await db
        .select()
        .from(groupShipmentParticipants)
        .where(
          and(
            eq(groupShipmentParticipants.shipmentId, input.shipmentId),
            eq(groupShipmentParticipants.userId, ctx.user.id),
            sql`${groupShipmentParticipants.status} != 'cancelled'`
          )
        )
        .limit(1);

      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "You already have an active booking in this shipment",
        });
      }

      // Calculate total price (pricePerCbm is in USD cents per CBM-tenth)
      const totalPriceUsd = Math.round((cbmTenths * shipment.pricePerCbm) / 10);
      const bookingRef = generateBookingRef();

      // Insert participant
      await db.insert(groupShipmentParticipants).values({
        shipmentId: input.shipmentId,
        userId: ctx.user.id,
        cbmBooked: cbmTenths,
        productDescription: input.productDescription,
        productCategory: input.productCategory ?? null,
        estimatedWeight: input.estimatedWeightKg ?? null,
        specialRequirements: input.specialRequirements ?? null,
        totalPriceUsd,
        paymentStatus: "pending",
        bookingReference: bookingRef,
        status: "pending",
        contactName: input.contactName,
        contactEmail: input.contactEmail,
        contactPhone: input.contactPhone ?? null,
        companyName: input.companyName ?? null,
        notes: input.notes ?? null,
      });

      // Update shipment usedCbm and participantsCount
      const newUsedCbm = shipment.usedCbm + cbmTenths;
      const newStatus =
        newUsedCbm >= shipment.totalCbm
          ? "full"
          : newUsedCbm >= shipment.totalCbm * 0.5
          ? "filling"
          : "open";

      await db
        .update(groupShipments)
        .set({
          usedCbm: newUsedCbm,
          participantsCount: shipment.participantsCount + 1,
          status: newStatus,
        })
        .where(eq(groupShipments.id, input.shipmentId));

      return {
        success: true,
        bookingReference: bookingRef,
        cbmBooked: input.cbmNeeded,
        totalPriceUsd: (totalPriceUsd / 100).toFixed(2),
        message: `Booking confirmed! Reference: ${bookingRef}. Our team will contact you within 24 hours.`,
      };
    }),

  // ── PROTECTED: Get my bookings ────────────────────────────────────────────
  myBookings: protectedProcedure.query(async ({ ctx }) => {
    const db = getDb();
    const participants = await db
      .select()
      .from(groupShipmentParticipants)
      .where(eq(groupShipmentParticipants.userId, ctx.user.id))
      .orderBy(desc(groupShipmentParticipants.createdAt));

    // Enrich with shipment info
    const enriched = await Promise.all(
      participants.map(async (p) => {
        const [shipment] = await db
          .select()
          .from(groupShipments)
          .where(eq(groupShipments.id, p.shipmentId))
          .limit(1);
        return {
          ...p,
          cbmBookedDisplay: (p.cbmBooked / 10).toFixed(1),
          totalPriceDisplay: (p.totalPriceUsd / 100).toFixed(2),
          shipment: shipment ?? null,
        };
      })
    );

    return enriched;
  }),

  // ── PROTECTED: Cancel my booking ─────────────────────────────────────────
  cancelBooking: protectedProcedure
    .input(z.object({ participantId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const [participant] = await db
        .select()
        .from(groupShipmentParticipants)
        .where(
          and(
            eq(groupShipmentParticipants.id, input.participantId),
            eq(groupShipmentParticipants.userId, ctx.user.id)
          )
        )
        .limit(1);

      if (!participant) throw new TRPCError({ code: "NOT_FOUND", message: "Booking not found" });
      if (participant.status === "cancelled") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Booking already cancelled" });
      }
      if (participant.paymentStatus === "paid") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Cannot cancel a paid booking. Please contact support.",
        });
      }

      await db
        .update(groupShipmentParticipants)
        .set({ status: "cancelled" })
        .where(eq(groupShipmentParticipants.id, input.participantId));

      // Free up the CBM
      const [shipment] = await db
        .select()
        .from(groupShipments)
        .where(eq(groupShipments.id, participant.shipmentId))
        .limit(1);

      if (shipment) {
        const newUsedCbm = Math.max(0, shipment.usedCbm - participant.cbmBooked);
        const newParticipants = Math.max(0, shipment.participantsCount - 1);
        const newStatus =
          newUsedCbm >= shipment.totalCbm ? "full" : newUsedCbm >= shipment.totalCbm * 0.5 ? "filling" : "open";

        await db
          .update(groupShipments)
          .set({ usedCbm: newUsedCbm, participantsCount: newParticipants, status: newStatus })
          .where(eq(groupShipments.id, participant.shipmentId));
      }

      return { success: true, message: "Booking cancelled successfully" };
    }),

  // ── ADMIN: Create a new group shipment ───────────────────────────────────
  adminCreateShipment: protectedProcedure
    .input(
      z.object({
        title: z.string().min(5),
        description: z.string().optional(),
        originCity: z.string().default("Guangzhou"),
        originCountry: z.string().default("China"),
        destinationCity: z.string().min(2),
        destinationCountry: z.string().min(2),
        destinationPort: z.string().optional(),
        containerType: z.enum(["20ft", "40ft", "40hc", "lcl"]).default("40ft"),
        totalCbm: z.number().min(5).max(100), // total CBM capacity
        pricePerCbmUsd: z.number().min(10).max(500), // price per CBM in USD
        minCbmPerParticipant: z.number().default(1),
        maxCbmPerParticipant: z.number().default(20),
        cutoffDate: z.string(), // ISO date string
        estimatedDeparture: z.string(),
        estimatedArrival: z.string(),
        shippingLine: z.string().optional(),
        includedServices: z.array(z.string()).optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }

      const db = getDb();

      await db.insert(groupShipments).values({
        organizerId: ctx.user.id,
        title: input.title,
        description: input.description ?? null,
        originCity: input.originCity,
        originCountry: input.originCountry,
        destinationCity: input.destinationCity,
        destinationCountry: input.destinationCountry,
        destinationPort: input.destinationPort ?? null,
        containerType: input.containerType,
        totalCbm: Math.round(input.totalCbm * 10), // store as tenths
        usedCbm: 0,
        pricePerCbm: Math.round(input.pricePerCbmUsd * 100), // store in cents
        minCbmPerParticipant: Math.round(input.minCbmPerParticipant * 10),
        maxCbmPerParticipant: Math.round(input.maxCbmPerParticipant * 10),
        cutoffDate: new Date(input.cutoffDate),
        estimatedDeparture: new Date(input.estimatedDeparture),
        estimatedArrival: new Date(input.estimatedArrival),
        shippingLine: input.shippingLine ?? null,
        status: "open",
        includedServices: JSON.stringify(input.includedServices ?? []),
        notes: input.notes ?? null,
        participantsCount: 0,
      });

      return { success: true, message: "Group shipment created successfully" };
    }),

  // ── ADMIN: List all participants for a shipment ───────────────────────────
  adminListParticipants: protectedProcedure
    .input(z.object({ shipmentId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      const db = getDb();
      return await db
        .select()
        .from(groupShipmentParticipants)
        .where(eq(groupShipmentParticipants.shipmentId, input.shipmentId))
        .orderBy(desc(groupShipmentParticipants.createdAt));
    }),

  // ── ADMIN: Confirm a participant ──────────────────────────────────────────
  adminConfirmParticipant: protectedProcedure
    .input(z.object({ participantId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      const db = getDb();
      await db
        .update(groupShipmentParticipants)
        .set({ status: "confirmed", paymentStatus: "paid" })
        .where(eq(groupShipmentParticipants.id, input.participantId));
      return { success: true };
    }),

  // ── ADMIN: Post a shipment update ─────────────────────────────────────────
  adminPostUpdate: protectedProcedure
    .input(
      z.object({
        shipmentId: z.number(),
        title: z.string().min(3),
        content: z.string().min(10),
        updateType: z.enum(["info", "milestone", "alert", "arrival"]).default("info"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      const db = getDb();
      await db.insert(groupShipmentUpdates).values({
        shipmentId: input.shipmentId,
        authorId: ctx.user.id,
        title: input.title,
        content: input.content,
        updateType: input.updateType,
      });
      return { success: true };
    }),

  // ── ADMIN: Update shipment status ─────────────────────────────────────────
  adminUpdateShipmentStatus: protectedProcedure
    .input(
      z.object({
        shipmentId: z.number(),
        status: z.enum(["open", "filling", "full", "departed", "arrived", "closed"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      const db = getDb();
      await db
        .update(groupShipments)
        .set({ status: input.status })
        .where(eq(groupShipments.id, input.shipmentId));
      return { success: true };
    }),

  // ── PUBLIC: Get stats for the landing page ────────────────────────────────
  getStats: publicProcedure.query(async () => {
    const db = getDb();
    const shipments = await db.select().from(groupShipments);
    const totalShipments = shipments.length;
    const activeShipments = shipments.filter((s) => s.status === "open" || s.status === "filling").length;
    const completedShipments = shipments.filter((s) => s.status === "arrived" || s.status === "closed").length;
    const totalParticipants = shipments.reduce((sum, s) => sum + s.participantsCount, 0);

    return {
      totalShipments,
      activeShipments,
      completedShipments,
      totalParticipants,
      avgSavingsPercent: 65, // Static marketing figure
    };
  }),
});
