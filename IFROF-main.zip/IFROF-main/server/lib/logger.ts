/**
 * Structured logger for IFROF
 * Outputs JSON in production (easy to ingest into any log aggregator)
 * Outputs coloured human-readable lines in development
 */

import { ENV } from "../_core/env";

type Level = "debug" | "info" | "warn" | "error";

const LEVELS: Record<Level, number> = { debug: 0, info: 1, warn: 2, error: 3 };

// Minimum level: debug in dev, info in prod
const MIN_LEVEL: number = ENV.isProduction ? LEVELS.info : LEVELS.debug;

const COLOURS: Record<Level, string> = {
  debug: "\x1b[36m", // cyan
  info:  "\x1b[32m", // green
  warn:  "\x1b[33m", // yellow
  error: "\x1b[31m", // red
};
const RESET = "\x1b[0m";

function log(level: Level, msg: string, meta?: Record<string, unknown>) {
  if (LEVELS[level] < MIN_LEVEL) return;

  const ts = new Date().toISOString();

  if (ENV.isProduction) {
    // Structured JSON — pipe to your log aggregator
    const entry: Record<string, unknown> = { ts, level, msg, ...meta };
    (level === "error" ? process.stderr : process.stdout).write(
      JSON.stringify(entry) + "\n"
    );
  } else {
    const colour = COLOURS[level];
    const metaStr = meta ? " " + JSON.stringify(meta) : "";
    const out = `${colour}[${level.toUpperCase()}]${RESET} ${ts} ${msg}${metaStr}`;
    level === "error" ? console.error(out) : console.log(out);
  }
}

export const logger = {
  debug: (msg: string, meta?: Record<string, unknown>) => log("debug", msg, meta),
  info:  (msg: string, meta?: Record<string, unknown>) => log("info",  msg, meta),
  warn:  (msg: string, meta?: Record<string, unknown>) => log("warn",  msg, meta),
  error: (msg: string, meta?: Record<string, unknown>) => log("error", msg, meta),

  /** Attach a persistent namespace prefix, e.g. logger.child("Auth") */
  child: (ns: string) => ({
    debug: (msg: string, meta?: Record<string, unknown>) => log("debug", `[${ns}] ${msg}`, meta),
    info:  (msg: string, meta?: Record<string, unknown>) => log("info",  `[${ns}] ${msg}`, meta),
    warn:  (msg: string, meta?: Record<string, unknown>) => log("warn",  `[${ns}] ${msg}`, meta),
    error: (msg: string, meta?: Record<string, unknown>) => log("error", `[${ns}] ${msg}`, meta),
  }),
};
