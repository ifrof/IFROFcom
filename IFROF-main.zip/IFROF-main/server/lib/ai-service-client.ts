/**
 * AI Microservice Client
 * HTTP client for calling the Python FastAPI AI service
 * All request and response schemas are aligned with the Python FastAPI routes
 */

import { ENV } from '../_core/env';

const AI_SERVICE_URL = ENV.aiServiceUrl || 'http://localhost:8000';

interface AIServiceResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

/**
 * Call the AI service with error handling and timeout
 */
async function callAIService<T = any>(
  endpoint: string,
  payload: Record<string, any>,
  options: { timeout?: number; retries?: number } = {}
): Promise<AIServiceResponse<T>> {
  const { timeout = 30000, retries = 1 } = options;

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(`${AI_SERVICE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'IFROF-Node-Client/1.0',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.error || errorData.message || `HTTP ${response.status}`
        );
      }

      const data = await response.json();
      return {
        success: true,
        data,
      };
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      if (attempt < retries) {
        // Exponential backoff before retry
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 1000)
        );
      }
    }
  }

  return {
    success: false,
    error: lastError?.message || 'Unknown error calling AI service',
  };
}

/**
 * Generate a customer support reply
 * Request: { customer_message: string, context?: object }
 * Response: { reply: string }
 */
export async function generateSupportReply(
  customerMessage: string,
  context?: Record<string, any>
): Promise<AIServiceResponse<{ reply: string }>> {
  return callAIService('/support/reply', {
    customer_message: customerMessage,
    context: context || {},
  });
}

/**
 * Generate blog content
 * Request: { topic: string, keywords?: string[] }
 * Response: { title: string, content: string, seoTags: string[] }
 */
export async function generateBlogContent(
  topic: string,
  keywords?: string[]
): Promise<AIServiceResponse<{ title: string; content: string; seoTags: string[] }>> {
  return callAIService('/content/blog/generate', {
    topic,
    keywords: keywords || [],
  });
}

/**
 * Summarize trade news
 * Request: { news_url: string, industry?: string }
 * Response: { summary: string, keyPoints: string[], sentiment: string }
 */
export async function summarizeTradeNews(
  newsUrl: string,
  industry?: string
): Promise<AIServiceResponse<{ summary: string; keyPoints: string[]; sentiment: string }>> {
  return callAIService('/trade-news/summarize', {
    news_url: newsUrl,
    industry: industry || '',
  });
}

/**
 * Run the complete product decision flow
 * Request: { query: string, preferences?: object }
 * Response: { productName, supplier, price, profitEstimate, confidence, reasons, risks, description }
 */
export async function runProductDecisionFlow(
  query: string,
  preferences?: Record<string, any>
): Promise<
  AIServiceResponse<{
    productName: string;
    supplier: string;
    price: number;
    profitEstimate: number;
    confidence: number;
    reasons: string[];
    risks: string[];
    description: string;
  }>
> {
  return callAIService('/product-decision/run', {
    query,
    preferences: preferences || {},
  });
}

/**
 * Draft an outreach email
 * Request: { target_name: string, target_company: string, purpose: string, tone?: string }
 * Response: { subject: string, body: string }
 */
export async function draftOutreachEmail(
  targetName: string,
  targetCompany: string,
  purpose: string,
  tone?: 'professional' | 'friendly' | 'formal'
): Promise<AIServiceResponse<{ subject: string; body: string }>> {
  return callAIService('/outreach/draft', {
    target_name: targetName,
    target_company: targetCompany,
    purpose,
    tone: tone || 'professional',
  });
}

/**
 * Health check for the AI service
 */
export async function healthCheckAIService(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const response = await fetch(`${AI_SERVICE_URL}/health`, {
      method: 'GET',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    return response.ok;
  } catch {
    return false;
  }
}

export default {
  generateSupportReply,
  generateBlogContent,
  summarizeTradeNews,
  runProductDecisionFlow,
  draftOutreachEmail,
  healthCheckAIService,
  callAIService,
};
