import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as schema from "../drizzle/schema";
import * as db from "./db";

// ============ DB HELPERS ============

async function createServiceInquiry(data: schema.InsertServiceInquiry) {
  const dbConn = await db.getDb();
  if (!dbConn) throw new Error('Database not available');
  const result = await dbConn.insert(schema.serviceInquiries).values(data);
  return result;
}

async function listServiceInquiries(filters?: { serviceType?: string; status?: string; limit?: number; offset?: number }) {
  const dbConn = await db.getDb();
  if (!dbConn) throw new Error('Database not available');
  const rows = await dbConn.select().from(schema.serviceInquiries).limit(filters?.limit ?? 50).offset(filters?.offset ?? 0);
  if (filters?.serviceType) return rows.filter(r => r.serviceType === filters.serviceType);
  if (filters?.status) return rows.filter(r => r.status === filters.status);
  return rows;
}

async function updateServiceInquiryStatus(id: number, status: schema.ServiceInquiry["status"], notes?: string, assignedTo?: string) {
  const dbConn = await db.getDb();
  if (!dbConn) throw new Error('Database not available');
  const updateData: Partial<schema.ServiceInquiry> = { status };
  if (notes !== undefined) updateData.notes = notes;
  if (assignedTo !== undefined) updateData.assignedTo = assignedTo;
  await dbConn.update(schema.serviceInquiries).set(updateData).where(
    (await import("drizzle-orm")).eq(schema.serviceInquiries.id, id)
  );
}

// ============ ROUTER ============

export const servicesRouter = router({
  /**
   * Public: submit a service inquiry (lead capture)
   * Used by all four service pages
   */
  submitInquiry: publicProcedure
    .input(
      z.object({
        serviceType: z.enum(["concierge", "brand_launch", "stock_liquidation", "escrow"]),
        name: z.string().min(1, "Name is required"),
        email: z.string().email("Valid email required"),
        company: z.string().optional(),
        // concierge
        productType: z.string().optional(),
        monthlyVolume: z.string().optional(),
        // brand launch
        brandName: z.string().optional(),
        productCategory: z.string().optional(),
        budget: z.string().optional(),
        timeline: z.string().optional(),
        // stock liquidation
        interestedIn: z.string().optional(),
        // escrow
        orderValue: z.string().optional(),
        factoryName: z.string().optional(),
        factoryCountry: z.string().optional(),
        // shared
        message: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await createServiceInquiry({
        serviceType: input.serviceType,
        name: input.name,
        email: input.email,
        company: input.company ?? null,
        productType: input.productType ?? null,
        monthlyVolume: input.monthlyVolume ?? null,
        brandName: input.brandName ?? null,
        productCategory: input.productCategory ?? null,
        budget: input.budget ?? null,
        timeline: input.timeline ?? null,
        interestedIn: input.interestedIn ?? null,
        orderValue: input.orderValue ?? null,
        factoryName: input.factoryName ?? null,
        factoryCountry: input.factoryCountry ?? null,
        message: input.message ?? null,
        status: "new",
      });
      return { success: true, message: "Inquiry received. We will contact you within 24 hours." };
    }),

  /**
   * Admin: list all service inquiries with optional filters
   */
  listInquiries: protectedProcedure
    .input(
      z.object({
        serviceType: z.enum(["concierge", "brand_launch", "stock_liquidation", "escrow"]).optional(),
        status: z.enum(["new", "contacted", "in_progress", "closed"]).optional(),
        limit: z.number().default(50),
        offset: z.number().default(0),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      return await listServiceInquiries(input);
    }),

  /**
   * Admin: update inquiry status and notes
   */
  updateInquiryStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["new", "contacted", "in_progress", "closed"]),
        notes: z.string().optional(),
        assignedTo: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      await updateServiceInquiryStatus(input.id, input.status, input.notes, input.assignedTo);
      return { success: true };
    }),

  /**
   * Public: list active stock liquidation deals
   * In production this would pull from a deals table; for now returns curated mock data
   */
  listStockDeals: publicProcedure
    .input(z.object({ category: z.string().optional() }).optional())
    .query(async ({ input }) => {
      // This is intentionally a static list until a `stockDeals` table is built
      const deals = [
        { id: 1, category: "Electronics", title: "Bluetooth Earbuds — Factory Overstock", units: 2000, originalPrice: 18, dealPrice: 7.5, margin: "58%", moq: 200, tag: "HOT" },
        { id: 2, category: "Apparel", title: "Cotton T-Shirts — End of Season", units: 5000, originalPrice: 8, dealPrice: 2.8, margin: "65%", moq: 500, tag: "NEW" },
        { id: 3, category: "Home Goods", title: "LED Desk Lamps — Discontinued Model", units: 800, originalPrice: 22, dealPrice: 9, margin: "59%", moq: 100, tag: "LIMITED" },
        { id: 4, category: "Beauty", title: "Lip Gloss Sets — Packaging Change", units: 3000, originalPrice: 5, dealPrice: 1.9, margin: "62%", moq: 300, tag: "HOT" },
        { id: 5, category: "Sports", title: "Resistance Bands — Excess Inventory", units: 4000, originalPrice: 6, dealPrice: 2.2, margin: "63%", moq: 400, tag: "NEW" },
        { id: 6, category: "Electronics", title: "USB-C Hubs — Surplus Stock", units: 1200, originalPrice: 28, dealPrice: 11, margin: "61%", moq: 150, tag: "LIMITED" },
      ];
      if (input?.category && input.category !== "All") {
        return deals.filter(d => d.category === input.category);
      }
      return deals;
    }),
});
