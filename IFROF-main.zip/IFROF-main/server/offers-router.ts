/**
 * Offers Router
 * Facebook-style social feed for IFROF daily deals and announcements.
 * Supports: list, get, create (admin), like/unlike, comment, reply, share count.
 */
import { router, publicProcedure, protectedProcedure } from './_core/trpc';
import { z } from 'zod';
import { getDb } from './db';
import { offers, offerLikes, offerComments, offerCommentLikes, users } from '../drizzle/schema';
import { eq, and, desc, sql, isNull, inArray } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database unavailable' });
  return db;
}

// ─────────────────────────────────────────────────────────────────────────────
// Router
// ─────────────────────────────────────────────────────────────────────────────

export const offersRouter = router({

  // ── List published offers (public feed) ────────────────────────────────────
  list: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(50).default(20),
      offset: z.number().min(0).default(0),
      offerType: z.enum(['deal', 'new_product', 'announcement', 'tip', 'event']).optional(),
    }).optional())
    .query(async ({ input, ctx }) => {
      const db = await requireDb();
      const limit = input?.limit ?? 20;
      const offset = input?.offset ?? 0;

      const rows = await db
        .select({
          offer: offers,
          author: {
            id: users.id,
            name: users.name,
          },
        })
        .from(offers)
        .leftJoin(users, eq(offers.authorId, users.id))
        .where(
          input?.offerType
            ? and(eq(offers.status, 'published'), eq(offers.offerType, input.offerType))
            : eq(offers.status, 'published')
        )
        .orderBy(desc(offers.pinned), desc(offers.publishedAt))
        .limit(limit)
        .offset(offset);

      // If user is authenticated, check which offers they liked
      const likedOfferIds = new Set<number>();
      if (ctx.user) {
        const userLikes = await db
          .select({ offerId: offerLikes.offerId })
          .from(offerLikes)
          .where(eq(offerLikes.userId, ctx.user.id));
        userLikes.forEach(l => likedOfferIds.add(l.offerId));
      }

      return rows.map(r => ({
        ...r.offer,
        tags: r.offer.tags ? JSON.parse(r.offer.tags) : [],
        author: r.author,
        isLiked: likedOfferIds.has(r.offer.id),
      }));
    }),

  // ── Get single offer by ID ──────────────────────────────────────────────────
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await requireDb();

      const [row] = await db
        .select({
          offer: offers,
          author: {
            id: users.id,
            name: users.name,
          },
        })
        .from(offers)
        .leftJoin(users, eq(offers.authorId, users.id))
        .where(eq(offers.id, input.id))
        .limit(1);

      if (!row) throw new TRPCError({ code: 'NOT_FOUND', message: 'Offer not found' });

      // Increment view count
      await db
        .update(offers)
        .set({ viewsCount: sql`${offers.viewsCount} + 1` })
        .where(eq(offers.id, input.id));

      const isLiked = ctx.user
        ? (await db
            .select({ id: offerLikes.id })
            .from(offerLikes)
            .where(and(eq(offerLikes.offerId, input.id), eq(offerLikes.userId, ctx.user.id)))
            .limit(1)).length > 0
        : false;

      return {
        ...row.offer,
        tags: row.offer.tags ? JSON.parse(row.offer.tags) : [],
        author: row.author,
        isLiked,
      };
    }),

  // ── Create offer (admin only) ───────────────────────────────────────────────
  create: protectedProcedure
    .input(z.object({
      title: z.string().min(3).max(255),
      content: z.string().min(10),
      imageUrl: z.string().url().optional(),
      videoUrl: z.string().url().optional(),
      linkUrl: z.string().url().optional(),
      linkLabel: z.string().max(100).optional(),
      tags: z.array(z.string()).optional(),
      offerType: z.enum(['deal', 'new_product', 'announcement', 'tip', 'event']).default('deal'),
      discountPercent: z.number().min(0).max(100).optional(),
      originalPrice: z.number().min(0).optional(),
      salePrice: z.number().min(0).optional(),
      validUntil: z.string().datetime().optional(),
      status: z.enum(['draft', 'published']).default('draft'),
      pinned: z.boolean().default(false),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Only admins can create offers' });
      }

      const db = await requireDb();

      const result = await db.insert(offers).values({
        authorId: ctx.user.id,
        title: input.title,
        content: input.content,
        imageUrl: input.imageUrl,
        videoUrl: input.videoUrl,
        linkUrl: input.linkUrl,
        linkLabel: input.linkLabel,
        tags: input.tags ? JSON.stringify(input.tags) : null,
        offerType: input.offerType,
        discountPercent: input.discountPercent,
        originalPrice: input.originalPrice,
        salePrice: input.salePrice,
        validUntil: input.validUntil ? new Date(input.validUntil) : undefined,
        status: input.status,
        pinned: input.pinned,
        publishedAt: input.status === 'published' ? new Date() : undefined,
      });

      return { success: true, offerId: (result as unknown as { insertId: number }).insertId };
    }),

  // ── Update offer (admin only) ───────────────────────────────────────────────
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      title: z.string().min(3).max(255).optional(),
      content: z.string().min(10).optional(),
      imageUrl: z.string().url().optional().nullable(),
      videoUrl: z.string().url().optional().nullable(),
      linkUrl: z.string().url().optional().nullable(),
      linkLabel: z.string().max(100).optional().nullable(),
      tags: z.array(z.string()).optional(),
      offerType: z.enum(['deal', 'new_product', 'announcement', 'tip', 'event']).optional(),
      discountPercent: z.number().min(0).max(100).optional().nullable(),
      originalPrice: z.number().min(0).optional().nullable(),
      salePrice: z.number().min(0).optional().nullable(),
      validUntil: z.string().datetime().optional().nullable(),
      status: z.enum(['draft', 'published', 'archived']).optional(),
      pinned: z.boolean().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Only admins can update offers' });
      }

      const db = await requireDb();
      const { id, tags, validUntil, status, ...rest } = input;

      const updateData: Record<string, unknown> = { ...rest };
      if (tags !== undefined) updateData.tags = JSON.stringify(tags);
      if (validUntil !== undefined) updateData.validUntil = validUntil ? new Date(validUntil) : null;
      if (status !== undefined) {
        updateData.status = status;
        if (status === 'published') updateData.publishedAt = new Date();
      }

      await db.update(offers).set(updateData).where(eq(offers.id, id));
      return { success: true };
    }),

  // ── Delete offer (admin only) ───────────────────────────────────────────────
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Only admins can delete offers' });
      }

      const db = await requireDb();
      await db.delete(offerCommentLikes).where(
        sql`${offerCommentLikes.commentId} IN (SELECT id FROM offerComments WHERE offerId = ${input.id})`
      );
      await db.delete(offerComments).where(eq(offerComments.offerId, input.id));
      await db.delete(offerLikes).where(eq(offerLikes.offerId, input.id));
      await db.delete(offers).where(eq(offers.id, input.id));
      return { success: true };
    }),

  // ── Toggle like on an offer ─────────────────────────────────────────────────
  toggleLike: protectedProcedure
    .input(z.object({
      offerId: z.number(),
      reactionType: z.enum(['like', 'love', 'wow', 'haha', 'sad', 'angry']).default('like'),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await requireDb();

      const [existing] = await db
        .select({ id: offerLikes.id })
        .from(offerLikes)
        .where(and(eq(offerLikes.offerId, input.offerId), eq(offerLikes.userId, ctx.user.id)))
        .limit(1);

      if (existing) {
        // Unlike
        await db.delete(offerLikes).where(eq(offerLikes.id, existing.id));
        await db
          .update(offers)
          .set({ likesCount: sql`GREATEST(0, ${offers.likesCount} - 1)` })
          .where(eq(offers.id, input.offerId));
        return { liked: false };
      } else {
        // Like
        await db.insert(offerLikes).values({
          offerId: input.offerId,
          userId: ctx.user.id,
          reactionType: input.reactionType,
        });
        await db
          .update(offers)
          .set({ likesCount: sql`${offers.likesCount} + 1` })
          .where(eq(offers.id, input.offerId));
        return { liked: true };
      }
    }),

  // ── Increment share count ───────────────────────────────────────────────────
  recordShare: publicProcedure
    .input(z.object({ offerId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      await db
        .update(offers)
        .set({ sharesCount: sql`${offers.sharesCount} + 1` })
        .where(eq(offers.id, input.offerId));
      return { success: true };
    }),

  // ── List comments for an offer ──────────────────────────────────────────────
  listComments: publicProcedure
    .input(z.object({
      offerId: z.number(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input, ctx }) => {
      const db = await requireDb();

      // Top-level comments only
      const rows = await db
        .select({
          comment: offerComments,
          author: {
            id: users.id,
            name: users.name,
          },
        })
        .from(offerComments)
        .leftJoin(users, eq(offerComments.userId, users.id))
        .where(and(eq(offerComments.offerId, input.offerId), isNull(offerComments.parentId)))
        .orderBy(desc(offerComments.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      // Fetch replies for each top-level comment
      const commentIds = rows.map(r => r.comment.id);
      const replies = commentIds.length > 0
        ? await db
            .select({
              comment: offerComments,
              author: { id: users.id, name: users.name },
            })
            .from(offerComments)
            .leftJoin(users, eq(offerComments.userId, users.id))
            .where(inArray(offerComments.parentId, commentIds))
            .orderBy(offerComments.createdAt)
        : [];

      const repliesByParent = new Map<number, typeof replies>();
      replies.forEach(r => {
        const pid = r.comment.parentId!;
        if (!repliesByParent.has(pid)) repliesByParent.set(pid, []);
        repliesByParent.get(pid)!.push(r);
      });

      // Check which comments current user liked
      const likedCommentIds = new Set<number>();
      if (ctx.user) {
        const allCommentIds = [
          ...rows.map(r => r.comment.id),
          ...replies.map(r => r.comment.id),
        ];
        if (allCommentIds.length > 0) {
          const userLikes = await db
            .select({ commentId: offerCommentLikes.commentId })
            .from(offerCommentLikes)
            .where(
              and(
                eq(offerCommentLikes.userId, ctx.user.id),
                inArray(offerCommentLikes.commentId, allCommentIds)
              )
            );
          userLikes.forEach(l => likedCommentIds.add(l.commentId));
        }
      }

      return rows.map(r => ({
        ...r.comment,
        author: r.author,
        isLiked: likedCommentIds.has(r.comment.id),
        replies: (repliesByParent.get(r.comment.id) ?? []).map(reply => ({
          ...reply.comment,
          author: reply.author,
          isLiked: likedCommentIds.has(reply.comment.id),
        })),
      }));
    }),

  // ── Add a comment ───────────────────────────────────────────────────────────
  addComment: protectedProcedure
    .input(z.object({
      offerId: z.number(),
      content: z.string().min(1).max(2000),
      parentId: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await requireDb();

      const result = await db.insert(offerComments).values({
        offerId: input.offerId,
        userId: ctx.user.id,
        content: input.content,
        parentId: input.parentId,
      });

      // Update comment count on the offer
      await db
        .update(offers)
        .set({ commentsCount: sql`${offers.commentsCount} + 1` })
        .where(eq(offers.id, input.offerId));

      return { success: true, commentId: (result as unknown as { insertId: number }).insertId };
    }),

  // ── Delete a comment ────────────────────────────────────────────────────────
  deleteComment: protectedProcedure
    .input(z.object({ commentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await requireDb();

      const [comment] = await db
        .select()
        .from(offerComments)
        .where(eq(offerComments.id, input.commentId))
        .limit(1);

      if (!comment) throw new TRPCError({ code: 'NOT_FOUND', message: 'Comment not found' });

      if (comment.userId !== ctx.user.id && ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Cannot delete this comment' });
      }

      await db.delete(offerCommentLikes).where(eq(offerCommentLikes.commentId, input.commentId));
      await db.delete(offerComments).where(eq(offerComments.id, input.commentId));

      await db
        .update(offers)
        .set({ commentsCount: sql`GREATEST(0, ${offers.commentsCount} - 1)` })
        .where(eq(offers.id, comment.offerId));

      return { success: true };
    }),

  // ── Toggle like on a comment ────────────────────────────────────────────────
  toggleCommentLike: protectedProcedure
    .input(z.object({ commentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await requireDb();

      const [existing] = await db
        .select({ id: offerCommentLikes.id })
        .from(offerCommentLikes)
        .where(and(eq(offerCommentLikes.commentId, input.commentId), eq(offerCommentLikes.userId, ctx.user.id)))
        .limit(1);

      if (existing) {
        await db.delete(offerCommentLikes).where(eq(offerCommentLikes.id, existing.id));
        await db
          .update(offerComments)
          .set({ likesCount: sql`GREATEST(0, ${offerComments.likesCount} - 1)` })
          .where(eq(offerComments.id, input.commentId));
        return { liked: false };
      } else {
        await db.insert(offerCommentLikes).values({
          commentId: input.commentId,
          userId: ctx.user.id,
        });
        await db
          .update(offerComments)
          .set({ likesCount: sql`${offerComments.likesCount} + 1` })
          .where(eq(offerComments.id, input.commentId));
        return { liked: true };
      }
    }),

  // ── Admin: list all offers (including drafts) ───────────────────────────────
  adminList: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
      status: z.enum(['draft', 'published', 'archived']).optional(),
    }).optional())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
      }

      const db = await requireDb();

      const rows = await db
        .select({
          offer: offers,
          author: { id: users.id, name: users.name },
        })
        .from(offers)
        .leftJoin(users, eq(offers.authorId, users.id))
        .where(input?.status ? eq(offers.status, input.status) : undefined)
        .orderBy(desc(offers.createdAt))
        .limit(input?.limit ?? 50)
        .offset(input?.offset ?? 0);

      return rows.map(r => ({
        ...r.offer,
        tags: r.offer.tags ? JSON.parse(r.offer.tags) : [],
        author: r.author,
      }));
    }),
});
