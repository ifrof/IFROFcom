import { z } from "zod";
import { protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  shipments, shipmentEvents, shippingDocuments, shippingQuotes, orders,
} from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const shipmentRouter = router({
  /** Get all shipments for the current user */
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db.select({
      shipment: shipments,
      order: orders,
    })
      .from(shipments)
      .leftJoin(orders, eq(shipments.orderId, orders.id))
      .where(eq(shipments.userId, ctx.user.id))
      .orderBy(desc(shipments.createdAt));
  }),

  /** Get shipment by ID with events timeline */
  getById: protectedProcedure
    .input(z.object({ shipmentId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.select()
        .from(shipments)
        .where(eq(shipments.id, input.shipmentId))
        .limit(1);

      if (result.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Shipment not found" });
      if (result[0].userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }

      const events = await db.select()
        .from(shipmentEvents)
        .where(eq(shipmentEvents.shipmentId, input.shipmentId))
        .orderBy(desc(shipmentEvents.timestamp));

      const docs = await db.select()
        .from(shippingDocuments)
        .where(eq(shippingDocuments.shipmentId, input.shipmentId))
        .orderBy(desc(shippingDocuments.createdAt));

      return { shipment: result[0], events, documents: docs };
    }),

  /** Get shipment by tracking number */
  getByTracking: protectedProcedure
    .input(z.object({ trackingNumber: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.select()
        .from(shipments)
        .where(eq(shipments.trackingNumber, input.trackingNumber))
        .limit(1);

      if (result.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Shipment not found" });
      if (result[0].userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }

      const events = await db.select()
        .from(shipmentEvents)
        .where(eq(shipmentEvents.shipmentId, result[0].id))
        .orderBy(desc(shipmentEvents.timestamp));

      return { shipment: result[0], events };
    }),

  /** Get shipping documents for user */
  listDocuments: protectedProcedure
    .input(z.object({ orderId: z.number().optional() }).optional())
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let query = db.select()
        .from(shippingDocuments)
        .where(eq(shippingDocuments.userId, ctx.user.id))
        .$dynamic();

      if (input?.orderId) {
        query = query.where(and(
          eq(shippingDocuments.userId, ctx.user.id),
          eq(shippingDocuments.orderId, input.orderId)
        ));
      }

      return await query.orderBy(desc(shippingDocuments.createdAt));
    }),

  /** Save a shipping quote */
  saveQuote: protectedProcedure
    .input(z.object({
      origin: z.string(),
      destination: z.string(),
      weight: z.number(),
      dimensions: z.string().optional(),
      method: z.enum(["sea", "air", "rail", "express"]),
      cost: z.number(),
      customs: z.number().optional(),
      insurance: z.number().optional(),
      total: z.number(),
      duration: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(shippingQuotes).values({
        userId: ctx.user.id,
        origin: input.origin,
        destination: input.destination,
        weight: input.weight,
        dimensions: input.dimensions ?? null,
        method: input.method,
        cost: input.cost,
        customs: input.customs ?? 0,
        insurance: input.insurance ?? 0,
        total: input.total,
        duration: input.duration ?? null,
      });

      return { success: true, quoteId: result[0].insertId };
    }),

  /** Get saved quotes */
  listQuotes: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db.select()
      .from(shippingQuotes)
      .where(eq(shippingQuotes.userId, ctx.user.id))
      .orderBy(desc(shippingQuotes.createdAt));
  }),

  // ============ ADMIN SHIPMENT MANAGEMENT ============

  /** Admin: Create shipment for an order */
  create: adminProcedure
    .input(z.object({
      orderId: z.number(),
      userId: z.number(),
      trackingNumber: z.string().optional(),
      carrier: z.string().optional(),
      method: z.enum(["sea", "air", "rail", "express"]).optional(),
      origin: z.string().optional(),
      destination: z.string().optional(),
      estimatedDelivery: z.string().optional(),
      weight: z.number().optional(),
      dimensions: z.string().optional(),
      shippingCost: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(shipments).values({
        orderId: input.orderId,
        userId: input.userId,
        trackingNumber: input.trackingNumber ?? null,
        carrier: input.carrier ?? null,
        method: input.method ?? "sea",
        origin: input.origin ?? null,
        destination: input.destination ?? null,
        estimatedDelivery: input.estimatedDelivery ? new Date(input.estimatedDelivery) : null,
        weight: input.weight ?? null,
        dimensions: input.dimensions ?? null,
        shippingCost: input.shippingCost ?? 0,
        status: "pending",
      });

      const shipmentId = result[0].insertId;

      await db.insert(shipmentEvents).values({
        shipmentId,
        status: "pending",
        description: "Shipment created",
      });

      return { success: true, shipmentId };
    }),

  /** Admin: Update shipment status */
  updateStatus: adminProcedure
    .input(z.object({
      shipmentId: z.number(),
      status: z.enum(["pending", "picked_up", "in_transit", "customs", "out_for_delivery", "delivered", "exception"]),
      location: z.string().optional(),
      description: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(shipments).set({
        status: input.status,
        lastLocation: input.location ?? null,
        lastUpdate: new Date(),
        ...(input.status === "delivered" ? { actualDelivery: new Date() } : {}),
      }).where(eq(shipments.id, input.shipmentId));

      await db.insert(shipmentEvents).values({
        shipmentId: input.shipmentId,
        status: input.status,
        location: input.location ?? null,
        description: input.description ?? `Status updated to ${input.status}`,
      });

      return { success: true };
    }),

  /** Admin: List all shipments */
  listAll: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db.select({
      shipment: shipments,
      order: orders,
    })
      .from(shipments)
      .leftJoin(orders, eq(shipments.orderId, orders.id))
      .orderBy(desc(shipments.createdAt));
  }),
});
