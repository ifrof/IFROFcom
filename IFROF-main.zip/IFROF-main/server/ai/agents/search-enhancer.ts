/**
 * Agent 4: Smart Search Enhancer
 * Expands user queries, detects intent, and suggests filters.
 */

import { invokeLLM } from '../../_core/llm';

export type SearchIntent = 'product_search' | 'factory_search' | 'general_inquiry';

export interface SearchEnhancerInput {
  query: string;
  filters?: Record<string, unknown>;
  userContext?: {
    previousSearches?: string[];
    viewedProducts?:   string[];
  };
}

export interface SearchEnhancerOutput {
  enhancedQuery:    string;
  suggestedFilters: Record<string, unknown>;
  searchIntent:     SearchIntent;
  relatedQueries:   string[];
  keywords:         string[];
}

const SYSTEM_PROMPT = `You are a B2B search intelligence engine for a platform that connects global importers with Chinese manufacturers.
Given a user's search query, improve it for better results.

Understand trade terminology: HS codes, MOQ, OEM/ODM, FOB/CIF, lead time, certifications (ISO, CE, RoHS, FDA).
Always respond with ONLY valid JSON — no markdown, no extra text.`;

export async function enhanceSearch(input: SearchEnhancerInput): Promise<SearchEnhancerOutput> {
  const userContent = `Enhance this B2B search query:

Query: "${input.query}"
Current Filters: ${JSON.stringify(input.filters ?? {})}
Previous Searches: ${input.userContext?.previousSearches?.slice(-5).join(', ') ?? 'none'}

Return this JSON:
{
  "enhancedQuery": "improved search query with B2B terms",
  "suggestedFilters": { "category": "...", "minOrderQty": null, "certifications": [] },
  "searchIntent": "product_search",
  "relatedQueries": ["related query 1", "related query 2", "related query 3"],
  "keywords": ["keyword1", "keyword2", "keyword3"]
}

searchIntent must be one of: product_search, factory_search, general_inquiry`;

  const result = await invokeLLM({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: userContent },
    ],
    maxTokens: 512,
  });

  const raw = result.choices[0]?.message?.content ?? '{}';
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as SearchEnhancerOutput;
  } catch {}

  return {
    enhancedQuery:    input.query,
    suggestedFilters: {},
    searchIntent:     'product_search',
    relatedQueries:   [],
    keywords:         input.query.split(' ').filter(Boolean),
  };
}
