/**
 * Agent 1: Factory Validator
 * Analyses company information and decides whether it is a legitimate
 * manufacturer or a trading company / fraud risk.
 */

import { invokeLLM } from '../../_core/llm';

export interface FactoryValidatorInput {
  companyName: string;
  website?: string;
  description?: string;
  businessLicense?: string;
  contactInfo?: string;
  productCategories?: string[];
}

export interface FactoryValidatorOutput {
  isLegitimate: boolean;
  confidenceScore: number;             // 0-100
  category: 'verified_factory' | 'likely_factory' | 'trading_company' | 'suspicious' | 'fraud_risk';
  redFlags:   string[];
  greenFlags: string[];
  reasoning:  string;
  recommendations: string[];
}

const SYSTEM_PROMPT = `You are a B2B supply-chain due-diligence expert specialising in Chinese manufacturing.
Your job is to evaluate whether a company is a genuine factory or a trading company/agent.

Genuine factory signals: owns machinery, has production lines, employs workers, has factory address, OEM/ODM capability, ISO/CE certifications, shows production videos, factory tours.
Red flags: "trading company", "import & export", "sourcing agent", "buying office", intermediary language, no mention of production, vague addresses.

Always respond with ONLY valid JSON — no markdown, no explanation outside the JSON object.`;

export async function validateFactory(input: FactoryValidatorInput): Promise<FactoryValidatorOutput> {
  const userContent = `Evaluate this company:

Company Name: ${input.companyName}
Website: ${input.website ?? 'not provided'}
Description: ${input.description ?? 'not provided'}
Business License: ${input.businessLicense ?? 'not provided'}
Contact Info: ${input.contactInfo ?? 'not provided'}
Product Categories: ${input.productCategories?.join(', ') ?? 'not provided'}

Return this exact JSON structure:
{
  "isLegitimate": true,
  "confidenceScore": 85,
  "category": "likely_factory",
  "redFlags": ["list of red flags or empty array"],
  "greenFlags": ["list of positive signals"],
  "reasoning": "2-3 sentence explanation",
  "recommendations": ["suggested verification steps"]
}

category must be one of: verified_factory, likely_factory, trading_company, suspicious, fraud_risk`;

  const result = await invokeLLM({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: userContent },
    ],
    maxTokens: 1024,
  });

  const raw = result.choices[0]?.message?.content ?? '{}';
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as FactoryValidatorOutput;
  } catch {}

  // Fallback
  return {
    isLegitimate:    false,
    confidenceScore: 0,
    category:        'suspicious',
    redFlags:        ['Could not parse AI response'],
    greenFlags:      [],
    reasoning:       'AI response could not be parsed.',
    recommendations: ['Manual verification required'],
  };
}
