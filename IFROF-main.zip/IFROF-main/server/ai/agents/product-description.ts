/**
 * Agent 2: Product Description Generator
 * Produces SEO-optimised B2B product descriptions from raw specs.
 */

import { invokeLLM } from '../../_core/llm';

export interface ProductDescriptionInput {
  productName:   string;
  category:      string;
  specifications?: Record<string, string | number>;
  rawData?:      string;
  targetMarket?: string;
}

export interface ProductDescriptionOutput {
  title:       string;      // SEO-optimised, max 70 chars
  description: string;      // 150-250 words, professional B2B tone
  keyFeatures: string[];    // 4-6 bullet points
  applications: string[];   // use-case industries
  tags:        string[];    // SEO tags
}

const SYSTEM_PROMPT = `You are a professional B2B product copywriter with deep knowledge of manufacturing and export trade.
Write clear, professional descriptions optimised for buyers searching on wholesale platforms.
Highlight factory-direct advantages: MOQ, OEM/ODM availability, certifications, lead times.
Always respond with ONLY valid JSON — no markdown, no extra text.`;

export async function generateProductDescription(
  input: ProductDescriptionInput,
): Promise<ProductDescriptionOutput> {
  const specs = input.specifications
    ? Object.entries(input.specifications).map(([k, v]) => `${k}: ${v}`).join('\n')
    : '';

  const userContent = `Generate a B2B product description for:

Product: ${input.productName}
Category: ${input.category}
Target Market: ${input.targetMarket ?? 'Global B2B buyers'}
Specifications:
${specs || 'Not provided'}
Additional Info: ${input.rawData ?? 'None'}

Return this JSON:
{
  "title": "SEO product title (max 70 chars)",
  "description": "150-250 word professional B2B description",
  "keyFeatures": ["Feature 1", "Feature 2", "Feature 3", "Feature 4"],
  "applications": ["Industry 1", "Industry 2"],
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}`;

  const result = await invokeLLM({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: userContent },
    ],
    maxTokens: 1024,
  });

  const raw = result.choices[0]?.message?.content ?? '{}';
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as ProductDescriptionOutput;
  } catch {}

  return {
    title:        input.productName,
    description:  'Description could not be generated. Please try again.',
    keyFeatures:  [],
    applications: [],
    tags:         [],
  };
}
