/**
 * Agent 5: Email Composer
 * Generates professional B2B emails for various platform workflows.
 */

import { invokeLLM } from '../../_core/llm';

export type EmailType =
  | 'supplier_invitation'
  | 'order_inquiry'
  | 'payment_confirmation'
  | 'shipping_update'
  | 'rfq_response'
  | 'custom';

export type RecipientType = 'buyer' | 'supplier';
export type EmailLanguage = 'en' | 'ar' | 'zh';
export type EmailTone = 'formal' | 'friendly' | 'urgent';

export interface EmailComposerInput {
  emailType:     EmailType;
  recipientType: RecipientType;
  context:       Record<string, unknown>;
  language?:     EmailLanguage;
}

export interface EmailComposerOutput {
  subject: string;
  body:    string;
  tone:    EmailTone;
}

const SYSTEM_PROMPT = `You are a professional B2B communications writer for IFROF, a platform connecting global buyers with Chinese manufacturers.
Write clear, concise, professional emails. Adapt tone based on email type (formal for contracts/payments, friendly for introductions, urgent for time-sensitive matters).
Always respond with ONLY valid JSON — no markdown, no extra text.`;

export async function composeEmail(input: EmailComposerInput): Promise<EmailComposerOutput> {
  const lang =
    input.language === 'ar' ? 'Arabic' :
    input.language === 'zh' ? 'Chinese (Simplified)' :
    'English';

  const userContent = `Compose a B2B email:

Type: ${input.emailType}
Recipient: ${input.recipientType}
Language: ${lang}
Context data: ${JSON.stringify(input.context, null, 2)}

Return this JSON:
{
  "subject": "Email subject line",
  "body": "Full email body with proper greeting, content, and sign-off",
  "tone": "formal"
}

tone must be one of: formal, friendly, urgent`;

  const result = await invokeLLM({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: userContent },
    ],
    maxTokens: 1024,
  });

  const raw = result.choices[0]?.message?.content ?? '{}';
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as EmailComposerOutput;
  } catch {}

  return {
    subject: 'IFROF Platform Notification',
    body:    'Please contact support@ifrof.com for assistance.',
    tone:    'formal',
  };
}
