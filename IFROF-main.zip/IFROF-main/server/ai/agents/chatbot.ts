/**
 * Agent 3: Customer Support Chatbot
 * 24/7 multilingual support for buyers and suppliers (en / ar / zh).
 */

import { invokeLLM } from '../../_core/llm';

export type UserLanguage = 'en' | 'ar' | 'zh';
export type UserType     = 'buyer' | 'supplier' | 'guest';

export interface ChatMessage {
  role:    'user' | 'assistant';
  content: string;
}

export interface ChatbotInput {
  message:             string;
  conversationHistory: ChatMessage[];
  userType:            UserType;
  context?: {
    currentPage?:  string;
    userLanguage?: UserLanguage;
  };
}

export interface ChatbotOutput {
  response:          string;
  suggestedActions?: Array<{ label: string; action: string }>;
  needsHumanSupport: boolean;
}

const buildSystemPrompt = (userType: UserType, lang: UserLanguage): string => {
  const role = userType === 'supplier'
    ? 'Chinese factory / supplier'
    : userType === 'buyer'
    ? 'international B2B buyer'
    : 'platform visitor';

  const langInstruction =
    lang === 'ar' ? 'Always reply in Arabic.' :
    lang === 'zh' ? 'Always reply in Chinese (Simplified).' :
    'Always reply in English.';

  return `You are a helpful customer support assistant for IFROF — a B2B platform connecting global buyers with verified Chinese factories.
The current user is a ${role}.
${langInstruction}

You can help with: product sourcing, factory verification, RFQ submission, shipping quotes, order status, payment questions, account issues, and platform navigation.
If you cannot resolve the issue, set needsHumanSupport to true and suggest contacting support@ifrof.com.

Always respond with ONLY valid JSON — no markdown, no extra text.`;
};

export async function chat(input: ChatbotInput): Promise<ChatbotOutput> {
  const lang = input.context?.userLanguage ?? 'en';
  const systemPrompt = buildSystemPrompt(input.userType, lang);

  const history = input.conversationHistory.slice(-10); // last 10 turns
  const messages = [
    { role: 'system' as const, content: systemPrompt },
    ...history,
    { role: 'user' as const, content: input.message },
  ];

  const result = await invokeLLM({ messages, maxTokens: 512 });
  const raw = result.choices[0]?.message?.content ?? '{}';

  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as ChatbotOutput;
  } catch {}

  // If the model returned plain text instead of JSON, wrap it
  return {
    response:          raw || 'I apologise, I could not process your request. Please contact support@ifrof.com',
    needsHumanSupport: false,
  };
}
