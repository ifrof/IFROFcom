/**
 * Agent 6: Recommendation Engine
 * Suggests similar products, factories, or trending items using AI reasoning.
 * Note: Returns recommendation metadata; actual DB lookup is done in ai-router.ts.
 */

import { invokeLLM } from '../../_core/llm';

export type RecommendationType = 'similar_products' | 'similar_factories' | 'cross_sell' | 'trending';
export type ItemType = 'product' | 'factory';

export interface RecommendationInput {
  type: RecommendationType;
  currentItem: {
    id:          string;
    type:        ItemType;
    name?:       string;
    category?:   string;
    description?: string;
  };
  userHistory?: {
    viewedItems?:    string[];
    searchHistory?:  string[];
  };
  limit?: number;
}

export interface RecommendationReasoning {
  category:         string;
  searchTerms:      string[];
  reasoning:        string;
  recommendedTypes: string[];
}

const SYSTEM_PROMPT = `You are a B2B recommendation engine for a manufacturing sourcing platform.
Given context about what a buyer is viewing, suggest what else they might be interested in.
Focus on supply-chain logic: complementary products, related categories, cross-sell opportunities.
Always respond with ONLY valid JSON — no markdown, no extra text.`;

/**
 * Returns search/filter guidance that the router uses to query the database.
 */
export async function getRecommendationGuidance(
  input: RecommendationInput,
): Promise<RecommendationReasoning> {
  const userContent = `Generate recommendation guidance for:

Type: ${input.type}
Current Item: ${JSON.stringify(input.currentItem)}
User History: ${JSON.stringify(input.userHistory ?? {})}
Limit: ${input.limit ?? 6}

Return this JSON:
{
  "category": "suggested product/factory category to search",
  "searchTerms": ["term1", "term2", "term3"],
  "reasoning": "1-2 sentence explanation of why these are relevant",
  "recommendedTypes": ["specific product types or factory specialties"]
}`;

  const result = await invokeLLM({
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user',   content: userContent },
    ],
    maxTokens: 512,
  });

  const raw = result.choices[0]?.message?.content ?? '{}';
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]) as RecommendationReasoning;
  } catch {}

  return {
    category:         input.currentItem.category ?? '',
    searchTerms:      [],
    reasoning:        'Similar items in the same category.',
    recommendedTypes: [],
  };
}
