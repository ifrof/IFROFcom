/**
 * Ollama client — thin wrapper around Ollama's local chat completions endpoint.
 * No API key required; just point OLLAMA_BASE_URL at your Ollama server.
 */

import { ENV } from '../_core/env';

const BASE_URL = () => (ENV.ollamaBaseUrl || 'http://localhost:11434').replace(/\/$/, '');
const MODEL    = () => ENV.ollamaModel || 'qwen2.5:14b-instruct';
const TIMEOUT  = 30_000;

export interface OllamaMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface OllamaChatOptions {
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface OllamaChatResult {
  content: string;
  model: string;
  latencyMs: number;
}

/**
 * Send a chat request to Ollama (local chat completions endpoint).
 */
export async function ollamaChat(
  messages: OllamaMessage[],
  options: OllamaChatOptions = {},
): Promise<OllamaChatResult> {
  const url   = `${BASE_URL()}/v1/chat/completions`;
  const model = options.model ?? MODEL();
  const start = Date.now();

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT);

  try {
    const res = await fetch(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      signal:  controller.signal,
      body: JSON.stringify({
        model,
        messages,
        max_tokens:  options.maxTokens  ?? 2048,
        temperature: options.temperature ?? 0.3,
        stream: false,
      }),
    });

    if (!res.ok) {
      const err = await res.text().catch(() => res.statusText);
      throw new Error(`Ollama ${res.status}: ${err}`);
    }

    const data = await res.json();
    return {
      content:   data.choices?.[0]?.message?.content ?? '',
      model,
      latencyMs: Date.now() - start,
    };
  } finally {
    clearTimeout(timer);
  }
}

/** Returns true if Ollama server is reachable. */
export async function isOllamaAvailable(): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL()}/api/tags`, {
      signal: AbortSignal.timeout(3_000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Ask Ollama to pull a model (fire-and-forget safe).
 * Called once on startup so the model is ready.
 */
export async function ensureModel(modelName?: string): Promise<void> {
  const name = modelName ?? MODEL();
  await fetch(`${BASE_URL()}/api/pull`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ name, stream: false }),
  }).catch((e) => console.warn(`[Ollama] Pull failed for ${name}:`, e));
}
