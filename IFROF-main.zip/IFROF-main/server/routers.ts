import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getProducts, getProductById, getCategories, incrementProductViews } from "./db-products";
import * as db from "./db";
import { createCheckoutSession } from "./stripe";
import { TRPCError } from "@trpc/server";
import { gmailRouter } from "./gmail-router";
import { factoryFinderRouter } from "./factory-finder-router";
import { rfqRouter } from "./rfq-router";
import { messagingRouter } from "./messaging-router";
import { passportRouter } from "./passport-router";
import { revenueRouter } from "./revenue-router";
import { analyticsRouter } from "./analytics-router";
import { adminRouter } from "./admin-router";
import { shipmentRouter } from "./shipment-router";
import { servicesRouter } from "./services-router";
import { shippingRouter } from "./shipping-router";
import { offersRouter } from "./offers-router";
import { groupShippingRouter } from "./group-shipping-router";
import { aiRouter } from "./ai-router";
import { unifiedFlowRouter } from "./unified-flow-router";
import { authRouter } from "./auth.router";
import { ordersRouter } from "./orders.router";


export const appRouter = router({

  // ============ UPLOAD ROUTER ============
  upload: router({
    // Upload image as base64 and return a public URL (uses storage proxy if configured, else data URL)
    image: protectedProcedure
      .input(z.object({
        base64: z.string(),
        mimeType: z.string().default('image/jpeg'),
        folder: z.string().default('blog'),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        try {
          const { storagePut } = await import('./storage');
          const buffer = Buffer.from(input.base64, 'base64');
          const ext = input.mimeType.split('/')[1] || 'jpg';
          const key = `${input.folder}/${Date.now()}-${ctx.user.id}.${ext}`;
          const result = await storagePut(key, buffer, input.mimeType);
          return { url: result.url };
        } catch {
          // Storage not configured — return data URL as fallback
          return { url: `data:${input.mimeType};base64,${input.base64}` };
        }
      }),
  }),

  // ============ QUOTE REQUESTS ROUTER ============
  quotes: router({
    submit: publicProcedure
      .input(z.object({
        productId: z.number(),
        name: z.string().min(2),
        email: z.string().email(),
        phone: z.string().optional(),
        company: z.string().optional(),
        quantity: z.number().min(1),
        unit: z.string().optional(),
        message: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const id = await db.createQuoteRequest({
          userId: ctx.user?.id,
          productId: input.productId,
          name: input.name,
          email: input.email,
          phone: input.phone,
          company: input.company,
          quantity: input.quantity,
          unit: input.unit,
          message: input.message,
        });
        return { success: true, id };
      }),

    list: protectedProcedure
      .input(z.object({ status: z.string().optional() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        return await db.listQuoteRequests(input.status);
      }),

    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(['pending', 'reviewed', 'quoted', 'closed']), adminNotes: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        await db.updateQuoteRequestStatus(input.id, input.status, input.adminNotes);
        return { success: true };
      }),
  }),


  system: systemRouter,
  gmail: gmailRouter,
  factoryFinder: factoryFinderRouter,

  // ============ NEW SPRINT ROUTERS ============
  rfq: rfqRouter,
  messaging: messagingRouter,
  passport: passportRouter,
  revenue: revenueRouter,
  analytics: analyticsRouter,
  admin: adminRouter,
  shipment: shipmentRouter,
  services: servicesRouter,
  shipping: shippingRouter,
  offers: offersRouter,
  groupShipping: groupShippingRouter,
  ai: aiRouter,
  unified: unifiedFlowRouter,

  // ============ AUTH ROUTER ============
  auth: authRouter,

  // ============ PRODUCTS ROUTER ============
  products: router({
    list: publicProcedure
      .input(
        z.object({
          categoryId: z.number().optional(),
          factoryId: z.number().optional(),
          featured: z.string().optional(),
          search: z.string().optional(),
          limit: z.number().default(20),
          offset: z.number().default(0),
        }).optional()
      )
      .query(async ({ input }) => {
        const { cacheQuery, CacheKeys, CacheTTL } = await import('./cache');
        const cacheKey = CacheKeys.products(JSON.stringify(input ?? {}));
        return await cacheQuery(cacheKey, CacheTTL.products, () => getProducts(input));
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const { cacheQuery, CacheKeys, CacheTTL } = await import('./cache');
        const cacheKey = CacheKeys.products(`id:${input.id}`);
        const product = await cacheQuery(cacheKey, CacheTTL.products, () => getProductById(input.id));
        if (!product) throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
        await incrementProductViews(input.id);
        return product;
      }),
  }),

  // ============ CATEGORIES ROUTER ============
  categories: router({
    list: publicProcedure.query(async () => {
      const { cacheQuery, CacheKeys, CacheTTL } = await import('./cache');
      return await cacheQuery(CacheKeys.categories(), CacheTTL.categories, () => getCategories());
    }),
  }),



  // ============ ORDERS ROUTER ============
  orders: ordersRouter,

  // ============ WAITLIST ROUTER ============
  waitlist: router({
    join: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(async ({ input }) => {
        await db.addToWaitlist(input.email);
        return { success: true };
      }),
  }),

  // ============ REVIEWS ROUTER ============
  reviews: router({
    getByProduct: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        return await db.getProductReviews(input.productId);
      }),

    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        rating: z.number().min(1).max(5),
        title: z.string().optional(),
        comment: z.string(),
        images: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const reviewId = await db.createReview({
          productId: input.productId,
          userId: ctx.user.id,
          rating: input.rating,
          title: input.title,
          comment: input.comment,
          images: input.images ? JSON.stringify(input.images) : null,
        });

        return { success: true, reviewId };
      }),
  }),

  // ============ FORUM ROUTER ============
  forum: router({
    getPosts: publicProcedure
      .input(z.object({
        categorySlug: z.string().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return await db.getForumPosts(input.categorySlug, input.limit, input.offset);
      }),

    getPostById: publicProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        const post = await db.getForumPostById(input.postId);
        if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        return post;
      }),

    createPost: protectedProcedure
      .input(z.object({
        categorySlug: z.string(),
        title: z.string().min(5),
        content: z.string().min(10),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const postId = await db.createForumPost({
          userId: ctx.user.id,
          categorySlug: input.categorySlug,
          title: input.title,
          content: input.content,
          tags: input.tags ? JSON.stringify(input.tags) : null,
        });

        return { success: true, postId };
      }),

    getComments: publicProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        return await db.getForumComments(input.postId);
      }),

    createComment: protectedProcedure
      .input(z.object({
        postId: z.number(),
        content: z.string().min(1),
        parentId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const commentId = await db.createForumComment({
          postId: input.postId,
          userId: ctx.user.id,
          content: input.content,
          parentId: input.parentId,
        });

        return { success: true, commentId };
      }),

    vote: protectedProcedure
      .input(z.object({
        postId: z.number(),
        voteType: z.enum(["up", "down"]),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.voteOnPost(ctx.user.id, input.postId, input.voteType);
        return { success: true };
      }),
  }),

  // ============ STRIPE PAYMENT ROUTER ============
  payment: router({
    createCheckout: protectedProcedure
      .input(z.object({
        items: z.array(z.object({
          productId: z.number(),
          name: z.string(),
          description: z.string().optional(),
          amount: z.number(),
          quantity: z.number(),
          images: z.array(z.string()).optional(),
        })),
        orderId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const origin = ctx.req.headers.origin || 'http://localhost:3000';

        const session = await createCheckoutSession({
          userId: ctx.user.id,
          userEmail: ctx.user.email || '',
          userName: ctx.user.name || '',
          items: input.items,
          successUrl: `${origin}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${origin}/checkout/cancel`,
          metadata: input.orderId ? { order_id: input.orderId.toString() } : {},
        });

        return { checkoutUrl: session.url };
      }),
  }),

  // ============ BLOG ROUTER ============
  blog: router({
    listCategories: publicProcedure.query(async () => {
      return await db.getBlogCategories();
    }),

    listArticles: publicProcedure
      .input(
        z.object({
          categoryId: z.number().optional(),
          status: z.enum(["draft", "published", "archived"]).optional(),
          featured: z.boolean().optional(),
          limit: z.number().default(20),
          offset: z.number().default(0),
        }).optional()
      )
      .query(async ({ input }) => {
        return await db.getBlogArticles(input);
      }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        const article = await db.getBlogArticleBySlug(input.slug);
        if (!article) throw new TRPCError({ code: "NOT_FOUND", message: "Article not found" });
        await db.incrementBlogArticleViews(article.article.id);
        return article;
      }),

    create: protectedProcedure
      .input(
        z.object({
          categoryId: z.number(),
          title: z.string().min(1),
          slug: z.string().min(1),
          excerpt: z.string().optional(),
          content: z.string().min(1),
          coverImage: z.string().optional(),
          tags: z.array(z.string()).optional(),
          status: z.enum(["draft", "published", "archived"]).default("draft"),
          featured: z.boolean().default(false),
          readTime: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can create articles" });
        }

        const result = await db.createBlogArticle({
          authorId: ctx.user.id,
          categoryId: input.categoryId,
          title: input.title,
          slug: input.slug,
          excerpt: input.excerpt,
          content: input.content,
          coverImage: input.coverImage,
          tags: input.tags ? JSON.stringify(input.tags) : null,
          status: input.status,
          featured: input.featured ? 1 : 0,
          readTime: input.readTime || 5,
          publishedAt: input.status === "published" ? new Date() : null,
        });

        return { success: true, articleId: (result as any).insertId };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          categoryId: z.number().optional(),
          title: z.string().optional(),
          slug: z.string().optional(),
          excerpt: z.string().optional(),
          content: z.string().optional(),
          coverImage: z.string().optional(),
          tags: z.array(z.string()).optional(),
          status: z.enum(["draft", "published", "archived"]).optional(),
          featured: z.boolean().optional(),
          readTime: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update articles" });
        }

        const updateData: any = {};
        if (input.categoryId !== undefined) updateData.categoryId = input.categoryId;
        if (input.title !== undefined) updateData.title = input.title;
        if (input.slug !== undefined) updateData.slug = input.slug;
        if (input.excerpt !== undefined) updateData.excerpt = input.excerpt;
        if (input.content !== undefined) updateData.content = input.content;
        if (input.coverImage !== undefined) updateData.coverImage = input.coverImage;
        if (input.tags !== undefined) updateData.tags = JSON.stringify(input.tags);
        if (input.status !== undefined) {
          updateData.status = input.status;
          if (input.status === "published") updateData.publishedAt = new Date();
        }
        if (input.featured !== undefined) updateData.featured = input.featured ? 1 : 0;
        if (input.readTime !== undefined) updateData.readTime = input.readTime;

        await db.updateBlogArticle(input.id, updateData);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can delete articles" });
        }

        await db.deleteBlogArticle(input.id);
        return { success: true };
      }),

    listComments: publicProcedure
      .input(z.object({ articleId: z.number() }))
      .query(async ({ input }) => {
        return await db.getBlogComments(input.articleId);
      }),

    createComment: protectedProcedure
      .input(
        z.object({
          articleId: z.number(),
          content: z.string().min(1),
          parentId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await db.createBlogComment({
          articleId: input.articleId,
          userId: ctx.user.id,
          content: input.content,
          parentId: input.parentId,
        });

        return { success: true, commentId: (result as any).insertId };
      }),
  }),

    // ============ NOTIFICATIONS ROUTER ============
  notifications: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return await db.getUserNotifications(ctx.user.id, input.limit);
      }),
    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.notificationId);
        return { success: true };
      }),
    markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
      await db.markAllNotificationsAsRead(ctx.user.id);
      return { success: true };
    }),
  }),

  // ============ CART ROUTER ============
  cart: router({
    getCart: protectedProcedure.query(async ({ ctx }) => {
      const items = await db.getCartItems(ctx.user.id);
      return { items };
    }),
    addItem: protectedProcedure
      .input(z.object({ productId: z.number(), quantity: z.number().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const cartItemId = await db.addToCart(ctx.user.id, input.productId, input.quantity);
        return { success: true, cartItemId };
      }),
    removeItem: protectedProcedure
      .input(z.object({ cartItemId: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeFromCart(input.cartItemId);
        return { success: true };
      }),
    updateQuantity: protectedProcedure
      .input(z.object({ cartItemId: z.number(), quantity: z.number().min(0) }))
      .mutation(async ({ input }) => {
        await db.updateCartItemQuantity(input.cartItemId, input.quantity);
        return { success: true };
      }),
    clearCart: protectedProcedure.mutation(async ({ ctx }) => {
      await db.clearCart(ctx.user.id);
      return { success: true };
    }),
  }),

  // ============ WISHLIST ROUTER ============
  wishlist: router({
    getWishlist: protectedProcedure.query(async ({ ctx }) => {
      const items = await db.getWishlistItems(ctx.user.id);
      return { items };
    }),
    addItem: protectedProcedure
      .input(z.object({ productId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const wishlistItemId = await db.addToWishlist(ctx.user.id, input.productId);
        return { success: true, wishlistItemId };
      }),
    removeItem: protectedProcedure
      .input(z.object({ wishlistItemId: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeFromWishlist(input.wishlistItemId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
