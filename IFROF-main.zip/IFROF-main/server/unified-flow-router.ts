import { z } from "zod";
import { router, publicProcedure } from "./_core/trpc";
import aiServiceClient from "./lib/ai-service-client";
import { TRPCError } from "@trpc/server";

export const unifiedFlowRouter = router({
  generateProductPage: publicProcedure
    .input(z.object({
      productName: z.string(),
      description: z.string(),
      features: z.array(z.string()),
    }))
    .mutation(async ({ input }) => {
      const result = await aiServiceClient.generateBlogContent(
        `Product Page for ${input.productName}`,
        [input.productName, ...input.features]
      );

      if (!result.success || !result.data) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: result.error || "Failed to generate product page content.",
        });
      }

      return {
        headline: result.data.title,
        body: result.data.content,
        bulletPoints: result.data.seoTags,
        tags: result.data.seoTags,
      };
    }),

  generateAd: publicProcedure
    .input(z.object({
      productName: z.string(),
      description: z.string(),
      features: z.array(z.string()),
    }))
    .mutation(async ({ input }) => {
      const result = await aiServiceClient.draftOutreachEmail(
        input.productName,
        "potential customers",
        `Create a strong ad for ${input.productName} based on its description: ${input.description} and features: ${input.features.join(", ")}`,
        "professional"
      );

      if (!result.success || !result.data) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: result.error || "Failed to generate ad content.",
        });
      }

      return {
        headline: result.data.subject,
        hook: result.data.body.split("\n")[0] || "Grab attention with this amazing product!",
        script: result.data.body,
      };
    }),

  startFlow: publicProcedure
    .input(z.object({
      query: z.string().min(1),
    }))
    .mutation(async ({ input }) => {
      const result = await aiServiceClient.runProductDecisionFlow(input.query);

      if (!result.success || !result.data) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: result.error || "An error occurred while processing your request.",
        });
      }

      return result.data;
    }),
});
