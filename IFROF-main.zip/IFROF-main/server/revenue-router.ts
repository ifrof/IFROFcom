import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { users, protectedOrders, escrowStatuses, analyticsEvents } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { stripe } from "./stripe";
import { ENV } from "./_core/env";

const STRIPE_PRICES = {
  basic_monthly: ENV.stripePriceIds.basicMonthly,
  pro_monthly: ENV.stripePriceIds.proMonthly,
  verified_match_pack: ENV.stripePriceIds.verifiedMatchPack,
};

export const revenueRouter = router({
  /** Get current user's subscription info */
  getSubscription: protectedProcedure.query(async ({ ctx }) => {
    return {
      plan: ctx.user.plan ?? 'free',
      planStatus: ctx.user.planStatus ?? 'active',
      planExpiresAt: ctx.user.planExpiresAt,
      packCredits: ctx.user.verifiedMatchPackCredits ?? 0,
      stripeCustomerId: ctx.user.stripeCustomerId ?? null,
    };
  }),

  /** Create a Stripe Checkout session for subscription */
  createSubscriptionCheckout: protectedProcedure
    .input(z.object({
      plan: z.enum(["basic", "pro"]),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!stripe) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Stripe not configured" });

      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const origin = ctx.req.headers.origin || 'http://localhost:3000';

      // Get or create Stripe customer
      let customerId = ctx.user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: ctx.user.email || undefined,
          name: ctx.user.name || undefined,
          metadata: { userId: ctx.user.id.toString() },
        });
        customerId = customer.id;
        await db.update(users).set({ stripeCustomerId: customerId }).where(eq(users.id, ctx.user.id));
      }

      const priceId = input.plan === 'pro' ? STRIPE_PRICES.pro_monthly : STRIPE_PRICES.basic_monthly;

      // If no price IDs configured, create ad-hoc prices
      const lineItems = priceId ? [{
        price: priceId,
        quantity: 1,
      }] : [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: input.plan === 'pro' ? 'IFROF Pro Plan' : 'IFROF Basic Plan',
            description: input.plan === 'pro'
              ? 'Full access: verified reviews, priority matching, unlimited messaging'
              : 'Essential access: messaging, basic matching, factory passport view',
          },
          unit_amount: input.plan === 'pro' ? 4990 : 990,
          recurring: { interval: 'month' as const },
        },
        quantity: 1,
      }];

      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        line_items: lineItems,
        mode: 'subscription',
        success_url: `${origin}/pricing?success=true&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${origin}/pricing?canceled=true`,
        metadata: {
          user_id: ctx.user.id.toString(),
          plan: input.plan,
        },
      });

      // Track event
      await db.insert(analyticsEvents).values({
        userId: ctx.user.id,
        event: "upgrade_clicked",
        properties: JSON.stringify({ plan: input.plan }),
      });

      return { checkoutUrl: session.url };
    }),

  /** Create a Stripe Checkout for one-time Verified Match Pack */
  createPackCheckout: protectedProcedure.mutation(async ({ ctx }) => {
    if (!stripe) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Stripe not configured" });

    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const origin = ctx.req.headers.origin || 'http://localhost:3000';

    let customerId = ctx.user.stripeCustomerId;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: ctx.user.email || undefined,
        name: ctx.user.name || undefined,
        metadata: { userId: ctx.user.id.toString() },
      });
      customerId = customer.id;
      await db.update(users).set({ stripeCustomerId: customerId }).where(eq(users.id, ctx.user.id));
    }

    const lineItems = STRIPE_PRICES.verified_match_pack ? [{
      price: STRIPE_PRICES.verified_match_pack,
      quantity: 1,
    }] : [{
      price_data: {
        currency: 'usd',
        product_data: {
          name: 'Verified Match Pack',
          description: 'One-time purchase: 1 verified factory review credit',
        },
        unit_amount: 1990, // $19.90
      },
      quantity: 1,
    }];

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: `${origin}/pricing?pack_success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/pricing?canceled=true`,
      metadata: {
        user_id: ctx.user.id.toString(),
        type: 'verified_match_pack',
      },
    });

    return { checkoutUrl: session.url };
  }),

  /** Create customer portal session for managing subscription */
  createPortalSession: protectedProcedure.mutation(async ({ ctx }) => {
    if (!stripe) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Stripe not configured" });

    if (!ctx.user.stripeCustomerId) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "No active subscription" });
    }

    const origin = ctx.req.headers.origin || 'http://localhost:3000';

    const session = await stripe.billingPortal.sessions.create({
      customer: ctx.user.stripeCustomerId,
      return_url: `${origin}/pricing`,
    });

    return { portalUrl: session.url };
  }),

  /** Request Order Protection (managed escrow beta) */
  requestProtection: protectedProcedure
    .input(z.object({
      rfqId: z.number().optional(),
      factoryId: z.number().optional(),
      amountEstimate: z.number().optional(),
      currency: z.string().default("USD"),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(protectedOrders).values({
        buyerId: ctx.user.id,
        rfqId: input.rfqId ?? null,
        factoryId: input.factoryId ?? null,
        status: "requested",
        amountEstimate: input.amountEstimate ?? null,
        currency: input.currency,
        notes: input.notes ?? null,
      }).$returningId();

      // Track event
      await db.insert(analyticsEvents).values({
        userId: ctx.user.id,
        event: "protection_requested",
        properties: JSON.stringify({ protectedOrderId: result[0].id }),
      });

      return { success: true, protectedOrderId: result[0].id };
    }),

  /** List user's protected orders */
  listProtectedOrders: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    return await db
      .select()
      .from(protectedOrders)
      .where(eq(protectedOrders.buyerId, ctx.user.id))
      .orderBy(protectedOrders.createdAt);
  }),
});
