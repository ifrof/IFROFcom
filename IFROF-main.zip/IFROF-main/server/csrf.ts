import crypto from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import { parse as parseCookieHeader } from "cookie";
import { ENV } from "./_core/env";

const CSRF_COOKIE = "ifrof_csrf";
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

function isSecureRequest(req: Request): boolean {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const values = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return values.some(v => v.trim().toLowerCase() === "https");
}

function getAllowedOrigins(): Set<string> {
  const raw = ENV.corsOrigins;
  const origins = new Set(raw.split(",").map(v => v.trim()).filter(Boolean));
  if (!ENV.isProduction) {
    origins.add("http://localhost:3000");
    origins.add("http://127.0.0.1:3000");
    origins.add("http://localhost:5173");
    origins.add("http://127.0.0.1:5173");
  }
  return origins;
}

export function csrfCookieMiddleware(req: Request, res: Response, next: NextFunction) {
  const parsed = parseCookieHeader(req.headers.cookie ?? "");
  const existing = parsed[CSRF_COOKIE];
  if (!existing) {
    const token = crypto.randomBytes(32).toString("hex");
    res.cookie(CSRF_COOKIE, token, {
      httpOnly: false,
      sameSite: "lax",
      secure: isSecureRequest(req),
      path: "/",
    });
    (req as any).csrfToken = token;
  } else {
    (req as any).csrfToken = existing;
  }
  next();
}

export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  if (SAFE_METHODS.has(req.method)) return next();

  // Exempt Stripe raw webhook endpoint (signature verifies authenticity)
  if (req.path === "/api/stripe/webhook") return next();

  const origin = req.headers.origin;
  if (origin) {
    const allowed = getAllowedOrigins();
    if (allowed.size > 0 && !allowed.has(origin)) {
      return res.status(403).json({ error: "Origin not allowed" });
    }
  }

  // If origin is not present (older clients/non-browser), fallback to double-submit token check.
  if (!origin) {
    const parsed = parseCookieHeader(req.headers.cookie ?? "");
    const cookieToken = parsed[CSRF_COOKIE];
    const headerToken = req.headers["x-csrf-token"];
    if (!cookieToken || !headerToken || headerToken !== cookieToken) {
      return res.status(403).json({ error: "Invalid CSRF token" });
    }
  }

  next();
}

export const Csrf = {
  cookieName: CSRF_COOKIE,
};