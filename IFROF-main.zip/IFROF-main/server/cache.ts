/**
 * Redis Cache Layer for IFROF Platform
 * Supports 1M+ users with distributed caching
 */

import Redis from 'ioredis';
import { ENV } from "./_core/env";

// Redis client singleton
let redis: Redis | null = null;

/**
 * Get or create Redis client
 * Falls back to in-memory cache if Redis is not available
 */
export function getRedisClient(): Redis | null {
  if (redis) return redis;

  const redisUrl = ENV.redisUrl;
  
  if (!redisUrl) {
    console.warn('[Cache] REDIS_URL not configured - caching disabled');
    return null;
  }

  try {
    redis = new Redis(redisUrl, {
      maxRetriesPerRequest: 3,
      enableReadyCheck: true,
      lazyConnect: true,
    });

    redis.on('error', (err) => {
      console.error('[Cache] Redis error:', err);
    });

    redis.on('connect', () => {
      console.log('[Cache] Redis connected');
    });

    // Connect asynchronously
    redis.connect().catch((err) => {
      console.error('[Cache] Redis connection failed:', err);
      redis = null;
    });

    return redis;
  } catch (error) {
    console.error('[Cache] Failed to create Redis client:', error);
    return null;
  }
}

/**
 * Cache keys generator
 */
export const CacheKeys = {
  product: (id: number) => `product:${id}`,
  products: (filters: string) => `products:${filters}`,
  category: (id: number) => `category:${id}`,
  categories: () => `categories:all`,
  factory: (id: number) => `factory:${id}`,
  factories: (filters: string) => `factories:${filters}`,
  user: (id: number) => `user:${id}`,
  cart: (userId: number) => `cart:${userId}`,
  wishlist: (userId: number) => `wishlist:${userId}`,
  forumPost: (id: number) => `forum:post:${id}`,
  forumPosts: (category: string, page: number) => `forum:posts:${category}:${page}`,
};

/**
 * Cache TTL (Time To Live) in seconds
 */
export const CacheTTL = {
  product: 300, // 5 minutes
  products: 60, // 1 minute
  category: 3600, // 1 hour
  categories: 3600, // 1 hour
  factory: 600, // 10 minutes
  factories: 300, // 5 minutes
  user: 300, // 5 minutes
  cart: 60, // 1 minute
  wishlist: 300, // 5 minutes
  forumPost: 180, // 3 minutes
  forumPosts: 60, // 1 minute
};

/**
 * Get cached value
 */
export async function getCache<T>(key: string): Promise<T | null> {
  const client = getRedisClient();
  if (!client) return null;

  try {
    const value = await client.get(key);
    if (!value) return null;
    return JSON.parse(value) as T;
  } catch (error) {
    console.error('[Cache] Get error:', error);
    return null;
  }
}

/**
 * Set cached value with TTL
 */
export async function setCache(key: string, value: any, ttl: number): Promise<boolean> {
  const client = getRedisClient();
  if (!client) return false;

  try {
    await client.setex(key, ttl, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error('[Cache] Set error:', error);
    return false;
  }
}

/**
 * Delete cached value
 */
export async function deleteCache(key: string): Promise<boolean> {
  const client = getRedisClient();
  if (!client) return false;

  try {
    await client.del(key);
    return true;
  } catch (error) {
    console.error('[Cache] Delete error:', error);
    return false;
  }
}

/**
 * Delete multiple cached values by pattern
 */
export async function deleteCachePattern(pattern: string): Promise<boolean> {
  const client = getRedisClient();
  if (!client) return false;

  try {
    const keys = await client.keys(pattern);
    if (keys.length > 0) {
      await client.del(...keys);
    }
    return true;
  } catch (error) {
    console.error('[Cache] Delete pattern error:', error);
    return false;
  }
}

/**
 * Increment counter (for rate limiting)
 */
export async function incrementCounter(key: string, ttl: number): Promise<number> {
  const client = getRedisClient();
  if (!client) return 0;

  try {
    const count = await client.incr(key);
    if (count === 1) {
      await client.expire(key, ttl);
    }
    return count;
  } catch (error) {
    console.error('[Cache] Increment error:', error);
    return 0;
  }
}

/**
 * Cache wrapper for database queries
 */
export async function cacheQuery<T>(
  key: string,
  ttl: number,
  queryFn: () => Promise<T>
): Promise<T> {
  // Try to get from cache first
  const cached = await getCache<T>(key);
  if (cached !== null) {
    return cached;
  }

  // Execute query
  const result = await queryFn();

  // Cache the result
  await setCache(key, result, ttl);

  return result;
}
