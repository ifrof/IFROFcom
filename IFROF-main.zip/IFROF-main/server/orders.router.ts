import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { createOrderWithNotifications, updateOrderStatusWithNotifications } from "./services/order.service";

const OrderCreateSchema = z.object({
  items: z.array(
    z.object({
      productId: z.number(),
      quantity: z.number(),
      price: z.number(),
    }),
  ),
  shippingAddress: z.object({
    fullName: z.string(),
    address: z.string(),
    city: z.string(),
    state: z.string(),
    zipCode: z.string(),
    country: z.string(),
    phone: z.string(),
  }),
  shippingMethod: z.string(),
  shippingCost: z.number(),
  totalAmount: z.number(),
  paymentMethod: z.string(),
});

export const ordersRouter = router({
  create: protectedProcedure
    .input(OrderCreateSchema)
    .mutation(async ({ ctx, input }) => {
      const { orderId, orderNumber } = await createOrderWithNotifications({
        userId: ctx.user.id,
        userEmail: ctx.user.email,
        userName: ctx.user.name,
        items: input.items,
        shippingAddress: input.shippingAddress,
        shippingMethod: input.shippingMethod,
        shippingCost: input.shippingCost,
        totalAmount: input.totalAmount,
        paymentMethod: input.paymentMethod,
      });

      return { success: true, orderId, orderNumber };
    }),

  getById: protectedProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ ctx, input }) => {
      const orderData = await db.getOrderById(input.orderId);
      if (!orderData) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

      if (orderData.order.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }

      return orderData;
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return await db.getUserOrders(ctx.user.id);
  }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        orderId: z.number(),
        status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== ("factory" as any)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }

      await updateOrderStatusWithNotifications(input.orderId, input.status);
      return { success: true };
    }),
});
