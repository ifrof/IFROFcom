/**
 * Async Job Queue for IFROF Platform
 * Handles heavy operations asynchronously
 */

import { Queue, Worker, QueueEvents } from 'bullmq';
import { getRedisClient } from './cache';

// Queue names
export const QueueNames = {
  EMAIL: 'email',
  NOTIFICATION: 'notification',
  IMAGE_PROCESSING: 'image-processing',
  VERIFICATION: 'verification',
  ANALYTICS: 'analytics',
};

// Job data types
export interface EmailJob {
  to: string;
  subject: string;
  body: string;
  html?: string;
}

export interface NotificationJob {
  userId: number;
  title: string;
  message: string;
  type: string;
}

export interface ImageProcessingJob {
  imageUrl: string;
  operations: string[];
  outputPath: string;
}

export interface VerificationJob {
  factoryId: number;
  userId: number;
}

/**
 * Create a queue instance
 */
function createQueue(name: string): Queue | null {
  const redisClient = getRedisClient();
  if (!redisClient) {
    console.warn(`[Queue] Redis not available, ${name} queue disabled`);
    return null;
  }

  return new Queue(name, {
    connection: {
      host: redisClient.options.host,
      port: redisClient.options.port,
    },
    defaultJobOptions: {
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 1000,
      },
      removeOnComplete: 100, // Keep last 100 completed jobs
      removeOnFail: 500, // Keep last 500 failed jobs
    },
  });
}

// Queue instances
export const emailQueue = createQueue(QueueNames.EMAIL);
export const notificationQueue = createQueue(QueueNames.NOTIFICATION);
export const imageProcessingQueue = createQueue(QueueNames.IMAGE_PROCESSING);
export const verificationQueue = createQueue(QueueNames.VERIFICATION);
export const analyticsQueue = createQueue(QueueNames.ANALYTICS);

/**
 * Add email job to queue
 */
export async function queueEmail(data: EmailJob) {
  if (!emailQueue) {
    console.warn('[Queue] Email queue not available, skipping');
    return null;
  }

  return await emailQueue.add('send-email', data);
}

/**
 * Add notification job to queue
 */
export async function queueNotification(data: NotificationJob) {
  if (!notificationQueue) {
    console.warn('[Queue] Notification queue not available, skipping');
    return null;
  }

  return await notificationQueue.add('send-notification', data);
}

/**
 * Add image processing job to queue
 */
export async function queueImageProcessing(data: ImageProcessingJob) {
  if (!imageProcessingQueue) {
    console.warn('[Queue] Image processing queue not available, skipping');
    return null;
  }

  return await imageProcessingQueue.add('process-image', data);
}

/**
 * Add verification job to queue
 */
export async function queueVerification(data: VerificationJob) {
  if (!verificationQueue) {
    console.warn('[Queue] Verification queue not available, skipping');
    return null;
  }

  return await verificationQueue.add('verify-factory', data);
}

/**
 * Create workers to process jobs
 * Call this in a separate worker process
 */
export function startWorkers() {
  const redisClient = getRedisClient();
  if (!redisClient) {
    console.warn('[Queue] Redis not available, workers not started');
    return;
  }

  const connection = {
    host: redisClient.options.host,
    port: redisClient.options.port,
  };

  // Email worker
  new Worker(
    QueueNames.EMAIL,
    async (job) => {
      console.log(`[Worker] Processing email job ${job.id}`);
      const { to, subject, body } = job.data as EmailJob;
      // TODO: Implement actual email sending
      console.log(`[Worker] Sending email to ${to}: ${subject}`);
      await new Promise((resolve) => setTimeout(resolve, 1000)); // Simulate work
    },
    { connection }
  );

  // Notification worker
  new Worker(
    QueueNames.NOTIFICATION,
    async (job) => {
      console.log(`[Worker] Processing notification job ${job.id}`);
      const { userId, title, message } = job.data as NotificationJob;
      // TODO: Implement actual notification sending
      console.log(`[Worker] Sending notification to user ${userId}: ${title}`);
      await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate work
    },
    { connection }
  );

  // Image processing worker
  new Worker(
    QueueNames.IMAGE_PROCESSING,
    async (job) => {
      console.log(`[Worker] Processing image job ${job.id}`);
      const { imageUrl, operations } = job.data as ImageProcessingJob;
      // TODO: Implement actual image processing
      console.log(`[Worker] Processing image ${imageUrl} with operations:`, operations);
      await new Promise((resolve) => setTimeout(resolve, 2000)); // Simulate work
    },
    { connection }
  );

  // Verification worker
  new Worker(
    QueueNames.VERIFICATION,
    async (job) => {
      console.log(`[Worker] Processing verification job ${job.id}`);
      const { factoryId, userId } = job.data as VerificationJob;
      // TODO: Implement actual verification logic
      console.log(`[Worker] Verifying factory ${factoryId} for user ${userId}`);
      await new Promise((resolve) => setTimeout(resolve, 3000)); // Simulate work
    },
    { connection }
  );

  console.log('[Queue] All workers started');
}

/**
 * Get queue statistics
 */
export async function getQueueStats(queueName: string) {
  const queue = {
    [QueueNames.EMAIL]: emailQueue,
    [QueueNames.NOTIFICATION]: notificationQueue,
    [QueueNames.IMAGE_PROCESSING]: imageProcessingQueue,
    [QueueNames.VERIFICATION]: verificationQueue,
  }[queueName];

  if (!queue) return null;

  const [waiting, active, completed, failed, delayed] = await Promise.all([
    queue.getWaitingCount(),
    queue.getActiveCount(),
    queue.getCompletedCount(),
    queue.getFailedCount(),
    queue.getDelayedCount(),
  ]);

  return {
    waiting,
    active,
    completed,
    failed,
    delayed,
  };
}
