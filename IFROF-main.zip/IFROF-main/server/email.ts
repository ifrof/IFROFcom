import nodemailer from "nodemailer";
import { ENV } from "./_core/env";

const { host, port: smtpPort, user, pass, from: smtpFrom, secure } = ENV.smtp;

const transporter = nodemailer.createTransport({
  host: host || "mail.ifrof.com",
  port: smtpPort,
  secure,
  auth: user ? { user, pass } : undefined,
  tls: {
    // Always verify TLS certificates — never disable in production
    rejectUnauthorized: ENV.isProduction ? true : false,
    minVersion: "TLSv1.2",
  },
});

const FROM = `"IFROF Sourcing Platform" <${smtpFrom || user || "noreply@ifrof.com"}>`;
const BASE_URL = ENV.frontendUrl;

function wrap(title: string, body: string): string {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/><title>${title}</title>
<style>
body{margin:0;padding:0;background:#f4f6f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;}
.wrap{max-width:600px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,.08);}
.header{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%);padding:32px 40px;text-align:center;}
.logo{color:#22d3ee;font-size:28px;font-weight:800;letter-spacing:-1px;}.logo span{color:#fff;}
.tagline{color:#94a3b8;font-size:12px;margin-top:4px;letter-spacing:2px;text-transform:uppercase;}
.body{padding:36px 40px;}
h1{color:#0f172a;font-size:22px;margin:0 0 16px;}
p{color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px;}
.badge{display:inline-block;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;border-radius:6px;padding:4px 12px;font-size:13px;font-weight:600;margin-bottom:20px;}
.badge.blue{background:#eff6ff;color:#1d4ed8;border-color:#bfdbfe;}
.badge.orange{background:#fff7ed;color:#c2410c;border-color:#fed7aa;}
.info-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:20px 24px;margin:20px 0;}
.info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:14px;}
.info-row:last-child{border-bottom:none;}
.info-label{color:#64748b;font-weight:500;}.info-value{color:#0f172a;font-weight:600;}
.btn{display:inline-block;background:linear-gradient(135deg,#0ea5e9,#0284c7);color:#fff!important;text-decoration:none;padding:14px 32px;border-radius:8px;font-weight:700;font-size:15px;margin:8px 0;}
.footer{background:#f8fafc;border-top:1px solid #e2e8f0;padding:24px 40px;text-align:center;}
.footer p{color:#94a3b8;font-size:12px;margin:4px 0;}.footer a{color:#0ea5e9;text-decoration:none;}
.divider{height:1px;background:#f1f5f9;margin:24px 0;}
</style></head><body>
<div class="wrap">
<div class="header"><div class="logo">IF<span>ROF</span></div><div class="tagline">Global Sourcing Platform</div></div>
<div class="body">${body}</div>
<div class="footer">
<p>&copy; ${new Date().getFullYear()} IFROF Sourcing Platform. All rights reserved.</p>
<p><a href="${BASE_URL}">ifrof.com</a> &middot; <a href="${BASE_URL}/support">Support</a> &middot; <a href="${BASE_URL}/privacy">Privacy</a></p>
<p style="margin-top:12px;color:#cbd5e1;">All transactions are protected by IFROF Escrow. Never pay outside the platform.</p>
</div></div></body></html>`;
}

async function send(to: string, subject: string, html: string) {
  try {
    await transporter.sendMail({ from: FROM, to, subject, html });
    console.log(`[EMAIL] Sent "${subject}" to ${to}`);
  } catch (err) {
    console.error("[EMAIL] Failed to send to", to, ":", (err as Error).message);
  }
}

export async function sendWelcomeEmail(to: string, name: string) {
  const html = wrap("Welcome to IFROF", `
    <div class="badge">🎉 Welcome aboard!</div>
    <h1>Welcome to IFROF, ${name}!</h1>
    <p>You've joined the most trusted B2B sourcing platform connecting global buyers with verified manufacturers.</p>
    <div class="info-box">
      <div class="info-row"><span class="info-label">✅ Verified Factories</span><span class="info-value">340+ manufacturers</span></div>
      <div class="info-row"><span class="info-label">🔒 Escrow Protection</span><span class="info-value">100% secure payments</span></div>
      <div class="info-row"><span class="info-label">🌍 Countries Served</span><span class="info-value">50+ countries</span></div>
      <div class="info-row"><span class="info-label">⭐ Platform Rating</span><span class="info-value">4.9 / 5.0</span></div>
    </div>
    <p>Start by submitting your first <strong>Request for Quotation (RFQ)</strong> — it's free and takes less than 2 minutes.</p>
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${BASE_URL}/rfq">Submit Your First RFQ &rarr;</a></div>
    <p style="font-size:13px;color:#94a3b8;">Need help? Contact us at <a href="mailto:support@ifrof.com" style="color:#0ea5e9;">support@ifrof.com</a></p>
  `);
  await send(to, "Welcome to IFROF — Your Global Sourcing Partner 🌍", html);
}

export async function sendRfqConfirmation(to: string, name: string, rfq: {
  id: number; productName: string; quantity: number; unit: string; targetPrice?: string; deadline?: string;
}) {
  const html = wrap("RFQ Submitted", `
    <div class="badge blue">📋 RFQ Submitted</div>
    <h1>Your RFQ has been received, ${name}!</h1>
    <p>Our team is matching you with verified factories. You'll receive quotes within <strong>24–48 hours</strong>.</p>
    <div class="info-box">
      <div class="info-row"><span class="info-label">RFQ ID</span><span class="info-value">#RFQ-${rfq.id}</span></div>
      <div class="info-row"><span class="info-label">Product</span><span class="info-value">${rfq.productName}</span></div>
      <div class="info-row"><span class="info-label">Quantity</span><span class="info-value">${rfq.quantity.toLocaleString()} ${rfq.unit}</span></div>
      ${rfq.targetPrice ? `<div class="info-row"><span class="info-label">Target Price</span><span class="info-value">${rfq.targetPrice}</span></div>` : ""}
      ${rfq.deadline ? `<div class="info-row"><span class="info-label">Deadline</span><span class="info-value">${rfq.deadline}</span></div>` : ""}
      <div class="info-row"><span class="info-label">Status</span><span class="info-value" style="color:#16a34a;">✅ Active</span></div>
    </div>
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${BASE_URL}/rfq/${rfq.id}">View Your RFQ &rarr;</a></div>
  `);
  await send(to, `RFQ #${rfq.id} Submitted — Matching You with Factories`, html);
}

export async function sendOrderConfirmation(to: string, name: string, order: {
  orderNumber: string; id: number; totalAmount: number;
  items: Array<{ name: string; quantity: number; price: number }>; shippingMethod: string;
}) {
  const itemsHtml = order.items.map(i =>
    `<div class="info-row"><span class="info-label">${i.name} &times; ${i.quantity}</span><span class="info-value">$${(i.price * i.quantity).toFixed(2)}</span></div>`
  ).join("");
  const html = wrap("Order Confirmed", `
    <div class="badge">✅ Order Confirmed</div>
    <h1>Order confirmed, ${name}!</h1>
    <p>Your payment is held securely in <strong>IFROF Escrow</strong> and released only after you confirm delivery.</p>
    <div class="info-box">
      <div class="info-row"><span class="info-label">Order Number</span><span class="info-value">${order.orderNumber}</span></div>
      <div class="info-row"><span class="info-label">Shipping</span><span class="info-value">${order.shippingMethod}</span></div>
      <div class="divider"></div>
      ${itemsHtml}
      <div class="info-row" style="margin-top:8px;"><span class="info-label" style="font-weight:700;">Total</span><span class="info-value" style="color:#0ea5e9;font-size:18px;">$${order.totalAmount.toFixed(2)}</span></div>
    </div>
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${BASE_URL}/orders/${order.id}">Track Your Order &rarr;</a></div>
  `);
  await send(to, `Order ${order.orderNumber} Confirmed — Protected by IFROF Escrow 🔒`, html);
}

export async function sendOrderStatusUpdate(to: string, name: string, order: {
  orderNumber: string; id: number; status: string; message?: string;
}) {
  const statusMap: Record<string, { label: string; color: string; emoji: string }> = {
    pending:    { label: "Pending",     color: "#f59e0b", emoji: "⏳" },
    confirmed:  { label: "Confirmed",   color: "#3b82f6", emoji: "✅" },
    processing: { label: "Processing",  color: "#8b5cf6", emoji: "⚙️" },
    shipped:    { label: "Shipped",     color: "#0ea5e9", emoji: "🚢" },
    delivered:  { label: "Delivered",   color: "#16a34a", emoji: "📦" },
    cancelled:  { label: "Cancelled",   color: "#ef4444", emoji: "❌" },
  };
  const s = statusMap[order.status] || { label: order.status, color: "#64748b", emoji: "📋" };
  const html = wrap(`Order ${order.orderNumber} Update`, `
    <div class="badge" style="color:${s.color};">${s.emoji} Status Updated</div>
    <h1>Order update, ${name}</h1>
    <p>Your order <strong>${order.orderNumber}</strong> status has changed.</p>
    <div class="info-box" style="text-align:center;padding:28px;">
      <div style="font-size:48px;margin-bottom:12px;">${s.emoji}</div>
      <div style="font-size:22px;font-weight:800;color:${s.color};">${s.label}</div>
    </div>
    ${order.message ? `<p>${order.message}</p>` : ""}
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${BASE_URL}/orders/${order.id}">View Order &rarr;</a></div>
  `);
  await send(to, `${s.emoji} Order ${order.orderNumber} — Status: ${s.label}`, html);
}

export async function sendAdminNewRfqAlert(rfq: {
  id: number; productName: string; quantity: number; unit: string;
  userName: string; userEmail: string; country?: string;
}) {
  const html = wrap("New RFQ Received", `
    <div class="badge blue">📋 New RFQ</div>
    <h1>New RFQ #${rfq.id} received</h1>
    <div class="info-box">
      <div class="info-row"><span class="info-label">RFQ ID</span><span class="info-value">#RFQ-${rfq.id}</span></div>
      <div class="info-row"><span class="info-label">Product</span><span class="info-value">${rfq.productName}</span></div>
      <div class="info-row"><span class="info-label">Quantity</span><span class="info-value">${rfq.quantity.toLocaleString()} ${rfq.unit}</span></div>
      <div class="info-row"><span class="info-label">Buyer</span><span class="info-value">${rfq.userName}</span></div>
      <div class="info-row"><span class="info-label">Email</span><span class="info-value">${rfq.userEmail}</span></div>
      ${rfq.country ? `<div class="info-row"><span class="info-label">Country</span><span class="info-value">${rfq.country}</span></div>` : ""}
    </div>
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${BASE_URL}/admin">Review in Admin Panel &rarr;</a></div>
  `);
  await send("info@ifrof.com", `New RFQ #${rfq.id} — ${rfq.productName} (${rfq.quantity} ${rfq.unit})`, html);
}

export async function sendPasswordResetEmail(to: string, resetUrl: string) {
  const html = wrap("Reset Your Password", `
    <div class="badge orange">🔐 Password Reset</div>
    <h1>Reset your password</h1>
    <p>We received a request to reset the password for your IFROF account. Click the button below to set a new password.</p>
    <div style="text-align:center;margin:28px 0;"><a class="btn" href="${resetUrl}">Reset Password &rarr;</a></div>
    <div class="info-box">
      <p style="margin:0;font-size:13px;color:#64748b;">This link expires in <strong>1 hour</strong>. If you didn't request a password reset, you can safely ignore this email — your account is secure.</p>
    </div>
    <p style="font-size:13px;color:#94a3b8;margin-top:20px;">Or copy and paste this link into your browser:<br/><span style="color:#0ea5e9;word-break:break-all;">${resetUrl}</span></p>
  `);
  await send(to, "Reset Your IFROF Password 🔐", html);
}

export default transporter;
