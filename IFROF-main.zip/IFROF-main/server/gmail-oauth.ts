/**
 * Gmail OAuth Configuration
 * Handles Google Sign-In for IFROF Platform
 */

import { OAuth2Client } from 'google-auth-library';
import { ENV } from './_core/env';

const GOOGLE_CLIENT_ID = ENV.googleClientId;
const GOOGLE_CLIENT_SECRET = ENV.googleClientSecret;
const GOOGLE_REDIRECT_URI = `${ENV.frontendUrl.replace(/\/$/, '')}/api/auth/google/callback`;

export const googleOAuthClient = new OAuth2Client(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_REDIRECT_URI
);

/**
 * Generate Google OAuth login URL
 */
export function getGoogleLoginUrl() {
  const scopes = [
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
  ];

  return googleOAuthClient.generateAuthUrl({
    access_type: 'offline',
    scope: scopes,
    prompt: 'consent',
  });
}

/**
 * Exchange authorization code for tokens
 */
export async function exchangeCodeForTokens(code: string) {
  try {
    const { tokens } = await googleOAuthClient.getToken(code);
    return tokens;
  } catch (error) {
    console.error('[Gmail OAuth] Token exchange failed:', error);
    throw new Error('Failed to exchange authorization code');
  }
}

/**
 * Get user info from access token
 */
export async function getGoogleUserInfo(accessToken: string) {
  try {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch user info');
    }

    return await response.json();
  } catch (error) {
    console.error('[Gmail OAuth] Failed to get user info:', error);
    throw new Error('Failed to get user information');
  }
}
