import { eq, desc, and, sql, like } from "drizzle-orm";
import { products, categories, factories } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Get all products with optional filters
 */
export async function getProducts(filters?: {
  categoryId?: number;
  factoryId?: number;
  featured?: string;
  search?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Build conditions
  const conditions = [eq(products.status, "active")];

  if (filters?.categoryId) {
    conditions.push(eq(products.categoryId, filters.categoryId));
  }

  if (filters?.factoryId) {
    conditions.push(eq(products.factoryId, filters.factoryId));
  }

  if (filters?.featured && filters.featured !== "none") {
    conditions.push(eq(products.featured, filters.featured as any));
  }

  if (filters?.search) {
    conditions.push(
      sql`${products.name} LIKE ${`%${filters.search}%`} OR ${products.description} LIKE ${`%${filters.search}%`}`
    );
  }

  let query = db
    .select({
      id: products.id,
      name: products.name,
      description: products.description,
      price: products.price,
      originalPrice: products.originalPrice,
      currency: products.currency,
      unit: products.unit,
      minOrder: products.minOrder,
      stockQuantity: products.stockQuantity,
      images: products.images,
      tags: products.tags,
      status: products.status,
      featured: products.featured,
      views: products.views,
      orders: products.orders,
      rating: products.rating,
      reviewCount: products.reviewCount,
      createdAt: products.createdAt,
      factory: {
        id: factories.id,
        name: factories.name,
        logo: factories.logo,
        verified: factories.verified,
        trustScore: factories.trustScore,
      },
      category: {
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
      },
    })
    .from(products)
    .leftJoin(factories, eq(products.factoryId, factories.id))
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(and(...conditions))
    .orderBy(desc(products.createdAt))
    .$dynamic();

  // Apply pagination
  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  if (filters?.offset) {
    query = query.offset(filters.offset);
  }

  const result = await query;

  // Parse JSON fields
  return result.map(row => ({
    ...row,
    images: row.images ? JSON.parse(row.images) : [],
    tags: row.tags ? JSON.parse(row.tags) : [],
  }));
}

/**
 * Get a single product by ID
 */
export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select({
      id: products.id,
      name: products.name,
      description: products.description,
      price: products.price,
      originalPrice: products.originalPrice,
      currency: products.currency,
      unit: products.unit,
      minOrder: products.minOrder,
      stockQuantity: products.stockQuantity,
      sku: products.sku,
      images: products.images,
      tags: products.tags,
      status: products.status,
      featured: products.featured,
      views: products.views,
      orders: products.orders,
      rating: products.rating,
      reviewCount: products.reviewCount,
      createdAt: products.createdAt,
      updatedAt: products.updatedAt,
      factory: {
        id: factories.id,
        name: factories.name,
        logo: factories.logo,
        verified: factories.verified,
        trustScore: factories.trustScore,
        country: factories.country,
        city: factories.city,
      },
      category: {
        id: categories.id,
        name: categories.name,
        slug: categories.slug,
      },
    })
    .from(products)
    .leftJoin(factories, eq(products.factoryId, factories.id))
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.id, id))
    .limit(1);

  if (result.length === 0) return null;

  const product = result[0];

  // Parse JSON fields
  return {
    ...product,
    images: product.images ? JSON.parse(product.images) : [],
    tags: product.tags ? JSON.parse(product.tags) : [],
  };
}

/**
 * Get all categories
 */
export async function getCategories() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(categories).orderBy(categories.name);
}

/**
 * Increment product views
 */
export async function incrementProductViews(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(products)
    .set({ views: sql`${products.views} + 1` })
    .where(eq(products.id, id));
}
