import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { factorySearches, factoryResults, searchCache } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import * as crypto from "crypto";
import { ENV } from "./_core/env";
import { invokeLLM } from "./_core/llm";

const getStripe = () => {
  if (!ENV.stripeSecretKey) return null;
  const Stripe = require("stripe");
  return new Stripe(ENV.stripeSecretKey, { apiVersion: "2024-12-18.acacia" });
};

const FACTORY_OUTPUT_SCHEMA = `
Return this exact JSON structure:
{
  "factoryName": "Full factory name",
  "contactPerson": "Contact name or null",
  "email": "Email or null",
  "phone": "Phone with country code or null",
  "whatsapp": "WhatsApp number or null",
  "website": "Website URL or null",
  "address": "Full address or null",
  "city": "City name",
  "country": "China",
  "productCategories": ["category1", "category2"],
  "certifications": ["ISO 9001", "CE"],
  "yearEstablished": 2010,
  "employeeCount": 500,
  "trustScore": 75,
  "verificationNote": "Brief note on why this is a factory not a trading company"
}`;

async function searchFactoryBasic(query: string, searchType: string) {
  const result = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "You are a B2B sourcing expert. Find real Chinese manufacturers (not trading companies). Return valid JSON only.",
      },
      {
        role: "user",
        content: `Find a verified Chinese factory for: "${query}" (search type: ${searchType})\n${FACTORY_OUTPUT_SCHEMA}`,
      },
    ],
  });

  const content = result.choices[0]?.message?.content ?? "{}";
  try {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch {}

  return {
    factoryName: query,
    country: "China",
    city: "Unknown",
    productCategories: [],
    certifications: [],
    trustScore: 50,
    verificationNote: "Basic local AI search result",
  };
}

async function searchFactoryPro(query: string, searchType: string) {
  const result = await invokeLLM({
    messages: [
      {
        role: "system",
        content: "You are a senior sourcing analyst. Validate likely factory authenticity using manufacturing indicators, certification clues, and risk markers. Return valid JSON only.",
      },
      {
        role: "user",
        content: `Perform an in-depth factory verification for: "${query}" (search type: ${searchType}).

Requirements:
- prioritize manufacturers with clear production capability signals
- include trustScore from 0 to 100
- include a concise verificationNote with strengths and risks
- do not use markdown

${FACTORY_OUTPUT_SCHEMA}`,
      },
    ],
  });

  const content = result.choices[0]?.message?.content ?? "{}";
  try {
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        ...parsed,
        trustScore: typeof parsed.trustScore === "number" ? Math.max(0, Math.min(100, parsed.trustScore)) : 70,
      };
    }
  } catch {}

  const fallback = await searchFactoryBasic(query, searchType);
  return {
    ...fallback,
    trustScore: Math.max(70, fallback.trustScore ?? 70),
    verificationNote: "Pro local AI verification fallback result",
  };
}

export const factoryFinderRouter = router({
  getPricing: protectedProcedure.query(() => ({
    basic: {
      price: ENV.basicSearchPrice,
      priceDisplay: `$${(ENV.basicSearchPrice / 100).toFixed(2)}`,
      label: "Basic Local AI Search",
      features: ["Ollama-powered", "Factory contact info", "Trust score", "Fast results (30s)"],
    },
    pro: {
      price: ENV.proSearchPrice,
      priceDisplay: `$${(ENV.proSearchPrice / 100).toFixed(2)}`,
      label: "Pro Local AI Verification",
      features: ["Enhanced verification prompt", "Structured risk notes", "Full contact details", "Higher confidence scoring"],
    },
  })),

  createPayment: protectedProcedure
    .input(z.object({
      searchType: z.enum(["text", "link", "image", "hscode", "description"]),
      searchQuery: z.string().min(1),
      tier: z.enum(["basic", "pro"]).default("basic"),
    }))
    .mutation(async ({ input, ctx }) => {
      const { searchType, searchQuery, tier } = input;
      const userId = ctx.user.id;

      const normalizedQuery = searchQuery.trim().toLowerCase();
      const searchHash = crypto.createHash("sha256").update(`${userId}:${tier}:${searchType}:${normalizedQuery}`).digest("hex");

      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const cached = await (db as any).query.searchCache.findFirst({ where: eq(searchCache.searchHash, searchHash) });
      if (cached) {
        const result = await (db as any).query.factoryResults.findFirst({ where: eq(factoryResults.id, cached.resultId) });
        return { cached: true, result };
      }

      const price = tier === "pro" ? ENV.proSearchPrice : ENV.basicSearchPrice;
      const label = tier === "pro" ? "Pro Local AI Factory Verification ($49.9)" : "Basic Local AI Factory Search ($9.9)";

      const insertResult = await db.insert(factorySearches).values({
        userId, searchType, searchQuery: normalizedQuery, searchHash,
        paymentStatus: "pending", status: "pending",
      }).$returningId();
      const searchId = insertResult[0].id;

      const stripe = getStripe();
      if (!stripe) {
        return { cached: false, devMode: true, searchId, message: "Stripe not configured - dev mode" };
      }

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [{
          price_data: {
            currency: "usd",
            product_data: { name: label, description: `Search: ${searchQuery.substring(0, 80)}` },
            unit_amount: price,
          },
          quantity: 1,
        }],
        mode: "payment",
        success_url: `${ENV.frontendUrl}/factory-finder/result?search_id=${searchId}&tier=${tier}&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${ENV.frontendUrl}/factory-finder`,
        metadata: { searchId: searchId.toString(), userId: userId.toString(), searchType, tier },
      });

      return { cached: false, checkoutUrl: session.url, searchId };
    }),

  processSearch: protectedProcedure
    .input(z.object({
      searchId: z.number(),
      tier: z.enum(["basic", "pro"]).default("basic"),
      paymentIntentId: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { searchId, tier } = input;
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const search = await (db as any).query.factorySearches.findFirst({ where: eq(factorySearches.id, searchId) });
      if (!search) throw new Error("Search not found");
      if (search.userId !== ctx.user.id) throw new Error("Unauthorized");

      await db.update(factorySearches).set({ paymentStatus: "paid", status: "processing" }).where(eq(factorySearches.id, searchId));

      try {
        const factoryData = tier === "pro"
          ? await searchFactoryPro(search.searchQuery, search.searchType)
          : await searchFactoryBasic(search.searchQuery, search.searchType);

        const resultInsert = await db.insert(factoryResults).values({
          searchId,
          factoryName: factoryData.factoryName ?? "Unknown Factory",
          contactPerson: factoryData.contactPerson,
          email: factoryData.email,
          phone: factoryData.phone,
          whatsapp: factoryData.whatsapp,
          website: factoryData.website,
          address: factoryData.address,
          city: factoryData.city ?? "China",
          country: factoryData.country ?? "China",
          verificationEvidence: JSON.stringify(factoryData.verificationEvidence ?? factoryData.verificationNote ?? {}),
          productCategories: JSON.stringify(factoryData.productCategories ?? []),
          certifications: JSON.stringify(factoryData.certifications ?? []),
          yearEstablished: factoryData.yearEstablished,
          employeeCount: factoryData.employeeCount,
          trustScore: factoryData.trustScore ?? 70,
          rawData: JSON.stringify({ tier, data: factoryData }),
        }).$returningId();

        const resultId = resultInsert[0].id;

        await db.insert(searchCache).values({
          searchHash: search.searchHash,
          searchType: search.searchType,
          searchQuery: search.searchQuery,
          resultId,
          accessCount: 1,
          lastAccessed: new Date(),
        });

        await db.update(factorySearches).set({ status: "completed", completedAt: new Date() }).where(eq(factorySearches.id, searchId));

        return { success: true, resultId };
      } catch (error) {
        await db.update(factorySearches).set({ status: "failed" }).where(eq(factorySearches.id, searchId));
        throw error;
      }
    }),

  getResult: protectedProcedure
    .input(z.object({ searchId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const search = await (db as any).query.factorySearches.findFirst({ where: eq(factorySearches.id, input.searchId) });
      if (!search) throw new Error("Search not found");
      if (search.userId !== ctx.user.id) throw new Error("Unauthorized");
      const result = await (db as any).query.factoryResults.findFirst({ where: eq(factoryResults.searchId, input.searchId) });
      return { search, result };
    }),

  getHistory: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    return await (db as any).query.factorySearches.findMany({
      where: eq(factorySearches.userId, ctx.user.id),
      orderBy: (t: any, { desc }: any) => [desc(t.createdAt)],
      limit: 50,
    });
  }),
});
