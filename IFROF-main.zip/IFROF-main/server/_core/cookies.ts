import type { CookieOptions, Request } from "express";
import { ENV } from "./env";

function isSecureRequest(req: Request) {
  if (req.protocol === "https") return true;

  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;

  const protoList = Array.isArray(forwardedProto)
    ? forwardedProto
    : forwardedProto.split(",");

  return protoList.some(proto => proto.trim().toLowerCase() === "https");
}

function getSameSite(): "lax" | "strict" | "none" {
  const configured = ENV.sessionSameSite.toLowerCase();
  if (configured === "strict") return "strict";
  if (configured === "none") return "none";
  return "lax";
}

export function getSessionCookieOptions(
  req: Request
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  const secure = isSecureRequest(req);
  const sameSite = getSameSite();

  // Browsers require secure=true when SameSite=None.
  if (sameSite === "none" && !secure) {
    return {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      secure,
    };
  }

  return {
    httpOnly: true,
    path: "/",
    sameSite,
    secure,
  };
}