import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin') {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

// Subscription-gated procedures
function createPlanMiddleware(minimumPlan: 'basic' | 'pro') {
  const planHierarchy: Record<string, number> = { free: 0, basic: 1, pro: 2 };

  return t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
    }

    const userPlan = ctx.user.plan ?? 'free';
    const userPlanLevel = planHierarchy[userPlan] ?? 0;
    const requiredLevel = planHierarchy[minimumPlan];

    if (userPlanLevel < requiredLevel) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: `This feature requires a ${minimumPlan} plan or higher. Please upgrade at /pricing.`,
      });
    }

    return next({ ctx: { ...ctx, user: ctx.user } });
  });
}

/** Requires at least Basic plan ($9.9/mo) */
export const basicProcedure = t.procedure.use(createPlanMiddleware('basic'));

/** Requires Pro plan ($49.9/mo) */
export const proProcedure = t.procedure.use(createPlanMiddleware('pro'));

/**
 * Check if user has Pro OR has a pack credit available.
 * Used for features that can be unlocked with either Pro or a one-time pack purchase.
 */
export const proOrPackProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
    }

    const userPlan = ctx.user.plan ?? 'free';
    const hasPackCredits = (ctx.user.verifiedMatchPackCredits ?? 0) > 0;

    if (userPlan !== 'pro' && !hasPackCredits) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "This feature requires a Pro plan or a Verified Match Pack. Please upgrade at /pricing.",
      });
    }

    return next({ ctx: { ...ctx, user: ctx.user } });
  }),
);
