import { z } from "zod";
import * as crypto from "crypto";

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  VITE_APP_ID: z.string().default(""),
  JWT_SECRET: z.string().default(""),
  DATABASE_URL: z.string().default(""),
  OAUTH_SERVER_URL: z.string().default(""),
  OWNER_OPEN_ID: z.string().default(""),
  FRONTEND_URL: z.string().url().default("http://localhost:3000"),
  CORS_ORIGINS: z.string().optional(),
  SESSION_SAMESITE: z.enum(["lax", "strict", "none"]).default("lax"),
  AI_SERVICE_URL: z.string().url().default("http://localhost:8000"),
  OLLAMA_BASE_URL: z.string().default("http://localhost:11434"),
  OLLAMA_URL: z.string().default(""),
  OLLAMA_MODEL: z.string().default("qwen2.5:14b-instruct"),
  BUILT_IN_FORGE_API_URL: z.string().default(""),
  BUILT_IN_FORGE_API_KEY: z.string().default(""),
  STRIPE_SECRET_KEY: z.string().default(""),
  STRIPE_WEBHOOK_SECRET: z.string().default(""),
  GOOGLE_CLIENT_ID: z.string().default(""),
  GOOGLE_CLIENT_SECRET: z.string().default(""),
  BASIC_SEARCH_PRICE: z.coerce.number().int().positive().default(990),
  PRO_SEARCH_PRICE: z.coerce.number().int().positive().default(4990),
  SMTP_HOST: z.string().default(""),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_USER: z.string().default(""),
  SMTP_PASS: z.string().default(""),
  SMTP_FROM: z.string().default(""),
  SMTP_SECURE: z.coerce.boolean().default(false),
  REDIS_URL: z.string().default("redis://localhost:6379"),
  PORT: z.coerce.number().default(3000),
  AWS_REGION: z.string().default("us-east-1"),
  AWS_ACCESS_KEY_ID: z.string().default(""),
  AWS_SECRET_ACCESS_KEY: z.string().default(""),
  S3_BUCKET_NAME: z.string().default("ifrof-assets"),
  CLOUDFLARE_CDN_URL: z.string().default("https://cdn.ifrof.com"),
  MEILISEARCH_HOST: z.string().default("http://localhost:7700"),
  MEILISEARCH_API_KEY: z.string().default(""),
  REQUIRE_GMAIL_ONLY: z.coerce.boolean().default(false),
  STRIPE_BASIC_PRICE_ID: z.string().default(""),
  STRIPE_PRO_PRICE_ID: z.string().default(""),
  STRIPE_PACK_PRICE_ID: z.string().default(""),
});

const parsed = EnvSchema.safeParse(process.env);
if (!parsed.success) {
  console.error("❌ Invalid environment configuration:");
  console.error(parsed.error.format());
  process.exit(1);
}

const env = parsed.data;
const isDev = env.NODE_ENV === "development";
const isTest = env.NODE_ENV === "test";
const isProd = env.NODE_ENV === "production";

let jwtSecret = env.JWT_SECRET;
if (!jwtSecret) {
  if (isProd) {
    console.error("❌ JWT_SECRET is required in production.");
    process.exit(1);
  }
  jwtSecret = crypto.randomBytes(64).toString("hex");
  console.warn("⚠️  JWT_SECRET not set — generated temporary secret. Sessions reset on restart. Set JWT_SECRET in .env");
}
if (jwtSecret.length < 32) {
  console.error("❌ JWT_SECRET must be at least 32 characters.");
  process.exit(1);
}

if (isProd) {
  const required: [string, string][] = [
    ["DATABASE_URL", env.DATABASE_URL],
    ["FRONTEND_URL", env.FRONTEND_URL],
    ["STRIPE_SECRET_KEY", env.STRIPE_SECRET_KEY],
    ["STRIPE_WEBHOOK_SECRET", env.STRIPE_WEBHOOK_SECRET],
    ["AI_SERVICE_URL", env.AI_SERVICE_URL],
    ["OLLAMA_BASE_URL", env.OLLAMA_BASE_URL],
  ];
  const missing = required.filter(([, v]) => !v).map(([k]) => k);
  if (missing.length > 0) {
    console.error(`❌ Missing required production env vars: ${missing.join(", ")}`);
    process.exit(1);
  }

  const recommended: [string, string][] = [["SMTP_HOST", env.SMTP_HOST]];
  recommended.filter(([, v]) => !v).forEach(([k]) => console.warn(`⚠️  Recommended env var not set: ${k}`));
}

export const ENV = {
  port: env.PORT,
  appId: env.VITE_APP_ID,
  jwtSecret,
  cookieSecret: jwtSecret,
  databaseUrl: env.DATABASE_URL,
  oAuthServerUrl: env.OAUTH_SERVER_URL,
  ownerOpenId: env.OWNER_OPEN_ID,
  isDev,
  isTest,
  isProduction: isProd,
  frontendUrl: env.FRONTEND_URL,
  corsOrigins: env.CORS_ORIGINS ?? env.FRONTEND_URL,
  sessionSameSite: env.SESSION_SAMESITE,
  redisUrl: env.REDIS_URL,
  aiServiceUrl: env.AI_SERVICE_URL,
  ollamaBaseUrl: env.OLLAMA_BASE_URL || env.OLLAMA_URL,
  ollamaUrl: env.OLLAMA_URL || env.OLLAMA_BASE_URL,
  ollamaModel: env.OLLAMA_MODEL,
  forgeApiUrl: env.BUILT_IN_FORGE_API_URL,
  forgeApiKey: env.BUILT_IN_FORGE_API_KEY,
  stripeSecretKey: env.STRIPE_SECRET_KEY,
  stripeWebhookSecret: env.STRIPE_WEBHOOK_SECRET,
  googleClientId: env.GOOGLE_CLIENT_ID,
  googleClientSecret: env.GOOGLE_CLIENT_SECRET,
  basicSearchPrice: env.BASIC_SEARCH_PRICE,
  proSearchPrice: env.PRO_SEARCH_PRICE,
  aws: {
    region: env.AWS_REGION,
    accessKeyId: env.AWS_ACCESS_KEY_ID,
    secretAccessKey: env.AWS_SECRET_ACCESS_KEY,
    bucketName: env.S3_BUCKET_NAME,
    cdnUrl: env.CLOUDFLARE_CDN_URL,
  },
  meilisearch: {
    host: env.MEILISEARCH_HOST,
    apiKey: env.MEILISEARCH_API_KEY,
  },
  requireGmailOnly: env.REQUIRE_GMAIL_ONLY,
  stripePriceIds: {
    basicMonthly: env.STRIPE_BASIC_PRICE_ID,
    proMonthly: env.STRIPE_PRO_PRICE_ID,
    verifiedMatchPack: env.STRIPE_PACK_PRICE_ID,
  },
  smtp: {
    host: env.SMTP_HOST,
    port: env.SMTP_PORT,
    user: env.SMTP_USER,
    pass: env.SMTP_PASS,
    from: env.SMTP_FROM,
    secure: env.SMTP_SECURE || env.SMTP_PORT === 465,
  },
};
