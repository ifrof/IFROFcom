import type { NextFunction, Request, Response } from "express";
import { ENV } from "./env";

const ALLOWED_METHODS = "GET,HEAD,POST,PUT,PATCH,DELETE,OPTIONS";
const ALLOWED_HEADERS = "Content-Type, Authorization, X-CSRF-Token, X-Request-ID";

// Build the allowed-origins set once at startup (not per request)
const ALLOWED_ORIGINS: Set<string> = (() => {
  const origins = new Set(
    ENV.corsOrigins
      .split(",")
      .map((o) => o.trim())
      .filter(Boolean),
  );
  // Always allow localhost in non-production so devs don't need to configure CORS
  if (!ENV.isProduction) {
    origins.add("http://localhost:3000");
    origins.add("http://localhost:5173");
    origins.add("http://127.0.0.1:3000");
    origins.add("http://127.0.0.1:5173");
  }
  return origins;
})();

export function corsMiddleware(req: Request, res: Response, next: NextFunction) {
  const origin = req.headers.origin;

  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Vary", "Origin");
  } else if (origin && ENV.isProduction) {
    // In production, reject unknown origins early for non-preflight
    if (req.method !== "OPTIONS") {
      res.status(403).json({ error: "Origin not allowed" });
      return;
    }
  }

  res.setHeader("Access-Control-Allow-Methods", ALLOWED_METHODS);
  res.setHeader("Access-Control-Allow-Headers", ALLOWED_HEADERS);
  res.setHeader("Access-Control-Max-Age", "86400"); // cache preflight 24h

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  next();
}
