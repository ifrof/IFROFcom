import "dotenv/config";
import express from "express";
import helmet from "helmet";
import { logger } from "../lib/logger";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerGoogleOAuthRoutes } from "../google-auth-routes";
import { registerAuthRoutes } from "../auth-routes";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { handleStripeWebhook } from "../stripe-webhook";
import {
  initRateLimitRedis,
  globalRateLimiter,
  apiRateLimiter,
  authRateLimiter,
  paymentRateLimiter,
} from "../rate-limit";
import { getRedisClient } from "../cache";
import { csrfCookieMiddleware, csrfProtection } from "../csrf";
import { corsMiddleware } from "./cors";
import { ENV } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => server.close(() => resolve(true)));
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) return port;
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  // ── 1. Init external dependencies BEFORE accepting requests ────────────────
  try {
    await initRateLimitRedis();
  } catch (err) {
    logger.warn("[Startup] Redis not available — using in-process rate-limit store:", (err as Error).message);
  }
  getRedisClient(); // warm up cache client

  // ── 2. Express app ─────────────────────────────────────────────────────────
  const app = express();
  const server = createServer(app);

  // Trust proxy (required for rate limiting behind load balancer / Nginx)
  app.set("trust proxy", 1);

  // Security headers
  app.use(
    helmet({
      contentSecurityPolicy: ENV.isProduction
        ? {
            directives: {
              defaultSrc: ["'self'"],
              scriptSrc: ["'self'", "'unsafe-inline'", "https://js.stripe.com"],
              styleSrc: ["'self'", "'unsafe-inline'"],
              imgSrc: ["'self'", "data:", "https:"],
              connectSrc: ["'self'", "https://api.stripe.com"],
              frameSrc: ["https://js.stripe.com"],
            },
          }
        : false,
      crossOriginEmbedderPolicy: false,
    })
  );

  app.use(corsMiddleware);
  app.use(csrfCookieMiddleware);

  // ── 3. Health check (no auth / rate-limit) ─────────────────────────────────
  app.get("/api/health", (_req, res) => {
    res.status(200).json({
      status: "ok",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      env: process.env.NODE_ENV,
    });
  });

  // ── 4. Request logging ─────────────────────────────────────────────────────
  app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => {
      const ms = Date.now() - start;
      if (!req.path.startsWith("/api/trpc/system.healthcheck")) {
        console.log(
          `[${new Date().toISOString()}] ${req.method} ${req.path} ${res.statusCode} ${ms}ms`
        );
      }
    });
    next();
  });

  // ── 5. Global rate limit ───────────────────────────────────────────────────
  app.use(globalRateLimiter);

  // ── 6. Stripe webhook — raw body BEFORE json() ────────────────────────────
  app.post(
    "/api/stripe/webhook",
    paymentRateLimiter,
    express.raw({ type: "application/json" }),
    handleStripeWebhook
  );

  // ── 7. Body parsers ────────────────────────────────────────────────────────
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ limit: "2mb", extended: true }));

  // ── 8. Auth routes (rate-limited, CSRF exempt for login/register) ──────────
  app.use("/api/oauth", authRateLimiter);
  app.use("/api/auth", authRateLimiter);

  // ── 9. CSRF protection on all other mutations ──────────────────────────────
  app.use("/api", csrfProtection);

  // ── 10. OAuth ──────────────────────────────────────────────────────────────
  if (ENV.oAuthServerUrl && ENV.appId) {
    registerOAuthRoutes(app);
  } else {
    app.get("/api/oauth/callback", (_req, res) =>
      res.status(503).json({ error: "OAuth not configured" })
    );
    app.get("/api/oauth/login", (_req, res) =>
      res.status(503).json({ error: "OAuth not configured" })
    );
  }

  if (ENV.googleClientId && ENV.googleClientSecret) {
    registerGoogleOAuthRoutes(app);
  } else {
    app.get("/api/auth/google", (_req, res) =>
      res.status(503).json({ error: "Google OAuth not configured" })
    );
    app.get("/api/auth/google/callback", (_req, res) =>
      res.status(503).json({ error: "Google OAuth not configured" })
    );
  }

  registerAuthRoutes(app);

  // ── 11. SSE notifications ─────────────────────────────────────────────────
  const sseClients = new Map<number, Set<import("http").ServerResponse>>();
  (app as any).__sseClients = sseClients;

  app.get("/api/notifications/stream", (req, res) => {
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": ENV.frontendUrl,
      "Access-Control-Allow-Credentials": "true",
      Vary: "Origin",
    });
    res.write('data: {"type":"connected"}\n\n');
    const ping = setInterval(() => res.write(": ping\n\n"), 30_000);
    req.on("close", () => clearInterval(ping));
  });

  // ── 12. tRPC ──────────────────────────────────────────────────────────────
  app.use(
    "/api/trpc",
    apiRateLimiter,
    createExpressMiddleware({ router: appRouter, createContext })
  );

  // ── 13. Static / Vite ─────────────────────────────────────────────────────
  if (ENV.isDev) {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ── 14. Listen ────────────────────────────────────────────────────────────
  const preferredPort = ENV.port;
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} busy — using ${port}`);
  }

  server.listen(port, () => {
    console.log(`🚀 Server running on http://localhost:${port}/`);
  });
}

startServer().catch((err) => {
  console.error("❌ Server failed to start:", err);
  process.exit(1);
});
