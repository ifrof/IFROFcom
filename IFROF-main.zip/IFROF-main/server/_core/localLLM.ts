/**
 * Local LLM — proxies to Ollama (self-hosted) or falls back to cloud APIs.
 *
 * This module preserves the localChat() interface used by legacy code while
 * routing all inference through the unified invokeLLM() provider chain.
 */
import { invokeLLM } from "./llm";

export type LocalMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

export async function localChat(messages: LocalMessage[]): Promise<string> {
  const result = await invokeLLM({ messages });
  return result.choices[0]?.message?.content ?? "";
}
