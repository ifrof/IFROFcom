/**
 * Database Connection Pooling for High Traffic
 * Optimized for 1M+ users
 */

import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from '../drizzle/schema';
import { ENV } from './_core/env';

let pool: mysql.Pool | null = null;
let db: any | null = null;

/**
 * Create database connection pool
 * Optimized for high concurrency
 */
export function createDbPool() {
  if (pool) return pool;

  const databaseUrl = ENV.databaseUrl;
  if (!databaseUrl) {
    throw new Error('DATABASE_URL is not defined');
  }

  pool = mysql.createPool({
    uri: databaseUrl,
    // Connection pool settings for high traffic
    connectionLimit: 100, // Max 100 concurrent connections (was 5-10)
    waitForConnections: true,
    queueLimit: 0, // Unlimited queue
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    
    // Connection timeout settings
    connectTimeout: 10000, // 10 seconds
    
    // Performance settings
    multipleStatements: false, // Security: prevent SQL injection
    dateStrings: false,
    supportBigNumbers: true,
    bigNumberStrings: false,
    
    // Charset
    charset: 'utf8mb4',
  });

  // Log only when the pool queue is exhausted (a warning signal under high load)
  pool.on('enqueue', () => {
    console.warn('[DB Pool] All connections busy – request queued');
  });

  return pool;
}

/**
 * Get Drizzle ORM instance with connection pool
 */
export function getDbWithPool() {
  if (db) return db;

  const dbPool = createDbPool();
  db = drizzle(dbPool, { schema, mode: 'default' });

  return db;
}

/**
 * Get pool statistics for monitoring
 */
export function getPoolStats() {
  if (!pool) return null;

  return {
    totalConnections: (pool as any)._allConnections?.length || 0,
    freeConnections: (pool as any)._freeConnections?.length || 0,
    queuedRequests: (pool as any)._connectionQueue?.length || 0,
  };
}

/**
 * Close all connections (for graceful shutdown)
 */
export async function closePool() {
  if (pool) {
    await pool.end();
    pool = null;
    db = null;
    console.log('[DB Pool] All connections closed');
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('[DB Pool] SIGTERM received, closing pool...');
  await closePool();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('[DB Pool] SIGINT received, closing pool...');
  await closePool();
  process.exit(0);
});
