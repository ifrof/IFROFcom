/**
 * HTTP Response Caching Middleware
 * Optimizes CDN and browser caching
 */

import { Request, Response, NextFunction } from 'express';

/**
 * Cache control middleware for static assets
 */
export function cacheStatic(req: Request, res: Response, next: NextFunction) {
  // Cache static assets for 1 year
  if (req.url.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)$/)) {
    res.set('Cache-Control', 'public, max-age=31536000, immutable');
  }
  next();
}

/**
 * Cache control middleware for API responses
 */
export function cacheAPI(maxAge: number = 60) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method === 'GET') {
      res.set('Cache-Control', `public, max-age=${maxAge}, s-maxage=${maxAge * 2}`);
    } else {
      res.set('Cache-Control', 'no-store');
    }
    next();
  };
}

/**
 * Cache control for product listings
 */
export const cacheProducts = cacheAPI(300); // 5 minutes

/**
 * Cache control for categories
 */
export const cacheCategories = cacheAPI(3600); // 1 hour

/**
 * Cache control for factory data
 */
export const cacheFactories = cacheAPI(600); // 10 minutes

/**
 * No cache for user-specific data
 */
export function noCache(req: Request, res: Response, next: NextFunction) {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
}

/**
 * Add security headers
 */
export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  // Prevent clickjacking
  res.set('X-Frame-Options', 'SAMEORIGIN');
  
  // Prevent MIME type sniffing
  res.set('X-Content-Type-Options', 'nosniff');
  
  // Enable XSS protection
  res.set('X-XSS-Protection', '1; mode=block');
  
  // Referrer policy
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Content Security Policy (basic)
  res.set('Content-Security-Policy', "default-src 'self'; img-src 'self' data: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';");
  
  next();
}

/**
 * Compression middleware (gzip/brotli)
 */
export function enableCompression(req: Request, res: Response, next: NextFunction) {
  // Modern browsers support brotli
  const acceptEncoding = req.headers['accept-encoding'] || '';
  
  if (acceptEncoding.includes('br')) {
    res.set('Content-Encoding', 'br');
  } else if (acceptEncoding.includes('gzip')) {
    res.set('Content-Encoding', 'gzip');
  }
  
  next();
}

/**
 * ETag support for conditional requests
 */
export function enableETags(req: Request, res: Response, next: NextFunction) {
  // Express automatically generates ETags
  // This middleware just ensures they're enabled
  res.set('ETag', 'strong');
  next();
}
