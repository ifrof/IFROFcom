import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import {
  factories, factoryDocuments, verificationLogs, riskFlags,
  verificationRequests, analyticsEvents,
} from "../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

/**
 * Compute trust level for a factory based on evidence.
 * Returns both a numeric score and an evidence breakdown.
 */
function computeTrustEvidence(factory: any, documents: any[], risks: any[]) {
  let score = 0;
  const evidence: Array<{ label: string; status: 'present' | 'absent' | 'warning'; detail: string }> = [];

  // Business license
  const hasLicense = documents.some(d => d.type === 'business_license' && d.verifiedStatus === 'verified');
  score += hasLicense ? 15 : 0;
  evidence.push({
    label: 'Business License',
    status: hasLicense ? 'present' : 'absent',
    detail: hasLicense ? 'Verified by admin' : 'Not provided',
  });

  // Social Credit Code
  const hasSCC = !!factory.socialCreditCode;
  score += hasSCC ? 15 : 0;
  evidence.push({
    label: 'Unified Social Credit Code',
    status: hasSCC ? 'present' : 'absent',
    detail: hasSCC ? `Code: ${factory.socialCreditCode}` : 'Not provided',
  });

  // Certifications
  const certs = factory.certifications ? JSON.parse(factory.certifications) : [];
  const hasCertDocs = documents.some(d => d.type === 'certification' && d.verifiedStatus === 'verified');
  score += certs.length > 0 ? 10 : 0;
  score += hasCertDocs ? 5 : 0;
  evidence.push({
    label: 'Certifications',
    status: certs.length > 0 ? 'present' : 'absent',
    detail: certs.length > 0 ? `${certs.join(', ')}${hasCertDocs ? ' (documents verified)' : ''}` : 'None uploaded',
  });

  // Years in business
  const years = factory.yearEstablished ? (new Date().getFullYear() - factory.yearEstablished) : 0;
  score += years >= 5 ? 10 : years >= 2 ? 5 : 0;
  evidence.push({
    label: 'Years in Business',
    status: years > 0 ? 'present' : 'absent',
    detail: years > 0 ? `Established ${factory.yearEstablished} (${years} years)` : 'Unknown',
  });

  // Export indicators
  const exports = factory.exportCountries ? JSON.parse(factory.exportCountries) : [];
  score += exports.length > 0 ? 10 : 0;
  evidence.push({
    label: 'Export Experience',
    status: exports.length > 0 ? 'present' : 'absent',
    detail: exports.length > 0 ? `Exports to: ${exports.join(', ')}` : 'No export data',
  });

  // Verification level bonus
  const vLevel = factory.verificationLevel ?? 0;
  score += vLevel * 10;

  // Risk flags penalty
  const openRisks = risks.filter(r => r.status === 'open' || r.status === 'investigating');
  score -= openRisks.length * 15;
  if (openRisks.length > 0) {
    evidence.push({
      label: 'Risk Flags',
      status: 'warning',
      detail: `${openRisks.length} open risk flag(s)`,
    });
  }

  return {
    score: Math.max(0, Math.min(100, score)),
    evidence,
    verificationLevel: vLevel,
    verificationLevelLabel: ['Submitted', 'Document Verified', 'Live Call Verified', 'Third-Party Audit'][vLevel] ?? 'Unknown',
  };
}

export const passportRouter = router({
  /** Get full Factory Passport data */
  getPassport: publicProcedure
    .input(z.object({ factoryId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const factoryResult = await db.select().from(factories).where(eq(factories.id, input.factoryId)).limit(1);
      if (factoryResult.length === 0) throw new TRPCError({ code: "NOT_FOUND", message: "Factory not found" });

      const factory = factoryResult[0];

      const docs = await db
        .select()
        .from(factoryDocuments)
        .where(eq(factoryDocuments.factoryId, input.factoryId))
        .orderBy(desc(factoryDocuments.uploadedAt));

      const risks = await db
        .select()
        .from(riskFlags)
        .where(eq(riskFlags.factoryId, input.factoryId));

      const trust = computeTrustEvidence(factory, docs, risks);

      // Track view if user is logged in
      if (ctx.user) {
        await db.insert(analyticsEvents).values({
          userId: ctx.user.id,
          event: "passport_viewed",
          properties: JSON.stringify({ factoryId: input.factoryId }),
        }).catch(() => {});
      }

      return {
        factory: {
          ...factory,
          capabilities: factory.capabilities ? JSON.parse(factory.capabilities) : [],
          exportCountries: factory.exportCountries ? JSON.parse(factory.exportCountries) : [],
          certifications: factory.certifications ? JSON.parse(factory.certifications) : [],
        },
        documents: docs.map(d => ({
          id: d.id,
          type: d.type,
          label: d.label,
          verifiedStatus: d.verifiedStatus,
          verifiedAt: d.verifiedAt,
          uploadedAt: d.uploadedAt,
          // Only show file URL to admin
          fileUrl: ctx.user?.role === 'admin' ? d.fileUrl : undefined,
        })),
        trust,
        riskFlags: risks.filter(r => r.status !== 'dismissed').map(r => ({
          id: r.id,
          type: r.type,
          description: r.description,
          status: r.status,
          createdAt: r.createdAt,
        })),
      };
    }),

  /** Request verification for a factory */
  requestVerification: protectedProcedure
    .input(z.object({
      factoryId: z.number(),
      reason: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db.insert(verificationRequests).values({
        factoryId: input.factoryId,
        requesterId: ctx.user.id,
        reason: input.reason ?? null,
        status: "pending",
      }).$returningId();

      return { success: true, requestId: result[0].id };
    }),

  /** Report suspicious factory info */
  reportSuspicious: protectedProcedure
    .input(z.object({
      factoryId: z.number(),
      description: z.string().min(10).max(2000),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(riskFlags).values({
        factoryId: input.factoryId,
        type: "user_report",
        description: input.description,
        status: "open",
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

  /** List all factories (for browsing) */
  listFactories: publicProcedure
    .input(z.object({
      category: z.string().optional(),
      limit: z.number().default(20),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let query = db.select().from(factories).$dynamic();

      if (input?.category) {
        query = query.where(eq(factories.category, input.category));
      }

      const result = await query
        .orderBy(desc(factories.verificationLevel), desc(factories.trustScore))
        .limit(input?.limit ?? 20)
        .offset(input?.offset ?? 0);

      return result.map(f => ({
        ...f,
        capabilities: f.capabilities ? JSON.parse(f.capabilities) : [],
        exportCountries: f.exportCountries ? JSON.parse(f.exportCountries) : [],
        certifications: f.certifications ? JSON.parse(f.certifications) : [],
      }));
    }),
});
