import { drizzle } from "drizzle-orm/mysql2";
import { factories, categories, products } from "../drizzle/schema.js";

// Get database connection from environment
const db = drizzle(process.env.DATABASE_URL);

console.log("🌱 Seeding marketplace data...");

// Seed categories
const categoriesToInsert = [
  { name: "Electronics", slug: "electronics", description: "Electronic devices and components", icon: "Zap" },
  { name: "Textiles", slug: "textiles", description: "Fabrics, clothing, and textile products", icon: "Shirt" },
  { name: "Home & Garden", slug: "home-garden", description: "Home and garden products", icon: "Home" },
  { name: "Packaging", slug: "packaging", description: "Packaging materials and boxes", icon: "Package" },
  { name: "Furniture", slug: "furniture", description: "Furniture and home furnishings", icon: "Armchair" },
];

console.log("Inserting categories...");
await db.insert(categories).values(categoriesToInsert);
console.log("✓ Categories inserted");

// Seed factories
const factoriesToInsert = [
  { userId: 1, name: "Shenzhen Audio Tech", description: "Leading manufacturer of audio electronics", city: "Shenzhen", country: "China", verified: "verified", trustScore: 95, subscriptionTier: "premium" },
  { userId: 1, name: "Guangzhou TextileMaster", description: "Premium textile manufacturer", city: "Guangzhou", country: "China", verified: "verified", trustScore: 92, subscriptionTier: "premium" },
  { userId: 1, name: "Shanghai Lighting Co.", description: "Smart lighting solutions", city: "Shanghai", country: "China", verified: "verified", trustScore: 90, subscriptionTier: "free" },
  { userId: 1, name: "Yiwu Metal Products", description: "Metal products and drinkware", city: "Yiwu", country: "China", verified: "verified", trustScore: 88, subscriptionTier: "free" },
  { userId: 1, name: "Dongguan PackPro", description: "Packaging solutions", city: "Dongguan", country: "China", verified: "verified", trustScore: 85, subscriptionTier: "premium" },
  { userId: 1, name: "Foshan FurniCraft", description: "Quality furniture manufacturer", city: "Foshan", country: "China", verified: "verified", trustScore: 87, subscriptionTier: "free" },
  { userId: 1, name: "Shenzhen Mobile Acc.", description: "Mobile accessories", city: "Shenzhen", country: "China", verified: "verified", trustScore: 82, subscriptionTier: "free" },
  { userId: 1, name: "Yiwu SmartHome", description: "Smart home products", city: "Yiwu", country: "China", verified: "verified", trustScore: 84, subscriptionTier: "free" },
];

console.log("Inserting factories...");
await db.insert(factories).values(factoriesToInsert);
console.log("✓ Factories inserted");

// Seed products
const productsToInsert = [
  {
    factoryId: 1,
    categoryId: 1,
    name: "Wireless Bluetooth Earbuds Pro",
    description: "High-quality wireless earbuds with noise cancellation",
    price: 850, // $8.50 in cents
    originalPrice: 1500, // $15.00
    minOrder: 100,
    unit: "pcs",
    stockQuantity: 5000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Electronics", "Audio", "Clearance"]),
    featured: "hot_deal",
    rating: 48,
    reviewCount: 892,
  },
  {
    factoryId: 2,
    categoryId: 2,
    name: "Organic Cotton T-Shirt Blanks",
    description: "Premium organic cotton t-shirts for printing",
    price: 230, // $2.30
    originalPrice: 450,
    minOrder: 500,
    unit: "pcs",
    stockQuantity: 15000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Clothing", "Textile", "Clearance"]),
    featured: "stock_sale",
    rating: 47,
    reviewCount: 1203,
  },
  {
    factoryId: 3,
    categoryId: 1,
    name: "Smart LED Bulb WiFi RGB",
    description: "WiFi-enabled RGB LED bulb with app control",
    price: 120, // $1.20
    minOrder: 200,
    unit: "pcs",
    stockQuantity: 10000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1550985616-10810253b84d?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Electronics", "Lighting"]),
    featured: "top_rated",
    rating: 48,
    reviewCount: 2341,
  },
  {
    factoryId: 4,
    categoryId: 3,
    name: "Stainless Steel Water Bottles",
    description: "Durable stainless steel water bottles",
    price: 350, // $3.50
    originalPrice: 600,
    minOrder: 300,
    unit: "pcs",
    stockQuantity: 8000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Drinkware", "Metal", "Clearance"]),
    featured: "stock_sale",
    rating: 47,
    reviewCount: 789,
  },
  {
    factoryId: 5,
    categoryId: 4,
    name: "Custom Kraft Paper Gift Box",
    description: "Eco-friendly kraft paper gift boxes",
    price: 45, // $0.45
    originalPrice: 80,
    minOrder: 5000,
    unit: "pcs",
    stockQuantity: 25000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Packaging", "Paper", "Clearance"]),
    featured: "stock_sale",
    rating: 45,
    reviewCount: 567,
  },
  {
    factoryId: 6,
    categoryId: 5,
    name: "Ergonomic Office Chair",
    description: "Comfortable ergonomic office chair",
    price: 4500, // $45.00
    minOrder: 50,
    unit: "pcs",
    stockQuantity: 500,
    images: JSON.stringify(["https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Furniture", "Office"]),
    featured: "verified",
    rating: 47,
    reviewCount: 134,
  },
  {
    factoryId: 7,
    categoryId: 1,
    name: "Phone Cases Assorted Styles",
    description: "Variety of phone cases for different models",
    price: 75, // $0.75
    originalPrice: 150,
    minOrder: 500,
    unit: "pcs",
    stockQuantity: 20000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Mobile", "Accessories", "Clearance"]),
    featured: "hot_deal",
    rating: 44,
    reviewCount: 1456,
  },
  {
    factoryId: 8,
    categoryId: 3,
    name: "Bamboo Cutting Board Set",
    description: "Eco-friendly bamboo cutting boards",
    price: 580, // $5.80
    minOrder: 300,
    unit: "pcs",
    stockQuantity: 2000,
    images: JSON.stringify(["https://images.unsplash.com/photo-1594226801341-41427b4e5c22?w=400&h=400&fit=crop"]),
    tags: JSON.stringify(["Kitchen", "Bamboo"]),
    featured: "new",
    rating: 46,
    reviewCount: 87,
  },
];

console.log("Inserting products...");
await db.insert(products).values(productsToInsert);
console.log("✓ Products inserted");

console.log("✅ Marketplace data seeded successfully!");
process.exit(0);
