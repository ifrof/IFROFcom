import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { analyticsEvents } from "../drizzle/schema";

const ALLOWED_EVENTS = [
  "rfq_created", "matches_viewed", "passport_viewed", "message_sent",
  "upgrade_clicked", "subscription_purchased", "pack_purchased",
  "protection_requested",
] as const;

export const analyticsRouter = router({
  /** Track an analytics event */
  track: publicProcedure
    .input(z.object({
      event: z.string().min(1).max(100),
      properties: z.record(z.string(), z.unknown()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { success: true }; // Silently skip if no DB

      await db.insert(analyticsEvents).values({
        userId: ctx.user?.id ?? null,
        event: input.event,
        properties: input.properties ? JSON.stringify(input.properties) : null,
      }).catch(() => {}); // Never fail on analytics

      return { success: true };
    }),
});
