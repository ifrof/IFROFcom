import { Request, Response } from 'express';
import { stripe } from './stripe';
import * as db from './db';
import { getDb } from './db';
import { users, analyticsEvents } from '../drizzle/schema';
import { eq, sql } from 'drizzle-orm';
import { ENV } from './_core/env';

/**
 * Handle Stripe webhook events
 * This must be registered with express.raw() middleware BEFORE express.json()
 */
export async function handleStripeWebhook(req: Request, res: Response) {
  // Stripe webhook is optional - skip if not configured
  if (!ENV.stripeWebhookSecret || !stripe) {
    console.log('[Stripe Webhook] Stripe not configured, skipping webhook');
    return res.json({ received: true });
  }

  const sig = req.headers['stripe-signature'];

  if (!sig) {
    console.error('[Stripe Webhook] No signature found');
    return res.status(400).send('No signature');
  }

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      ENV.stripeWebhookSecret
    );
  } catch (err: any) {
    console.error('[Stripe Webhook] Signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle test events
  if (event.id.startsWith('evt_test_')) {
    console.log('[Stripe Webhook] Test event detected, returning verification response');
    return res.json({ verified: true });
  }

  console.log('[Stripe Webhook] Received event:', event.type, event.id);

  try {
    const drizzleDb = await getDb();

    switch (event.type) {
      // ============ SUBSCRIPTION EVENTS ============
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object as any;
        const customerId = subscription.customer;

        if (!drizzleDb) break;

        const userResult = await drizzleDb.select().from(users).where(eq(users.stripeCustomerId, customerId)).limit(1);
        if (userResult.length === 0) {
          console.warn('[Stripe Webhook] No user found for customer:', customerId);
          break;
        }

        const userId = userResult[0].id;

        // Determine plan from price amount
        const priceAmount = subscription.items?.data?.[0]?.price?.unit_amount ?? 0;
        let plan: 'free' | 'basic' | 'pro' = 'free';
        if (priceAmount >= 4000) plan = 'pro';
        else if (priceAmount >= 500) plan = 'basic';

        // Map subscription status
        let planStatus: 'active' | 'canceled' | 'past_due' | 'trialing' = 'active';
        if (subscription.status === 'canceled' || subscription.status === 'incomplete_expired') planStatus = 'canceled';
        else if (subscription.status === 'past_due') planStatus = 'past_due';
        else if (subscription.status === 'trialing') planStatus = 'trialing';

        const expiresAt = subscription.current_period_end
          ? new Date(subscription.current_period_end * 1000)
          : null;

        await drizzleDb.update(users).set({
          plan,
          planStatus,
          planExpiresAt: expiresAt,
          stripeSubscriptionId: subscription.id,
        }).where(eq(users.id, userId));

        await drizzleDb.insert(analyticsEvents).values({
          userId,
          event: "subscription_purchased",
          properties: JSON.stringify({ plan, subscriptionId: subscription.id }),
        }).catch(() => {});

        console.log(`[Stripe Webhook] User ${userId} subscription updated: ${plan} (${planStatus})`);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as any;
        const customerId = subscription.customer;

        if (!drizzleDb) break;

        const userResult = await drizzleDb.select().from(users).where(eq(users.stripeCustomerId, customerId)).limit(1);
        if (userResult.length === 0) break;

        await drizzleDb.update(users).set({
          plan: 'free',
          planStatus: 'canceled',
          stripeSubscriptionId: null,
        }).where(eq(users.id, userResult[0].id));

        console.log(`[Stripe Webhook] User ${userResult[0].id} subscription canceled`);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as any;
        const customerId = invoice.customer;

        if (!drizzleDb) break;

        const userResult = await drizzleDb.select().from(users).where(eq(users.stripeCustomerId, customerId)).limit(1);
        if (userResult.length > 0) {
          await drizzleDb.update(users).set({ planStatus: 'past_due' }).where(eq(users.id, userResult[0].id));
        }
        break;
      }

      // ============ CHECKOUT EVENTS ============
      case 'checkout.session.completed': {
        const session = event.data.object as any;
        console.log('[Stripe Webhook] Checkout session completed:', session.id);

        const userId = parseInt(session.metadata?.user_id, 10);
        if (!userId) {
          console.error('[Stripe Webhook] No user_id in metadata');
          break;
        }

        // Handle one-time pack purchase
        if (session.metadata?.type === 'verified_match_pack' && drizzleDb) {
          await drizzleDb.execute(
            sql`UPDATE users SET verifiedMatchPackCredits = COALESCE(verifiedMatchPackCredits, 0) + 1 WHERE id = ${userId}`
          );

          await drizzleDb.insert(analyticsEvents).values({
            userId,
            event: "pack_purchased",
            properties: JSON.stringify({ sessionId: session.id }),
          }).catch(() => {});

          console.log(`[Stripe Webhook] Pack credit added for user ${userId}`);
          break;
        }

        // Subscription checkout is handled by customer.subscription.created above
        if (session.mode === 'subscription') break;

        // Handle order payment (existing logic)
        const paymentIntentId = session.payment_intent;
        const orders = await db.getUserOrders(userId);
        const order = orders.find(o => o.paymentIntentId === paymentIntentId);

        if (order) {
          await db.updateOrderStatus(order.id, 'confirmed');

          await db.createNotification({
            userId,
            type: 'payment_success',
            title: 'Payment Successful',
            message: `Your payment for order ${order.orderNumber} has been confirmed.`,
            link: `/orders/${order.id}`,
          });

          console.log('[Stripe Webhook] Order updated:', order.id);
        }

        break;
      }

      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as any;
        console.log('[Stripe Webhook] Payment succeeded:', paymentIntent.id);
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object as any;
        console.log('[Stripe Webhook] Payment failed:', paymentIntent.id);

        const metadata = paymentIntent.metadata;
        if (metadata?.user_id) {
          const userId = parseInt(metadata.user_id, 10);
          await db.createNotification({
            userId,
            type: 'payment_failed',
            title: 'Payment Failed',
            message: 'Your payment could not be processed. Please try again.',
          });
        }
        break;
      }

      default:
        console.log('[Stripe Webhook] Unhandled event type:', event.type);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('[Stripe Webhook] Error processing event:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}
