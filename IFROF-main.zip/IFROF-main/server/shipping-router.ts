/**
 * Shipping Router
 * Provides shipping rate calculation, tracking, and shipment management.
 * Uses a deterministic rate table instead of Math.random().
 */
import { router, publicProcedure, protectedProcedure } from './_core/trpc';
import { z } from 'zod';
import { getDb } from './db';
import { shipments } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

// ---------------------------------------------------------------------------
// Deterministic shipping rate table (replaces the old Math.random() hack)
// Rates are in USD. Key format: "ORIGIN-DESTINATION"
// ---------------------------------------------------------------------------
const SHIPPING_RATES: Record<string, { standard: number; express: number; overnight: number }> = {
  'CN-US': { standard: 45, express: 85, overnight: 150 },
  'CN-EU': { standard: 40, express: 75, overnight: 130 },
  'CN-UK': { standard: 38, express: 72, overnight: 125 },
  'CN-ME': { standard: 30, express: 55, overnight: 95 },
  'CN-AU': { standard: 50, express: 90, overnight: 160 },
  'CN-CA': { standard: 48, express: 88, overnight: 155 },
  'CN-JP': { standard: 20, express: 40, overnight: 70 },
  'CN-KR': { standard: 18, express: 35, overnight: 65 },
  'CN-SG': { standard: 22, express: 42, overnight: 75 },
  'DEFAULT': { standard: 45, express: 85, overnight: 150 },
};

const DELIVERY_DAYS: Record<string, { standard: number; express: number; overnight: number }> = {
  'CN-US': { standard: 7, express: 3, overnight: 1 },
  'CN-EU': { standard: 8, express: 4, overnight: 2 },
  'CN-UK': { standard: 8, express: 4, overnight: 2 },
  'CN-ME': { standard: 6, express: 3, overnight: 1 },
  'CN-AU': { standard: 9, express: 5, overnight: 2 },
  'CN-CA': { standard: 8, express: 4, overnight: 2 },
  'CN-JP': { standard: 4, express: 2, overnight: 1 },
  'CN-KR': { standard: 4, express: 2, overnight: 1 },
  'CN-SG': { standard: 5, express: 2, overnight: 1 },
  'DEFAULT': { standard: 7, express: 3, overnight: 1 },
};

function calculateShippingRate(
  origin: string,
  destination: string,
  weight: number,
): Array<{ carrier: string; service: string; rate: number; estimatedDays: number; currency: string }> {
  const routeKey = `${origin.toUpperCase()}-${destination.toUpperCase()}`;
  const baseRates = SHIPPING_RATES[routeKey] ?? SHIPPING_RATES['DEFAULT'];
  const deliveryDays = DELIVERY_DAYS[routeKey] ?? DELIVERY_DAYS['DEFAULT'];

  // $2 per kg over 5 kg
  const weightSurcharge = Math.max(0, (weight - 5)) * 2;

  return [
    {
      carrier: 'FedEx',
      service: 'Standard',
      rate: Math.round((baseRates.standard + weightSurcharge) * 100) / 100,
      estimatedDays: deliveryDays.standard,
      currency: 'USD',
    },
    {
      carrier: 'DHL',
      service: 'Express',
      rate: Math.round((baseRates.express + weightSurcharge) * 100) / 100,
      estimatedDays: deliveryDays.express,
      currency: 'USD',
    },
    {
      carrier: 'UPS',
      service: 'Overnight',
      rate: Math.round((baseRates.overnight + weightSurcharge) * 100) / 100,
      estimatedDays: deliveryDays.overnight,
      currency: 'USD',
    },
  ];
}

export const shippingRouter = router({
  // Calculate shipping rates
  calculateRates: publicProcedure
    .input(z.object({
      origin: z.string(),
      destination: z.string(),
      weight: z.number().positive(),
      dimensions: z.object({
        length: z.number().positive(),
        width: z.number().positive(),
        height: z.number().positive(),
      }).optional(),
    }))
    .mutation(async ({ input }) => {
      const rates = calculateShippingRate(
        input.origin,
        input.destination,
        input.weight,
      );

      return {
        success: true,
        rates,
        origin: input.origin,
        destination: input.destination,
      };
    }),

  // Get shipping methods
  getShippingMethods: publicProcedure.query(async () => {
    return [
      {
        id: 'standard',
        name: 'Standard Shipping',
        description: 'Delivery in 5-9 business days',
        icon: 'package',
      },
      {
        id: 'express',
        name: 'Express Shipping',
        description: 'Delivery in 2-5 business days',
        icon: 'zap',
      },
      {
        id: 'overnight',
        name: 'Priority Overnight',
        description: 'Next business day delivery',
        icon: 'clock',
      },
    ];
  }),

  // Track shipment
  trackShipment: publicProcedure
    .input(z.object({ trackingNumber: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database unavailable' });
      }

      const [shipment] = await db
        .select()
        .from(shipments)
        .where(eq(shipments.trackingNumber, input.trackingNumber))
        .limit(1);

      if (!shipment) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Shipment not found' });
      }

      return {
        success: true,
        shipment: {
          trackingNumber: shipment.trackingNumber,
          carrier: shipment.carrier,
          status: shipment.status,
          origin: shipment.origin,
          destination: shipment.destination,
          estimatedDelivery: shipment.estimatedDelivery,
          currentLocation: shipment.origin ?? null,
          lastUpdate: shipment.updatedAt,
          events: [
            { date: shipment.createdAt, status: 'Order Placed', location: shipment.origin },
            { date: new Date(Date.now() - 86400000), status: 'In Transit', location: 'Distribution Center' },
            { date: new Date(), status: 'Out for Delivery', location: shipment.destination },
          ],
        },
      };
    }),

  // Estimate delivery date
  estimateDelivery: publicProcedure
    .input(z.object({
      origin: z.string(),
      destination: z.string(),
      shippingMethod: z.enum(['standard', 'express', 'overnight']),
    }))
    .query(async ({ input }) => {
      const routeKey = `${input.origin.toUpperCase()}-${input.destination.toUpperCase()}`;
      const deliveryDays = DELIVERY_DAYS[routeKey] ?? DELIVERY_DAYS['DEFAULT'];
      const days = deliveryDays[input.shippingMethod];
      const estimatedDate = new Date();
      estimatedDate.setDate(estimatedDate.getDate() + days);

      return {
        estimatedDeliveryDate: estimatedDate,
        daysToDeliver: days,
        method: input.shippingMethod,
      };
    }),

  // Create shipment (admin only)
  createShipment: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      carrier: z.string(),
      trackingNumber: z.string(),
      origin: z.string(),
      destination: z.string(),
      weight: z.number(),
      cost: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'Unauthorized' });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database unavailable' });
      }

      const estimatedDelivery = new Date();
      estimatedDelivery.setDate(estimatedDelivery.getDate() + 5);

      await db.insert(shipments).values({
        orderId: input.orderId,
        userId: 0, // Will be set from auth context if available
        carrier: input.carrier,
        trackingNumber: input.trackingNumber,
        origin: input.origin,
        destination: input.destination,
        weight: input.weight ?? null,
        shippingCost: input.cost ?? 0,
        status: 'pending',
        estimatedDelivery,
      });

      return { success: true, message: 'Shipment created' };
    }),
});
