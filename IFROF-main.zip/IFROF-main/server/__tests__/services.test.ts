import { describe, it, expect, beforeEach, vi } from 'vitest';
import { SearchService } from '../services/SearchService';
import { StorageService } from '../services/StorageService';
import { InspectionService } from '../services/InspectionService';

describe('SearchService', () => {
  let searchService: SearchService;

  beforeEach(() => {
    searchService = new SearchService();
  });

  it('should initialize index successfully', async () => {
    const initSpy = vi.spyOn(searchService, 'initializeIndex');
    await searchService.initializeIndex();
    expect(initSpy).toHaveBeenCalled();
  });

  it('should index a single product', async () => {
    const product = {
      id: 1,
      name: 'Test Product',
      description: 'A test product',
      category: 'Electronics',
      price: 99.99,
      rating: 4.5,
      stock: 100,
      supplier: 'Test Supplier',
      country: 'China',
      certifications: ['CE', 'RoHS'],
      tags: ['electronics', 'gadget'],
    };

    const indexSpy = vi.spyOn(searchService, 'indexProduct');
    await searchService.indexProduct(product);
    expect(indexSpy).toHaveBeenCalledWith(product);
  });

  it('should search products with query', async () => {
    const searchSpy = vi.spyOn(searchService, 'search');
    await searchService.search('electronics', 20, 0);
    expect(searchSpy).toHaveBeenCalledWith('electronics', 20, 0);
  });

  it('should filter products by price range', async () => {
    const filterSpy = vi.spyOn(searchService, 'filter');
    await searchService.filter({
      minPrice: 10,
      maxPrice: 100,
      limit: 20,
    });
    expect(filterSpy).toHaveBeenCalled();
  });

  it('should delete product from index', async () => {
    const deleteSpy = vi.spyOn(searchService, 'deleteProduct');
    await searchService.deleteProduct(1);
    expect(deleteSpy).toHaveBeenCalledWith(1);
  });
});

describe('StorageService', () => {
  let storageService: StorageService;

  beforeEach(() => {
    storageService = new StorageService();
  });

  it('should generate CDN URL correctly', () => {
    const key = 'products/test-image.jpg';
    const cdnUrl = storageService.getCdnUrl(key);
    expect(cdnUrl).toContain('cdn.ifrof.com');
    expect(cdnUrl).toContain(key);
  });

  it('should generate S3 URL correctly', () => {
    const key = 'products/test-image.jpg';
    const s3Url = storageService.getS3Url(key);
    expect(s3Url).toContain('s3.amazonaws.com');
    expect(s3Url).toContain(key);
  });

  it('should handle file upload with options', async () => {
    const buffer = Buffer.from('test image data');
    const uploadSpy = vi.spyOn(storageService, 'uploadFile');

    await storageService.uploadFile({
      folder: 'products',
      filename: 'test.jpg',
      mimeType: 'image/jpeg',
      buffer,
      optimize: true,
    });

    expect(uploadSpy).toHaveBeenCalled();
  });

  it('should delete file from S3', async () => {
    const deleteSpy = vi.spyOn(storageService, 'deleteFile');
    await storageService.deleteFile('products/test.jpg');
    expect(deleteSpy).toHaveBeenCalledWith('products/test.jpg');
  });
});

describe('InspectionService', () => {
  let inspectionService: InspectionService;

  beforeEach(() => {
    inspectionService = new InspectionService();
  });

  it('should get audit checklist', () => {
    const checklist = inspectionService.getAuditChecklist('manufacturing');
    expect(checklist).toBeDefined();
    expect(checklist?.category).toBe('Manufacturing Facility');
    expect(checklist?.items.length).toBeGreaterThan(0);
  });

  it('should schedule inspection', async () => {
    const result = await inspectionService.scheduleInspection(1, 1, new Date());
    expect(result.success).toBe(true);
    expect(result.message).toBe('Inspection scheduled');
  });

  it('should calculate inspection score', async () => {
    const score = await inspectionService.calculateInspectionScore(1);
    expect(typeof score).toBe('number');
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(100);
  });

  it('should generate inspection certificate', async () => {
    const result = await inspectionService.generateCertificate(1, 1);
    expect(result.success).toBe(true);
    expect(result.certificateUrl).toContain('certificates');
  });

  it('should return null for invalid checklist category', () => {
    const checklist = inspectionService.getAuditChecklist('invalid');
    expect(checklist).toBeNull();
  });
});

describe('Integration Tests', () => {
  it('should handle full inspection workflow', async () => {
    const inspectionService = new InspectionService();
    
    // 1. Schedule inspection
    const scheduled = await inspectionService.scheduleInspection(1, 1, new Date());
    expect(scheduled.success).toBe(true);

    // 2. Get checklist
    const checklist = inspectionService.getAuditChecklist('manufacturing');
    expect(checklist).toBeDefined();

    // 3. Calculate score
    const score = await inspectionService.calculateInspectionScore(1);
    expect(typeof score).toBe('number');

    // 4. Generate certificate
    const cert = await inspectionService.generateCertificate(1, 1);
    expect(cert.success).toBe(true);
  });

  it('should handle search and filter workflow', async () => {
    const searchService = new SearchService();

    // 1. Initialize index
    await searchService.initializeIndex();

    // 2. Index products
    const products = [
      {
        id: 1,
        name: 'Product 1',
        description: 'Desc 1',
        category: 'Electronics',
        price: 50,
        rating: 4.5,
        stock: 100,
        supplier: 'Supplier 1',
        country: 'China',
        certifications: [],
        tags: [],
      },
    ];
    await searchService.indexProducts(products);

    // 3. Search
    const results = await searchService.search('Product', 10, 0);
    expect(results).toBeDefined();

    // 4. Filter
    const filtered = await searchService.filter({
      minPrice: 40,
      maxPrice: 60,
    });
    expect(filtered).toBeDefined();
  });
});
