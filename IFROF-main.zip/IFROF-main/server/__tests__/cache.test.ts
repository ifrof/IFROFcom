/**
 * Cache Module Tests
 *
 * Tests the pure CacheKeys helpers (no Redis needed) and verifies
 * that getRedisClient returns null when REDIS_URL is not set.
 */
import { describe, it, expect, beforeEach } from "vitest";
import { CacheKeys, getRedisClient } from "../cache";

// ── CacheKeys (pure functions — no I/O) ─────────────────────────────────────

describe("CacheKeys", () => {
  it("product(id) returns 'product:<id>'", () => {
    expect(CacheKeys.product(42)).toBe("product:42");
    expect(CacheKeys.product(1)).toBe("product:1");
  });

  it("products(filters) returns 'products:<filters>'", () => {
    expect(CacheKeys.products("category=electronics")).toBe("products:category=electronics");
    expect(CacheKeys.products("{}")).toBe("products:{}");
  });

  it("category(id) returns 'category:<id>'", () => {
    expect(CacheKeys.category(3)).toBe("category:3");
  });

  it("categories() always returns 'categories:all'", () => {
    expect(CacheKeys.categories()).toBe("categories:all");
  });

  it("factory(id) returns 'factory:<id>'", () => {
    expect(CacheKeys.factory(7)).toBe("factory:7");
  });

  it("factories(filters) returns 'factories:<filters>'", () => {
    expect(CacheKeys.factories("country=CN")).toBe("factories:country=CN");
  });

  it("each product id produces a unique key", () => {
    const keys = [1, 2, 3, 99, 100].map(CacheKeys.product);
    const unique = new Set(keys);
    expect(unique.size).toBe(keys.length);
  });
});

// ── getRedisClient ─────────────────────────────────────────────────────────────

describe("getRedisClient", () => {
  beforeEach(() => {
    // Make sure REDIS_URL is not set so we don't attempt a real connection
    delete process.env.REDIS_URL;
  });

  it("returns null when REDIS_URL is not configured", () => {
    // Since the module caches the Redis instance, and it was never set up
    // in this test environment (no REDIS_URL), getRedisClient returns null.
    const client = getRedisClient();
    expect(client).toBeNull();
  });
});
