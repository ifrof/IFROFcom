/**
 * AI Router Tests
 *
 * Tests the ai.chat endpoint which now uses the full 6-agent AI router.
 * Input: { message, conversationHistory?, userType?, context? }
 * Output: { response, suggestedActions?, needsHumanSupport }
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock invokeLLM so no real API calls are made
const mockInvokeLLM = vi.hoisted(() => vi.fn());
vi.mock("../_core/llm", () => ({ invokeLLM: mockInvokeLLM }));

// Mock Redis cache so tests don't need a Redis connection
vi.mock("../cache", () => ({
  getCache: vi.fn().mockResolvedValue(null),
  setCache: vi.fn().mockResolvedValue(true),
}));

// Mock DB so tests don't need a database
vi.mock("../db", () => ({ getDb: vi.fn().mockResolvedValue(null) }));

import { aiRouter } from "../ai-router";

const mockResponse = (content: string) => ({
  id: "test",
  created: Date.now(),
  model: "test",
  choices: [{ index: 0, message: { role: "assistant" as const, content }, finish_reason: "stop" }],
});

function caller(user: object | null = null) {
  return aiRouter.createCaller({ user, req: {} as any, res: {} as any });
}

describe("ai.chat", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockInvokeLLM.mockResolvedValue(
      mockResponse(JSON.stringify({ response: "مرحباً، كيف يمكنني مساعدتك؟", needsHumanSupport: false }))
    );
  });

  it("returns a reply for a simple user message", async () => {
    const result = await caller().chat({ message: "ما هو الاستيراد من الصين؟" });
    expect(typeof result.response).toBe("string");
    expect(result.response).toBe("مرحباً، كيف يمكنني مساعدتك؟");
  });

  it("works for guests (public endpoint)", async () => {
    const result = await caller(null).chat({ message: "test" });
    expect(result).toHaveProperty("response");
    expect(result).toHaveProperty("needsHumanSupport");
  });

  it("works for authenticated users too", async () => {
    const result = await caller({ id: 1, role: "user", plan: "free" }).chat({
      message: "test",
    });
    expect(result).toHaveProperty("response");
  });

  it("supports multi-turn conversations via conversationHistory", async () => {
    const history = Array.from({ length: 6 }, (_, i) => ({
      role: (i % 2 === 0 ? "user" : "assistant") as "user" | "assistant",
      content: `message ${i}`,
    }));
    const result = await caller().chat({ message: "continue", conversationHistory: history });
    expect(result).toHaveProperty("response");
  });

  it("accepts userType and context", async () => {
    const result = await caller().chat({
      message: "hello",
      userType: "buyer",
      context: { userLanguage: "ar" },
    });
    expect(result).toHaveProperty("response");
  });

  it("falls back gracefully when AI returns plain text instead of JSON", async () => {
    mockInvokeLLM.mockResolvedValue(mockResponse("هذا رد نصي عادي"));
    const result = await caller().chat({ message: "test" });
    expect(typeof result.response).toBe("string");
    expect(result.response).toBe("هذا رد نصي عادي");
  });

  it("rejects empty message", async () => {
    await expect(caller().chat({ message: "" })).rejects.toThrow();
  });

  it("rejects message exceeding 2000 chars", async () => {
    await expect(caller().chat({ message: "x".repeat(2001) })).rejects.toThrow();
  });

  it("rejects invalid userType", async () => {
    await expect(
      caller().chat({ message: "hi", userType: "moderator" as any })
    ).rejects.toThrow();
  });
});
