/**
 * Services Router Tests
 *
 * Covers:
 * - submitInquiry: public, validates required fields
 * - listInquiries: protected + admin role
 * - updateInquiryStatus: protected + admin role
 * - listStockDeals: public static data + category filter
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { servicesRouter } from "../services-router";

function caller(user: object | null) {
  return servicesRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const freeUser = { id: 1, role: "user",  plan: "free" };
const admin    = { id: 9, role: "admin", plan: "pro"  };

function makeDb() {
  return {
    select: vi.fn().mockReturnValue({
      from: vi.fn().mockReturnThis(),
      limit: vi.fn().mockReturnValue({ offset: vi.fn().mockResolvedValue([]) }),
    }),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockResolvedValue([{ insertId: 1 }]),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({ where: vi.fn().mockResolvedValue({}) }),
    }),
  };
}

// ── submitInquiry (public) ────────────────────────────────────────────────────

describe("services.submitInquiry", () => {
  beforeEach(() => vi.clearAllMocks());

  it("allows guests to submit a concierge inquiry", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(guest).submitInquiry({
      serviceType: "concierge",
      name: "Alice",
      email: "alice@example.com",
    });
    expect(result.success).toBe(true);
  });

  it("allows authenticated users to submit an escrow inquiry", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(freeUser).submitInquiry({
      serviceType: "escrow",
      name: "Bob",
      email: "bob@example.com",
      orderValue: "50000",
      factoryName: "Shenzhen Factory Ltd",
    });
    expect(result.success).toBe(true);
  });

  it("rejects missing name", async () => {
    await expect(
      caller(guest).submitInquiry({
        serviceType: "concierge",
        name: "",
        email: "x@x.com",
      })
    ).rejects.toThrow();
  });

  it("rejects invalid email", async () => {
    await expect(
      caller(guest).submitInquiry({
        serviceType: "concierge",
        name: "Alice",
        email: "not-an-email",
      })
    ).rejects.toThrow();
  });

  it("rejects invalid serviceType", async () => {
    await expect(
      caller(guest).submitInquiry({
        serviceType: "invalid_type" as any,
        name: "Alice",
        email: "alice@example.com",
      })
    ).rejects.toThrow();
  });
});

// ── listInquiries (admin only) ────────────────────────────────────────────────

describe("services.listInquiries", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).listInquiries()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    await expect(caller(freeUser).listInquiries()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("returns array for admins", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(admin).listInquiries();
    expect(Array.isArray(result)).toBe(true);
  });
});

// ── updateInquiryStatus (admin only) ─────────────────────────────────────────

describe("services.updateInquiryStatus", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).updateInquiryStatus({ id: 1, status: "contacted" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    await expect(
      caller(freeUser).updateInquiryStatus({ id: 1, status: "contacted" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("returns success for admins", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(admin).updateInquiryStatus({
      id: 1,
      status: "in_progress",
      notes: "Following up",
    });
    expect(result.success).toBe(true);
  });

  it("rejects invalid status values", async () => {
    await expect(
      caller(admin).updateInquiryStatus({ id: 1, status: "unknown_status" as any })
    ).rejects.toThrow();
  });
});

// ── listStockDeals (public static data) ───────────────────────────────────────

describe("services.listStockDeals", () => {
  it("returns all deals with no filter", async () => {
    const deals = await caller(guest).listStockDeals();
    expect(Array.isArray(deals)).toBe(true);
    expect(deals.length).toBeGreaterThan(0);
  });

  it("filters by category when provided", async () => {
    const electronics = await caller(guest).listStockDeals({ category: "Electronics" });
    electronics.forEach((d) => expect(d.category).toBe("Electronics"));
  });

  it("returns all deals when category is 'All'", async () => {
    const all = await caller(guest).listStockDeals({ category: "All" });
    const none = await caller(guest).listStockDeals();
    expect(all.length).toBe(none.length);
  });

  it("returns empty array for unknown category", async () => {
    const result = await caller(guest).listStockDeals({ category: "Rockets" });
    expect(result).toHaveLength(0);
  });

  it("each deal has required pricing fields", async () => {
    const deals = await caller(guest).listStockDeals();
    deals.forEach((d) => {
      expect(d).toHaveProperty("originalPrice");
      expect(d).toHaveProperty("dealPrice");
      expect(d).toHaveProperty("moq");
      expect(d.dealPrice).toBeLessThan(d.originalPrice);
    });
  });
});
