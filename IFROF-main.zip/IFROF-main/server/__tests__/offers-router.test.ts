/**
 * Offers Router Tests
 *
 * Verifies that:
 * - Public endpoints (list, getById) are accessible without auth
 * - Admin-only operations (create, update, delete, adminList) reject non-admins
 * - Authenticated-only operations (toggleLike, addComment, etc.) reject guests
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { offersRouter } from "../offers-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return offersRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const freeUser = { id: 1, role: "user",  plan: "free" };
const admin    = { id: 9, role: "admin", plan: "pro"  };

/** A minimal DB that satisfies ALL select chain patterns used by the offers router.
 *
 * Uses a "thenable chain" so `await` at any depth resolves to `rows`,
 * while every method call (from, leftJoin, where, orderBy, limit, offset)
 * returns the same chain so arbitrary chaining works.
 */
function makeSelectDb(rows: any[] = []) {
  // Build a thenable chain: awaiting it at any point yields `rows`
  const chain: any = {};
  const resolve = (then: any, _reject: any) => Promise.resolve(rows).then(then, _reject);
  chain.then = resolve;
  chain.catch = (fn: any) => Promise.resolve(rows).catch(fn);

  // Every method returns the same chain so you can keep chaining or just await
  ["from", "leftJoin", "where", "orderBy", "limit", "offset", "$dynamic"].forEach(
    (m) => { chain[m] = vi.fn().mockReturnValue(chain); }
  );

  return {
    select: vi.fn().mockReturnValue(chain),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockResolvedValue({ insertId: 1 }),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue({}),
      }),
    }),
    delete: vi.fn().mockReturnValue({
      where: vi.fn().mockResolvedValue({}),
    }),
  };
}

const sampleOffer = {
  id: 1,
  title: "Great Deal",
  content: "Buy now and save!",
  status: "published",
  offerType: "deal",
  tags: null,
  pinned: false,
  publishedAt: new Date(),
  viewsCount: 0,
  likesCount: 0,
  commentsCount: 0,
  sharesCount: 0,
  authorId: 9,
};

// ── Tests ────────────────────────────────────────────────────────────────────

describe("offers.list (public)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("works for unauthenticated guests", async () => {
    const db = makeSelectDb([]);
    mockGetDb.mockResolvedValue(db);
    const result = await caller(guest).list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("works for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeSelectDb([]));
    const result = await caller(freeUser).list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("offers.getById (public)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws NOT_FOUND when offer does not exist", async () => {
    const db = makeSelectDb([]);
    mockGetDb.mockResolvedValue(db);
    await expect(caller(guest).getById({ id: 999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });
});

describe("offers.create (admin only)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).create({ title: "Deal", content: "Some great deal here" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeSelectDb());
    await expect(
      caller(freeUser).create({ title: "Deal", content: "Some great deal here" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("validates minimum title length (3 chars)", async () => {
    await expect(
      caller(admin).create({ title: "Hi", content: "Some great deal here" })
    ).rejects.toThrow();
  });

  it("validates minimum content length (10 chars)", async () => {
    await expect(
      caller(admin).create({ title: "Good Title", content: "short" })
    ).rejects.toThrow();
  });
});

describe("offers.update (admin only)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).update({ id: 1, title: "Updated Title for offer" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeSelectDb());
    await expect(
      caller(freeUser).update({ id: 1, title: "Updated Title for offer" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("offers.delete (admin only)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).delete({ id: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeSelectDb());
    await expect(
      caller(freeUser).delete({ id: 1 })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("offers.toggleLike (requires auth)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).toggleLike({ offerId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});

describe("offers.addComment (requires auth)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).addComment({ offerId: 1, content: "Nice!" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects empty content", async () => {
    await expect(
      caller(freeUser).addComment({ offerId: 1, content: "" })
    ).rejects.toThrow();
  });
});

describe("offers.deleteComment (requires auth)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).deleteComment({ commentId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws NOT_FOUND when comment does not exist", async () => {
    const db = makeSelectDb([]);
    mockGetDb.mockResolvedValue(db);
    await expect(
      caller(freeUser).deleteComment({ commentId: 999 })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("offers.toggleCommentLike (requires auth)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).toggleCommentLike({ commentId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});

describe("offers.adminList (admin only)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).adminList()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue(makeSelectDb());
    await expect(caller(freeUser).adminList()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});

describe("offers.recordShare (public)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("allows anyone to record a share", async () => {
    const db = makeSelectDb();
    mockGetDb.mockResolvedValue(db);
    const result = await caller(guest).recordShare({ offerId: 1 });
    expect(result.success).toBe(true);
  });
});

describe("offers.listComments (public)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("allows guests to list comments", async () => {
    const db = makeSelectDb([]);
    mockGetDb.mockResolvedValue(db);
    const result = await caller(guest).listComments({ offerId: 1 });
    expect(Array.isArray(result)).toBe(true);
  });
});
