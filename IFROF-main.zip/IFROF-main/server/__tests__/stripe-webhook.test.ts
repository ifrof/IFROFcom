/**
 * Stripe Webhook Tests
 *
 * Tests signature verification, plan determination logic,
 * subscription lifecycle, and pack credit allocation.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks (must be hoisted above imports) ────────────────────────────────────

const mockConstructEvent = vi.hoisted(() => vi.fn());
const mockGetDb = vi.hoisted(() => vi.fn());

vi.mock("../stripe", () => ({
  stripe: { webhooks: { constructEvent: mockConstructEvent } },
}));

vi.mock("../db", () => ({
  getDb: mockGetDb,
  getUserOrders: vi.fn().mockResolvedValue([]),
  updateOrderStatus: vi.fn().mockResolvedValue({}),
  createNotification: vi.fn().mockResolvedValue({}),
}));

import { handleStripeWebhook } from "../stripe-webhook";

// ── Helpers ──────────────────────────────────────────────────────────────────

function makeReq(sig: string | undefined = "valid-sig") {
  return {
    headers: sig ? { "stripe-signature": sig } : {},
    body: Buffer.from("{}"),
  } as any;
}

function makeRes() {
  const calls: { statusCode: number; body: unknown }[] = [];
  const res: any = {};

  res.json = vi.fn().mockImplementation((body) => {
    calls.push({ statusCode: 200, body });
    return res;
  });
  res.send = vi.fn().mockImplementation((body) => {
    calls.push({ statusCode: res._code ?? 200, body });
    return res;
  });
  res.status = vi.fn().mockImplementation((code) => {
    res._code = code;
    return { send: res.send, json: res.json };
  });

  return { res, calls };
}

/** Captured value from the last db.update().set(...) call */
let capturedUpdateArgs: any = null;

function makeDb(userRows: any[] = [{ id: 42 }]) {
  capturedUpdateArgs = null;

  const selectChain: any = {
    from: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnValue({
      limit: vi.fn().mockResolvedValue(userRows),
    }),
  };

  const setChain = {
    where: vi.fn().mockResolvedValue({}),
  };

  const updateChain = {
    set: vi.fn().mockImplementation((args: any) => {
      capturedUpdateArgs = args;
      return setChain;
    }),
  };

  return {
    select: vi.fn().mockReturnValue(selectChain),
    update: vi.fn().mockReturnValue(updateChain),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockResolvedValue([{ id: 1 }]),
    }),
    execute: vi.fn().mockResolvedValue({}),
  };
}

function makeSubscriptionEvent(
  type: string,
  priceAmount: number,
  status = "active",
  customerId = "cus_1"
) {
  return {
    id: `evt_live_${Date.now()}`,
    type,
    data: {
      object: {
        id: "sub_1",
        customer: customerId,
        status,
        items: { data: [{ price: { unit_amount: priceAmount } }] },
        current_period_end: null,
      },
    },
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("handleStripeWebhook", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    process.env.STRIPE_WEBHOOK_SECRET = "whsec_test";
  });

  // ── Signature / config guard ──────────────────────────────────────────────

  describe("guard checks", () => {
    it("returns 200 {received:true} when Stripe is not configured", async () => {
      delete process.env.STRIPE_WEBHOOK_SECRET;
      const { res } = makeRes();
      await handleStripeWebhook(makeReq(), res);
      expect(res.json).toHaveBeenCalledWith({ received: true });
    });

    it("returns 400 when the stripe-signature header is missing", async () => {
      const reqNoSig = { headers: {}, body: Buffer.from("{}") } as any;
      const { res } = makeRes();
      await handleStripeWebhook(reqNoSig, res);
      expect(res.status).toHaveBeenCalledWith(400);
    });

    it("returns 400 when signature verification fails", async () => {
      mockConstructEvent.mockImplementation(() => {
        throw new Error("No signatures found matching the expected signature");
      });
      const { res } = makeRes();
      await handleStripeWebhook(makeReq("bad-sig"), res);
      expect(res.status).toHaveBeenCalledWith(400);
    });
  });

  // ── Test events ───────────────────────────────────────────────────────────

  describe("test events", () => {
    it("returns {verified:true} for test events without processing them", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_test_123",
        type: "customer.subscription.created",
        data: { object: {} },
      });
      const db = makeDb();
      mockGetDb.mockResolvedValue(db);
      const { res } = makeRes();
      await handleStripeWebhook(makeReq(), res);
      expect(res.json).toHaveBeenCalledWith({ verified: true });
      expect(db.update).not.toHaveBeenCalled();
    });
  });

  // ── Plan determination logic ──────────────────────────────────────────────

  describe("subscription plan determination", () => {
    it("sets plan to 'pro' when unit_amount >= 4000 cents", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 4990)
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.plan).toBe("pro");
    });

    it("sets plan to 'basic' when 500 <= unit_amount < 4000", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 990)
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.plan).toBe("basic");
    });

    it("sets plan to 'free' when unit_amount < 500", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 0)
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.plan).toBe("free");
    });

    it("sets planStatus to 'active' for active subscriptions", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 4990, "active")
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.planStatus).toBe("active");
    });

    it("sets planStatus to 'past_due' for past_due subscriptions", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 4990, "past_due")
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.planStatus).toBe("past_due");
    });

    it("sets planStatus to 'trialing' for trialing subscriptions", async () => {
      mockConstructEvent.mockReturnValue(
        makeSubscriptionEvent("customer.subscription.updated", 4990, "trialing")
      );
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(capturedUpdateArgs?.planStatus).toBe("trialing");
    });
  });

  // ── Subscription deletion ─────────────────────────────────────────────────

  describe("customer.subscription.deleted", () => {
    it("resets user to free plan with canceled status", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_live_del",
        type: "customer.subscription.deleted",
        data: { object: { id: "sub_del", customer: "cus_1" } },
      });
      mockGetDb.mockResolvedValue(makeDb([{ id: 42 }]));
      const { res } = makeRes();
      await handleStripeWebhook(makeReq(), res);
      expect(capturedUpdateArgs?.plan).toBe("free");
      expect(capturedUpdateArgs?.planStatus).toBe("canceled");
      expect(capturedUpdateArgs?.stripeSubscriptionId).toBeNull();
      expect(res.json).toHaveBeenCalledWith({ received: true });
    });

    it("does nothing when no user matches the customer ID", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_live_del2",
        type: "customer.subscription.deleted",
        data: { object: { id: "sub_x", customer: "cus_unknown" } },
      });
      const db = makeDb([]); // empty — no user found
      mockGetDb.mockResolvedValue(db);
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(db.update).not.toHaveBeenCalled();
    });
  });

  // ── Checkout completed ────────────────────────────────────────────────────

  describe("checkout.session.completed", () => {
    it("calls db.execute to add pack credit for verified_match_pack", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_live_cs",
        type: "checkout.session.completed",
        data: {
          object: {
            id: "cs_1",
            mode: "payment",
            metadata: { user_id: "42", type: "verified_match_pack" },
            payment_intent: null,
          },
        },
      });
      const db = makeDb();
      mockGetDb.mockResolvedValue(db);
      const { res } = makeRes();
      await handleStripeWebhook(makeReq(), res);
      expect(db.execute).toHaveBeenCalled();
      expect(res.json).toHaveBeenCalledWith({ received: true });
    });

    it("skips db.execute for subscription checkout sessions", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_live_cs2",
        type: "checkout.session.completed",
        data: {
          object: {
            id: "cs_2",
            mode: "subscription",
            metadata: { user_id: "42" },
            payment_intent: null,
          },
        },
      });
      const db = makeDb();
      mockGetDb.mockResolvedValue(db);
      await handleStripeWebhook(makeReq(), makeRes().res);
      expect(db.execute).not.toHaveBeenCalled();
    });
  });

  // ── Unknown events ────────────────────────────────────────────────────────

  describe("unknown event types", () => {
    it("returns {received:true} without errors for unhandled event types", async () => {
      mockConstructEvent.mockReturnValue({
        id: "evt_live_unk",
        type: "some.future.event",
        data: { object: {} },
      });
      mockGetDb.mockResolvedValue(makeDb());
      const { res } = makeRes();
      await handleStripeWebhook(makeReq(), res);
      expect(res.json).toHaveBeenCalledWith({ received: true });
    });
  });
});
