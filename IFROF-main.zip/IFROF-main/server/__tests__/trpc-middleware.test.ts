/**
 * tRPC Middleware Tests
 *
 * Tests that authentication and plan-gating middleware enforce
 * the correct access rules without touching the database.
 */
import { describe, it, expect } from "vitest";
import {
  router,
  publicProcedure,
  protectedProcedure,
  adminProcedure,
  basicProcedure,
  proProcedure,
  proOrPackProcedure,
} from "../_core/trpc";

// Minimal test router — one endpoint per middleware type
const testRouter = router({
  public: publicProcedure.query(() => "public"),
  protected: protectedProcedure.query(() => "protected"),
  adminOnly: adminProcedure.query(() => "admin"),
  basicOnly: basicProcedure.query(() => "basic"),
  proOnly: proProcedure.query(() => "pro"),
  proOrPack: proOrPackProcedure.query(() => "proOrPack"),
});

function caller(user: object | null) {
  return testRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest = null;
const freeUser  = { id: 1, role: "user",  plan: "free",  verifiedMatchPackCredits: 0 };
const basicUser = { id: 2, role: "user",  plan: "basic", verifiedMatchPackCredits: 0 };
const proUser   = { id: 3, role: "user",  plan: "pro",   verifiedMatchPackCredits: 0 };
const packUser  = { id: 4, role: "user",  plan: "free",  verifiedMatchPackCredits: 1 };
const admin     = { id: 9, role: "admin", plan: "pro",   verifiedMatchPackCredits: 0 };

// ─── publicProcedure ─────────────────────────────────────────────────────────

describe("publicProcedure", () => {
  it("allows unauthenticated access", async () => {
    expect(await caller(guest).public()).toBe("public");
  });

  it("allows authenticated users", async () => {
    expect(await caller(freeUser).public()).toBe("public");
  });

  it("allows admins", async () => {
    expect(await caller(admin).public()).toBe("public");
  });
});

// ─── protectedProcedure ──────────────────────────────────────────────────────

describe("protectedProcedure", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).protected()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("allows regular authenticated users", async () => {
    expect(await caller(freeUser).protected()).toBe("protected");
  });

  it("allows admins", async () => {
    expect(await caller(admin).protected()).toBe("protected");
  });
});

// ─── adminProcedure ──────────────────────────────────────────────────────────

describe("adminProcedure", () => {
  it("throws FORBIDDEN for guests", async () => {
    await expect(caller(guest).adminOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("throws FORBIDDEN for regular users", async () => {
    await expect(caller(freeUser).adminOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("throws FORBIDDEN for pro users who are not admin role", async () => {
    await expect(caller(proUser).adminOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("allows admin-role users", async () => {
    expect(await caller(admin).adminOnly()).toBe("admin");
  });
});

// ─── basicProcedure ──────────────────────────────────────────────────────────

describe("basicProcedure", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).basicOnly()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws FORBIDDEN for free-plan users", async () => {
    await expect(caller(freeUser).basicOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("allows basic-plan users", async () => {
    expect(await caller(basicUser).basicOnly()).toBe("basic");
  });

  it("allows pro-plan users (higher plan satisfies basic requirement)", async () => {
    expect(await caller(proUser).basicOnly()).toBe("basic");
  });
});

// ─── proProcedure ────────────────────────────────────────────────────────────

describe("proProcedure", () => {
  it("throws FORBIDDEN for free-plan users", async () => {
    await expect(caller(freeUser).proOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("throws FORBIDDEN for basic-plan users", async () => {
    await expect(caller(basicUser).proOnly()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("allows pro-plan users", async () => {
    expect(await caller(proUser).proOnly()).toBe("pro");
  });
});

// ─── proOrPackProcedure ──────────────────────────────────────────────────────

describe("proOrPackProcedure", () => {
  it("throws FORBIDDEN when user has free plan and no pack credits", async () => {
    await expect(caller(freeUser).proOrPack()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("throws FORBIDDEN when user has basic plan and no pack credits", async () => {
    await expect(caller(basicUser).proOrPack()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("allows pro-plan users", async () => {
    expect(await caller(proUser).proOrPack()).toBe("proOrPack");
  });

  it("allows free-plan users who have at least one pack credit", async () => {
    expect(await caller(packUser).proOrPack()).toBe("proOrPack");
  });
});
