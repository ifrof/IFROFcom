/**
 * Revenue Router Tests
 *
 * Tests authentication guards, Stripe-not-configured errors,
 * and read-only endpoints that don't require Stripe.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

// Mock stripe as null (not configured) by default
vi.mock("../stripe", () => ({ stripe: null }));

import { revenueRouter } from "../revenue-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return revenueRouter.createCaller({ user, req: { headers: {} } as any, res: {} as any });
}

const guest     = null;
const freeUser  = { id: 1, role: "user", plan: "free",  planStatus: "active",  planExpiresAt: null, verifiedMatchPackCredits: 0, stripeCustomerId: null, email: "u@test.com", name: "User" };
const proUser   = { id: 2, role: "user", plan: "pro",   planStatus: "active",  planExpiresAt: null, verifiedMatchPackCredits: 0, stripeCustomerId: "cus_123", email: "p@test.com", name: "Pro" };

function makeDb() {
  return {
    select: vi.fn().mockReturnValue({
      from: vi.fn().mockReturnThis(),
      where: vi.fn().mockReturnValue({
        orderBy: vi.fn().mockResolvedValue([]),
      }),
    }),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockResolvedValue([{ id: 1 }]),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue({}),
      }),
    }),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("revenue.getSubscription", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).getSubscription()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns subscription info for authenticated users (no DB needed)", async () => {
    const result = await caller(freeUser).getSubscription();
    expect(result.plan).toBe("free");
    expect(result.planStatus).toBe("active");
    expect(result.packCredits).toBe(0);
  });

  it("returns pro subscription for pro users", async () => {
    const result = await caller(proUser).getSubscription();
    expect(result.plan).toBe("pro");
    expect(result.stripeCustomerId).toBe("cus_123");
  });
});

describe("revenue.createSubscriptionCheckout", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).createSubscriptionCheckout({ plan: "basic" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws INTERNAL_SERVER_ERROR when Stripe is not configured", async () => {
    await expect(
      caller(freeUser).createSubscriptionCheckout({ plan: "basic" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("rejects invalid plan values", async () => {
    await expect(
      caller(freeUser).createSubscriptionCheckout({ plan: "enterprise" as any })
    ).rejects.toThrow();
  });
});

describe("revenue.createPackCheckout", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).createPackCheckout()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws INTERNAL_SERVER_ERROR when Stripe is not configured", async () => {
    await expect(caller(freeUser).createPackCheckout()).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
    });
  });
});

describe("revenue.createPortalSession", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).createPortalSession()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws INTERNAL_SERVER_ERROR when Stripe is not configured", async () => {
    await expect(caller(freeUser).createPortalSession()).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
    });
  });
});

describe("revenue.requestProtection", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).requestProtection({})
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("creates a protected order and returns ID", async () => {
    const db = makeDb();
    db.insert = vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        $returningId: vi.fn().mockResolvedValue([{ id: 55 }]),
      }),
    });
    mockGetDb.mockResolvedValue(db);

    const result = await caller(freeUser).requestProtection({
      rfqId: 10,
      amountEstimate: 5000,
      currency: "USD",
      notes: "Need escrow for this order",
    });

    expect(result.success).toBe(true);
    expect(result.protectedOrderId).toBe(55);
  });
});

describe("revenue.listProtectedOrders", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).listProtectedOrders()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns an array for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(freeUser).listProtectedOrders();
    expect(Array.isArray(result)).toBe(true);
  });
});
