/**
 * Factory Finder Router Tests
 *
 * Verifies authentication guards and data-isolation rules.
 * All procedures require an authenticated user; processSearch and
 * getResult also enforce ownership (userId must match).
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));
vi.mock("../_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: '{"factoryName":"Test Factory","country":"China","city":"Shenzhen","productCategories":[],"certifications":[],"trustScore":75}' } }],
  }),
}));

import { factoryFinderRouter } from "../factory-finder-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return factoryFinderRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const userA    = { id: 1, role: "user", plan: "free", email: "a@test.com" };
const userB    = { id: 2, role: "user", plan: "free", email: "b@test.com" };

function makeDb(overrides: {
  searchRow?: any;
  cacheRow?: any;
} = {}) {
  const searchRow = overrides.searchRow ?? null;
  const cacheRow  = overrides.cacheRow  ?? null;

  return {
    // Drizzle relational API used in this router
    query: {
      factorySearches: {
        findFirst: vi.fn().mockResolvedValue(searchRow),
        findMany: vi.fn().mockResolvedValue([]),
      },
      factoryResults: {
        findFirst: vi.fn().mockResolvedValue(null),
      },
      searchCache: {
        findFirst: vi.fn().mockResolvedValue(cacheRow),
      },
    },
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        $returningId: vi.fn().mockResolvedValue([{ id: 10 }]),
      }),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue({}),
      }),
    }),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("factoryFinder.getPricing", () => {
  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).getPricing()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns pricing for authenticated users (no DB needed)", async () => {
    const result = await caller(userA).getPricing();
    expect(result).toHaveProperty("basic");
    expect(result).toHaveProperty("pro");
    expect(result.basic).toHaveProperty("price");
    expect(result.pro).toHaveProperty("price");
  });
});

describe("factoryFinder.createPayment", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).createPayment({
        searchType: "text",
        searchQuery: "ceramic mugs",
        tier: "basic",
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("returns cached result when search was already performed", async () => {
    const db = makeDb({
      cacheRow: { id: 1, resultId: 99 },
    });
    db.query.factoryResults.findFirst = vi.fn().mockResolvedValue({ id: 99, factoryName: "Test" });
    mockGetDb.mockResolvedValue(db);

    const result = await caller(userA).createPayment({
      searchType: "text",
      searchQuery: "ceramic mugs",
      tier: "basic",
    });

    expect(result.cached).toBe(true);
  });

  it("returns devMode:true when Stripe is not configured (no cache hit)", async () => {
    // No cache hit, Stripe not configured
    const db = makeDb({ cacheRow: null });
    mockGetDb.mockResolvedValue(db);

    const result = await caller(userA).createPayment({
      searchType: "text",
      searchQuery: "unique query abc123xyz",
      tier: "basic",
    });

    expect(result.devMode).toBe(true);
    expect(result.cached).toBe(false);
  });
});

describe("factoryFinder.getResult", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).getResult({ searchId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws when search is not found", async () => {
    mockGetDb.mockResolvedValue(makeDb({ searchRow: null }));
    await expect(
      caller(userA).getResult({ searchId: 999 })
    ).rejects.toThrow("Search not found");
  });

  it("throws when the search belongs to a different user", async () => {
    // Search belongs to userB (id=2), userA (id=1) is requesting
    const db = makeDb({
      searchRow: { id: 5, userId: userB.id, searchQuery: "Widget" },
    });
    mockGetDb.mockResolvedValue(db);

    await expect(caller(userA).getResult({ searchId: 5 })).rejects.toThrow(
      "Unauthorized"
    );
  });

  it("returns search and result when the owner requests it", async () => {
    const db = makeDb({
      searchRow: { id: 5, userId: userA.id, searchQuery: "Ceramic mug" },
    });
    mockGetDb.mockResolvedValue(db);

    const result = await caller(userA).getResult({ searchId: 5 });
    expect(result.search).toBeDefined();
    expect(result.search.userId).toBe(userA.id);
  });
});

describe("factoryFinder.getHistory", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).getHistory()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns history array for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb());
    const result = await caller(userA).getHistory();
    expect(Array.isArray(result)).toBe(true);
  });
});
