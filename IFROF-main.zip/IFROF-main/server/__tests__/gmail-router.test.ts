/**
 * Gmail Router Tests
 *
 * Tests the Google OAuth integration endpoints:
 * - getLoginUrl: throws when OAuth is not configured
 * - callback: validates required code parameter, handles OAuth errors gracefully
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetGoogleLoginUrl     = vi.hoisted(() => vi.fn());
const mockExchangeCodeForTokens = vi.hoisted(() => vi.fn());
const mockGetGoogleUserInfo     = vi.hoisted(() => vi.fn());
const mockUpsertUser            = vi.hoisted(() => vi.fn());
const mockGetUserByOpenId       = vi.hoisted(() => vi.fn());
const mockCreateSessionToken    = vi.hoisted(() => vi.fn());

vi.mock("../gmail-oauth", () => ({
  getGoogleLoginUrl:     mockGetGoogleLoginUrl,
  exchangeCodeForTokens: mockExchangeCodeForTokens,
  getGoogleUserInfo:     mockGetGoogleUserInfo,
}));

vi.mock("../db", () => ({
  upsertUser:      mockUpsertUser,
  getUserByOpenId: mockGetUserByOpenId,
}));

// Mock SDK — the router calls sdk.createSessionToken(openId, opts)
vi.mock("../_core/sdk", () => ({
  sdk: {
    createSessionToken: mockCreateSessionToken,
  },
}));

// Mock cookies helper
vi.mock("../_core/cookies", () => ({
  getSessionCookieOptions: vi.fn().mockReturnValue({ httpOnly: true, sameSite: "lax" }),
}));

import { gmailRouter } from "../gmail-router";

function caller(user: object | null = null) {
  const mockRes = { cookie: vi.fn() };
  return gmailRouter.createCaller({ user, req: { headers: {} } as any, res: mockRes as any });
}

// ── getLoginUrl ───────────────────────────────────────────────────────────────

describe("gmail.getLoginUrl", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns a Google OAuth URL when OAuth is configured", async () => {
    mockGetGoogleLoginUrl.mockReturnValue("https://accounts.google.com/o/oauth2/auth?...");
    const result = await caller().getLoginUrl();
    expect(result.url).toMatch(/^https:\/\/accounts\.google\.com/);
  });

  it("throws INTERNAL_SERVER_ERROR when OAuth is not configured", async () => {
    mockGetGoogleLoginUrl.mockImplementation(() => {
      throw new Error("GOOGLE_CLIENT_ID is not configured");
    });
    await expect(caller().getLoginUrl()).rejects.toMatchObject({
      code: "INTERNAL_SERVER_ERROR",
    });
  });
});

// ── callback ──────────────────────────────────────────────────────────────────

describe("gmail.callback", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects when code is an empty string", async () => {
    await expect(caller().callback({ code: "" })).rejects.toThrow();
  });

  it("throws INTERNAL_SERVER_ERROR when token exchange fails", async () => {
    mockExchangeCodeForTokens.mockRejectedValue(new Error("invalid_grant"));
    await expect(
      caller().callback({ code: "bad-code" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("throws INTERNAL_SERVER_ERROR when access_token is missing in response", async () => {
    mockExchangeCodeForTokens.mockResolvedValue({ access_token: null });
    await expect(
      caller().callback({ code: "valid-code" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("throws INTERNAL_SERVER_ERROR when Google user ID is missing", async () => {
    mockExchangeCodeForTokens.mockResolvedValue({ access_token: "tok_xxx" });
    mockGetGoogleUserInfo.mockResolvedValue({ id: null, email: "user@test.com" });
    await expect(
      caller().callback({ code: "valid-code" })
    ).rejects.toMatchObject({ code: "INTERNAL_SERVER_ERROR" });
  });

  it("creates a session and returns success for valid OAuth flow", async () => {
    mockExchangeCodeForTokens.mockResolvedValue({ access_token: "goog_tok_123" });
    mockGetGoogleUserInfo.mockResolvedValue({
      id: "google-user-id-456",
      email: "alice@gmail.com",
      name: "Alice",
    });
    mockUpsertUser.mockResolvedValue(undefined);
    mockGetUserByOpenId.mockResolvedValue({
      id: 42,
      email: "alice@gmail.com",
      name: "Alice",
    });
    mockCreateSessionToken.mockResolvedValue("jwt_tok_abc");

    const result = await caller().callback({ code: "auth-code-xyz" });

    expect(mockUpsertUser).toHaveBeenCalledWith(
      expect.objectContaining({ openId: "google:google-user-id-456" })
    );
    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
  });
});
