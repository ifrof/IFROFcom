/**
 * Messaging Router Tests
 *
 * Verifies buyer isolation (buyers cannot read each other's conversations),
 * admin access (admins can read all conversations), and authentication guards.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { messagingRouter } from "../messaging-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return messagingRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const buyer1 = { id: 1, role: "user", plan: "free" };
const buyer2 = { id: 2, role: "user", plan: "free" };
const admin  = { id: 9, role: "admin", plan: "pro" };

/**
 * A conversation record owned by a specific buyer.
 */
function makeConversation(buyerId: number, overrides: object = {}) {
  return {
    id: 100,
    buyerId,
    rfqId: null,
    factoryId: null,
    status: "active",
    lastMessageAt: new Date(),
    ...overrides,
  };
}

function makeDb(conv: any = null) {
  const selectChain: any = {
    from: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnValue({
      limit: vi.fn().mockResolvedValue(conv ? [conv] : []),
      orderBy: vi.fn().mockResolvedValue(conv ? [conv] : []),
    }),
    orderBy: vi.fn().mockResolvedValue(conv ? [conv] : []),
    leftJoin: vi.fn().mockReturnThis(),
  };

  return {
    select: vi.fn().mockReturnValue(selectChain),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        $returningId: vi.fn().mockResolvedValue([{ id: 200 }]),
      }),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue({}),
      }),
    }),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("messaging.getOrCreateSupportConversation", () => {
  beforeEach(() => vi.resetAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(null).getOrCreateSupportConversation({})
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("returns existing conversation ID when one already exists for the buyer", async () => {
    const existingConv = makeConversation(buyer1.id, { id: 77 });
    mockGetDb.mockResolvedValue(makeDb(existingConv));

    const result = await caller(buyer1).getOrCreateSupportConversation({});

    expect(result.conversationId).toBe(77);
    expect(result.isNew).toBe(false);
  });

  it("creates a new conversation when none exists", async () => {
    // no existing conversation → empty rows → insert
    const db = makeDb(null);
    mockGetDb.mockResolvedValue(db);

    const result = await caller(buyer1).getOrCreateSupportConversation({});

    expect(result.isNew).toBe(true);
    expect(typeof result.conversationId).toBe("number");
  });
});

describe("messaging.getMessages", () => {
  beforeEach(() => vi.resetAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(null).getMessages({ conversationId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws NOT_FOUND when the conversation does not exist", async () => {
    mockGetDb.mockResolvedValue(makeDb(null));
    await expect(
      caller(buyer1).getMessages({ conversationId: 999 })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("throws FORBIDDEN when buyer tries to read another buyer's conversation", async () => {
    // Conversation belongs to buyer2, but buyer1 is requesting
    const conv = makeConversation(buyer2.id);
    const db = makeDb(conv);
    // Also need to handle the messages select and update
    let selectCallCount = 0;
    const originalSelect = db.select;
    db.select = vi.fn().mockImplementation(() => {
      selectCallCount++;
      if (selectCallCount === 1) {
        // First select: get conversation — returns buyer2's conversation
        return {
          from: vi.fn().mockReturnThis(),
          where: vi.fn().mockReturnValue({
            limit: vi.fn().mockResolvedValue([conv]),
          }),
        };
      }
      // Subsequent selects: messages
      return originalSelect();
    });
    mockGetDb.mockResolvedValue(db);

    await expect(
      caller(buyer1).getMessages({ conversationId: 100 })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("allows an admin to read any conversation regardless of buyerId", async () => {
    // Conversation belongs to buyer1, admin is requesting
    const conv = makeConversation(buyer1.id);
    const db = makeDb(conv);
    let selectCallCount = 0;
    db.select = vi.fn().mockImplementation(() => {
      selectCallCount++;
      if (selectCallCount === 1) {
        return {
          from: vi.fn().mockReturnThis(),
          where: vi.fn().mockReturnValue({
            limit: vi.fn().mockResolvedValue([conv]),
          }),
        };
      }
      // messages select
      return {
        from: vi.fn().mockReturnThis(),
        leftJoin: vi.fn().mockReturnThis(),
        where: vi.fn().mockReturnValue({
          orderBy: vi.fn().mockReturnValue({
            limit: vi.fn().mockReturnValue({
              offset: vi.fn().mockResolvedValue([]),
            }),
          }),
        }),
      };
    });
    mockGetDb.mockResolvedValue(db);

    // Should not throw FORBIDDEN
    const result = await caller(admin).getMessages({ conversationId: 100 });
    expect(result.conversation.id).toBe(100);
  });
});

describe("messaging.sendMessage", () => {
  beforeEach(() => vi.resetAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(null).sendMessage({ conversationId: 1, body: "hello" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws NOT_FOUND when conversation does not exist", async () => {
    mockGetDb.mockResolvedValue(makeDb(null));
    await expect(
      caller(buyer1).sendMessage({ conversationId: 999, body: "hi" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("throws FORBIDDEN when buyer tries to send to another buyer's conversation", async () => {
    const conv = makeConversation(buyer2.id);
    const db = makeDb(conv);
    db.select = vi.fn().mockReturnValue({
      from: vi.fn().mockReturnThis(),
      where: vi.fn().mockReturnValue({
        limit: vi.fn().mockResolvedValue([conv]),
      }),
    });
    mockGetDb.mockResolvedValue(db);

    await expect(
      caller(buyer1).sendMessage({ conversationId: 100, body: "hi" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects messages with empty body", async () => {
    await expect(
      caller(buyer1).sendMessage({ conversationId: 1, body: "" })
    ).rejects.toThrow();
  });
});

describe("messaging admin procedures", () => {
  beforeEach(() => vi.resetAllMocks());

  it("adminListConversations throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(buyer1).adminListConversations()
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("adminReply throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(buyer1).adminReply({ conversationId: 1, body: "hello" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
