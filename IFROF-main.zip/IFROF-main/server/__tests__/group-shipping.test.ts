/**
 * Unit tests for Group Container Shipping business logic
 * Tests the core calculation and validation functions
 */

import { describe, it, expect } from "vitest";

// ── Pure helper functions extracted for testing ────────────────────────────

function generateBookingRef(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let ref = "GS-";
  for (let i = 0; i < 8; i++) ref += chars[Math.floor(Math.random() * chars.length)];
  return ref;
}

function calculateTotalPrice(cbmTenths: number, pricePerCbm: number): number {
  return Math.round((cbmTenths * pricePerCbm) / 10);
}

function getShipmentStatus(usedCbm: number, totalCbm: number): string {
  if (usedCbm >= totalCbm) return "full";
  if (usedCbm >= totalCbm * 0.5) return "filling";
  return "open";
}

function cbmDecimalToTenths(cbm: number): number {
  return Math.round(cbm * 10);
}

function fillPercent(usedCbm: number, totalCbm: number): number {
  return Math.round((usedCbm / totalCbm) * 100);
}

// ── Tests ──────────────────────────────────────────────────────────────────

describe("Group Shipping — Booking Reference", () => {
  it("generates a reference starting with GS-", () => {
    const ref = generateBookingRef();
    expect(ref.startsWith("GS-")).toBe(true);
  });

  it("generates a reference with correct total length (GS- + 8 chars = 11)", () => {
    const ref = generateBookingRef();
    expect(ref.length).toBe(11);
  });

  it("generates unique references", () => {
    const refs = new Set(Array.from({ length: 100 }, () => generateBookingRef()));
    expect(refs.size).toBeGreaterThan(90); // Very unlikely to have >10 collisions in 100
  });
});

describe("Group Shipping — Price Calculation", () => {
  it("calculates correct total for 1.5 CBM at $80/CBM", () => {
    // 1.5 CBM = 15 tenths, pricePerCbm = 8000 cents ($80)
    const total = calculateTotalPrice(15, 8000);
    expect(total).toBe(12000); // $120.00
  });

  it("calculates correct total for 5 CBM at $65/CBM", () => {
    // 5 CBM = 50 tenths, pricePerCbm = 6500 cents ($65)
    const total = calculateTotalPrice(50, 6500);
    expect(total).toBe(32500); // $325.00
  });

  it("calculates correct total for 0.5 CBM at $100/CBM", () => {
    // 0.5 CBM = 5 tenths, pricePerCbm = 10000 cents ($100)
    const total = calculateTotalPrice(5, 10000);
    expect(total).toBe(5000); // $50.00
  });

  it("handles fractional CBM correctly", () => {
    // 2.3 CBM = 23 tenths, pricePerCbm = 7500 cents ($75)
    const total = calculateTotalPrice(23, 7500);
    expect(total).toBe(17250); // $172.50
  });
});

describe("Group Shipping — CBM Conversion", () => {
  it("converts 1.5 CBM to 15 tenths", () => {
    expect(cbmDecimalToTenths(1.5)).toBe(15);
  });

  it("converts 10 CBM to 100 tenths", () => {
    expect(cbmDecimalToTenths(10)).toBe(100);
  });

  it("converts 0.1 CBM to 1 tenth", () => {
    expect(cbmDecimalToTenths(0.1)).toBe(1);
  });

  it("rounds correctly for floating point", () => {
    expect(cbmDecimalToTenths(2.35)).toBe(24); // rounds to nearest
  });
});

describe("Group Shipping — Status Logic", () => {
  it("returns 'open' when less than 50% full", () => {
    // 670 total (67 CBM), 200 used (20 CBM) = 29.8%
    expect(getShipmentStatus(200, 670)).toBe("open");
  });

  it("returns 'filling' when 50-99% full", () => {
    // 670 total, 400 used = 59.7%
    expect(getShipmentStatus(400, 670)).toBe("filling");
  });

  it("returns 'full' when 100% full", () => {
    expect(getShipmentStatus(670, 670)).toBe("full");
  });

  it("returns 'full' when over-booked (edge case)", () => {
    expect(getShipmentStatus(680, 670)).toBe("full");
  });

  it("returns 'filling' at exactly 50%", () => {
    expect(getShipmentStatus(335, 670)).toBe("filling");
  });
});

describe("Group Shipping — Fill Percent", () => {
  it("calculates 0% when empty", () => {
    expect(fillPercent(0, 670)).toBe(0);
  });

  it("calculates 100% when full", () => {
    expect(fillPercent(670, 670)).toBe(100);
  });

  it("calculates 50% correctly", () => {
    expect(fillPercent(335, 670)).toBe(50);
  });

  it("rounds to nearest integer", () => {
    // 200/670 = 29.85% → rounds to 30
    expect(fillPercent(200, 670)).toBe(30);
  });
});

describe("Group Shipping — Business Scenarios", () => {
  it("correctly splits cost of 40ft container among 10 importers (5 CBM each)", () => {
    // Container: 670 tenths total, $3200 total cost → $47.76/CBM
    // Each importer: 5 CBM = 50 tenths
    const pricePerCbmCents = Math.round((3200 * 100) / 67); // $47.76 per CBM in cents
    const costPerImporter = calculateTotalPrice(50, pricePerCbmCents);
    // Should be roughly $238.80 per importer (vs $3200 for full container)
    expect(costPerImporter).toBeLessThan(32000); // Less than $320
    expect(costPerImporter).toBeGreaterThan(20000); // More than $200
  });

  it("validates that minimum CBM check works", () => {
    const minCbmTenths = 10; // 1.0 CBM minimum
    const requestedTenths = cbmDecimalToTenths(0.5); // 0.5 CBM
    expect(requestedTenths).toBeLessThan(minCbmTenths); // Should fail validation
  });

  it("validates that maximum CBM check works", () => {
    const maxCbmTenths = 200; // 20 CBM maximum
    const requestedTenths = cbmDecimalToTenths(25); // 25 CBM
    expect(requestedTenths).toBeGreaterThan(maxCbmTenths); // Should fail validation
  });

  it("calculates available CBM correctly after bookings", () => {
    const totalCbm = 670; // 67 CBM in tenths
    const booking1 = cbmDecimalToTenths(5);  // 50 tenths
    const booking2 = cbmDecimalToTenths(3);  // 30 tenths
    const booking3 = cbmDecimalToTenths(8);  // 80 tenths
    const usedCbm = booking1 + booking2 + booking3; // 160 tenths = 16 CBM
    const availableCbm = totalCbm - usedCbm; // 510 tenths = 51 CBM
    expect(availableCbm).toBe(510);
    expect(availableCbm / 10).toBe(51); // 51 CBM remaining
  });
});
