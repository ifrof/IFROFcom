/**
 * Shipping Router Tests
 *
 * Covers:
 * - calculateRates: pure deterministic logic with known rate table values
 * - getShippingMethods: static data
 * - estimateDelivery: pure date calculation logic
 * - trackShipment: NOT_FOUND when shipment is missing
 * - createShipment: UNAUTHORIZED/FORBIDDEN auth guards
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { shippingRouter } from "../shipping-router";

function caller(user: object | null) {
  return shippingRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const freeUser = { id: 1, role: "user",  plan: "free" };
const admin    = { id: 9, role: "admin", plan: "pro"  };

// ── calculateRates (pure logic — no DB) ──────────────────────────────────────

describe("shipping.calculateRates", () => {
  it("returns 3 carriers for a known route (CN→US)", async () => {
    const result = await caller(guest).calculateRates({
      origin: "CN",
      destination: "US",
      weight: 1,
    });
    expect(result.rates).toHaveLength(3);
    const carriers = result.rates.map((r) => r.carrier);
    expect(carriers).toContain("FedEx");
    expect(carriers).toContain("DHL");
    expect(carriers).toContain("UPS");
  });

  it("uses the DEFAULT rate table for unknown routes", async () => {
    const knownResult = await caller(guest).calculateRates({
      origin: "CN",
      destination: "US",
      weight: 1,
    });
    const unknownResult = await caller(guest).calculateRates({
      origin: "ZZ",
      destination: "XX",
      weight: 1,
    });
    // DEFAULT rates match CN-US rates (both are the same in the table)
    expect(unknownResult.rates[0].rate).toBe(knownResult.rates[0].rate);
  });

  it("applies a $2/kg weight surcharge over 5 kg", async () => {
    const base = await caller(guest).calculateRates({
      origin: "CN",
      destination: "US",
      weight: 5,
    });
    const heavy = await caller(guest).calculateRates({
      origin: "CN",
      destination: "US",
      weight: 10, // 5 kg over limit → $10 surcharge
    });
    expect(heavy.rates[0].rate - base.rates[0].rate).toBeCloseTo(10);
  });

  it("no surcharge for weight ≤ 5 kg", async () => {
    const r1 = await caller(guest).calculateRates({ origin: "CN", destination: "US", weight: 1 });
    const r2 = await caller(guest).calculateRates({ origin: "CN", destination: "US", weight: 5 });
    expect(r1.rates[0].rate).toBe(r2.rates[0].rate);
  });

  it("CN→JP standard rate is cheaper than CN→US standard rate", async () => {
    const us = await caller(guest).calculateRates({ origin: "CN", destination: "US", weight: 1 });
    const jp = await caller(guest).calculateRates({ origin: "CN", destination: "JP", weight: 1 });
    const usStandard = us.rates.find((r) => r.service === "Standard")!.rate;
    const jpStandard = jp.rates.find((r) => r.service === "Standard")!.rate;
    expect(jpStandard).toBeLessThan(usStandard);
  });

  it("returns origin and destination in the response", async () => {
    const result = await caller(guest).calculateRates({
      origin: "CN",
      destination: "SA",
      weight: 2,
    });
    expect(result.origin).toBe("CN");
    expect(result.destination).toBe("SA");
  });

  it("rejects non-positive weight", async () => {
    await expect(
      caller(guest).calculateRates({ origin: "CN", destination: "US", weight: 0 })
    ).rejects.toThrow();
  });
});

// ── getShippingMethods (static data) ─────────────────────────────────────────

describe("shipping.getShippingMethods", () => {
  it("returns exactly 3 shipping methods", async () => {
    const methods = await caller(guest).getShippingMethods();
    expect(methods).toHaveLength(3);
  });

  it("includes standard, express, and overnight ids", async () => {
    const methods = await caller(guest).getShippingMethods();
    const ids = methods.map((m) => m.id);
    expect(ids).toContain("standard");
    expect(ids).toContain("express");
    expect(ids).toContain("overnight");
  });
});

// ── estimateDelivery (pure logic — no DB) ────────────────────────────────────

describe("shipping.estimateDelivery", () => {
  it("CN→US standard is slower than express", async () => {
    const standard = await caller(guest).estimateDelivery({
      origin: "CN", destination: "US", shippingMethod: "standard",
    });
    const express = await caller(guest).estimateDelivery({
      origin: "CN", destination: "US", shippingMethod: "express",
    });
    expect(standard.daysToDeliver).toBeGreaterThan(express.daysToDeliver);
  });

  it("returns a future estimated delivery date", async () => {
    const result = await caller(guest).estimateDelivery({
      origin: "CN", destination: "US", shippingMethod: "overnight",
    });
    expect(result.estimatedDeliveryDate.getTime()).toBeGreaterThan(Date.now() - 1000);
  });

  it("daysToDeliver matches known table for CN→JP standard (4 days)", async () => {
    const result = await caller(guest).estimateDelivery({
      origin: "CN", destination: "JP", shippingMethod: "standard",
    });
    expect(result.daysToDeliver).toBe(4);
  });
});

// ── trackShipment ────────────────────────────────────────────────────────────

describe("shipping.trackShipment", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws NOT_FOUND when no shipment matches the tracking number", async () => {
    mockGetDb.mockResolvedValue({
      select: vi.fn().mockReturnValue({
        from: vi.fn().mockReturnThis(),
        where: vi.fn().mockReturnValue({
          limit: vi.fn().mockResolvedValue([]), // empty
        }),
      }),
    });
    await expect(
      caller(guest).trackShipment({ trackingNumber: "NONEXISTENT" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

// ── createShipment (admin only via role check) ───────────────────────────────

describe("shipping.createShipment", () => {
  const validInput = {
    orderId: 1, carrier: "FedEx", trackingNumber: "TRK123",
    origin: "CN", destination: "US", weight: 3, cost: 45,
  };

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).createShipment(validInput)).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws FORBIDDEN for regular users", async () => {
    mockGetDb.mockResolvedValue({
      insert: vi.fn().mockReturnValue({
        values: vi.fn().mockResolvedValue([{ insertId: 1 }]),
      }),
    });
    await expect(
      caller(freeUser).createShipment(validInput)
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
