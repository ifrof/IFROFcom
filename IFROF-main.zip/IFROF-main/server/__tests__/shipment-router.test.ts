/**
 * Shipment Router Tests
 *
 * Tests authentication guards, user isolation (only own shipments),
 * admin gate on management procedures, and NOT_FOUND handling.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { shipmentRouter } from "../shipment-router";

function caller(user: object | null) {
  return shipmentRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest   = null;
const userA   = { id: 1, role: "user",  plan: "free" };
const userB   = { id: 2, role: "user",  plan: "free" };
const admin   = { id: 9, role: "admin", plan: "pro"  };

/** Thenable chain: awaits to `rows` at any chain depth */
function makeChain(rows: any[] = []) {
  const chain: any = {
    then: (res: any, rej: any) => Promise.resolve(rows).then(res, rej),
    catch: (fn: any) => Promise.resolve(rows).catch(fn),
  };
  ["from", "leftJoin", "where", "orderBy", "limit", "offset", "$dynamic"].forEach(
    (m) => { chain[m] = vi.fn().mockReturnValue(chain); }
  );
  return chain;
}

function makeDb(rows: any[] = []) {
  return {
    select: vi.fn().mockReturnValue(makeChain(rows)),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockResolvedValue([{ insertId: 1 }]),
    }),
    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({ where: vi.fn().mockResolvedValue({}) }),
    }),
  };
}

// ── list ─────────────────────────────────────────────────────────────────────

describe("shipment.list", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).list()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns an array for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb([]));
    expect(Array.isArray(await caller(userA).list())).toBe(true);
  });
});

// ── getById ───────────────────────────────────────────────────────────────────

describe("shipment.getById", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).getById({ shipmentId: 1 })).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("throws NOT_FOUND when shipment does not exist", async () => {
    mockGetDb.mockResolvedValue(makeDb([]));
    await expect(caller(userA).getById({ shipmentId: 999 })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("throws FORBIDDEN when shipment belongs to a different user", async () => {
    // First select returns shipment owned by userB
    let selectCount = 0;
    const db = makeDb();
    db.select = vi.fn().mockImplementation(() => {
      selectCount++;
      if (selectCount === 1) {
        return makeChain([{ id: 10, userId: userB.id }]);
      }
      return makeChain([]);
    });
    mockGetDb.mockResolvedValue(db);
    await expect(caller(userA).getById({ shipmentId: 10 })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("allows admin to access any shipment", async () => {
    let selectCount = 0;
    const db = makeDb();
    db.select = vi.fn().mockImplementation(() => {
      selectCount++;
      if (selectCount === 1) return makeChain([{ id: 10, userId: userB.id }]);
      return makeChain([]);
    });
    mockGetDb.mockResolvedValue(db);
    const result = await caller(admin).getById({ shipmentId: 10 });
    expect(result.shipment).toBeDefined();
    expect(result.shipment.userId).toBe(userB.id);
  });
});

// ── getByTracking ─────────────────────────────────────────────────────────────

describe("shipment.getByTracking", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).getByTracking({ trackingNumber: "TRK001" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws NOT_FOUND for unknown tracking numbers", async () => {
    mockGetDb.mockResolvedValue(makeDb([]));
    await expect(
      caller(userA).getByTracking({ trackingNumber: "UNKNOWN" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("throws FORBIDDEN when tracking belongs to a different user", async () => {
    let selectCount = 0;
    const db = makeDb();
    db.select = vi.fn().mockImplementation(() => {
      selectCount++;
      if (selectCount === 1) return makeChain([{ id: 5, userId: userB.id }]);
      return makeChain([]);
    });
    mockGetDb.mockResolvedValue(db);
    await expect(
      caller(userA).getByTracking({ trackingNumber: "TRK-B" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

// ── listDocuments / listQuotes ────────────────────────────────────────────────

describe("shipment.listDocuments", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).listDocuments()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns an array for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb([]));
    expect(Array.isArray(await caller(userA).listDocuments())).toBe(true);
  });
});

describe("shipment.listQuotes", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).listQuotes()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });
});

describe("shipment.saveQuote", () => {
  const validInput = {
    origin: "CN", destination: "US", weight: 5,
    method: "sea" as const, cost: 40, total: 45,
  };

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(guest).saveQuote(validInput)).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });
});

// ── Admin procedures ──────────────────────────────────────────────────────────

describe("shipment admin procedures", () => {
  const createInput = { orderId: 1, userId: 1 };
  const updateInput = { shipmentId: 1, status: "in_transit" as const };

  it("shipment.create throws FORBIDDEN for regular users", async () => {
    await expect(caller(userA).create(createInput)).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("shipment.updateStatus throws FORBIDDEN for regular users", async () => {
    await expect(caller(userA).updateStatus(updateInput)).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("shipment.listAll throws FORBIDDEN for regular users", async () => {
    await expect(caller(userA).listAll()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});
