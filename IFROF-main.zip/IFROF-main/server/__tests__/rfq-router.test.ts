/**
 * RFQ Router Tests
 *
 * Tests authentication boundaries, data isolation between users,
 * and the create mutation return shape.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());

vi.mock("../db", () => ({ getDb: mockGetDb }));
vi.mock("../email", () => ({
  sendRfqConfirmation: vi.fn().mockResolvedValue(undefined),
  sendAdminNewRfqAlert: vi.fn().mockResolvedValue(undefined),
}));

import { rfqRouter } from "../rfq-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return rfqRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const freeUser = { id: 1, role: "user", plan: "free", email: "a@test.com", name: "Alice" };
const otherUser = { id: 2, role: "user", plan: "free", email: "b@test.com", name: "Bob" };
const adminUser = { id: 9, role: "admin", plan: "pro", email: "admin@ifrof.com", name: "Admin" };

/**
 * Build a minimal mock DB for the RFQ router.
 * insert() calls:
 *   1st → rfqs table  → needs $returningId → [{id: rfqId}]
 *   2nd → analyticsEvents → just resolve
 *   3rd → notifications → just resolve
 */
function makeDb({
  rfqId = 42,
  rfqRows = [] as any[],
  quoteRows = [] as any[],
  quoteRow = null as any,
} = {}) {
  let insertCount = 0;

  return {
    insert: vi.fn().mockImplementation(() => {
      insertCount++;
      if (insertCount === 1) {
        // rfqs insert — needs $returningId
        return {
          values: vi.fn().mockReturnValue({
            $returningId: vi.fn().mockResolvedValue([{ id: rfqId }]),
          }),
        };
      }
      // analytics / notifications inserts — just resolve
      return { values: vi.fn().mockResolvedValue([]) };
    }),

    select: vi.fn().mockImplementation(() => {
      const chain: any = {
        from: vi.fn().mockReturnThis(),
        where: vi.fn().mockReturnValue({
          limit: vi.fn().mockImplementation((n: number) => {
            // getWithQuote first queries rfqs
            return Promise.resolve(rfqRows.slice(0, n));
          }),
          orderBy: vi.fn().mockResolvedValue(rfqRows),
        }),
        orderBy: vi.fn().mockResolvedValue(rfqRows),
      };
      return chain;
    }),

    update: vi.fn().mockReturnValue({
      set: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue({}),
      }),
    }),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("rfq.create", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for unauthenticated users", async () => {
    await expect(
      caller(null).create({ productName: "Widget" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("creates an RFQ and returns rfqId for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb({ rfqId: 42 }));

    const result = await caller(freeUser).create({ productName: "Ceramic Mug" });

    expect(result.success).toBe(true);
    expect(result.rfqId).toBe(42);
  });

  it("accepts optional fields without error", async () => {
    mockGetDb.mockResolvedValue(makeDb({ rfqId: 7 }));

    const result = await caller(freeUser).create({
      productName: "Laptop Stand",
      specifications: "Aluminum, foldable",
      quantity: 500,
      targetPrice: 25,
      destinationCountry: "SA",
      shippingPreference: "sea",
      certificationsRequired: ["CE", "RoHS"],
      customizationNeeded: "yes",
    });

    expect(result.rfqId).toBe(7);
  });

  it("rejects an empty productName", async () => {
    await expect(
      caller(freeUser).create({ productName: "" })
    ).rejects.toThrow();
  });
});

describe("rfq.list", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(caller(null).list()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("returns an array for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb({ rfqRows: [] }));
    const result = await caller(freeUser).list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("rfq.getWithQuote", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(null).getWithQuote({ rfqId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("throws NOT_FOUND when the RFQ does not exist", async () => {
    // Simulate DB returning no RFQ rows
    mockGetDb.mockResolvedValue(makeDb({ rfqRows: [] }));
    await expect(
      caller(freeUser).getWithQuote({ rfqId: 999 })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("throws FORBIDDEN when the RFQ belongs to a different user", async () => {
    // RFQ belongs to otherUser (id=2), but freeUser (id=1) is requesting
    mockGetDb.mockResolvedValue(
      makeDb({
        rfqRows: [{ id: 5, userId: otherUser.id, productName: "Widget", certificationsRequired: null }],
      })
    );
    await expect(
      caller(freeUser).getWithQuote({ rfqId: 5 })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

describe("rfq.respondToQuote", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(null).respondToQuote({ quoteId: 1, action: "accept" })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});

describe("rfq admin procedures", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rfq.adminListAll throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(freeUser).adminListAll({})
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rfq.adminCreateQuote throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(freeUser).adminCreateQuote({
        rfqId: 1,
        buyerId: 1,
        unitPrice: 10,
        quantity: 100,
      })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rfq.adminSendQuote throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(freeUser).adminSendQuote({ quoteId: 1 })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rfq.adminListQuotes throws FORBIDDEN for regular users", async () => {
    await expect(
      caller(freeUser).adminListQuotes({})
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
