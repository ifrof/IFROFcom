import { describe, it, expect } from 'vitest';
import { SearchService } from '../services/SearchService';

describe('SearchService fallback mode', () => {
  it('returns an empty result set when meilisearch is unavailable', async () => {
    const searchService = new SearchService();

    const result = await searchService.search('test query');

    expect(result.hits).toEqual([]);
    expect(result.nbHits).toBe(0);
  });
});
