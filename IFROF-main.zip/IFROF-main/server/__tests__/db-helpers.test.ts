/**
 * DB Helpers Tests
 *
 * Tests the helper functions in server/db.ts using a no-database
 * environment (DATABASE_URL is not set), covering:
 *  - Graceful null-db handling (functions that return undefined or no-op)
 *  - Input validation (upsertUser requires openId)
 *  - Functions that throw when db is unavailable
 */
import { describe, it, expect, beforeAll, beforeEach } from "vitest";

// Ensure no real DB is initialized during these tests.
// The module caches _db at module scope; since DATABASE_URL is not set
// in the test environment, getDb() always returns null here.
import {
  getUserByOpenId,
  getUserById,
  upsertUser,
  getUserByEmail,
} from "../db";

// ── Tests ────────────────────────────────────────────────────────────────────

describe("getDb (lazy init)", () => {
  it("returns null when DATABASE_URL is not set", async () => {
    const { getDb } = await import("../db");
    const db = await getDb();
    expect(db).toBeNull();
  });
});

describe("getUserByOpenId", () => {
  it("returns undefined when the database is unavailable", async () => {
    const result = await getUserByOpenId("non-existent-open-id");
    expect(result).toBeUndefined();
  });
});

describe("getUserById", () => {
  it("returns undefined when the database is unavailable", async () => {
    const result = await getUserById(999);
    expect(result).toBeUndefined();
  });
});

describe("getUserByEmail", () => {
  it("returns undefined when the database is unavailable", async () => {
    const result = await getUserByEmail("test@example.com");
    expect(result).toBeUndefined();
  });
});

describe("upsertUser", () => {
  it("throws an error when openId is missing", async () => {
    await expect(
      upsertUser({ openId: undefined as any })
    ).rejects.toThrow("openId is required");
  });

  it("returns undefined (no-op) when database is unavailable", async () => {
    // With no database, upsertUser should log a warning and return void
    const result = await upsertUser({ openId: "test-open-id-xyz" });
    expect(result).toBeUndefined();
  });

  it("throws for empty string openId", async () => {
    // Empty string is falsy so the guard should trigger
    await expect(
      upsertUser({ openId: "" as any })
    ).rejects.toThrow("openId is required");
  });
});
