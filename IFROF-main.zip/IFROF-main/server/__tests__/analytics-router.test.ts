/**
 * Analytics Router Tests
 *
 * The analytics track endpoint is public (no auth required) and
 * must never throw — even when the database is unavailable.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ── Mocks ────────────────────────────────────────────────────────────────────

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { analyticsRouter } from "../analytics-router";

// ── Helpers ──────────────────────────────────────────────────────────────────

function caller(user: object | null) {
  return analyticsRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const freeUser = { id: 1, role: "user", plan: "free" };

function makeDb() {
  return {
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        catch: vi.fn().mockResolvedValue({}),
      }),
    }),
  };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe("analytics.track", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns {success:true} when the database is unavailable", async () => {
    mockGetDb.mockResolvedValue(null); // no DB configured
    const result = await caller(null).track({ event: "page_view" });
    expect(result.success).toBe(true);
  });

  it("tracks an event for an authenticated user", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValue(db);
    const result = await caller(freeUser).track({
      event: "rfq_created",
      properties: { rfqId: 42 },
    });
    expect(result.success).toBe(true);
    expect(db.insert).toHaveBeenCalled();
  });

  it("tracks an event for an anonymous user (guest)", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValue(db);
    const result = await caller(null).track({ event: "page_view" });
    expect(result.success).toBe(true);
  });

  it("returns {success:true} even when db.insert throws", async () => {
    // The .catch(() => {}) in the router suppresses DB errors
    const db = {
      insert: vi.fn().mockReturnValue({
        values: vi.fn().mockReturnValue({
          catch: vi.fn().mockResolvedValue({}), // suppressed
        }),
      }),
    };
    mockGetDb.mockResolvedValue(db);
    const result = await caller(freeUser).track({ event: "test_event" });
    expect(result.success).toBe(true);
  });

  it("rejects events with empty string", async () => {
    await expect(caller(null).track({ event: "" })).rejects.toThrow();
  });

  it("rejects events exceeding 100 characters", async () => {
    await expect(
      caller(null).track({ event: "x".repeat(101) })
    ).rejects.toThrow();
  });

  it("accepts optional properties object", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValue(db);
    const result = await caller(freeUser).track({
      event: "upgrade_clicked",
      properties: { plan: "pro", source: "header" },
    });
    expect(result.success).toBe(true);
  });
});
