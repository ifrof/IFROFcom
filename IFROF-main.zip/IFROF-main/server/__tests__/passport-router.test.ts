/**
 * Passport Router Tests
 *
 * Tests the trust-score computation logic (via getPassport), access-control
 * boundaries, and input validation for all four procedures.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const mockGetDb = vi.hoisted(() => vi.fn());
vi.mock("../db", () => ({ getDb: mockGetDb }));

import { passportRouter } from "../passport-router";

function caller(user: object | null) {
  return passportRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const freeUser = { id: 1, role: "user",  plan: "free" };
const admin    = { id: 9, role: "admin", plan: "pro"  };

// ── Helpers ──────────────────────────────────────────────────────────────────

function makeFactory(overrides: Record<string, any> = {}) {
  return {
    id: 1, name: "ACME Factory", slug: "acme-factory",
    socialCreditCode: null, certifications: null,
    yearEstablished: null, exportCountries: null,
    capabilities: null, verificationLevel: 0,
    category: null, country: "CN", trustScore: 0, verified: false,
    ...overrides,
  };
}

function makeDoc(overrides: Record<string, any> = {}) {
  return {
    id: 1, factoryId: 1, type: "business_license",
    verifiedStatus: "pending", label: null, fileUrl: "https://cdn/doc.pdf",
    uploadedAt: new Date(), verifiedAt: null, verifiedBy: null,
    ...overrides,
  };
}

function makeRisk(overrides: Record<string, any> = {}) {
  return {
    id: 1, factoryId: 1, type: "admin_flag",
    description: "Suspicious activity", status: "open",
    createdBy: 9, createdAt: new Date(),
    ...overrides,
  };
}

/** Thenable chain that resolves to `rows` at any call depth */
function makeChain(rows: any[]) {
  const c: any = {
    then: (res: any, rej: any) => Promise.resolve(rows).then(res, rej),
    catch: (fn: any) => Promise.resolve(rows).catch(fn),
  };
  ["from","where","orderBy","limit","offset","leftJoin","$dynamic"].forEach(
    m => { c[m] = vi.fn().mockReturnValue(c); }
  );
  return c;
}

/** Build a DB mock whose 3 sequential `select()` calls return factory, docs, risks */
function makeDb(factory: object | null, docs: any[] = [], risks: any[] = []) {
  const results = [factory ? [factory] : [], docs, risks];
  let idx = 0;

  return {
    select: vi.fn().mockImplementation(() => makeChain(results[idx++] ?? [])),
    insert: vi.fn().mockReturnValue({
      values: vi.fn().mockReturnValue({
        catch: vi.fn().mockResolvedValue({}),
        $returningId: vi.fn().mockResolvedValue([{ id: 1 }]),
      }),
    }),
  };
}

// ── Trust score computation (tested via getPassport) ─────────────────────────

describe("passport.getPassport — trust score computation", () => {
  beforeEach(() => vi.clearAllMocks());

  it("score is 0 for a bare factory with no data", async () => {
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), [], []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(0);
  });

  it("verified business license adds 15 points", async () => {
    const docs = [makeDoc({ type: "business_license", verifiedStatus: "verified" })];
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), docs, []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(15);
  });

  it("unverified business license adds nothing", async () => {
    const docs = [makeDoc({ type: "business_license", verifiedStatus: "pending" })];
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), docs, []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(0);
  });

  it("social credit code adds 15 points", async () => {
    mockGetDb.mockResolvedValue(makeDb(makeFactory({ socialCreditCode: "91440300XXXXXXXXXX" }), [], []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(15);
  });

  it("certifications JSON array adds 10 points", async () => {
    mockGetDb.mockResolvedValue(makeDb(
      makeFactory({ certifications: '["ISO 9001","CE"]' }), [], []
    ));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(10);
  });

  it("verified certification document adds +5 on top", async () => {
    const docs = [makeDoc({ type: "certification", verifiedStatus: "verified" })];
    mockGetDb.mockResolvedValue(makeDb(
      makeFactory({ certifications: '["ISO 9001"]' }), docs, []
    ));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(15); // 10 (cert) + 5 (verified doc)
  });

  it("5+ years in business adds 10 points", async () => {
    const oldYear = new Date().getFullYear() - 10;
    mockGetDb.mockResolvedValue(makeDb(makeFactory({ yearEstablished: oldYear }), [], []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(10);
  });

  it("2-4 years in business adds 5 points", async () => {
    const year = new Date().getFullYear() - 3;
    mockGetDb.mockResolvedValue(makeDb(makeFactory({ yearEstablished: year }), [], []));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(5);
  });

  it("export countries JSON array adds 10 points", async () => {
    mockGetDb.mockResolvedValue(makeDb(
      makeFactory({ exportCountries: '["US","EU","SA"]' }), [], []
    ));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(10);
  });

  it("each verification level adds 10 points", async () => {
    for (const level of [1, 2, 3] as const) {
      vi.clearAllMocks();
      mockGetDb.mockResolvedValue(makeDb(makeFactory({ verificationLevel: level }), [], []));
      const { trust } = await caller(guest).getPassport({ factoryId: level });
      expect(trust.score).toBe(level * 10);
    }
  });

  it("open risk flag deducts 15 points", async () => {
    const risks = [makeRisk({ status: "open" })];
    mockGetDb.mockResolvedValue(makeDb(
      makeFactory({ verificationLevel: 2 }), // +20
      [], risks // -15
    ));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBe(5);
  });

  it("two open risk flags cannot push score below 0 (clamped)", async () => {
    const risks = [
      makeRisk({ id: 1, status: "open" }),
      makeRisk({ id: 2, status: "open" }),
    ];
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), [], risks));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBeGreaterThanOrEqual(0);
  });

  it("score cannot exceed 100 (clamped)", async () => {
    const oldYear = new Date().getFullYear() - 20;
    const docs = [
      makeDoc({ type: "business_license", verifiedStatus: "verified" }),
      makeDoc({ id: 2, type: "certification", verifiedStatus: "verified" }),
    ];
    mockGetDb.mockResolvedValue(makeDb(
      makeFactory({
        socialCreditCode: "91440300XX",
        certifications: '["ISO 9001","CE","RoHS"]',
        yearEstablished: oldYear,
        exportCountries: '["US","EU"]',
        verificationLevel: 3,
      }),
      docs, []
    ));
    const { trust } = await caller(guest).getPassport({ factoryId: 1 });
    expect(trust.score).toBeLessThanOrEqual(100);
  });

  it("dismissed risk flags do NOT appear in returned riskFlags", async () => {
    const risks = [
      makeRisk({ id: 1, status: "open" }),
      makeRisk({ id: 2, status: "dismissed" }),
    ];
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), [], risks));
    const { riskFlags } = await caller(guest).getPassport({ factoryId: 1 });
    expect(riskFlags).toHaveLength(1);
    expect(riskFlags[0].status).toBe("open");
  });

  it("fileUrl is visible to admins but hidden for regular users", async () => {
    const docs = [makeDoc({ fileUrl: "https://cdn/secret.pdf" })];
    mockGetDb.mockResolvedValue(makeDb(makeFactory(), docs, []));
    const asAdmin = await caller(admin).getPassport({ factoryId: 1 });
    expect(asAdmin.documents[0].fileUrl).toBe("https://cdn/secret.pdf");

    mockGetDb.mockResolvedValue(makeDb(makeFactory(), docs, []));
    const asUser = await caller(freeUser).getPassport({ factoryId: 1 });
    expect(asUser.documents[0].fileUrl).toBeUndefined();
  });

  it("throws NOT_FOUND when factory does not exist", async () => {
    mockGetDb.mockResolvedValue(makeDb(null));
    await expect(
      caller(guest).getPassport({ factoryId: 9999 })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

// ── requestVerification ───────────────────────────────────────────────────────

describe("passport.requestVerification", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).requestVerification({ factoryId: 1 })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("creates a verification request for authenticated users", async () => {
    mockGetDb.mockResolvedValue(makeDb(makeFactory()));
    const result = await caller(freeUser).requestVerification({ factoryId: 1, reason: "Due diligence" });
    expect(result.success).toBe(true);
    expect(typeof result.requestId).toBe("number");
  });
});

// ── reportSuspicious ──────────────────────────────────────────────────────────

describe("passport.reportSuspicious", () => {
  beforeEach(() => vi.clearAllMocks());

  it("throws UNAUTHORIZED for guests", async () => {
    await expect(
      caller(guest).reportSuspicious({
        factoryId: 1,
        description: "This looks like a scam operation",
      })
    ).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects description shorter than 10 characters", async () => {
    await expect(
      caller(freeUser).reportSuspicious({ factoryId: 1, description: "Bad!" })
    ).rejects.toThrow();
  });

  it("accepts valid reports", async () => {
    mockGetDb.mockResolvedValue(makeDb(makeFactory()));
    const result = await caller(freeUser).reportSuspicious({
      factoryId: 1,
      description: "Website does not match the listed address.",
    });
    expect(result.success).toBe(true);
  });
});

// ── listFactories (public) ────────────────────────────────────────────────────

describe("passport.listFactories", () => {
  beforeEach(() => vi.clearAllMocks());

  it("allows guests to browse factories", async () => {
    mockGetDb.mockResolvedValue({ select: vi.fn().mockReturnValue(makeChain([])) });
    const result = await caller(guest).listFactories();
    expect(Array.isArray(result)).toBe(true);
  });
});
