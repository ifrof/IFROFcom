/**
 * Admin Router Authorization Tests
 *
 * Verifies that every admin procedure throws FORBIDDEN for
 * non-admin users. Admin-only routes protect sensitive operations
 * like factory verification, risk flags, and user management.
 */
import { describe, it, expect, vi } from "vitest";

vi.mock("../db", () => ({ getDb: vi.fn() }));

import { adminRouter } from "../admin-router";

function caller(user: object | null) {
  return adminRouter.createCaller({ user, req: {} as any, res: {} as any });
}

const guest    = null;
const freeUser = { id: 1, role: "user", plan: "free" };
const proUser  = { id: 2, role: "user", plan: "pro"  };

// Every procedure name → minimal valid input
const procedures: [string, object][] = [
  ["listVerificationRequests",   {}],
  ["updateVerificationLevel",    { factoryId: 1, verificationLevel: 1 }],
  ["listUsers",                  undefined as any],
  ["listSuppliers",              undefined as any],
  ["createSupplier",             { name: "Acme Factory" }],
  ["addFactoryDocument",         { factoryId: 1, type: "business_license", fileUrl: "https://x.com/doc.pdf" }],
  ["verifyDocument",             { documentId: 1, status: "verified" }],
  ["addRiskFlag",                { factoryId: 1, description: "Suspicious activity detected on site" }],
  ["resolveRiskFlag",            { flagId: 1, status: "resolved" }],
  ["updateVerificationRequest",  { requestId: 1, status: "in_progress" }],
  ["listProtectedOrders",        undefined as any],
  ["updateProtectedOrderStatus", { orderId: 1, status: "approved" }],
  ["sendAdminMessage",           { conversationId: 1, body: "Hello" }],
  ["getStats",                   undefined as any],
];

describe("admin router — authorization", () => {
  for (const [procedureName, input] of procedures) {
    describe(procedureName, () => {
      it("throws FORBIDDEN for unauthenticated guests", async () => {
        const c = caller(guest) as any;
        const call = input !== undefined ? c[procedureName](input) : c[procedureName]();
        await expect(call).rejects.toMatchObject({ code: "FORBIDDEN" });
      });

      it("throws FORBIDDEN for regular free-plan users", async () => {
        const c = caller(freeUser) as any;
        const call = input !== undefined ? c[procedureName](input) : c[procedureName]();
        await expect(call).rejects.toMatchObject({ code: "FORBIDDEN" });
      });

      it("throws FORBIDDEN for pro-plan users who are not admin role", async () => {
        const c = caller(proUser) as any;
        const call = input !== undefined ? c[procedureName](input) : c[procedureName]();
        await expect(call).rejects.toMatchObject({ code: "FORBIDDEN" });
      });
    });
  }
});
