import Stripe from 'stripe';
import { ENV } from './_core/env';

// Stripe is optional — only initialise if STRIPE_SECRET_KEY is set
export const stripe = ENV.stripeSecretKey
  ? new Stripe(ENV.stripeSecretKey, {
      apiVersion: '2026-01-28.clover',
    })
  : null;

/**
 * Create a Stripe Checkout Session for payment
 */
export async function createCheckoutSession(params: {
  userId: number;
  userEmail: string;
  userName: string;
  items: Array<{
    name: string;
    description?: string;
    amount: number; // in cents
    quantity: number;
    images?: string[];
  }>;
  successUrl: string;
  cancelUrl: string;
  metadata?: Record<string, string>;
}) {
  if (!stripe) throw new Error('Stripe is not configured');
  
  const lineItems = params.items.map(item => ({
    price_data: {
      currency: 'usd',
      product_data: {
        name: item.name,
        description: item.description,
        images: item.images,
      },
      unit_amount: item.amount,
    },
    quantity: item.quantity,
  }));

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: lineItems,
    mode: 'payment',
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    customer_email: params.userEmail,
    client_reference_id: params.userId.toString(),
    allow_promotion_codes: true,
    metadata: {
      user_id: params.userId.toString(),
      customer_email: params.userEmail,
      customer_name: params.userName,
      ...params.metadata,
    },
  });

  return session;
}

/**
 * Retrieve a Stripe Checkout Session
 */
export async function getCheckoutSession(sessionId: string) {
  if (!stripe) throw new Error('Stripe is not configured');
  return await stripe.checkout.sessions.retrieve(sessionId);
}

/**
 * Retrieve a Payment Intent
 */
export async function getPaymentIntent(paymentIntentId: string) {
  if (!stripe) throw new Error('Stripe is not configured');
  return await stripe.paymentIntents.retrieve(paymentIntentId);
}

/**
 * Create a refund for a payment
 */
export async function createRefund(paymentIntentId: string, amount?: number) {
  if (!stripe) throw new Error('Stripe is not configured');
  return await stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount,
  });
}
