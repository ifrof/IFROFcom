import { publicProcedure, router } from "./_core/trpc";
import { clearSessionCookie } from "./services/auth.service";

export const authRouter = router({
  me: publicProcedure.query(opts => opts.ctx.user),
  logout: publicProcedure.mutation(({ ctx }) => {
    clearSessionCookie(ctx.req, ctx.res);
    return { success: true } as const;
  }),
});