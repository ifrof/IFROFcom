/**
 * Gmail OAuth Router
 * Handles Google Sign-In for IFROF Platform
 */

import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getGoogleLoginUrl, exchangeCodeForTokens, getGoogleUserInfo } from "./gmail-oauth";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { sdk } from "./_core/sdk";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const gmailRouter = router({
  /**
   * Get Google OAuth login URL
   */
  getLoginUrl: publicProcedure.query(() => {
    try {
      const url = getGoogleLoginUrl();
      return { url };
    } catch (error) {
      console.error('[Gmail Router] Failed to generate login URL:', error);
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Failed to generate login URL',
      });
    }
  }),

  /**
   * Handle Google OAuth callback
   */
  callback: publicProcedure
    .input(z.object({
      code: z.string(),
      state: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Exchange authorization code for tokens
        const tokens = await exchangeCodeForTokens(input.code);

        if (!tokens.access_token) {
          throw new Error('No access token received');
        }

        // Get user info from Google
        const googleUser = await getGoogleUserInfo(tokens.access_token);

        if (!googleUser.id) {
          throw new Error('No user ID in Google response');
        }

        // Use Google user ID as openId (prefixed for namespace clarity)
        const openId = `google:${googleUser.id}`;

        // Upsert user using the existing db helper
        await db.upsertUser({
          openId,
          name: googleUser.name || (googleUser.email ? googleUser.email.split('@')[0] : 'User'),
          email: googleUser.email || null,
          loginMethod: 'google',
          lastSignedIn: new Date(),
        });

        // Retrieve the upserted user
        const user = await db.getUserByOpenId(openId);

        if (!user) {
          throw new Error('Failed to create or retrieve user');
        }

        // Create a JWT session token using the existing auth infrastructure
        const sessionToken = await sdk.createSessionToken(openId, {
          name: user.name || '',
          expiresInMs: ONE_YEAR_MS,
        });

        // Set session cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, {
          ...cookieOptions,
          maxAge: ONE_YEAR_MS,
        });

        return {
          success: true,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
          },
        };
      } catch (error) {
        console.error('[Gmail Router] Callback failed:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Authentication failed',
        });
      }
    }),
});
