/**
 * AI Router — tRPC endpoints for all IFROF AI agents.
 *
 * All calls are:
 *  - Redis-cached (agent-specific TTL)
 *  - Logged to the aiRequests table for monitoring
 *  - Capped at 30s (enforced inside each agent via invokeLLM)
 */

import crypto from 'crypto';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, publicProcedure, protectedProcedure } from './_core/trpc';
import { getCache, setCache } from './cache';
import { getDb } from './db';
import { aiRequests, chatConversations } from '../drizzle/schema';
import { ENV } from './_core/env';

import { validateFactory }            from './ai/agents/factory-validator';
import { generateProductDescription } from './ai/agents/product-description';
import { chat }                       from './ai/agents/chatbot';
import { enhanceSearch }              from './ai/agents/search-enhancer';
import { composeEmail }               from './ai/agents/email-composer';
import { getRecommendationGuidance }  from './ai/agents/recommendation-engine';

// ─── Cache TTLs (seconds) ───────────────────────────────────────────────────
const AI_TTL = {
  factoryValidation:  7 * 24 * 60 * 60, // 7 days
  productDescription: 24 * 60 * 60,     // 24 hours
  searchEnhancement:  6 * 60 * 60,      // 6 hours
  recommendations:    2 * 60 * 60,      // 2 hours
} as const;

function cacheKey(agent: string, payload: unknown): string {
  const hash = crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex').slice(0, 16);
  return `ai:${agent}:${hash}`;
}

/** Log request to DB (best-effort — never throws) */
async function logRequest(params: {
  agent:     string;
  prompt:    string;
  response:  string;
  latencyMs: number;
  userId?:   number;
  success:   boolean;
  error?:    string;
}) {
  try {
    const db = await getDb();
    if (!db) return;
    await db.insert(aiRequests).values({
      agent:    params.agent,
      prompt:   params.prompt.slice(0, 4000),
      response: params.response.slice(0, 8000),
      latency:  params.latencyMs,
      model:    ENV.ollamaModel,
      userId:   params.userId,
      success:  params.success,
      error:    params.error?.slice(0, 1000),
    });
  } catch { /* non-critical */ }
}

// ─── Helper: run agent with cache + logging ──────────────────────────────────
async function runAgent<TInput, TOutput>(opts: {
  agent:   string;
  input:   TInput;
  ttl:     number;
  userId?: number;
  fn:      (input: TInput) => Promise<TOutput>;
}): Promise<TOutput> {
  const key = opts.ttl > 0 ? cacheKey(opts.agent, opts.input) : null;

  if (key) {
    const cached = await getCache<TOutput>(key);
    if (cached) return cached;
  }

  const start = Date.now();
  try {
    const result = await opts.fn(opts.input);
    const latencyMs = Date.now() - start;

    if (key) await setCache(key, result, opts.ttl);

    await logRequest({
      agent:     opts.agent,
      prompt:    JSON.stringify(opts.input).slice(0, 4000),
      response:  JSON.stringify(result).slice(0, 8000),
      latencyMs,
      userId:    opts.userId,
      success:   true,
    });

    return result;
  } catch (err: any) {
    await logRequest({
      agent:     opts.agent,
      prompt:    JSON.stringify(opts.input).slice(0, 4000),
      response:  '',
      latencyMs: Date.now() - start,
      userId:    opts.userId,
      success:   false,
      error:     err?.message,
    });
    throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: err?.message ?? 'AI agent failed' });
  }
}

// ─── Router ──────────────────────────────────────────────────────────────────
export const aiRouter = router({

  // ── Agent 1: Factory Validator ──────────────────────────────────────────
  verifyFactory: protectedProcedure
    .input(z.object({
      companyName:       z.string().min(1),
      website:           z.string().optional(),
      description:       z.string().optional(),
      businessLicense:   z.string().optional(),
      contactInfo:       z.string().optional(),
      productCategories: z.array(z.string()).optional(),
    }))
    .mutation(({ input, ctx }) =>
      runAgent({
        agent:  'factory_validator',
        input,
        ttl:    AI_TTL.factoryValidation,
        userId: ctx.user?.id,
        fn:     validateFactory,
      }),
    ),

  // ── Agent 2: Product Description Generator ──────────────────────────────
  generateProductDescription: protectedProcedure
    .input(z.object({
      productName:    z.string().min(1),
      category:       z.string(),
      specifications: z.record(z.string(), z.union([z.string(), z.number()])).optional(),
      rawData:        z.string().optional(),
      targetMarket:   z.string().optional(),
    }))
    .mutation(({ input, ctx }) =>
      runAgent({
        agent:  'product_description',
        input,
        ttl:    AI_TTL.productDescription,
        userId: ctx.user?.id,
        fn:     generateProductDescription,
      }),
    ),

  // ── Agent 3: Customer Support Chatbot ───────────────────────────────────
  chat: publicProcedure
    .input(z.object({
      message: z.string().min(1).max(2000),
      conversationHistory: z.array(z.object({
        role:    z.enum(['user', 'assistant']),
        content: z.string(),
      })).default([]),
      userType:       z.enum(['buyer', 'supplier', 'guest']).default('guest'),
      context:        z.object({
        currentPage:  z.string().optional(),
        userLanguage: z.enum(['en', 'ar', 'zh']).optional(),
      }).optional(),
      conversationId: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const result = await runAgent({
        agent:  'chatbot',
        input:  {
          message:             input.message,
          conversationHistory: input.conversationHistory,
          userType:            input.userType,
          context:             input.context,
        },
        ttl:    0,
        userId: ctx.user?.id,
        fn:     chat,
      });

      // Persist conversation (non-critical)
      if (ctx.user?.id) {
        const db = await getDb();
        if (db) {
          const allMessages = [
            ...input.conversationHistory,
            { role: 'user',      content: input.message },
            { role: 'assistant', content: result.response },
          ];
          try {
            if (input.conversationId) {
              await db.update(chatConversations)
                .set({ messages: JSON.stringify(allMessages) })
                .where(eq(chatConversations.id, input.conversationId));
            } else {
              await db.insert(chatConversations).values({
                userId:   ctx.user.id,
                messages: JSON.stringify(allMessages),
              });
            }
          } catch { /* non-critical */ }
        }
      }

      return result;
    }),

  // ── Agent 4: Smart Search Enhancer ──────────────────────────────────────
  enhanceSearch: publicProcedure
    .input(z.object({
      query:       z.string().min(1).max(500),
      filters:     z.record(z.string(), z.unknown()).optional(),
      userContext: z.object({
        previousSearches: z.array(z.string()).optional(),
        viewedProducts:   z.array(z.string()).optional(),
      }).optional(),
    }))
    .query(({ input, ctx }) =>
      runAgent({
        agent:  'search_enhancer',
        input,
        ttl:    AI_TTL.searchEnhancement,
        userId: ctx.user?.id,
        fn:     enhanceSearch,
      }),
    ),

  // ── Agent 5: Email Composer ──────────────────────────────────────────────
  composeEmail: protectedProcedure
    .input(z.object({
      emailType:     z.enum(['supplier_invitation', 'order_inquiry', 'payment_confirmation', 'shipping_update', 'rfq_response', 'custom']),
      recipientType: z.enum(['buyer', 'supplier']),
      context:       z.record(z.string(), z.unknown()),
      language:      z.enum(['en', 'ar', 'zh']).optional(),
    }))
    .mutation(({ input, ctx }) =>
      runAgent({
        agent:  'email_composer',
        input,
        ttl:    0,
        userId: ctx.user?.id,
        fn:     composeEmail,
      }),
    ),

  // ── Agent 6: Recommendations ─────────────────────────────────────────────
  getRecommendations: publicProcedure
    .input(z.object({
      type: z.enum(['similar_products', 'similar_factories', 'cross_sell', 'trending']),
      currentItem: z.object({
        id:          z.string(),
        type:        z.enum(['product', 'factory']),
        name:        z.string().optional(),
        category:    z.string().optional(),
        description: z.string().optional(),
      }),
      userHistory: z.object({
        viewedItems:   z.array(z.string()).optional(),
        searchHistory: z.array(z.string()).optional(),
      }).optional(),
      limit: z.number().min(1).max(20).default(6),
    }))
    .query(({ input, ctx }) =>
      runAgent({
        agent:  'recommendation_engine',
        input,
        ttl:    AI_TTL.recommendations,
        userId: ctx.user?.id,
        fn:     getRecommendationGuidance,
      }),
    ),

  // ── Health check ─────────────────────────────────────────────────────────
  health: publicProcedure.query(async () => {
    const { isOllamaAvailable, ensureModel } = await import('./ai/ollama-client');
    const ollamaUp = await isOllamaAvailable();
    if (ollamaUp) ensureModel().catch(() => {});
    return { ollama: ollamaUp, timestamp: new Date().toISOString() };
  }),
});
