/**
 * Email/Password Authentication Routes
 * POST /api/auth/register    — create account with email + password
 * POST /api/auth/login       — sign in with email + password
 * POST /api/auth/forgot-password — send password-reset email
 * POST /api/auth/reset-password  — apply new password via reset token
 */
import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { sdk } from "./_core/sdk";
import * as db from "./db";
import { sendPasswordResetEmail, sendWelcomeEmail } from "./email";
import { ENV } from "./_core/env";

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Derives a salted hash using Node's built-in scrypt (no extra deps). */
function hashPassword(password: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString("hex");
    crypto.scrypt(password, salt, 64, (err, derived) => {
      if (err) return reject(err);
      resolve(`${salt}:${derived.toString("hex")}`);
    });
  });
}

/** Returns true when the plain-text password matches the stored hash. */
function verifyPassword(password: string, stored: string): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return resolve(false);
    crypto.scrypt(password, salt, 64, (err, derived) => {
      if (err) return reject(err);
      // Constant-time comparison to prevent timing attacks
      const derivedBuf = Buffer.from(derived.toString("hex"));
      const storedBuf = Buffer.from(hash);
      if (derivedBuf.length !== storedBuf.length) return resolve(false);
      resolve(crypto.timingSafeEqual(derivedBuf, storedBuf));
    });
  });
}



function hashResetToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

function getBaseUrl(req: Request): string {
  const proto = req.headers["x-forwarded-proto"] || req.protocol || "https";
  const host = req.headers["x-forwarded-host"] || req.headers.host || "localhost:3000";
  return `${proto}://${host}`;
}

// ── Route Registration ────────────────────────────────────────────────────────

export function registerAuthRoutes(app: Express) {
  /**
   * POST /api/auth/register
   * Body: { email, password, name, role? }
   */
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, name, role } = req.body as {
        email?: string;
        password?: string;
        name?: string;
        role?: string;
      };

      if (!email || !password || !name) {
        res.status(400).json({ error: "Email, password, and name are required." });
        return;
      }

      if (password.length < 6) {
        res.status(400).json({ error: "Password must be at least 6 characters." });
        return;
      }

      // Check if email already registered
      const existing = await db.getUserByEmail(email.toLowerCase().trim());
      if (existing) {
        res.status(409).json({ error: "An account with this email already exists." });
        return;
      }

      const passwordHash = await hashPassword(password);
      // Use email as the openId for email/password accounts
      const openId = `email:${email.toLowerCase().trim()}`;

      await db.upsertUser({
        openId,
        name: name.trim(),
        email: email.toLowerCase().trim(),
        loginMethod: "email",
        lastSignedIn: new Date(),
        role: role === "admin" ? "admin" : "user",
      });

      const user = await db.getUserByOpenId(openId);
      if (!user) {
        res.status(500).json({ error: "Failed to create account. Please try again." });
        return;
      }

      // Store password hash
      await db.setUserPassword(user.id, passwordHash);

      // Issue session
      const sessionToken = await sdk.createSessionToken(openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      // Send welcome email (non-blocking)
      if (user.email) {
        sendWelcomeEmail(user.email, user.name || "").catch(() => {});
      }

      res.json({ success: true });
    } catch (err) {
      console.error("[Auth] Register error:", err);
      res.status(500).json({ error: "Registration failed. Please try again." });
    }
  });

  /**
   * POST /api/auth/login
   * Body: { email, password }
   */
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body as { email?: string; password?: string };

      if (!email || !password) {
        res.status(400).json({ error: "Email and password are required." });
        return;
      }

      const user = await db.getUserByEmail(email.toLowerCase().trim());

      if (!user || !user.passwordHash) {
        // Same error regardless of whether user exists (prevent user enumeration)
        res.status(401).json({ error: "Invalid email or password." });
        return;
      }

      const valid = await verifyPassword(password, user.passwordHash);
      if (!valid) {
        res.status(401).json({ error: "Invalid email or password." });
        return;
      }

      // Issue session
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.json({ success: true });
    } catch (err) {
      console.error("[Auth] Login error:", err);
      res.status(500).json({ error: "Login failed. Please try again." });
    }
  });

  /**
   * POST /api/auth/forgot-password
   * Body: { email }
   */
  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body as { email?: string };

      if (!email) {
        res.status(400).json({ error: "Email is required." });
        return;
      }

      // Always return success to prevent user enumeration
      const user = await db.getUserByEmail(email.toLowerCase().trim());
      if (user) {
        const token = crypto.randomBytes(48).toString("hex");
        const expires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

        await db.setResetToken(user.id, hashResetToken(token), expires);

        const resetUrl = `${getBaseUrl(req)}/reset-password?token=${token}`;
        await sendPasswordResetEmail(email.toLowerCase().trim(), resetUrl);
      }

      res.json({ success: true, message: "If that email is registered, a reset link has been sent." });
    } catch (err) {
      console.error("[Auth] Forgot password error:", err);
      res.status(500).json({ error: "Failed to send reset email. Please try again." });
    }
  });

  /**
   * POST /api/auth/reset-password
   * Body: { token, password }
   */
  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body as { token?: string; password?: string };

      if (!token || !password) {
        res.status(400).json({ error: "Token and new password are required." });
        return;
      }

      if (password.length < 6) {
        res.status(400).json({ error: "Password must be at least 6 characters." });
        return;
      }

      const user = await db.getUserByResetToken(hashResetToken(token));

      if (!user || !user.resetTokenExpires || user.resetTokenExpires < new Date()) {
        res.status(400).json({ error: "This reset link is invalid or has expired." });
        return;
      }

      const passwordHash = await hashPassword(password);
      await db.setUserPassword(user.id, passwordHash);
      await db.clearResetToken(user.id);

      res.json({ success: true, message: "Password updated successfully. You can now log in." });
    } catch (err) {
      console.error("[Auth] Reset password error:", err);
      res.status(500).json({ error: "Failed to reset password. Please try again." });
    }
  });
}
