/**
 * Seed script: Populates the database with 25 realistic Chinese factory profiles.
 * Run: npx tsx server/seed.ts
 */
import { drizzle } from "drizzle-orm/mysql2";
import { users, factories, categories, products } from "../drizzle/schema";
import { sql } from "drizzle-orm";

async function seed() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.error("DATABASE_URL not set. Skipping seed.");
    process.exit(1);
  }

  const db = drizzle(dbUrl);
  console.log("[Seed] Connected to database");

  // ---------- Categories ----------
  const categoryData = [
    { name: "Electronics", slug: "electronics", description: "Consumer electronics and components", icon: "Cpu" },
    { name: "LED Lighting", slug: "led-lighting", description: "LED lights, strips, and fixtures", icon: "Lightbulb" },
    { name: "Textiles & Apparel", slug: "textiles", description: "Clothing, fabrics, and accessories", icon: "Shirt" },
    { name: "Auto Parts", slug: "auto-parts", description: "Automotive components and accessories", icon: "Car" },
    { name: "Home & Garden", slug: "home-garden", description: "Furniture, decor, and garden tools", icon: "Home" },
    { name: "Machinery", slug: "machinery", description: "Industrial machinery and equipment", icon: "Wrench" },
    { name: "Packaging", slug: "packaging", description: "Packaging materials and solutions", icon: "Package" },
    { name: "Beauty & Personal Care", slug: "beauty", description: "Cosmetics, skincare, and personal care", icon: "Sparkles" },
    { name: "Toys & Games", slug: "toys", description: "Toys, games, and recreational products", icon: "Gamepad2" },
    { name: "Solar & Energy", slug: "solar-energy", description: "Solar panels and energy equipment", icon: "Sun" },
  ];

  console.log("[Seed] Inserting categories...");
  for (const cat of categoryData) {
    await db.insert(categories).values(cat).onDuplicateKeyUpdate({ set: { name: cat.name } });
  }

  // ---------- Seed user for factory owners ----------
  console.log("[Seed] Inserting factory owner users...");
  const factoryOwnerIds: number[] = [];

  for (let i = 1; i <= 25; i++) {
    const openId = `seed_factory_owner_${i}`;
    await db.insert(users).values({
      openId,
      name: `Factory Owner ${i}`,
      email: `factory${i}@seed.ifrof.com`,
      role: "user",
      plan: "free",
    }).onDuplicateKeyUpdate({ set: { name: `Factory Owner ${i}` } });

    const [row] = await db.select({ id: users.id }).from(users).where(sql`${users.openId} = ${openId}`).limit(1);
    factoryOwnerIds.push(row.id);
  }

  // ---------- Factory data ----------
  const factoryData = [
    { name: "Shenzhen BrightLED Technology Co., Ltd.", city: "Shenzhen", category: "LED Lighting", description: "Leading manufacturer of LED strip lights, panel lights, and smart lighting solutions. Supplying major brands across 40+ countries.", moq: "500 pcs", yearEstablished: 2008, employeeCount: 350, verificationLevel: 3, trustScore: 92, certifications: ["ISO 9001", "CE", "RoHS", "UL"], capabilities: ["OEM", "ODM", "Custom Design"], exportCountries: ["USA", "Germany", "UK", "UAE", "Australia"], socialCreditCode: "91440300MA5DLXXX8P" },
    { name: "Guangzhou YiTong Electronics Co., Ltd.", city: "Guangzhou", category: "Electronics", description: "Specializing in Bluetooth earbuds, TWS headphones, and smart wearables. Annual production capacity of 5 million units.", moq: "1000 pcs", yearEstablished: 2012, employeeCount: 280, verificationLevel: 2, trustScore: 85, certifications: ["ISO 9001", "FCC", "CE"], capabilities: ["OEM", "ODM"], exportCountries: ["USA", "Brazil", "India", "Japan"], socialCreditCode: "91440101MA5CNXXX2T" },
    { name: "Ningbo HaiYuan Machinery Co., Ltd.", city: "Ningbo", category: "Machinery", description: "CNC precision parts, injection molding, and die casting. ISO certified with advanced quality control.", moq: "200 pcs", yearEstablished: 2005, employeeCount: 420, verificationLevel: 3, trustScore: 95, certifications: ["ISO 9001", "ISO 14001", "IATF 16949"], capabilities: ["CNC Machining", "Die Casting", "Surface Treatment"], exportCountries: ["USA", "Germany", "Japan", "South Korea", "Mexico"], socialCreditCode: "91330200MA28XXXX4K" },
    { name: "Dongguan SunPower Toys Factory", city: "Dongguan", category: "Toys & Games", description: "Plush toys, educational toys, and action figures. Disney, Hasbro-approved factory with ICTI certification.", moq: "3000 pcs", yearEstablished: 2003, employeeCount: 600, verificationLevel: 3, trustScore: 90, certifications: ["ICTI", "ISO 9001", "EN 71", "ASTM F963"], capabilities: ["Plush Toys", "Injection Molding", "Printing"], exportCountries: ["USA", "UK", "France", "Australia", "Canada"], socialCreditCode: "91441900MA4WXXXX5L" },
    { name: "Hangzhou GreenStar Solar Co., Ltd.", city: "Hangzhou", category: "Solar & Energy", description: "Manufacturer of monocrystalline and polycrystalline solar panels, inverters, and off-grid solar systems.", moq: "50 units", yearEstablished: 2010, employeeCount: 200, verificationLevel: 2, trustScore: 82, certifications: ["TUV", "IEC 61215", "ISO 9001", "CE"], capabilities: ["Solar Panels", "Inverters", "System Design"], exportCountries: ["Africa", "Middle East", "Southeast Asia", "South America"], socialCreditCode: "91330100MA27XXXX3N" },
    { name: "Foshan LiangTai Furniture Co., Ltd.", city: "Foshan", category: "Home & Garden", description: "Modern office and home furniture. Specializing in ergonomic chairs, standing desks, and modular storage.", moq: "100 sets", yearEstablished: 2007, employeeCount: 180, verificationLevel: 2, trustScore: 78, certifications: ["ISO 9001", "BIFMA", "FSC"], capabilities: ["Custom Design", "OEM", "Assembly"], exportCountries: ["USA", "UK", "Germany", "Saudi Arabia"], socialCreditCode: "91440600MA4WXXXX9Q" },
    { name: "Zhejiang DaHua Textile Co., Ltd.", city: "Shaoxing", category: "Textiles & Apparel", description: "Premium woven and knitted fabrics. Producing for global fashion brands with OEKO-TEX certified materials.", moq: "500 meters", yearEstablished: 2001, employeeCount: 500, verificationLevel: 3, trustScore: 88, certifications: ["OEKO-TEX", "ISO 9001", "GOTS"], capabilities: ["Weaving", "Knitting", "Dyeing", "Printing"], exportCountries: ["USA", "EU", "Japan", "Australia", "Turkey"], socialCreditCode: "91330600MA28XXXX1B" },
    { name: "Shenzhen WeiXin PCB Technology Co., Ltd.", city: "Shenzhen", category: "Electronics", description: "PCB fabrication and assembly. 2-layer to 16-layer boards, flexible PCBs, HDI, and SMT assembly services.", moq: "100 pcs", yearEstablished: 2009, employeeCount: 320, verificationLevel: 2, trustScore: 84, certifications: ["ISO 9001", "ISO 14001", "UL", "IPC"], capabilities: ["PCB Fabrication", "SMT Assembly", "Testing"], exportCountries: ["USA", "Germany", "Japan", "India", "UK"], socialCreditCode: "91440300MA5DXXXX6R" },
    { name: "Yiwu MingHe Packaging Co., Ltd.", city: "Yiwu", category: "Packaging", description: "Custom packaging solutions: corrugated boxes, rigid boxes, paper bags, and eco-friendly packaging.", moq: "2000 pcs", yearEstablished: 2011, employeeCount: 150, verificationLevel: 1, trustScore: 72, certifications: ["ISO 9001", "FSC"], capabilities: ["Offset Printing", "Die Cutting", "Lamination"], exportCountries: ["USA", "UK", "UAE", "Australia"], socialCreditCode: "91330782MA28XXXX5D" },
    { name: "Guangzhou MeiLi Beauty Co., Ltd.", city: "Guangzhou", category: "Beauty & Personal Care", description: "Private label cosmetics and skincare. GMP certified facility producing lipsticks, serums, and facial masks.", moq: "5000 pcs", yearEstablished: 2013, employeeCount: 180, verificationLevel: 2, trustScore: 80, certifications: ["GMP", "ISO 22716", "FDA Registered"], capabilities: ["Private Label", "OEM", "Formulation"], exportCountries: ["USA", "UK", "Japan", "South Korea", "Middle East"], socialCreditCode: "91440101MA5CRXXX7U" },
    { name: "Taizhou HuiLong Auto Parts Co., Ltd.", city: "Taizhou", category: "Auto Parts", description: "OEM auto parts: brake pads, filters, suspension parts, and engine components. IATF certified.", moq: "500 pcs", yearEstablished: 2006, employeeCount: 260, verificationLevel: 2, trustScore: 83, certifications: ["IATF 16949", "ISO 9001", "ECE R90"], capabilities: ["Stamping", "Machining", "Assembly", "Testing"], exportCountries: ["USA", "Germany", "Russia", "Middle East", "Africa"], socialCreditCode: "91331000MA28XXXX8F" },
    { name: "Shenzhen StarLink IoT Technology Co., Ltd.", city: "Shenzhen", category: "Electronics", description: "Smart home devices, WiFi cameras, and IoT sensors. Integration with Alexa, Google Home, and Tuya.", moq: "500 pcs", yearEstablished: 2015, employeeCount: 150, verificationLevel: 1, trustScore: 75, certifications: ["FCC", "CE", "RoHS"], capabilities: ["Hardware Design", "Firmware", "App Development"], exportCountries: ["USA", "EU", "Japan", "Brazil"], socialCreditCode: "91440300MA5ELXXX4N" },
    { name: "Fujian BaoLin Stone Co., Ltd.", city: "Xiamen", category: "Home & Garden", description: "Natural stone products: marble countertops, granite tiles, and stone sculptures. Own quarries in Fujian.", moq: "50 sqm", yearEstablished: 1998, employeeCount: 400, verificationLevel: 3, trustScore: 91, certifications: ["ISO 9001", "CE", "SGS Tested"], capabilities: ["Quarrying", "Cutting", "Polishing", "Custom Fabrication"], exportCountries: ["USA", "EU", "Middle East", "Australia", "Japan"], socialCreditCode: "91350200MA31XXXX2J" },
    { name: "Jiangsu TianHe New Materials Co., Ltd.", city: "Suzhou", category: "Packaging", description: "Biodegradable packaging, compostable bags, and eco-friendly food containers. PLA and PBAT materials.", moq: "10000 pcs", yearEstablished: 2016, employeeCount: 120, verificationLevel: 1, trustScore: 70, certifications: ["ISO 9001", "BPI", "OK Compost"], capabilities: ["Extrusion", "Thermoforming", "Bag Making"], exportCountries: ["USA", "EU", "Canada", "Australia"], socialCreditCode: "91320500MA1WXXXX5G" },
    { name: "Quanzhou JinLong Sports Co., Ltd.", city: "Quanzhou", category: "Textiles & Apparel", description: "Athletic footwear and sportswear. Manufacturing for multiple international sports brands.", moq: "1000 pairs", yearEstablished: 2004, employeeCount: 800, verificationLevel: 3, trustScore: 93, certifications: ["ISO 9001", "BSCI", "WRAP", "OEKO-TEX"], capabilities: ["Shoe Manufacturing", "Injection Molding", "Screen Printing"], exportCountries: ["USA", "EU", "Latin America", "Middle East", "Africa"], socialCreditCode: "91350500MA31XXXX6H" },
    { name: "Wenzhou DaFeng Hardware Co., Ltd.", city: "Wenzhou", category: "Home & Garden", description: "Stainless steel hardware, door handles, hinges, and bathroom accessories. Mirror polishing expertise.", moq: "300 pcs", yearEstablished: 2008, employeeCount: 160, verificationLevel: 2, trustScore: 79, certifications: ["ISO 9001", "CE"], capabilities: ["Investment Casting", "CNC", "Polishing", "PVD Coating"], exportCountries: ["USA", "EU", "Middle East", "Southeast Asia"], socialCreditCode: "91330300MA28XXXX7K" },
    { name: "Zhongshan OptoLight Electronics Co., Ltd.", city: "Zhongshan", category: "LED Lighting", description: "High-power LED drivers, commercial lighting, and smart lighting controllers. 15+ patents.", moq: "200 pcs", yearEstablished: 2011, employeeCount: 200, verificationLevel: 2, trustScore: 81, certifications: ["ISO 9001", "UL", "CE", "SAA"], capabilities: ["LED Driver Design", "Commercial Lighting", "Smart Controls"], exportCountries: ["USA", "Australia", "UK", "India", "Southeast Asia"], socialCreditCode: "91442000MA4WXXXX3M" },
    { name: "Changzhou PrecisionGear Co., Ltd.", city: "Changzhou", category: "Machinery", description: "High-precision gears, reducers, and transmission components. Serving automotive and robotics industries.", moq: "100 pcs", yearEstablished: 2002, employeeCount: 300, verificationLevel: 2, trustScore: 86, certifications: ["ISO 9001", "IATF 16949", "ISO 14001"], capabilities: ["Gear Hobbing", "Grinding", "Heat Treatment", "Testing"], exportCountries: ["USA", "Germany", "Japan", "South Korea"], socialCreditCode: "91320400MA1NXXXX9P" },
    { name: "Dongguan SilkRoad Bags Co., Ltd.", city: "Dongguan", category: "Textiles & Apparel", description: "Handbags, backpacks, and travel luggage. Leather, canvas, and sustainable materials.", moq: "500 pcs", yearEstablished: 2010, employeeCount: 220, verificationLevel: 1, trustScore: 74, certifications: ["ISO 9001", "BSCI", "REACH"], capabilities: ["Leather Crafting", "Sewing", "Metal Hardware", "Custom Design"], exportCountries: ["USA", "EU", "Japan", "Middle East"], socialCreditCode: "91441900MA4WXXXX2N" },
    { name: "Xiamen CleanAir Technology Co., Ltd.", city: "Xiamen", category: "Electronics", description: "Air purifiers, HEPA filters, and industrial ventilation systems. CADR certified, exporting to 30+ countries.", moq: "200 units", yearEstablished: 2014, employeeCount: 130, verificationLevel: 2, trustScore: 77, certifications: ["ISO 9001", "CE", "CARB", "ETL"], capabilities: ["Filter Manufacturing", "Assembly", "Testing"], exportCountries: ["USA", "EU", "Japan", "South Korea", "India"], socialCreditCode: "91350200MA31XXXX8L" },
    { name: "Ningbo OceanWave Fishing Tackle Co., Ltd.", city: "Ningbo", category: "Toys & Games", description: "Fishing rods, reels, lures, and accessories. Carbon fiber and fiberglass rod manufacturing.", moq: "500 pcs", yearEstablished: 2007, employeeCount: 180, verificationLevel: 2, trustScore: 80, certifications: ["ISO 9001", "BSCI"], capabilities: ["Carbon Fiber Processing", "Reel Assembly", "Custom Lures"], exportCountries: ["USA", "Japan", "Australia", "EU", "Russia"], socialCreditCode: "91330200MA28XXXX6M" },
    { name: "Shanghai MediPack Healthcare Co., Ltd.", city: "Shanghai", category: "Packaging", description: "Medical device packaging, blister packs, and sterilization pouches. FDA registered, cleanroom facility.", moq: "5000 pcs", yearEstablished: 2009, employeeCount: 250, verificationLevel: 3, trustScore: 89, certifications: ["ISO 13485", "FDA 21 CFR", "ISO 9001", "GMP"], capabilities: ["Cleanroom Packaging", "Sterilization", "Validation"], exportCountries: ["USA", "EU", "Japan", "Middle East", "Southeast Asia"], socialCreditCode: "91310000MA1FXXXX5Q" },
    { name: "Foshan GoldMetal Aluminum Co., Ltd.", city: "Foshan", category: "Home & Garden", description: "Aluminum profiles, curtain walls, and architectural systems. Largest extrusion capacity in South China.", moq: "1 ton", yearEstablished: 2000, employeeCount: 700, verificationLevel: 3, trustScore: 94, certifications: ["ISO 9001", "ISO 14001", "CE", "LEED"], capabilities: ["Extrusion", "Anodizing", "Powder Coating", "Fabrication"], exportCountries: ["USA", "EU", "Middle East", "Africa", "Australia"], socialCreditCode: "91440600MA4WXXXX1S" },
    { name: "Heshan WanDa Ceramic Co., Ltd.", city: "Jiangmen", category: "Home & Garden", description: "Porcelain tiles, bathroom ceramics, and sanitaryware. Modern production lines with digital printing.", moq: "500 sqm", yearEstablished: 2005, employeeCount: 450, verificationLevel: 2, trustScore: 82, certifications: ["ISO 9001", "CE", "SGS"], capabilities: ["Digital Printing", "Glazing", "Polishing", "Rectification"], exportCountries: ["USA", "Middle East", "Africa", "Southeast Asia", "South America"], socialCreditCode: "91440700MA4WXXXX4R" },
    { name: "Shenzhen NanoTech Materials Co., Ltd.", city: "Shenzhen", category: "Electronics", description: "Thermal management solutions: thermal pads, heat sinks, and phase change materials for electronics.", moq: "1000 pcs", yearEstablished: 2013, employeeCount: 100, verificationLevel: 1, trustScore: 71, certifications: ["ISO 9001", "UL", "RoHS"], capabilities: ["Material R&D", "Die Cutting", "Custom Solutions"], exportCountries: ["USA", "Japan", "South Korea", "EU"], socialCreditCode: "91440300MA5FXXXX9T" },
  ];

  console.log("[Seed] Inserting 25 factories...");
  for (let i = 0; i < factoryData.length; i++) {
    const f = factoryData[i];
    await db.insert(factories).values({
      userId: factoryOwnerIds[i],
      name: f.name,
      description: f.description,
      category: f.category,
      country: "China",
      city: f.city,
      verified: f.verificationLevel >= 1 ? "verified" : "pending",
      verificationLevel: f.verificationLevel,
      trustScore: f.trustScore,
      moq: f.moq,
      capabilities: JSON.stringify(f.capabilities),
      socialCreditCode: f.socialCreditCode,
      yearEstablished: f.yearEstablished,
      employeeCount: f.employeeCount,
      exportCountries: JSON.stringify(f.exportCountries),
      certifications: JSON.stringify(f.certifications),
      lastVerifiedAt: f.verificationLevel >= 2 ? new Date() : null,
      subscriptionTier: f.trustScore >= 85 ? "premium" : "free",
    }).onDuplicateKeyUpdate({ set: { name: f.name } });
  }

  // ---------- Sample products ----------
  console.log("[Seed] Inserting sample products...");
  const catRows = await db.select().from(categories);
  const factoryRows = await db.select({ id: factories.id, category: factories.category }).from(factories);

  const sampleProducts = [
    { name: "5050 RGB LED Strip Light 5M", price: 450, factory: "LED Lighting", categorySlug: "led-lighting", featured: "hot_deal" as const },
    { name: "TWS Bluetooth Earbuds V5.3", price: 890, factory: "Electronics", categorySlug: "electronics", featured: "new" as const },
    { name: "CNC Aluminum Precision Parts", price: 1200, factory: "Machinery", categorySlug: "machinery", featured: "verified" as const },
    { name: "Custom Plush Toy - 30cm", price: 350, factory: "Toys & Games", categorySlug: "toys", featured: "top_rated" as const },
    { name: "300W Monocrystalline Solar Panel", price: 8500, factory: "Solar & Energy", categorySlug: "solar-energy", featured: "hot_deal" as const },
    { name: "Ergonomic Mesh Office Chair", price: 4500, factory: "Home & Garden", categorySlug: "home-garden", featured: "stock_sale" as const },
    { name: "Premium Cotton Fabric 100GSM", price: 180, factory: "Textiles & Apparel", categorySlug: "textiles", featured: "none" as const },
    { name: "4-Layer PCB Assembly PCBA", price: 250, factory: "Electronics", categorySlug: "electronics", featured: "verified" as const },
    { name: "Luxury Rigid Gift Box Custom", price: 120, factory: "Packaging", categorySlug: "packaging", featured: "none" as const },
    { name: "Vitamin C Serum Private Label", price: 280, factory: "Beauty & Personal Care", categorySlug: "beauty", featured: "new" as const },
    { name: "Ceramic Brake Pads Set", price: 950, factory: "Auto Parts", categorySlug: "auto-parts", featured: "top_rated" as const },
    { name: "Smart WiFi Security Camera", price: 1500, factory: "Electronics", categorySlug: "electronics", featured: "hot_deal" as const },
  ];

  for (const prod of sampleProducts) {
    const matchingFactory = factoryRows.find(f => f.category === prod.factory);
    const matchingCategory = catRows.find(c => c.slug === prod.categorySlug);
    if (!matchingFactory || !matchingCategory) continue;

    await db.insert(products).values({
      factoryId: matchingFactory.id,
      categoryId: matchingCategory.id,
      name: prod.name,
      description: `High quality ${prod.name} manufactured in China. Direct from factory.`,
      price: prod.price,
      currency: "USD",
      unit: "pcs",
      minOrder: 100,
      stockQuantity: 5000,
      status: "active",
      featured: prod.featured,
      rating: Math.floor(Math.random() * 10) + 40, // 40-50 (4.0-5.0)
      reviewCount: Math.floor(Math.random() * 50) + 5,
      views: Math.floor(Math.random() * 1000) + 100,
    }).onDuplicateKeyUpdate({ set: { name: prod.name } });
  }

  console.log("[Seed] Done! Inserted 10 categories, 25 factories, and 12 products.");
  process.exit(0);
}

seed().catch((err) => {
  console.error("[Seed] Error:", err);
  process.exit(1);
});
