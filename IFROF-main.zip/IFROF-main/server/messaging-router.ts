import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { adminProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { conversations, messages, users, analyticsEvents } from "../drizzle/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

/**
 * Messaging Router — Managed Sourcing Agent Model
 *
 * All conversations are between a BUYER and an ADMIN (agent).
 * Factories/suppliers are never part of any conversation visible to buyers.
 *
 * Schema note: conversations.factoryId is kept as an internal reference only
 * (e.g. to track which supplier an admin is discussing internally), but it is
 * never surfaced to the buyer.
 */
export const messagingRouter = router({

  // ─── BUYER: Start or resume a conversation with the IFROF team ──────────
  getOrCreateSupportConversation: protectedProcedure
    .input(z.object({
      rfqId: z.number().optional(),
      subject: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Look for an existing open conversation for this buyer (optionally tied to an RFQ)
      const existing = await db
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.buyerId, ctx.user.id),
            input.rfqId ? eq(conversations.rfqId, input.rfqId) : sql`${conversations.rfqId} IS NULL`
          )
        )
        .limit(1);

      if (existing.length > 0) {
        return { conversationId: existing[0].id, isNew: false };
      }

      const result = await db.insert(conversations).values({
        buyerId: ctx.user.id,
        factoryId: null, // no factory — this is buyer↔admin
        rfqId: input.rfqId ?? null,
        status: "active",
      }).$returningId();

      return { conversationId: result[0].id, isNew: true };
    }),

  // ─── BUYER: List all own conversations ──────────────────────────────────
  listConversations: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const result = await db
      .select({ conversation: conversations })
      .from(conversations)
      .where(eq(conversations.buyerId, ctx.user.id))
      .orderBy(desc(conversations.lastMessageAt));

    const withLastMessage = await Promise.all(
      result.map(async (r) => {
        const lastMsg = await db
          .select()
          .from(messages)
          .where(eq(messages.conversationId, r.conversation.id))
          .orderBy(desc(messages.createdAt))
          .limit(1);

        const unreadResult = await db
          .select({ count: sql<number>`count(*)` })
          .from(messages)
          .where(
            and(
              eq(messages.conversationId, r.conversation.id),
              sql`${messages.readAt} IS NULL`,
              sql`${messages.senderId} != ${ctx.user.id}`
            )
          );

        return {
          ...r.conversation,
          // Return a generic "IFROF Team" label — never expose factory name
          agentLabel: "IFROF Sourcing Team",
          lastMessage: lastMsg[0] ?? null,
          unreadCount: Number(unreadResult[0]?.count ?? 0),
        };
      })
    );

    return withLastMessage;
  }),

  // ─── BUYER / ADMIN: Get messages in a conversation ───────────────────────
  getMessages: protectedProcedure
    .input(z.object({
      conversationId: z.number(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const conv = await db
        .select()
        .from(conversations)
        .where(eq(conversations.id, input.conversationId))
        .limit(1);

      if (conv.length === 0) throw new TRPCError({ code: "NOT_FOUND" });

      // Buyer can only access their own conversations; admin can access all
      if (conv[0].buyerId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const result = await db
        .select({
          message: messages,
          sender: {
            id: users.id,
            name: users.name,
            role: users.role,
          },
        })
        .from(messages)
        .leftJoin(users, eq(messages.senderId, users.id))
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(desc(messages.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      // Mark messages as read for the current user
      await db
        .update(messages)
        .set({ readAt: new Date() })
        .where(
          and(
            eq(messages.conversationId, input.conversationId),
            sql`${messages.readAt} IS NULL`,
            sql`${messages.senderId} != ${ctx.user.id}`
          )
        );

      return {
        conversation: {
          id: conv[0].id,
          rfqId: conv[0].rfqId,
          status: conv[0].status,
          lastMessageAt: conv[0].lastMessageAt,
          // Never expose factoryId to buyer
          agentLabel: "IFROF Sourcing Team",
        },
        messages: result.reverse().map(r => ({
          ...r.message,
          sender: {
            id: r.sender?.id,
            // If sender is admin, show as "IFROF Team" to buyer
            name: r.sender?.role === "admin" ? "IFROF Sourcing Team" : r.sender?.name,
            role: r.sender?.role,
          },
        })),
      };
    }),

  // ─── BUYER: Send a message ───────────────────────────────────────────────
  sendMessage: protectedProcedure
    .input(z.object({
      conversationId: z.number(),
      body: z.string().min(1).max(5000),
      attachments: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const conv = await db
        .select()
        .from(conversations)
        .where(eq(conversations.id, input.conversationId))
        .limit(1);

      if (conv.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
      if (conv[0].buyerId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const senderType = ctx.user.role === "admin" ? "admin" as const : "buyer" as const;

      const result = await db.insert(messages).values({
        conversationId: input.conversationId,
        senderType,
        senderId: ctx.user.id,
        body: input.body,
        attachments: input.attachments ? JSON.stringify(input.attachments) : null,
      }).$returningId();

      await db
        .update(conversations)
        .set({ lastMessageAt: new Date() })
        .where(eq(conversations.id, input.conversationId));

      await db.insert(analyticsEvents).values({
        userId: ctx.user.id,
        event: "message_sent",
        properties: JSON.stringify({ conversationId: input.conversationId, senderType }),
      });

      return { success: true, messageId: result[0].id };
    }),

  // ─── ADMIN: List ALL conversations (with buyer info) ─────────────────────
  adminListConversations: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const result = await db
      .select({
        conversation: conversations,
        buyer: { id: users.id, name: users.name, email: users.email },
      })
      .from(conversations)
      .leftJoin(users, eq(conversations.buyerId, users.id))
      .orderBy(desc(conversations.lastMessageAt));

    return Promise.all(
      result.map(async (r) => {
        const lastMsg = await db
          .select()
          .from(messages)
          .where(eq(messages.conversationId, r.conversation.id))
          .orderBy(desc(messages.createdAt))
          .limit(1);

        const unreadResult = await db
          .select({ count: sql<number>`count(*)` })
          .from(messages)
          .where(
            and(
              eq(messages.conversationId, r.conversation.id),
              sql`${messages.readAt} IS NULL`,
              eq(messages.senderType, "buyer")
            )
          );

        return {
          ...r.conversation,
          buyer: r.buyer,
          lastMessage: lastMsg[0] ?? null,
          unreadFromBuyer: Number(unreadResult[0]?.count ?? 0),
        };
      })
    );
  }),

  // ─── ADMIN: Reply to a conversation ──────────────────────────────────────
  adminReply: adminProcedure
    .input(z.object({
      conversationId: z.number(),
      body: z.string().min(1),
      attachments: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const conv = await db
        .select()
        .from(conversations)
        .where(eq(conversations.id, input.conversationId))
        .limit(1);

      if (conv.length === 0) throw new TRPCError({ code: "NOT_FOUND" });

      await db.insert(messages).values({
        conversationId: input.conversationId,
        senderType: "admin",
        senderId: ctx.user.id,
        body: input.body,
        attachments: input.attachments ? JSON.stringify(input.attachments) : null,
      });

      await db
        .update(conversations)
        .set({ lastMessageAt: new Date() })
        .where(eq(conversations.id, input.conversationId));

      return { success: true };
    }),
});
