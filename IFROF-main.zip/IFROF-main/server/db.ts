import { eq, and, desc, sql, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try {
      _db = drizzle(ENV.databaseUrl, { schema, mode: 'default' });
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER HELPERS ============

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(schema.users).where(eq(schema.users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertUser(user: schema.InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: schema.InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(schema.users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

// ============ CART HELPERS ============

export async function getCartItems(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select({
    cartItem: schema.cartItems,
    product: schema.products,
    factory: schema.factories,
  })
  .from(schema.cartItems)
  .leftJoin(schema.products, eq(schema.cartItems.productId, schema.products.id))
  .leftJoin(schema.factories, eq(schema.products.factoryId, schema.factories.id))
  .where(eq(schema.cartItems.userId, userId))
  .orderBy(desc(schema.cartItems.createdAt));
}

export async function addToCart(userId: number, productId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if item already exists
  const existing = await db.select()
    .from(schema.cartItems)
    .where(and(
      eq(schema.cartItems.userId, userId),
      eq(schema.cartItems.productId, productId)
    ))
    .limit(1);

  if (existing.length > 0) {
    // Update quantity
    await db.update(schema.cartItems)
      .set({ quantity: existing[0].quantity + quantity })
      .where(eq(schema.cartItems.id, existing[0].id));
    return existing[0].id;
  } else {
    // Create new cart item
    const result = await db.insert(schema.cartItems).values({ userId, productId, quantity });
    return result[0].insertId;
  }
}

export async function updateCartItemQuantity(cartItemId: number, quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (quantity <= 0) {
    await db.delete(schema.cartItems).where(eq(schema.cartItems.id, cartItemId));
  } else {
    await db.update(schema.cartItems).set({ quantity }).where(eq(schema.cartItems.id, cartItemId));
  }
}

export async function removeFromCart(cartItemId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(schema.cartItems).where(eq(schema.cartItems.id, cartItemId));
}

export async function clearCart(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(schema.cartItems).where(eq(schema.cartItems.userId, userId));
}

// ============ WISHLIST HELPERS ============

export async function getWishlistItems(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select({
    wishlistItem: schema.wishlistItems,
    product: schema.products,
    factory: schema.factories,
  })
  .from(schema.wishlistItems)
  .leftJoin(schema.products, eq(schema.wishlistItems.productId, schema.products.id))
  .leftJoin(schema.factories, eq(schema.products.factoryId, schema.factories.id))
  .where(eq(schema.wishlistItems.userId, userId))
  .orderBy(desc(schema.wishlistItems.createdAt));
}

export async function addToWishlist(userId: number, productId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if already in wishlist
  const existing = await db.select()
    .from(schema.wishlistItems)
    .where(and(
      eq(schema.wishlistItems.userId, userId),
      eq(schema.wishlistItems.productId, productId)
    ))
    .limit(1);

  if (existing.length > 0) return existing[0].id;

  const result = await db.insert(schema.wishlistItems).values({ userId, productId });
  return result[0].insertId;
}

export async function removeFromWishlist(wishlistItemId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(schema.wishlistItems).where(eq(schema.wishlistItems.id, wishlistItemId));
}

// ============ ORDER HELPERS ============

export async function createOrder(orderData: schema.InsertOrder, items: Array<{ productId: number; quantity: number; price: number }>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.transaction(async (tx) => {
    const orderResult = await tx.insert(schema.orders).values(orderData);
    const orderId = orderResult[0].insertId;

    for (const item of items) {
      await tx.insert(schema.orderItems).values({
        orderId,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price,
        subtotal: item.quantity * item.price,
      });

      await tx.update(schema.products)
        .set({ orders: sql`${schema.products.orders} + 1` })
        .where(eq(schema.products.id, item.productId));
    }

    return orderId;
  });
}

export async function getOrderById(orderId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const orderResult = await db.select().from(schema.orders).where(eq(schema.orders.id, orderId)).limit(1);
  if (orderResult.length === 0) return null;

  const items = await db.select({
    orderItem: schema.orderItems,
    product: schema.products,
  })
  .from(schema.orderItems)
  .leftJoin(schema.products, eq(schema.orderItems.productId, schema.products.id))
  .where(eq(schema.orderItems.orderId, orderId));

  return { order: orderResult[0], items };
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(schema.orders)
    .where(eq(schema.orders.userId, userId))
    .orderBy(desc(schema.orders.createdAt));
}

export async function updateOrderStatus(orderId: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(schema.orders)
    .set({ status: status as any })
    .where(eq(schema.orders.id, orderId));
}

// ============ REVIEW HELPERS ============

export async function getProductReviews(productId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select({
    review: schema.reviews,
    user: schema.users,
  })
  .from(schema.reviews)
  .leftJoin(schema.users, eq(schema.reviews.userId, schema.users.id))
  .where(eq(schema.reviews.productId, productId))
  .orderBy(desc(schema.reviews.createdAt));
}

export async function createReview(data: schema.InsertReview) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.reviews).values(data);
  
  // Update product rating
  const reviews = await db.select().from(schema.reviews).where(eq(schema.reviews.productId, data.productId));
  const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
  
  await db.update(schema.products)
    .set({ 
      rating: Math.round(avgRating * 10), // Store as integer (e.g., 4.5 = 45)
      reviewCount: reviews.length 
    })
    .where(eq(schema.products.id, data.productId));

  return result[0].insertId;
}

// ============ FORUM HELPERS ============

export async function getForumPosts(categorySlug?: string, limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let query = db.select({
    post: schema.forumPosts,
    user: schema.users,
  })
  .from(schema.forumPosts)
  .leftJoin(schema.users, eq(schema.forumPosts.userId, schema.users.id))
  .$dynamic();

  if (categorySlug) {
    query = query.where(eq(schema.forumPosts.categorySlug, categorySlug));
  }

  return await query
    .orderBy(desc(schema.forumPosts.isPinned), desc(schema.forumPosts.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getForumPostById(postId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select({
    post: schema.forumPosts,
    user: schema.users,
  })
  .from(schema.forumPosts)
  .leftJoin(schema.users, eq(schema.forumPosts.userId, schema.users.id))
  .where(eq(schema.forumPosts.id, postId))
  .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createForumPost(data: schema.InsertForumPost) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.forumPosts).values(data);
  return result[0].insertId;
}

export async function getForumComments(postId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select({
    comment: schema.forumComments,
    user: schema.users,
  })
  .from(schema.forumComments)
  .leftJoin(schema.users, eq(schema.forumComments.userId, schema.users.id))
  .where(eq(schema.forumComments.postId, postId))
  .orderBy(schema.forumComments.createdAt);
}

export async function createForumComment(data: schema.InsertForumComment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.forumComments).values(data);
  
  // Increment comment count on post
  await db.update(schema.forumPosts)
    .set({ commentCount: sql`${schema.forumPosts.commentCount} + 1` })
    .where(eq(schema.forumPosts.id, data.postId));

  return result[0].insertId;
}

export async function voteOnPost(userId: number, postId: number, voteType: "up" | "down") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if user already voted
  const existing = await db.select()
    .from(schema.forumVotes)
    .where(and(
      eq(schema.forumVotes.userId, userId),
      eq(schema.forumVotes.targetType, "post"),
      eq(schema.forumVotes.targetId, postId)
    ))
    .limit(1);

  if (existing.length > 0) {
    const vote = existing[0];
    if (vote.voteType === voteType) {
      // Remove vote
      await db.delete(schema.forumVotes).where(eq(schema.forumVotes.id, vote.id));
      
      if (voteType === "up") {
        await db.update(schema.forumPosts)
          .set({ upvotes: sql`${schema.forumPosts.upvotes} - 1` })
          .where(eq(schema.forumPosts.id, postId));
      } else {
        await db.update(schema.forumPosts)
          .set({ downvotes: sql`${schema.forumPosts.downvotes} - 1` })
          .where(eq(schema.forumPosts.id, postId));
      }
    } else {
      // Change vote
      await db.update(schema.forumVotes)
        .set({ voteType })
        .where(eq(schema.forumVotes.id, vote.id));

      if (voteType === "up") {
        await db.update(schema.forumPosts)
          .set({ 
            upvotes: sql`${schema.forumPosts.upvotes} + 1`,
            downvotes: sql`${schema.forumPosts.downvotes} - 1`
          })
          .where(eq(schema.forumPosts.id, postId));
      } else {
        await db.update(schema.forumPosts)
          .set({ 
            upvotes: sql`${schema.forumPosts.upvotes} - 1`,
            downvotes: sql`${schema.forumPosts.downvotes} + 1`
          })
          .where(eq(schema.forumPosts.id, postId));
      }
    }
  } else {
    // Add new vote
    await db.insert(schema.forumVotes).values({
      userId,
      targetType: "post",
      targetId: postId,
      voteType,
    });

    if (voteType === "up") {
      await db.update(schema.forumPosts)
        .set({ upvotes: sql`${schema.forumPosts.upvotes} + 1` })
        .where(eq(schema.forumPosts.id, postId));
    } else {
      await db.update(schema.forumPosts)
        .set({ downvotes: sql`${schema.forumPosts.downvotes} + 1` })
        .where(eq(schema.forumPosts.id, postId));
    }
  }
}

// ============ NOTIFICATION HELPERS ============

export async function getUserNotifications(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select()
    .from(schema.notifications)
    .where(eq(schema.notifications.userId, userId))
    .orderBy(desc(schema.notifications.createdAt))
    .limit(limit);
}

export async function createNotification(data: schema.InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.notifications).values(data);
  return result[0].insertId;
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(schema.notifications)
    .set({ isRead: 1 })
    .where(eq(schema.notifications.id, notificationId));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(schema.notifications)
    .set({ isRead: 1 })
    .where(eq(schema.notifications.userId, userId));
}

// ============ BLOG HELPERS ============

export async function getBlogCategories() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select().from(schema.blogCategories).orderBy(schema.blogCategories.name);
}

export async function getBlogArticles(filters?: {
  categoryId?: number;
  status?: "draft" | "published" | "archived";
  featured?: boolean;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let query = db.select({
    article: schema.blogArticles,
    author: schema.users,
    category: schema.blogCategories,
  })
    .from(schema.blogArticles)
    .leftJoin(schema.users, eq(schema.blogArticles.authorId, schema.users.id))
    .leftJoin(schema.blogCategories, eq(schema.blogArticles.categoryId, schema.blogCategories.id));

  if (filters?.categoryId) {
    query = query.where(eq(schema.blogArticles.categoryId, filters.categoryId)) as any;
  }
  if (filters?.status) {
    query = query.where(eq(schema.blogArticles.status, filters.status)) as any;
  }
  if (filters?.featured) {
    query = query.where(eq(schema.blogArticles.featured, 1)) as any;
  }

  query = query.orderBy(desc(schema.blogArticles.publishedAt)) as any;

  if (filters?.limit) {
    query = query.limit(filters.limit) as any;
  }
  if (filters?.offset) {
    query = query.offset(filters.offset) as any;
  }

  return await query;
}

export async function getBlogArticleBySlug(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select({
    article: schema.blogArticles,
    author: schema.users,
    category: schema.blogCategories,
  })
    .from(schema.blogArticles)
    .leftJoin(schema.users, eq(schema.blogArticles.authorId, schema.users.id))
    .leftJoin(schema.blogCategories, eq(schema.blogArticles.categoryId, schema.blogCategories.id))
    .where(eq(schema.blogArticles.slug, slug))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function createBlogArticle(article: schema.InsertBlogArticle) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.blogArticles).values(article);
  return result;
}

export async function updateBlogArticle(id: number, article: Partial<schema.InsertBlogArticle>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(schema.blogArticles).set(article).where(eq(schema.blogArticles.id, id));
}

export async function deleteBlogArticle(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(schema.blogArticles).where(eq(schema.blogArticles.id, id));
}

export async function incrementBlogArticleViews(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(schema.blogArticles)
    .set({ views: sql`${schema.blogArticles.views} + 1` })
    .where(eq(schema.blogArticles.id, id));
}

export async function getBlogComments(articleId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.select({
    comment: schema.blogComments,
    user: schema.users,
  })
    .from(schema.blogComments)
    .leftJoin(schema.users, eq(schema.blogComments.userId, schema.users.id))
    .where(eq(schema.blogComments.articleId, articleId))
    .orderBy(schema.blogComments.createdAt);
}

export async function createBlogComment(comment: schema.InsertBlogComment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(schema.blogComments).values(comment);
  return result;
}

// ============ EMAIL/PASSWORD AUTH HELPERS ============

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(schema.users)
    .where(eq(schema.users.email, email))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function setUserPassword(userId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(schema.users)
    .set({ passwordHash })
    .where(eq(schema.users.id, userId));
}

export async function setResetToken(userId: number, tokenHash: string, expires: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(schema.users)
    .set({ resetToken: tokenHash, resetTokenExpires: expires })
    .where(eq(schema.users.id, userId));
}

export async function getUserByResetToken(tokenHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(schema.users)
    .where(eq(schema.users.resetToken, tokenHash))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function clearResetToken(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(schema.users)
    .set({ resetToken: null, resetTokenExpires: null })
    .where(eq(schema.users.id, userId));
}

// ============ QUOTE REQUEST HELPERS ============

export async function createQuoteRequest(data: {
  userId?: number;
  productId: number;
  name: string;
  email: string;
  phone?: string;
  company?: string;
  quantity: number;
  unit?: string;
  message?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(schema.productQuoteRequests).values({
    userId: data.userId,
    productId: data.productId,
    name: data.name,
    email: data.email,
    phone: data.phone,
    company: data.company,
    quantity: data.quantity,
    unit: data.unit || 'piece',
    message: data.message,
    status: 'pending',
  });
  return (result[0] as any).insertId;
}

export async function listQuoteRequests(status?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const conditions = [];
  if (status) conditions.push(eq(schema.productQuoteRequests.status, status as any));
  return await db.select({
    request: schema.productQuoteRequests,
    product: { id: schema.products.id, name: schema.products.name },
  })
    .from(schema.productQuoteRequests)
    .leftJoin(schema.products, eq(schema.productQuoteRequests.productId, schema.products.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(schema.productQuoteRequests.createdAt));
}

export async function updateQuoteRequestStatus(id: number, status: string, adminNotes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(schema.productQuoteRequests)
    .set({ status: status as any, adminNotes })
    .where(eq(schema.productQuoteRequests.id, id));
}

// ============ WAITLIST HELPERS ============

export async function addToWaitlist(email: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const result = await db.insert(schema.waitlist).values({ email });
    return result[0].insertId;
  } catch (error: any) {
    // If already in waitlist, return existing status
    if (error.code === 'ER_DUP_ENTRY') {
      return -1;
    }
    throw error;
  }
}
