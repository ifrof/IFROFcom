/**
 * Downloads the Qwen2.5 3B model for local AI inference.
 * Run once on your server: pnpm run setup:model
 *
 * Model: Qwen2.5-3B-Instruct (Q4_K_M quantization)
 * Size:  ~2 GB
 * Good at: Arabic, Chinese manufacturing, general chat
 * Cost:  FREE forever — runs on your own CPU/GPU
 */
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createModelDownloader } from "node-llama-cpp";
import { MODEL_FILENAME } from "../server/_core/localLLM.js";

const MODELS_DIR = path.resolve(
  fileURLToPath(import.meta.url),
  "../../models"
);

const MODEL_PATH = path.join(MODELS_DIR, MODEL_FILENAME);

async function main() {
  if (fs.existsSync(MODEL_PATH)) {
    console.log(`✓ Model already exists: ${MODEL_PATH}`);
    console.log("  Delete it and re-run to re-download.");
    process.exit(0);
  }

  fs.mkdirSync(MODELS_DIR, { recursive: true });

  console.log("Downloading Qwen2.5-3B-Instruct (Q4_K_M) — ~2 GB...");
  console.log(`Destination: ${MODEL_PATH}`);
  console.log();

  const downloader = await createModelDownloader({
    modelUri: "hf:Qwen/Qwen2.5-3B-Instruct-GGUF/qwen2.5-3b-instruct-q4_k_m.gguf",
    dirPath: MODELS_DIR,
    onProgress({ downloadedSize, totalSize }) {
      const pct = totalSize ? Math.round((downloadedSize / totalSize) * 100) : "?";
      const mb = Math.round(downloadedSize / 1024 / 1024);
      const totalMb = totalSize ? Math.round(totalSize / 1024 / 1024) : "?";
      process.stdout.write(`\r  ${pct}%  ${mb} MB / ${totalMb} MB`);
    },
  });

  await downloader.download();
  console.log("\n\n✓ Model downloaded successfully.");
  console.log("  Start your server normally — it will load the model on first chat request.");
}

main().catch((err) => {
  console.error("Download failed:", err);
  process.exit(1);
});
