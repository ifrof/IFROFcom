-- ============================================
-- IFROF Database Indexes for 1M+ Users
-- Performance Optimization Migration
-- ============================================

-- Users Table Indexes
CREATE INDEX IF NOT EXISTS idx_users_openId ON users(openId);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_lastSignedIn ON users(lastSignedIn);

-- Products Table Indexes
CREATE INDEX IF NOT EXISTS idx_products_factoryId ON products(factoryId);
CREATE INDEX IF NOT EXISTS idx_products_categoryId ON products(categoryId);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured);
CREATE INDEX IF NOT EXISTS idx_products_status_created ON products(status, createdAt);
CREATE INDEX IF NOT EXISTS idx_products_status_featured ON products(status, featured);
CREATE INDEX IF NOT EXISTS idx_products_price ON products(price);
CREATE INDEX IF NOT EXISTS idx_products_rating ON products(rating);

-- Full-text search removed (not supported by TiDB)
-- Use LIKE queries or external search service instead

-- Cart Items Indexes
CREATE INDEX IF NOT EXISTS idx_cartItems_userId ON cartItems(userId);
CREATE INDEX IF NOT EXISTS idx_cartItems_productId ON cartItems(productId);
CREATE INDEX IF NOT EXISTS idx_cartItems_user_product ON cartItems(userId, productId);

-- Wishlist Items Indexes
CREATE INDEX IF NOT EXISTS idx_wishlistItems_userId ON wishlistItems(userId);
CREATE INDEX IF NOT EXISTS idx_wishlistItems_productId ON wishlistItems(productId);
CREATE INDEX IF NOT EXISTS idx_wishlistItems_user_product ON wishlistItems(userId, productId);

-- Orders Table Indexes
CREATE INDEX IF NOT EXISTS idx_orders_userId ON orders(userId);
CREATE INDEX IF NOT EXISTS idx_orders_orderNumber ON orders(orderNumber);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_paymentStatus ON orders(paymentStatus);
CREATE INDEX IF NOT EXISTS idx_orders_createdAt ON orders(createdAt);
CREATE INDEX IF NOT EXISTS idx_orders_user_status ON orders(userId, status);

-- Order Items Indexes
CREATE INDEX IF NOT EXISTS idx_orderItems_orderId ON orderItems(orderId);
CREATE INDEX IF NOT EXISTS idx_orderItems_productId ON orderItems(productId);

-- Reviews Table Indexes
CREATE INDEX IF NOT EXISTS idx_reviews_productId ON reviews(productId);
CREATE INDEX IF NOT EXISTS idx_reviews_userId ON reviews(userId);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_createdAt ON reviews(createdAt);
CREATE INDEX IF NOT EXISTS idx_reviews_product_created ON reviews(productId, createdAt);

-- Forum Posts Indexes
CREATE INDEX IF NOT EXISTS idx_forumPosts_userId ON forumPosts(userId);
CREATE INDEX IF NOT EXISTS idx_forumPosts_categorySlug ON forumPosts(categorySlug);
CREATE INDEX IF NOT EXISTS idx_forumPosts_isPinned ON forumPosts(isPinned);
CREATE INDEX IF NOT EXISTS idx_forumPosts_createdAt ON forumPosts(createdAt);
CREATE INDEX IF NOT EXISTS idx_forumPosts_category_pinned ON forumPosts(categorySlug, isPinned, createdAt);

-- Full-text search removed (not supported by TiDB)
-- Use LIKE queries or external search service instead

-- Forum Comments Indexes
CREATE INDEX IF NOT EXISTS idx_forumComments_postId ON forumComments(postId);
CREATE INDEX IF NOT EXISTS idx_forumComments_userId ON forumComments(userId);
CREATE INDEX IF NOT EXISTS idx_forumComments_parentId ON forumComments(parentId);
CREATE INDEX IF NOT EXISTS idx_forumComments_createdAt ON forumComments(createdAt);

-- Forum Votes Indexes
CREATE INDEX IF NOT EXISTS idx_forumVotes_userId ON forumVotes(userId);
CREATE INDEX IF NOT EXISTS idx_forumVotes_targetType ON forumVotes(targetType);
CREATE INDEX IF NOT EXISTS idx_forumVotes_targetId ON forumVotes(targetId);
CREATE INDEX IF NOT EXISTS idx_forumVotes_user_target ON forumVotes(userId, targetType, targetId);

-- Notifications Indexes
CREATE INDEX IF NOT EXISTS idx_notifications_userId ON notifications(userId);
CREATE INDEX IF NOT EXISTS idx_notifications_isRead ON notifications(isRead);
CREATE INDEX IF NOT EXISTS idx_notifications_createdAt ON notifications(createdAt);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(userId, isRead, createdAt);

-- Factories Table Indexes
CREATE INDEX IF NOT EXISTS idx_factories_userId ON factories(userId);
CREATE INDEX IF NOT EXISTS idx_factories_verified ON factories(verified);
CREATE INDEX IF NOT EXISTS idx_factories_trustScore ON factories(trustScore);
CREATE INDEX IF NOT EXISTS idx_factories_country ON factories(country);
CREATE INDEX IF NOT EXISTS idx_factories_verified_trust ON factories(verified, trustScore);

-- Categories Table Indexes
CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);
CREATE INDEX IF NOT EXISTS idx_categories_parentId ON categories(parentId);

-- ============================================
-- Performance Notes:
-- - These indexes will significantly improve query performance
-- - Expected query time reduction: 100x-1000x
-- - Disk space increase: ~20-30% of table size
-- - Index maintenance overhead: minimal
-- ============================================
