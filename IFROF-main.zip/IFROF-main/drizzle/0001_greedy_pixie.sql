CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`slug` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(50),
	`parentId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `factories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`country` varchar(100) DEFAULT 'China',
	`city` varchar(100),
	`address` text,
	`website` varchar(500),
	`logo` varchar(500),
	`verified` enum('pending','verified','rejected') DEFAULT 'pending',
	`trustScore` int DEFAULT 0,
	`subscriptionTier` enum('free','premium') DEFAULT 'free',
	`subscriptionExpiry` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `factories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`factoryId` int NOT NULL,
	`categoryId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`price` int NOT NULL,
	`originalPrice` int,
	`currency` varchar(3) DEFAULT 'USD',
	`unit` varchar(50) DEFAULT 'pcs',
	`minOrder` int DEFAULT 1,
	`stockQuantity` int DEFAULT 0,
	`sku` varchar(100),
	`images` text,
	`tags` text,
	`status` enum('draft','active','sold_out','archived') DEFAULT 'active',
	`featured` enum('none','hot_deal','stock_sale','new','top_rated','verified') DEFAULT 'none',
	`views` int DEFAULT 0,
	`orders` int DEFAULT 0,
	`rating` int DEFAULT 0,
	`reviewCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
