CREATE TABLE `factoryResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`searchId` int NOT NULL,
	`factoryName` varchar(255) NOT NULL,
	`contactPerson` varchar(255),
	`email` varchar(320),
	`phone` varchar(50),
	`whatsapp` varchar(50),
	`website` varchar(500),
	`address` text,
	`city` varchar(100),
	`country` varchar(100),
	`verificationEvidence` text,
	`productCategories` text,
	`certifications` text,
	`yearEstablished` int,
	`employeeCount` int,
	`trustScore` int DEFAULT 0,
	`rawData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `factoryResults_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `factorySearches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`searchType` enum('text','link','image','hscode','description') NOT NULL,
	`searchQuery` text NOT NULL,
	`searchHash` varchar(64) NOT NULL,
	`paymentIntentId` varchar(255),
	`paymentStatus` enum('pending','paid','failed') DEFAULT 'pending',
	`amountPaid` int DEFAULT 990,
	`status` enum('pending','processing','completed','failed') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `factorySearches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `searchCache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`searchHash` varchar(64) NOT NULL,
	`searchType` enum('text','link','image','hscode','description') NOT NULL,
	`searchQuery` text NOT NULL,
	`resultId` int NOT NULL,
	`accessCount` int DEFAULT 1,
	`lastAccessed` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `searchCache_id` PRIMARY KEY(`id`),
	CONSTRAINT `searchCache_searchHash_unique` UNIQUE(`searchHash`)
);
