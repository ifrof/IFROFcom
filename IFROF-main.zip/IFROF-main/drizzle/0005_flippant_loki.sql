CREATE TABLE `agentQuotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`rfqId` int NOT NULL,
	`buyerId` int NOT NULL,
	`agentId` int NOT NULL,
	`supplierId` int,
	`supplierName` varchar(255),
	`unitPrice` int NOT NULL,
	`quantity` int NOT NULL,
	`totalAmount` int NOT NULL,
	`currency` varchar(3) DEFAULT 'USD',
	`leadTimeDays` int,
	`shippingMethod` enum('sea','air','rail','express') DEFAULT 'sea',
	`shippingCost` int DEFAULT 0,
	`validUntil` timestamp,
	`notes` text,
	`internalNotes` text,
	`supplierUnitCost` int,
	`agentMarginPct` int,
	`status` enum('draft','sent','accepted','rejected','expired') NOT NULL DEFAULT 'draft',
	`acceptedAt` timestamp,
	`rejectedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `agentQuotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `analyticsEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`event` varchar(100) NOT NULL,
	`properties` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyticsEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`buyerId` int NOT NULL,
	`factoryId` int,
	`rfqId` int,
	`status` enum('active','archived','closed') DEFAULT 'active',
	`lastMessageAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `disputeCases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`protectedOrderId` int NOT NULL,
	`openedBy` int NOT NULL,
	`reason` text NOT NULL,
	`status` enum('open','investigating','resolved','closed') DEFAULT 'open',
	`resolution` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `disputeCases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `escrowStatuses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`protectedOrderId` int NOT NULL,
	`status` varchar(50) NOT NULL,
	`notes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedBy` int,
	CONSTRAINT `escrowStatuses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `factoryDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`factoryId` int NOT NULL,
	`type` enum('business_license','social_credit_code','certification','export_license','other') NOT NULL,
	`label` varchar(255),
	`fileUrl` varchar(500) NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	`verifiedStatus` enum('pending','verified','rejected') DEFAULT 'pending',
	`verifiedAt` timestamp,
	`verifiedBy` int,
	CONSTRAINT `factoryDocuments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `groupShipmentParticipants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`userId` int NOT NULL,
	`cbmBooked` int NOT NULL,
	`productDescription` text NOT NULL,
	`productCategory` varchar(100),
	`estimatedWeight` int,
	`specialRequirements` text,
	`totalPriceUsd` int NOT NULL,
	`paymentStatus` enum('pending','paid','refunded') NOT NULL DEFAULT 'pending',
	`bookingReference` varchar(50),
	`status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
	`contactName` varchar(255) NOT NULL,
	`contactEmail` varchar(320) NOT NULL,
	`contactPhone` varchar(50),
	`companyName` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `groupShipmentParticipants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `groupShipmentUpdates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`authorId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`updateType` enum('info','milestone','alert','arrival') NOT NULL DEFAULT 'info',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `groupShipmentUpdates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `groupShipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizerId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`originCity` varchar(100) NOT NULL DEFAULT 'Guangzhou',
	`originCountry` varchar(100) NOT NULL DEFAULT 'China',
	`destinationCity` varchar(100) NOT NULL,
	`destinationCountry` varchar(100) NOT NULL,
	`destinationPort` varchar(100),
	`containerType` enum('20ft','40ft','40hc','lcl') NOT NULL DEFAULT '40ft',
	`totalCbm` int NOT NULL DEFAULT 67,
	`usedCbm` int NOT NULL DEFAULT 0,
	`pricePerCbm` int NOT NULL,
	`minCbmPerParticipant` int DEFAULT 10,
	`maxCbmPerParticipant` int DEFAULT 200,
	`cutoffDate` timestamp NOT NULL,
	`estimatedDeparture` timestamp NOT NULL,
	`estimatedArrival` timestamp NOT NULL,
	`shippingLine` varchar(100),
	`status` enum('open','filling','full','departed','arrived','closed') NOT NULL DEFAULT 'open',
	`coverImage` varchar(500),
	`includedServices` text,
	`notes` text,
	`participantsCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `groupShipments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`senderType` enum('buyer','admin') NOT NULL,
	`senderId` int NOT NULL,
	`body` text NOT NULL,
	`attachments` text,
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `offerCommentLikes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`commentId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `offerCommentLikes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `offerComments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`offerId` int NOT NULL,
	`userId` int NOT NULL,
	`content` text NOT NULL,
	`parentId` int,
	`likesCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `offerComments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `offerLikes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`offerId` int NOT NULL,
	`userId` int NOT NULL,
	`reactionType` enum('like','love','wow','haha','sad','angry') NOT NULL DEFAULT 'like',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `offerLikes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `offers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`authorId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`imageUrl` varchar(500),
	`videoUrl` varchar(500),
	`linkUrl` varchar(500),
	`linkLabel` varchar(100),
	`tags` text,
	`offerType` enum('deal','new_product','announcement','tip','event') NOT NULL DEFAULT 'deal',
	`discountPercent` int,
	`originalPrice` int,
	`salePrice` int,
	`validUntil` timestamp,
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
	`pinned` boolean NOT NULL DEFAULT false,
	`likesCount` int NOT NULL DEFAULT 0,
	`commentsCount` int NOT NULL DEFAULT 0,
	`sharesCount` int NOT NULL DEFAULT 0,
	`viewsCount` int NOT NULL DEFAULT 0,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `offers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productQuoteRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`productId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(50),
	`company` varchar(255),
	`quantity` int NOT NULL,
	`unit` varchar(50) DEFAULT 'piece',
	`message` text,
	`status` enum('pending','reviewed','quoted','closed') NOT NULL DEFAULT 'pending',
	`adminNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `productQuoteRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `protectedOrders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`buyerId` int NOT NULL,
	`rfqId` int,
	`factoryId` int,
	`status` enum('requested','reviewed','approved','paid','held','released','disputed','cancelled') DEFAULT 'requested',
	`amountEstimate` int,
	`currency` varchar(3) DEFAULT 'USD',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `protectedOrders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rfqMatches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`rfqId` int NOT NULL,
	`factoryId` int NOT NULL,
	`matchScore` int DEFAULT 0,
	`matchReason` text,
	`status` enum('pending','viewed','contacted','declined') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rfqMatches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rfqs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`specifications` text,
	`quantity` int,
	`targetPrice` int,
	`destinationCountry` varchar(100),
	`imageUrl` varchar(500),
	`shippingPreference` enum('sea','air','express') DEFAULT 'sea',
	`certificationsRequired` text,
	`customizationNeeded` enum('yes','no') DEFAULT 'no',
	`status` enum('draft','submitted','matched','closed') DEFAULT 'submitted',
	`matchedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rfqs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `riskFlags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`factoryId` int NOT NULL,
	`type` enum('user_report','system_detected','admin_flag') NOT NULL,
	`description` text NOT NULL,
	`status` enum('open','investigating','resolved','dismissed') DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`createdBy` int,
	CONSTRAINT `riskFlags_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `serviceInquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serviceType` enum('concierge','brand_launch','stock_liquidation','escrow') NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`company` varchar(255),
	`productType` varchar(255),
	`monthlyVolume` varchar(100),
	`brandName` varchar(255),
	`productCategory` varchar(255),
	`budget` varchar(100),
	`timeline` varchar(100),
	`interestedIn` varchar(500),
	`orderValue` varchar(100),
	`factoryName` varchar(255),
	`factoryCountry` varchar(100),
	`message` text,
	`status` enum('new','contacted','in_progress','closed') NOT NULL DEFAULT 'new',
	`assignedTo` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `serviceInquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipmentEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`status` varchar(100) NOT NULL,
	`location` varchar(255),
	`description` text,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shipmentEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`userId` int NOT NULL,
	`trackingNumber` varchar(100),
	`carrier` varchar(100),
	`method` enum('sea','air','rail','express') DEFAULT 'sea',
	`origin` varchar(255),
	`destination` varchar(255),
	`status` enum('pending','picked_up','in_transit','customs','out_for_delivery','delivered','exception') DEFAULT 'pending',
	`estimatedDelivery` timestamp,
	`actualDelivery` timestamp,
	`weight` int,
	`dimensions` varchar(100),
	`shippingCost` int DEFAULT 0,
	`customsDuty` int DEFAULT 0,
	`insurance` int DEFAULT 0,
	`notes` text,
	`lastLocation` varchar(255),
	`lastUpdate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shippingDocuments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int,
	`orderId` int,
	`userId` int NOT NULL,
	`type` enum('bill_of_lading','commercial_invoice','packing_list','customs_declaration','certificate_of_origin','insurance_cert','other') NOT NULL,
	`name` varchar(255) NOT NULL,
	`fileUrl` varchar(500) NOT NULL,
	`fileSize` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shippingDocuments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shippingQuotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`origin` varchar(255) NOT NULL,
	`destination` varchar(255) NOT NULL,
	`weight` int NOT NULL,
	`dimensions` varchar(100),
	`method` enum('sea','air','rail','express') NOT NULL,
	`cost` int NOT NULL,
	`customs` int DEFAULT 0,
	`insurance` int DEFAULT 0,
	`total` int NOT NULL,
	`duration` varchar(50),
	`selected` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shippingQuotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`country` varchar(100) DEFAULT 'China',
	`city` varchar(100),
	`contactName` varchar(255),
	`contactEmail` varchar(320),
	`contactWhatsapp` varchar(50),
	`contactWechat` varchar(100),
	`categories` text,
	`moq` varchar(100),
	`leadTimeDays` int,
	`paymentTerms` varchar(255),
	`qualityCerts` text,
	`trustScore` int DEFAULT 0,
	`notes` text,
	`status` enum('active','inactive','blacklisted') NOT NULL DEFAULT 'active',
	`lastOrderDate` timestamp,
	`totalOrdersPlaced` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `verificationLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`factoryId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`createdBy` int,
	CONSTRAINT `verificationLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `verificationRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`factoryId` int NOT NULL,
	`requesterId` int NOT NULL,
	`reason` text,
	`status` enum('pending','in_progress','completed','rejected') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `verificationRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `factories` ADD `category` varchar(255);--> statement-breakpoint
ALTER TABLE `factories` ADD `verificationLevel` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `factories` ADD `moq` varchar(100);--> statement-breakpoint
ALTER TABLE `factories` ADD `capabilities` text;--> statement-breakpoint
ALTER TABLE `factories` ADD `socialCreditCode` varchar(50);--> statement-breakpoint
ALTER TABLE `factories` ADD `yearEstablished` int;--> statement-breakpoint
ALTER TABLE `factories` ADD `employeeCount` int;--> statement-breakpoint
ALTER TABLE `factories` ADD `exportCountries` text;--> statement-breakpoint
ALTER TABLE `factories` ADD `certifications` text;--> statement-breakpoint
ALTER TABLE `factories` ADD `lastVerifiedAt` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `stripeCustomerId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `stripeSubscriptionId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `plan` enum('free','basic','pro') DEFAULT 'free' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `planStatus` enum('active','canceled','past_due','trialing') DEFAULT 'active';--> statement-breakpoint
ALTER TABLE `users` ADD `planExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `users` ADD `verifiedMatchPackCredits` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `resetToken` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `resetTokenExpires` timestamp;--> statement-breakpoint
CREATE INDEX `conversations_buyerId_idx` ON `conversations` (`buyerId`);--> statement-breakpoint
CREATE INDEX `factoryDocuments_factoryId_idx` ON `factoryDocuments` (`factoryId`);--> statement-breakpoint
CREATE INDEX `messages_conversationId_idx` ON `messages` (`conversationId`);--> statement-breakpoint
CREATE INDEX `rfqMatches_rfqId_idx` ON `rfqMatches` (`rfqId`);--> statement-breakpoint
CREATE INDEX `rfqMatches_factoryId_idx` ON `rfqMatches` (`factoryId`);--> statement-breakpoint
CREATE INDEX `rfqs_userId_idx` ON `rfqs` (`userId`);--> statement-breakpoint
CREATE INDEX `shipmentEvents_shipmentId_idx` ON `shipmentEvents` (`shipmentId`);--> statement-breakpoint
CREATE INDEX `shipments_orderId_idx` ON `shipments` (`orderId`);--> statement-breakpoint
CREATE INDEX `shipments_userId_idx` ON `shipments` (`userId`);--> statement-breakpoint
CREATE INDEX `blogArticles_authorId_idx` ON `blogArticles` (`authorId`);--> statement-breakpoint
CREATE INDEX `blogArticles_categoryId_idx` ON `blogArticles` (`categoryId`);--> statement-breakpoint
CREATE INDEX `blogArticles_status_idx` ON `blogArticles` (`status`);--> statement-breakpoint
CREATE INDEX `blogComments_articleId_idx` ON `blogComments` (`articleId`);--> statement-breakpoint
CREATE INDEX `blogComments_userId_idx` ON `blogComments` (`userId`);--> statement-breakpoint
CREATE INDEX `cartItems_userId_idx` ON `cartItems` (`userId`);--> statement-breakpoint
CREATE INDEX `cartItems_productId_idx` ON `cartItems` (`productId`);--> statement-breakpoint
CREATE INDEX `factories_userId_idx` ON `factories` (`userId`);--> statement-breakpoint
CREATE INDEX `factoryResults_searchId_idx` ON `factoryResults` (`searchId`);--> statement-breakpoint
CREATE INDEX `factorySearches_userId_idx` ON `factorySearches` (`userId`);--> statement-breakpoint
CREATE INDEX `factorySearches_searchHash_idx` ON `factorySearches` (`searchHash`);--> statement-breakpoint
CREATE INDEX `forumComments_postId_idx` ON `forumComments` (`postId`);--> statement-breakpoint
CREATE INDEX `forumComments_userId_idx` ON `forumComments` (`userId`);--> statement-breakpoint
CREATE INDEX `forumPosts_userId_idx` ON `forumPosts` (`userId`);--> statement-breakpoint
CREATE INDEX `forumPosts_categorySlug_idx` ON `forumPosts` (`categorySlug`);--> statement-breakpoint
CREATE INDEX `notifications_userId_idx` ON `notifications` (`userId`);--> statement-breakpoint
CREATE INDEX `orderItems_orderId_idx` ON `orderItems` (`orderId`);--> statement-breakpoint
CREATE INDEX `orderItems_productId_idx` ON `orderItems` (`productId`);--> statement-breakpoint
CREATE INDEX `orders_userId_idx` ON `orders` (`userId`);--> statement-breakpoint
CREATE INDEX `products_factoryId_idx` ON `products` (`factoryId`);--> statement-breakpoint
CREATE INDEX `products_categoryId_idx` ON `products` (`categoryId`);--> statement-breakpoint
CREATE INDEX `reviews_productId_idx` ON `reviews` (`productId`);--> statement-breakpoint
CREATE INDEX `reviews_userId_idx` ON `reviews` (`userId`);--> statement-breakpoint
CREATE INDEX `wishlistItems_userId_idx` ON `wishlistItems` (`userId`);--> statement-breakpoint
CREATE INDEX `wishlistItems_productId_idx` ON `wishlistItems` (`productId`);