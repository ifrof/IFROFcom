import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Subscription fields
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  plan: mysqlEnum("plan", ["free", "basic", "pro"]).default("free").notNull(),
  planStatus: mysqlEnum("planStatus", ["active", "canceled", "past_due", "trialing"]).default("active"),
  planExpiresAt: timestamp("planExpiresAt"),
  // One-time pack credits
  verifiedMatchPackCredits: int("verifiedMatchPackCredits").default(0),
  // Email/password auth fields
  passwordHash: varchar("passwordHash", { length: 255 }),
  resetToken: varchar("resetToken", { length: 128 }),
  resetTokenExpires: timestamp("resetTokenExpires"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============ MARKETPLACE TABLES ============

/**
 * Factories (Sellers) - Companies that manufacture products
 */
export const factories = mysqlTable("factories", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // Link to users table
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 255 }), // Primary product category
  country: varchar("country", { length: 100 }).default("China"),
  city: varchar("city", { length: 100 }),
  address: text("address"),
  website: varchar("website", { length: 500 }),
  logo: varchar("logo", { length: 500 }),
  verified: mysqlEnum("verified", ["pending", "verified", "rejected"]).default("pending"),
  // Verification level: 0=submitted, 1=doc_verified, 2=live_call, 3=third_party_audit
  verificationLevel: int("verificationLevel").default(0),
  trustScore: int("trustScore").default(0), // 0-100
  // Capabilities and evidence fields
  moq: varchar("moq", { length: 100 }), // e.g. "500 pcs"
  capabilities: text("capabilities"), // JSON array of capabilities
  socialCreditCode: varchar("socialCreditCode", { length: 50 }), // Unified Social Credit Code
  yearEstablished: int("yearEstablished"),
  employeeCount: int("employeeCount"),
  exportCountries: text("exportCountries"), // JSON array
  certifications: text("certifications"), // JSON array
  lastVerifiedAt: timestamp("lastVerifiedAt"),
  subscriptionTier: mysqlEnum("subscriptionTier", ["free", "premium"]).default("free"),
  subscriptionExpiry: timestamp("subscriptionExpiry"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("factories_userId_idx").on(table.userId),
]);

export type Factory = typeof factories.$inferSelect;
export type InsertFactory = typeof factories.$inferInsert;

/**
 * Product Categories
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }), // Lucide icon name
  parentId: int("parentId"), // For subcategories
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Products - Items listed by factories
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  factoryId: int("factoryId").notNull(),
  categoryId: int("categoryId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: int("price").notNull(), // Price in cents (e.g., $8.50 = 850)
  originalPrice: int("originalPrice"), // Original price before discount
  currency: varchar("currency", { length: 3 }).default("USD"),
  unit: varchar("unit", { length: 50 }).default("pcs"), // pcs, kg, set, etc.
  minOrder: int("minOrder").default(1),
  stockQuantity: int("stockQuantity").default(0),
  sku: varchar("sku", { length: 100 }),
  images: text("images"), // JSON array of image URLs
  specifications: text("specifications"), // JSON object of specs
  tags: text("tags"), // JSON array of tags
  status: mysqlEnum("status", ["draft", "active", "sold_out", "archived"]).default("active"),
  featured: mysqlEnum("featured", ["none", "hot_deal", "stock_sale", "new", "top_rated", "verified"]).default("none"),
  views: int("views").default(0),
  orders: int("orders").default(0),
  rating: int("rating").default(0), // Average rating * 10 (e.g., 4.5 = 45)
  reviewCount: int("reviewCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("products_factoryId_idx").on(table.factoryId),
  index("products_categoryId_idx").on(table.categoryId),
]);

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Product Reviews
 */
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  userId: int("userId").notNull(),
  rating: int("rating").notNull(), // 1-5
  title: varchar("title", { length: 255 }),
  comment: text("comment"),
  images: text("images"), // JSON array of image URLs
  verified: int("verified").default(0), // 1 if verified purchase
  helpful: int("helpful").default(0), // Number of helpful votes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("reviews_productId_idx").on(table.productId),
  index("reviews_userId_idx").on(table.userId),
]);

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

/**
 * Orders
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  orderNumber: varchar("orderNumber", { length: 50 }).notNull().unique(),
  status: mysqlEnum("status", ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]).default("pending"),
  totalAmount: int("totalAmount").notNull(), // Total in cents
  currency: varchar("currency", { length: 3 }).default("USD"),
  shippingAddress: text("shippingAddress"), // JSON object
  shippingMethod: varchar("shippingMethod", { length: 100 }),
  shippingCost: int("shippingCost").default(0),
  trackingNumber: varchar("trackingNumber", { length: 100 }),
  paymentMethod: varchar("paymentMethod", { length: 50 }),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed", "refunded"]).default("pending"),
  paymentIntentId: varchar("paymentIntentId", { length: 255 }), // Stripe payment intent ID
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("orders_userId_idx").on(table.userId),
]);

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Order Items
 */
export const orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  productId: int("productId").notNull(),
  quantity: int("quantity").notNull(),
  price: int("price").notNull(), // Price at time of order (in cents)
  subtotal: int("subtotal").notNull(), // quantity * price
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("orderItems_orderId_idx").on(table.orderId),
  index("orderItems_productId_idx").on(table.productId),
]);

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

/**
 * Cart Items
 */
export const cartItems = mysqlTable("cartItems", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productId: int("productId").notNull(),
  quantity: int("quantity").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("cartItems_userId_idx").on(table.userId),
  index("cartItems_productId_idx").on(table.productId),
]);

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = typeof cartItems.$inferInsert;

/**
 * Wishlist Items
 */
export const wishlistItems = mysqlTable("wishlistItems", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productId: int("productId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("wishlistItems_userId_idx").on(table.userId),
  index("wishlistItems_productId_idx").on(table.productId),
]);

export type WishlistItem = typeof wishlistItems.$inferSelect;
export type InsertWishlistItem = typeof wishlistItems.$inferInsert;

/**
 * Forum Posts
 */
export const forumPosts = mysqlTable("forumPosts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categorySlug: varchar("categorySlug", { length: 100 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  tags: text("tags"), // JSON array
  views: int("views").default(0),
  upvotes: int("upvotes").default(0),
  downvotes: int("downvotes").default(0),
  commentCount: int("commentCount").default(0),
  isPinned: int("isPinned").default(0),
  isLocked: int("isLocked").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("forumPosts_userId_idx").on(table.userId),
  index("forumPosts_categorySlug_idx").on(table.categorySlug),
]);

export type ForumPost = typeof forumPosts.$inferSelect;
export type InsertForumPost = typeof forumPosts.$inferInsert;

/**
 * Forum Comments
 */
export const forumComments = mysqlTable("forumComments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  parentId: int("parentId"), // For nested comments
  content: text("content").notNull(),
  upvotes: int("upvotes").default(0),
  downvotes: int("downvotes").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("forumComments_postId_idx").on(table.postId),
  index("forumComments_userId_idx").on(table.userId),
]);

export type ForumComment = typeof forumComments.$inferSelect;
export type InsertForumComment = typeof forumComments.$inferInsert;

/**
 * Forum Votes (to track who voted on what)
 */
export const forumVotes = mysqlTable("forumVotes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  targetType: mysqlEnum("targetType", ["post", "comment"]).notNull(),
  targetId: int("targetId").notNull(),
  voteType: mysqlEnum("voteType", ["up", "down"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ForumVote = typeof forumVotes.$inferSelect;
export type InsertForumVote = typeof forumVotes.$inferInsert;

/**
 * Factory Verification Cache - AI Trust Engine V2
 */
export const verificationCache = mysqlTable("verificationCache", {
  id: int("id").autoincrement().primaryKey(),
  factoryName: varchar("factoryName", { length: 255 }).notNull().unique(),
  verificationData: text("verificationData"), // JSON with all verification details
  trustScore: int("trustScore").notNull(),
  verifiedBy: int("verifiedBy").notNull(), // User ID who first verified
  accessCount: int("accessCount").default(1), // How many times accessed
  lastAccessed: timestamp("lastAccessed").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VerificationCache = typeof verificationCache.$inferSelect;
export type InsertVerificationCache = typeof verificationCache.$inferInsert;

/**
 * Verification Access Log - Track who accessed cached verifications
 */
export const verificationAccessLog = mysqlTable("verificationAccessLog", {
  id: int("id").autoincrement().primaryKey(),
  cacheId: int("cacheId").notNull(),
  userId: int("userId").notNull(),
  pricePaid: int("pricePaid").notNull(), // In cents (50 for cached, 500 for new)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VerificationAccessLog = typeof verificationAccessLog.$inferSelect;
export type InsertVerificationAccessLog = typeof verificationAccessLog.$inferInsert;

/**
 * Notifications
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // order_update, new_message, etc.
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  link: varchar("link", { length: 500 }),
  isRead: int("isRead").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("notifications_userId_idx").on(table.userId),
]);

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Blog Categories - Educational content categories
 */
export const blogCategories = mysqlTable("blogCategories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }), // Lucide icon name
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BlogCategory = typeof blogCategories.$inferSelect;
export type InsertBlogCategory = typeof blogCategories.$inferInsert;

/**
 * Blog Articles - Educational content
 */
export const blogArticles = mysqlTable("blogArticles", {
  id: int("id").autoincrement().primaryKey(),
  authorId: int("authorId").notNull(), // Link to users table
  categoryId: int("categoryId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  excerpt: text("excerpt"), // Short summary
  content: text("content").notNull(), // Full article content (markdown)
  coverImage: varchar("coverImage", { length: 500 }),
  tags: text("tags"), // JSON array of tags
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft"),
  views: int("views").default(0),
  readTime: int("readTime").default(5), // Estimated read time in minutes
  featured: int("featured").default(0), // 1 if featured article
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("blogArticles_authorId_idx").on(table.authorId),
  index("blogArticles_categoryId_idx").on(table.categoryId),
  index("blogArticles_status_idx").on(table.status),
]);

export type BlogArticle = typeof blogArticles.$inferSelect;
export type InsertBlogArticle = typeof blogArticles.$inferInsert;

/**
 * Blog Comments
 */
export const blogComments = mysqlTable("blogComments", {
  id: int("id").autoincrement().primaryKey(),
  articleId: int("articleId").notNull(),
  userId: int("userId").notNull(),
  parentId: int("parentId"), // For nested comments
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("blogComments_articleId_idx").on(table.articleId),
  index("blogComments_userId_idx").on(table.userId),
]);

export type BlogComment = typeof blogComments.$inferSelect;
export type InsertBlogComment = typeof blogComments.$inferInsert;

// ============ FACTORY FINDER AI SEARCH TABLES ============

/**
 * Factory Searches - Track all factory searches ($9.9 per search)
 */
export const factorySearches = mysqlTable("factorySearches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  searchType: mysqlEnum("searchType", ["text", "link", "image", "hscode", "description"]).notNull(),
  searchQuery: text("searchQuery").notNull(), // The actual search input
  searchHash: varchar("searchHash", { length: 64 }).notNull(), // Hash of search query for caching
  paymentIntentId: varchar("paymentIntentId", { length: 255 }), // Stripe payment ID
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "failed"]).default("pending"),
  amountPaid: int("amountPaid").default(990), // $9.9 = 990 cents
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
}, (table) => [
  index("factorySearches_userId_idx").on(table.userId),
  index("factorySearches_searchHash_idx").on(table.searchHash),
]);

export type FactorySearch = typeof factorySearches.$inferSelect;
export type InsertFactorySearch = typeof factorySearches.$inferInsert;

/**
 * Factory Results - Cached factory search results
 */
export const factoryResults = mysqlTable("factoryResults", {
  id: int("id").autoincrement().primaryKey(),
  searchId: int("searchId").notNull(), // Link to factorySearches
  factoryName: varchar("factoryName", { length: 255 }).notNull(),
  contactPerson: varchar("contactPerson", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  whatsapp: varchar("whatsapp", { length: 50 }),
  website: varchar("website", { length: 500 }),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  country: varchar("country", { length: 100 }),
  verificationEvidence: text("verificationEvidence"), // JSON: why it's a factory not middleman
  productCategories: text("productCategories"), // JSON array
  certifications: text("certifications"), // JSON array
  yearEstablished: int("yearEstablished"),
  employeeCount: int("employeeCount"),
  trustScore: int("trustScore").default(0), // 0-100
  rawData: text("rawData"), // Full JSON response from Perplexity/Firecrawl
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("factoryResults_searchId_idx").on(table.searchId),
]);

export type FactoryResult = typeof factoryResults.$inferSelect;
export type InsertFactoryResult = typeof factoryResults.$inferInsert;

/**
 * Search Cache - Prevent duplicate API calls for same search
 */
export const searchCache = mysqlTable("searchCache", {
  id: int("id").autoincrement().primaryKey(),
  searchHash: varchar("searchHash", { length: 64 }).notNull().unique(),
  searchType: mysqlEnum("searchType", ["text", "link", "image", "hscode", "description"]).notNull(),
  searchQuery: text("searchQuery").notNull(),
  resultId: int("resultId").notNull(), // Link to factoryResults
  accessCount: int("accessCount").default(1), // How many times this result was accessed
  lastAccessed: timestamp("lastAccessed").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SearchCache = typeof searchCache.$inferSelect;
export type InsertSearchCache = typeof searchCache.$inferInsert;

// ============ RFQ SYSTEM ============

/**
 * Request for Quotation - Core activation engine
 */
export const rfqs = mysqlTable("rfqs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  specifications: text("specifications"),
  quantity: int("quantity"),
  targetPrice: int("targetPrice"), // in cents
  destinationCountry: varchar("destinationCountry", { length: 100 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  // Step 2
  shippingPreference: mysqlEnum("shippingPreference", ["sea", "air", "express"]).default("sea"),
  certificationsRequired: text("certificationsRequired"), // JSON array
  customizationNeeded: mysqlEnum("customizationNeeded", ["yes", "no"]).default("no"),
  // Status
  status: mysqlEnum("status", ["draft", "submitted", "matched", "closed"]).default("submitted"),
  matchedAt: timestamp("matchedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("rfqs_userId_idx").on(table.userId),
]);

export type Rfq = typeof rfqs.$inferSelect;
export type InsertRfq = typeof rfqs.$inferInsert;

/**
 * RFQ Matches - Factories matched to an RFQ
 */
export const rfqMatches = mysqlTable("rfqMatches", {
  id: int("id").autoincrement().primaryKey(),
  rfqId: int("rfqId").notNull(),
  factoryId: int("factoryId").notNull(),
  matchScore: int("matchScore").default(0), // 0-100 relevance
  matchReason: text("matchReason"), // Brief explanation
  status: mysqlEnum("status", ["pending", "viewed", "contacted", "declined"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("rfqMatches_rfqId_idx").on(table.rfqId),
  index("rfqMatches_factoryId_idx").on(table.factoryId),
]);

export type RfqMatch = typeof rfqMatches.$inferSelect;
export type InsertRfqMatch = typeof rfqMatches.$inferInsert;

// ============ MESSAGING SYSTEM ============

/**
 * Conversations between buyers and factories
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  buyerId: int("buyerId").notNull(),
  factoryId: int("factoryId"), // internal supplier reference, never exposed to buyer
  rfqId: int("rfqId"), // optional link to RFQ
  status: mysqlEnum("status", ["active", "archived", "closed"]).default("active"),
  lastMessageAt: timestamp("lastMessageAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("conversations_buyerId_idx").on(table.buyerId),
]);

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages within conversations
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  senderType: mysqlEnum("senderType", ["buyer", "admin"]).notNull(),
  senderId: int("senderId").notNull(), // user ID
  body: text("body").notNull(),
  attachments: text("attachments"), // JSON array of file URLs
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("messages_conversationId_idx").on(table.conversationId),
]);

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ============ FACTORY PASSPORT - TRUST EVIDENCE ============

/**
 * Factory Documents - uploaded verification evidence
 */
export const factoryDocuments = mysqlTable("factoryDocuments", {
  id: int("id").autoincrement().primaryKey(),
  factoryId: int("factoryId").notNull(),
  type: mysqlEnum("type", ["business_license", "social_credit_code", "certification", "export_license", "other"]).notNull(),
  label: varchar("label", { length: 255 }),
  fileUrl: varchar("fileUrl", { length: 500 }).notNull(),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  verifiedStatus: mysqlEnum("verifiedStatus", ["pending", "verified", "rejected"]).default("pending"),
  verifiedAt: timestamp("verifiedAt"),
  verifiedBy: int("verifiedBy"), // admin user ID
}, (table) => [
  index("factoryDocuments_factoryId_idx").on(table.factoryId),
]);

export type FactoryDocument = typeof factoryDocuments.$inferSelect;
export type InsertFactoryDocument = typeof factoryDocuments.$inferInsert;

/**
 * Verification Logs - Audit trail of verification actions
 */
export const verificationLogs = mysqlTable("verificationLogs", {
  id: int("id").autoincrement().primaryKey(),
  factoryId: int("factoryId").notNull(),
  action: varchar("action", { length: 100 }).notNull(), // e.g. "level_upgraded", "doc_verified", "risk_added"
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  createdBy: int("createdBy"), // admin user ID
});

export type VerificationLog = typeof verificationLogs.$inferSelect;
export type InsertVerificationLog = typeof verificationLogs.$inferInsert;

/**
 * Risk Flags - Issues flagged on a factory
 */
export const riskFlags = mysqlTable("riskFlags", {
  id: int("id").autoincrement().primaryKey(),
  factoryId: int("factoryId").notNull(),
  type: mysqlEnum("type", ["user_report", "system_detected", "admin_flag"]).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["open", "investigating", "resolved", "dismissed"]).default("open"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  createdBy: int("createdBy"), // user ID who flagged
});

export type RiskFlag = typeof riskFlags.$inferSelect;
export type InsertRiskFlag = typeof riskFlags.$inferInsert;

/**
 * Verification Requests - Users requesting factory verification
 */
export const verificationRequests = mysqlTable("verificationRequests", {
  id: int("id").autoincrement().primaryKey(),
  factoryId: int("factoryId").notNull(),
  requesterId: int("requesterId").notNull(), // user ID
  reason: text("reason"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "rejected"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VerificationRequest = typeof verificationRequests.$inferSelect;
export type InsertVerificationRequest = typeof verificationRequests.$inferInsert;

// ============ ORDER PROTECTION (MANAGED ESCROW BETA) ============

/**
 * Protected Orders - Managed escrow requests
 */
export const protectedOrders = mysqlTable("protectedOrders", {
  id: int("id").autoincrement().primaryKey(),
  buyerId: int("buyerId").notNull(),
  rfqId: int("rfqId"),
  factoryId: int("factoryId"),
  status: mysqlEnum("status", ["requested", "reviewed", "approved", "paid", "held", "released", "disputed", "cancelled"]).default("requested"),
  amountEstimate: int("amountEstimate"), // in cents
  currency: varchar("currency", { length: 3 }).default("USD"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProtectedOrder = typeof protectedOrders.$inferSelect;
export type InsertProtectedOrder = typeof protectedOrders.$inferInsert;

/**
 * Escrow Status - Status updates for protected orders
 */
export const escrowStatuses = mysqlTable("escrowStatuses", {
  id: int("id").autoincrement().primaryKey(),
  protectedOrderId: int("protectedOrderId").notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  notes: text("notes"),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  updatedBy: int("updatedBy"), // admin user ID
});

export type EscrowStatus = typeof escrowStatuses.$inferSelect;
export type InsertEscrowStatus = typeof escrowStatuses.$inferInsert;

/**
 * Dispute Cases - Disputes on protected orders
 */
export const disputeCases = mysqlTable("disputeCases", {
  id: int("id").autoincrement().primaryKey(),
  protectedOrderId: int("protectedOrderId").notNull(),
  openedBy: int("openedBy").notNull(), // user ID
  reason: text("reason").notNull(),
  status: mysqlEnum("status", ["open", "investigating", "resolved", "closed"]).default("open"),
  resolution: text("resolution"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DisputeCase = typeof disputeCases.$inferSelect;
export type InsertDisputeCase = typeof disputeCases.$inferInsert;

// ============ ANALYTICS EVENTS ============

/**
 * Analytics Events - Simple event tracking
 */
export const analyticsEvents = mysqlTable("analyticsEvents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  event: varchar("event", { length: 100 }).notNull(),
  properties: text("properties"), // JSON
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type InsertAnalyticsEvent = typeof analyticsEvents.$inferInsert;

// ============ SHIPMENT TRACKING ============

/**
 * Shipments - Track shipments linked to orders
 */
export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  userId: int("userId").notNull(),
  trackingNumber: varchar("trackingNumber", { length: 100 }),
  carrier: varchar("carrier", { length: 100 }), // DHL, FedEx, Maersk, etc.
  method: mysqlEnum("method", ["sea", "air", "rail", "express"]).default("sea"),
  origin: varchar("origin", { length: 255 }),
  destination: varchar("destination", { length: 255 }),
  status: mysqlEnum("status", ["pending", "picked_up", "in_transit", "customs", "out_for_delivery", "delivered", "exception"]).default("pending"),
  estimatedDelivery: timestamp("estimatedDelivery"),
  actualDelivery: timestamp("actualDelivery"),
  weight: int("weight"), // in grams
  dimensions: varchar("dimensions", { length: 100 }), // LxWxH cm
  shippingCost: int("shippingCost").default(0), // in cents
  customsDuty: int("customsDuty").default(0), // in cents
  insurance: int("insurance").default(0), // in cents
  notes: text("notes"),
  lastLocation: varchar("lastLocation", { length: 255 }),
  lastUpdate: timestamp("lastUpdate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("shipments_orderId_idx").on(table.orderId),
  index("shipments_userId_idx").on(table.userId),
]);

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = typeof shipments.$inferInsert;

/**
 * Shipment Events - Timeline of shipment updates
 */
export const shipmentEvents = mysqlTable("shipmentEvents", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  status: varchar("status", { length: 100 }).notNull(),
  location: varchar("location", { length: 255 }),
  description: text("description"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("shipmentEvents_shipmentId_idx").on(table.shipmentId),
]);

export type ShipmentEvent = typeof shipmentEvents.$inferSelect;
export type InsertShipmentEvent = typeof shipmentEvents.$inferInsert;

/**
 * Shipping Documents - Bills of lading, invoices, customs docs
 */
export const shippingDocuments = mysqlTable("shippingDocuments", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId"),
  orderId: int("orderId"),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["bill_of_lading", "commercial_invoice", "packing_list", "customs_declaration", "certificate_of_origin", "insurance_cert", "other"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  fileUrl: varchar("fileUrl", { length: 500 }).notNull(),
  fileSize: int("fileSize"), // in bytes
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ShippingDocument = typeof shippingDocuments.$inferSelect;
export type InsertShippingDocument = typeof shippingDocuments.$inferInsert;

/**
 * Shipping Quotes - Saved shipping cost calculations
 */
export const shippingQuotes = mysqlTable("shippingQuotes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  origin: varchar("origin", { length: 255 }).notNull(),
  destination: varchar("destination", { length: 255 }).notNull(),
  weight: int("weight").notNull(), // grams
  dimensions: varchar("dimensions", { length: 100 }),
  method: mysqlEnum("method", ["sea", "air", "rail", "express"]).notNull(),
  cost: int("cost").notNull(), // in cents
  customs: int("customs").default(0),
  insurance: int("insurance").default(0),
  total: int("total").notNull(),
  duration: varchar("duration", { length: 50 }),
  selected: int("selected").default(0), // 1 if user selected this quote
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ShippingQuote = typeof shippingQuotes.$inferSelect;
export type InsertShippingQuote = typeof shippingQuotes.$inferInsert;

/**
 * Service Inquiries - Lead capture for White-label Concierge, Brand Launch, Stock Liquidation, Escrow
 */
export const serviceInquiries = mysqlTable("serviceInquiries", {
  id: int("id").autoincrement().primaryKey(),
  serviceType: mysqlEnum("serviceType", ["concierge", "brand_launch", "stock_liquidation", "escrow"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  company: varchar("company", { length: 255 }),
  productType: varchar("productType", { length: 255 }),
  monthlyVolume: varchar("monthlyVolume", { length: 100 }),
  brandName: varchar("brandName", { length: 255 }),
  productCategory: varchar("productCategory", { length: 255 }),
  budget: varchar("budget", { length: 100 }),
  timeline: varchar("timeline", { length: 100 }),
  interestedIn: varchar("interestedIn", { length: 500 }),
  orderValue: varchar("orderValue", { length: 100 }),
  factoryName: varchar("factoryName", { length: 255 }),
  factoryCountry: varchar("factoryCountry", { length: 100 }),
  message: text("message"),
  status: mysqlEnum("status", ["new", "contacted", "in_progress", "closed"]).default("new").notNull(),
  assignedTo: varchar("assignedTo", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ServiceInquiry = typeof serviceInquiries.$inferSelect;
export type InsertServiceInquiry = typeof serviceInquiries.$inferInsert;

/**
 * Agent Quotes — Admin responds to RFQs with a formal quote (buyer never sees factory)
 */
export const agentQuotes = mysqlTable("agentQuotes", {
  id: int("id").autoincrement().primaryKey(),
  rfqId: int("rfqId").notNull(),
  buyerId: int("buyerId").notNull(),
  agentId: int("agentId").notNull(), // admin user who created the quote
  // Internal supplier reference (NEVER sent to buyer)
  supplierId: int("supplierId"), // references factories.id
  supplierName: varchar("supplierName", { length: 255 }), // internal only
  // What the buyer sees
  unitPrice: int("unitPrice").notNull(), // in cents (your selling price)
  quantity: int("quantity").notNull(),
  totalAmount: int("totalAmount").notNull(), // in cents
  currency: varchar("currency", { length: 3 }).default("USD"),
  leadTimeDays: int("leadTimeDays"),
  shippingMethod: mysqlEnum("shippingMethod", ["sea", "air", "rail", "express"]).default("sea"),
  shippingCost: int("shippingCost").default(0), // in cents
  validUntil: timestamp("validUntil"),
  notes: text("notes"), // visible to buyer
  internalNotes: text("internalNotes"), // admin only, never shown to buyer
  // Your margin tracking (internal)
  supplierUnitCost: int("supplierUnitCost"), // what you pay the factory
  agentMarginPct: int("agentMarginPct"), // e.g. 15 = 15%
  status: mysqlEnum("status", ["draft", "sent", "accepted", "rejected", "expired"]).default("draft").notNull(),
  acceptedAt: timestamp("acceptedAt"),
  rejectedAt: timestamp("rejectedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type AgentQuote = typeof agentQuotes.$inferSelect;
export type InsertAgentQuote = typeof agentQuotes.$inferInsert;

/**
 * Supplier Database — Admin-managed list of vetted suppliers (never exposed to buyers)
 */
export const suppliers = mysqlTable("suppliers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  country: varchar("country", { length: 100 }).default("China"),
  city: varchar("city", { length: 100 }),
  contactName: varchar("contactName", { length: 255 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactWhatsapp: varchar("contactWhatsapp", { length: 50 }),
  contactWechat: varchar("contactWechat", { length: 100 }),
  categories: text("categories"), // JSON array of product categories
  moq: varchar("moq", { length: 100 }),
  leadTimeDays: int("leadTimeDays"),
  paymentTerms: varchar("paymentTerms", { length: 255 }), // e.g. "30% deposit, 70% before shipment"
  qualityCerts: text("qualityCerts"), // JSON array: ISO9001, CE, etc.
  trustScore: int("trustScore").default(0), // 0-100, admin-assigned
  notes: text("notes"), // internal notes
  status: mysqlEnum("status", ["active", "inactive", "blacklisted"]).default("active").notNull(),
  lastOrderDate: timestamp("lastOrderDate"),
  totalOrdersPlaced: int("totalOrdersPlaced").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = typeof suppliers.$inferInsert;

// ============ OFFERS / SOCIAL FEED TABLES ============

/**
 * Offers — Admin-published promotional posts (Facebook-style feed)
 */
export const offers = mysqlTable("offers", {
  id: int("id").autoincrement().primaryKey(),
  authorId: int("authorId").notNull(), // references users.id (admin)
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  imageUrl: varchar("imageUrl", { length: 500 }),
  videoUrl: varchar("videoUrl", { length: 500 }),
  linkUrl: varchar("linkUrl", { length: 500 }),
  linkLabel: varchar("linkLabel", { length: 100 }),
  tags: text("tags"), // JSON array of tag strings
  offerType: mysqlEnum("offerType", ["deal", "new_product", "announcement", "tip", "event"]).default("deal").notNull(),
  discountPercent: int("discountPercent"), // e.g. 20 = 20% off
  originalPrice: int("originalPrice"), // in cents
  salePrice: int("salePrice"), // in cents
  validUntil: timestamp("validUntil"),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft").notNull(),
  pinned: boolean("pinned").default(false).notNull(),
  likesCount: int("likesCount").default(0).notNull(),
  commentsCount: int("commentsCount").default(0).notNull(),
  sharesCount: int("sharesCount").default(0).notNull(),
  viewsCount: int("viewsCount").default(0).notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Offer = typeof offers.$inferSelect;
export type InsertOffer = typeof offers.$inferInsert;

/**
 * Offer Likes — Users liking an offer post
 */
export const offerLikes = mysqlTable("offerLikes", {
  id: int("id").autoincrement().primaryKey(),
  offerId: int("offerId").notNull(),
  userId: int("userId").notNull(),
  reactionType: mysqlEnum("reactionType", ["like", "love", "wow", "haha", "sad", "angry"]).default("like").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type OfferLike = typeof offerLikes.$inferSelect;
export type InsertOfferLike = typeof offerLikes.$inferInsert;

/**
 * Offer Comments — Users commenting on an offer post
 */
export const offerComments = mysqlTable("offerComments", {
  id: int("id").autoincrement().primaryKey(),
  offerId: int("offerId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  parentId: int("parentId"), // for nested replies
  likesCount: int("likesCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type OfferComment = typeof offerComments.$inferSelect;
export type InsertOfferComment = typeof offerComments.$inferInsert;

/**
 * Offer Comment Likes — Users liking a comment
 */
export const offerCommentLikes = mysqlTable("offerCommentLikes", {
  id: int("id").autoincrement().primaryKey(),
  commentId: int("commentId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type OfferCommentLike = typeof offerCommentLikes.$inferSelect;
export type InsertOfferCommentLike = typeof offerCommentLikes.$inferInsert;

// ============ GROUP CONTAINER SHIPPING TABLES ============
/**
 * Group Shipments — Shared container shipments that importers can join
 */
export const groupShipments = mysqlTable("groupShipments", {
  id: int("id").autoincrement().primaryKey(),
  organizerId: int("organizerId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  originCity: varchar("originCity", { length: 100 }).notNull().default("Guangzhou"),
  originCountry: varchar("originCountry", { length: 100 }).notNull().default("China"),
  destinationCity: varchar("destinationCity", { length: 100 }).notNull(),
  destinationCountry: varchar("destinationCountry", { length: 100 }).notNull(),
  destinationPort: varchar("destinationPort", { length: 100 }),
  containerType: mysqlEnum("containerType", ["20ft", "40ft", "40hc", "lcl"]).default("40ft").notNull(),
  totalCbm: int("totalCbm").notNull().default(67),
  usedCbm: int("usedCbm").notNull().default(0),
  pricePerCbm: int("pricePerCbm").notNull(),
  minCbmPerParticipant: int("minCbmPerParticipant").default(10),
  maxCbmPerParticipant: int("maxCbmPerParticipant").default(200),
  cutoffDate: timestamp("cutoffDate").notNull(),
  estimatedDeparture: timestamp("estimatedDeparture").notNull(),
  estimatedArrival: timestamp("estimatedArrival").notNull(),
  shippingLine: varchar("shippingLine", { length: 100 }),
  status: mysqlEnum("status", ["open", "filling", "full", "departed", "arrived", "closed"]).default("open").notNull(),
  coverImage: varchar("coverImage", { length: 500 }),
  includedServices: text("includedServices"),
  notes: text("notes"),
  participantsCount: int("participantsCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type GroupShipment = typeof groupShipments.$inferSelect;
export type InsertGroupShipment = typeof groupShipments.$inferInsert;

/**
 * Group Shipment Participants — Importers who have joined a group shipment
 */
export const groupShipmentParticipants = mysqlTable("groupShipmentParticipants", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  userId: int("userId").notNull(),
  cbmBooked: int("cbmBooked").notNull(),
  productDescription: text("productDescription").notNull(),
  productCategory: varchar("productCategory", { length: 100 }),
  estimatedWeight: int("estimatedWeight"),
  specialRequirements: text("specialRequirements"),
  totalPriceUsd: int("totalPriceUsd").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "refunded"]).default("pending").notNull(),
  bookingReference: varchar("bookingReference", { length: 50 }),
  status: mysqlEnum("status", ["pending", "confirmed", "cancelled"]).default("pending").notNull(),
  contactName: varchar("contactName", { length: 255 }).notNull(),
  contactEmail: varchar("contactEmail", { length: 320 }).notNull(),
  contactPhone: varchar("contactPhone", { length: 50 }),
  companyName: varchar("companyName", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type GroupShipmentParticipant = typeof groupShipmentParticipants.$inferSelect;
export type InsertGroupShipmentParticipant = typeof groupShipmentParticipants.$inferInsert;

/**
 * Group Shipment Updates — Status updates / tracking posts for a shipment
 */
export const groupShipmentUpdates = mysqlTable("groupShipmentUpdates", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  authorId: int("authorId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  updateType: mysqlEnum("updateType", ["info", "milestone", "alert", "arrival"]).default("info").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type GroupShipmentUpdate = typeof groupShipmentUpdates.$inferSelect;
export type InsertGroupShipmentUpdate = typeof groupShipmentUpdates.$inferInsert;


/**
 * Product Quote Requests — Buyers request quotes for products
 */
export const productQuoteRequests = mysqlTable("productQuoteRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  productId: int("productId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  company: varchar("company", { length: 255 }),
  quantity: int("quantity").notNull(),
  unit: varchar("unit", { length: 50 }).default("piece"),
  message: text("message"),
  status: mysqlEnum("status", ["pending", "reviewed", "quoted", "closed"]).default("pending").notNull(),
  adminNotes: text("adminNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ProductQuoteRequest = typeof productQuoteRequests.$inferSelect;
export type InsertProductQuoteRequest = typeof productQuoteRequests.$inferInsert;

// ============ AI ENGINE TABLES ============

/**
 * AI Requests — audit log for every call to an AI agent.
 * Useful for monitoring costs, latency, and errors.
 */
export const aiRequests = mysqlTable("aiRequests", {
  id:        int("id").autoincrement().primaryKey(),
  agent:     varchar("agent",    { length: 100 }).notNull(), // e.g. "factory_validator"
  prompt:    text("prompt").notNull(),
  response:  text("response").notNull(),
  latency:   int("latency").notNull(),                       // milliseconds
  model:     varchar("model",    { length: 100 }).notNull(), // e.g. "qwen2.5:14b-instruct"
  userId:    int("userId"),
  success:   boolean("success").notNull(),
  error:     text("error"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AIRequest       = typeof aiRequests.$inferSelect;
export type InsertAIRequest = typeof aiRequests.$inferInsert;

/**
 * Chat Conversations — persisted support chat sessions.
 */
export const chatConversations = mysqlTable("chatConversations", {
  id:        int("id").autoincrement().primaryKey(),
  userId:    int("userId"),
  messages:  text("messages").notNull(),   // JSON array of { role, content }
  resolved:  boolean("resolved").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ChatConversation       = typeof chatConversations.$inferSelect;
export type InsertChatConversation = typeof chatConversations.$inferInsert;

/**
 * Waitlist for early access
 */
export const waitlist = mysqlTable("waitlist", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Waitlist = typeof waitlist.$inferSelect;
export type InsertWaitlist = typeof waitlist.$inferInsert;
