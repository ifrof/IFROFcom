# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| latest (main) | ✅ |

## Reporting a Vulnerability

Please **do not** open a public GitHub issue for security vulnerabilities.

Instead, email **security@ifrof.com** with:
- A description of the vulnerability
- Steps to reproduce
- Potential impact assessment

You will receive a response within 48 hours. We follow responsible disclosure and will credit reporters in release notes.

## Security Checklist for Self-Hosters

Before going live, make sure you have:

- [ ] `JWT_SECRET` is at least 64 random hex characters
- [ ] `MYSQL_ROOT_PASSWORD` is a strong unique password (not reused)
- [ ] `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` are set
- [ ] Nginx Proxy Manager default credentials changed (`admin@example.com / changeme`)
- [ ] SSL/TLS enabled via Let's Encrypt
- [ ] Firewall rules: only ports 80, 443 exposed; port 3000 bound to localhost only
- [ ] SSH access via key only (password auth disabled)
- [ ] `pnpm audit` run with no high/critical issues

## Environment Variables

Never commit `.env` to version control. Use `.env.example` as the template.

Generate a secure JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```
