// IFROF Service Worker — Performance-first caching
// Bump this version to force all clients to update their cache.
const CACHE_VERSION = 'v1.1.0';
const CACHE_NAME = `ifrof-${CACHE_VERSION}`;

// Core shell assets that should always be available offline.
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
];

// ── Install: precache shell ───────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_ASSETS))
  );
  // Activate immediately without waiting for old tabs to close.
  self.skipWaiting();
});

// ── Activate: remove stale caches ────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      // Delete old cache versions
      caches.keys().then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME)
            .map((key) => caches.delete(key))
        )
      ),
      // Enable Navigation Preload if supported (speeds up navigation on Android Chrome)
      'navigationPreload' in self.registration
        ? self.registration.navigationPreload.enable()
        : Promise.resolve(),
    ])
  );
  // Take control of all clients immediately.
  self.clients.claim();
});

// ── Fetch: strategy per request type ─────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle same-origin GET requests.
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  // Never cache API or auth calls — always network.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/auth/')) return;

  const dest = request.destination;

  // ── Static assets: Cache-First (immutable hashed files) ──
  if (dest === 'script' || dest === 'style' || dest === 'font' || dest === 'image' || dest === 'manifest') {
    event.respondWith(cacheFirst(request));
    return;
  }

  // ── HTML navigation: Network-First with cache fallback ───
  if (dest === 'document' || request.mode === 'navigate') {
    event.respondWith(networkFirstNav(event, request));
    return;
  }

  // ── Everything else: Network with cache fallback ──────────
  event.respondWith(networkFirst(request));
});

// ── Strategies ────────────────────────────────────────────────

/** Cache-first: serve from cache, update in background. */
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('', { status: 408, statusText: 'Offline' });
  }
}

/** Network-first for HTML navigations; use Navigation Preload when available. */
async function networkFirstNav(event, request) {
  try {
    // Use preload response if browser already started fetching in parallel.
    const preloadResponse = event.preloadResponse ? await event.preloadResponse : null;
    const response = preloadResponse || await fetch(request);

    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request) || await caches.match('/');
    return cached || new Response('Offline', {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'text/plain' },
    });
  }
}

/** Network-first for generic requests. */
async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    return cached || new Response('', { status: 503 });
  }
}

// ── Message: allow clients to trigger SW update ───────────────
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});
