import { useState } from "react";
import { trpc } from "../lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle2, AlertCircle, Clock } from "lucide-react";

interface ComingSoonProps {
  title?: string;
  description?: string;
}

export function ComingSoon({ 
  title = "Coming Soon", 
  description = "We’re building something powerful for your next step." 
}: ComingSoonProps) {
  const [email, setEmail] = useState("");
  const joinWaitlist = trpc.waitlist.join.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    try {
      await joinWaitlist.mutateAsync({ email: email.trim() });
    } catch (err) {
      console.error("Failed to join waitlist:", err);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] p-6 text-center bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-md w-full space-y-8">
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-sm font-bold border border-blue-100 mb-2">
            <Clock className="h-4 w-4" />
            {title}
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">
            {title}
          </h1>
          <p className="text-xl text-gray-600">
            {description}
          </p>
        </div>

        <Card className="border-2 border-blue-100 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardContent className="pt-8 pb-8">
            {joinWaitlist.isSuccess ? (
              <div className="space-y-4 animate-in fade-in zoom-in duration-300">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-gray-900">You're on the list!</h3>
                  <p className="text-sm text-gray-600">
                    We'll notify you as soon as we're ready for early access.
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    joinWaitlist.reset();
                    setEmail("");
                  }}
                  className="mt-4"
                >
                  Join with another email
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2 text-left">
                  <label className="text-sm font-semibold text-gray-900 ml-1">Get early access</label>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={joinWaitlist.isPending}
                      className="flex-1"
                    />
                    <Button 
                      type="submit" 
                      disabled={joinWaitlist.isPending || !email}
                      className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                    >
                      {joinWaitlist.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        "Notify Me"
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    No spam. Early users only.
                  </p>
                </div>

                {joinWaitlist.isError && (
                  <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 p-2 rounded border border-red-100 text-left">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    <span>{joinWaitlist.error.message || "Failed to join. Please try again."}</span>
                  </div>
                )}
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
