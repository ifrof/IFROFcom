/**
 * ProductCard — Shopify-style product card with:
 *   - Image zoom on hover
 *   - Secondary image swap on hover (if available)
 *   - Floating action bar (Quick View, Wishlist, Compare)
 *   - Slide-up "Add to Cart" button on hover
 *   - Discount badge, Verified badge, Stock badge
 *   - Quick View modal with full product details + RFQ CTA
 */
import { useState, useRef } from 'react';
import { Link } from 'wouter';
import {
  Heart, Eye, ShoppingCart, Star, MapPin, Zap, Shield,
  Package, X, ArrowRight, Check, ChevronLeft, ChevronRight,
  Share2, Bookmark, TrendingDown
} from 'lucide-react';

export interface ProductCardData {
  id: number;
  name: string;
  factory: string;
  factoryId?: number;
  location: string;
  price: number;
  originalPrice?: number;
  minOrder: number;
  unit: string;
  category: string;
  rating: number;
  reviews: number;
  image: string;
  images?: string[];
  isStock: boolean;
  discount?: number;
  badge?: string;
  stock: number;
  tags: string[];
  description?: string;
  leadTime?: string;
  certifications?: string[];
}

interface ProductCardProps {
  product: ProductCardData;
  isWishlisted: boolean;
  onWishlistToggle: (id: number) => void;
  onAddToCart: (product: ProductCardData) => void;
  viewMode?: 'grid' | 'list';
}

/* ─── Quick View Modal ─────────────────────────────────────────── */
function QuickViewModal({
  product,
  isWishlisted,
  onWishlistToggle,
  onAddToCart,
  onClose,
}: {
  product: ProductCardData;
  isWishlisted: boolean;
  onWishlistToggle: (id: number) => void;
  onAddToCart: (p: ProductCardData) => void;
  onClose: () => void;
}) {
  const images = product.images?.length ? product.images : [product.image];
  const [activeImg, setActiveImg] = useState(0);
  const [qty, setQty] = useState(product.minOrder);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart({ ...product, minOrder: qty });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '1rem', animation: 'fadeIn 200ms ease',
      }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{
          background: 'white', borderRadius: '1.25rem',
          width: '100%', maxWidth: 900, maxHeight: '90vh',
          overflow: 'auto', position: 'relative',
          boxShadow: '0 32px 80px rgba(0,0,0,0.25)',
          animation: 'scaleIn 250ms cubic-bezier(0.34,1.56,0.64,1)',
        }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute', top: '1rem', right: '1rem', zIndex: 10,
            width: 36, height: 36, borderRadius: '50%', border: 'none',
            background: 'rgba(0,0,0,0.07)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'background 150ms',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,0,0,0.14)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'rgba(0,0,0,0.07)')}
        >
          <X style={{ width: 18, height: 18, color: '#475569' }} />
        </button>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
          {/* ── Left: Images ── */}
          <div style={{ padding: '1.5rem', borderRight: '1px solid #f1f5f9' }}>
            {/* Main image */}
            <div style={{ position: 'relative', borderRadius: '0.875rem', overflow: 'hidden', aspectRatio: '1', marginBottom: '0.75rem', background: '#f8fafc' }}>
              <img
                src={images[activeImg]}
                alt={product.name}
                style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'opacity 200ms' }}
              />
              {product.discount && (
                <div style={{ position: 'absolute', top: '0.75rem', left: '0.75rem', background: '#ef4444', color: 'white', padding: '0.25rem 0.625rem', borderRadius: '0.375rem', fontSize: '0.75rem', fontWeight: 800 }}>
                  -{product.discount}%
                </div>
              )}
              {images.length > 1 && (
                <>
                  <button onClick={() => setActiveImg(i => Math.max(0, i - 1))} style={{ position: 'absolute', left: '0.5rem', top: '50%', transform: 'translateY(-50%)', width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.9)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <ChevronLeft style={{ width: 16, height: 16 }} />
                  </button>
                  <button onClick={() => setActiveImg(i => Math.min(images.length - 1, i + 1))} style={{ position: 'absolute', right: '0.5rem', top: '50%', transform: 'translateY(-50%)', width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,255,255,0.9)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <ChevronRight style={{ width: 16, height: 16 }} />
                  </button>
                </>
              )}
            </div>
            {/* Thumbnails */}
            {images.length > 1 && (
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {images.map((img, i) => (
                  <button key={i} onClick={() => setActiveImg(i)} style={{ width: 56, height: 56, borderRadius: '0.5rem', overflow: 'hidden', border: `2px solid ${activeImg === i ? '#06b6d4' : '#e2e8f0'}`, padding: 0, cursor: 'pointer', transition: 'border-color 150ms' }}>
                    <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ── Right: Details ── */}
          <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {/* Verified + Category */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', fontWeight: 700, color: '#06b6d4', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                <Shield style={{ width: 12, height: 12 }} /> IFROF Verified
              </span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>·</span>
              <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{product.category}</span>
              {product.badge && (
                <span style={{ padding: '0.125rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.6875rem', fontWeight: 700, background: product.isStock ? 'linear-gradient(135deg, #fef3c7, #fde68a)' : 'linear-gradient(135deg, #fee2e2, #fecaca)', color: product.isStock ? '#92400e' : '#991b1b' }}>
                  {product.badge}
                </span>
              )}
            </div>

            {/* Name */}
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 800, color: '#0f172a', lineHeight: 1.3, margin: 0 }}>{product.name}</h2>

            {/* Rating */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ display: 'flex', gap: '0.125rem' }}>
                {[1,2,3,4,5].map(s => (
                  <Star key={s} style={{ width: 14, height: 14, color: '#f59e0b', fill: s <= Math.round(product.rating) ? '#f59e0b' : 'none' }} />
                ))}
              </div>
              <span style={{ fontSize: '0.875rem', fontWeight: 700, color: '#0f172a' }}>{product.rating.toFixed(1)}</span>
              <span style={{ fontSize: '0.8125rem', color: '#94a3b8' }}>({product.reviews.toLocaleString()} reviews)</span>
            </div>

            {/* Price */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.625rem', padding: '0.875rem', background: '#f8fafc', borderRadius: '0.75rem' }}>
              <span style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.75rem', fontWeight: 900, color: '#0f172a' }}>${product.price.toFixed(2)}</span>
              {product.originalPrice && (
                <span style={{ fontSize: '1rem', color: '#94a3b8', textDecoration: 'line-through' }}>${product.originalPrice.toFixed(2)}</span>
              )}
              <span style={{ fontSize: '0.8125rem', color: '#64748b' }}>/{product.unit}</span>
              {product.discount && (
                <span style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.875rem', fontWeight: 700, color: '#16a34a' }}>
                  <TrendingDown style={{ width: 14, height: 14 }} /> Save {product.discount}%
                </span>
              )}
            </div>

            {/* Location + Lead time */}
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#475569' }}>
                <MapPin style={{ width: 14, height: 14, color: '#06b6d4' }} /> {product.location}
              </div>
              {product.leadTime && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#475569' }}>
                  <Zap style={{ width: 14, height: 14, color: '#f59e0b' }} /> {product.leadTime}
                </div>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#475569' }}>
                <Package style={{ width: 14, height: 14, color: '#8b5cf6' }} /> {product.stock.toLocaleString()} in stock
              </div>
            </div>

            {/* Tags */}
            {product.tags.length > 0 && (
              <div style={{ display: 'flex', gap: '0.375rem', flexWrap: 'wrap' }}>
                {product.tags.map((t, i) => (
                  <span key={i} style={{ padding: '0.25rem 0.625rem', borderRadius: '2rem', background: '#f1f5f9', color: '#475569', fontSize: '0.75rem', fontWeight: 600 }}>{t}</span>
                ))}
              </div>
            )}

            {/* Certifications */}
            {product.certifications && product.certifications.length > 0 && (
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                {product.certifications.map((c, i) => (
                  <span key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.25rem 0.625rem', borderRadius: '0.375rem', background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.2)', color: '#0891b2', fontSize: '0.75rem', fontWeight: 700 }}>
                    <Check style={{ width: 11, height: 11 }} /> {c}
                  </span>
                ))}
              </div>
            )}

            {/* Qty selector */}
            <div>
              <label style={{ fontSize: '0.8125rem', fontWeight: 700, color: '#374151', display: 'block', marginBottom: '0.5rem' }}>Quantity</label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <button onClick={() => setQty(q => Math.max(product.minOrder, q - product.minOrder))} style={{ width: 36, height: 36, borderRadius: '0.5rem', border: '1.5px solid #e2e8f0', background: 'white', cursor: 'pointer', fontWeight: 700, fontSize: '1.125rem', color: '#374151', transition: 'all 150ms' }}>−</button>
                <input
                  type="number"
                  value={qty}
                  min={product.minOrder}
                  onChange={e => setQty(Math.max(product.minOrder, Number(e.target.value)))}
                  style={{ width: 72, height: 36, textAlign: 'center', border: '1.5px solid #e2e8f0', borderRadius: '0.5rem', fontWeight: 700, fontSize: '0.9375rem', color: '#0f172a' }}
                />
                <button onClick={() => setQty(q => q + product.minOrder)} style={{ width: 36, height: 36, borderRadius: '0.5rem', border: '1.5px solid #e2e8f0', background: 'white', cursor: 'pointer', fontWeight: 700, fontSize: '1.125rem', color: '#374151', transition: 'all 150ms' }}>+</button>
                <span style={{ fontSize: '0.8125rem', color: '#94a3b8' }}>Min. {product.minOrder} {product.unit}</span>
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '0.625rem', marginTop: 'auto' }}>
              <button
                onClick={handleAdd}
                style={{
                  flex: 1, padding: '0.875rem', borderRadius: '0.75rem', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: '0.9375rem',
                  background: added ? 'linear-gradient(135deg, #16a34a, #15803d)' : 'linear-gradient(135deg, #06b6d4, #0891b2)',
                  color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                  transition: 'all 300ms', boxShadow: added ? '0 4px 16px rgba(22,163,74,0.3)' : '0 4px 16px rgba(6,182,212,0.3)',
                }}
              >
                {added ? <><Check style={{ width: 18, height: 18 }} /> Added!</> : <><ShoppingCart style={{ width: 18, height: 18 }} /> Add to Cart</>}
              </button>
              <button
                onClick={() => onWishlistToggle(product.id)}
                style={{ width: 48, height: 48, borderRadius: '0.75rem', border: `1.5px solid ${isWishlisted ? '#ef4444' : '#e2e8f0'}`, background: isWishlisted ? 'rgba(239,68,68,0.06)' : 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 200ms' }}
              >
                <Heart style={{ width: 20, height: 20, color: isWishlisted ? '#ef4444' : '#94a3b8', fill: isWishlisted ? '#ef4444' : 'none' }} />
              </button>
              <button style={{ width: 48, height: 48, borderRadius: '0.75rem', border: '1.5px solid #e2e8f0', background: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Share2 style={{ width: 18, height: 18, color: '#94a3b8' }} />
              </button>
            </div>

            {/* View Full Details */}
            <Link
              href={`/products/${product.id}`}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.375rem', padding: '0.625rem', borderRadius: '0.625rem', background: '#f8fafc', color: '#475569', textDecoration: 'none', fontSize: '0.875rem', fontWeight: 600, transition: 'background 150ms' }}
              onMouseEnter={e => (e.currentTarget.style.background = '#f1f5f9')}
              onMouseLeave={e => (e.currentTarget.style.background = '#f8fafc')}
            >
              View Full Details <ArrowRight style={{ width: 14, height: 14 }} />
            </Link>

            {/* Trust signals */}
            <div style={{ display: 'flex', gap: '1rem', paddingTop: '0.75rem', borderTop: '1px solid #f1f5f9' }}>
              {[
                { icon: Shield, text: 'Escrow Protected' },
                { icon: Check, text: 'Verified Supplier' },
                { icon: Zap, text: 'Fast Shipping' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.6875rem', color: '#64748b', fontWeight: 600 }}>
                  <Icon style={{ width: 12, height: 12, color: '#06b6d4' }} /> {text}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Grid Card ────────────────────────────────────────────────── */
function GridCard({ product, isWishlisted, onWishlistToggle, onAddToCart, onQuickView }: ProductCardProps & { onQuickView: (p: ProductCardData) => void }) {
  const [hovered, setHovered] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);
  const images = product.images?.length ? product.images : [product.image];
  const [added, setAdded] = useState(false);
  const hoverTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMouseEnter = () => {
    setHovered(true);
    if (images.length > 1) {
      hoverTimer.current = setTimeout(() => setImgIdx(1), 300);
    }
  };
  const handleMouseLeave = () => {
    setHovered(false);
    setImgIdx(0);
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
  };

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        background: 'white',
        borderRadius: '1rem',
        overflow: 'hidden',
        border: '1px solid #e8edf3',
        transition: 'transform 300ms cubic-bezier(0.34,1.56,0.64,1), box-shadow 300ms ease',
        transform: hovered ? 'translateY(-6px)' : 'translateY(0)',
        boxShadow: hovered ? '0 20px 48px rgba(0,0,0,0.12), 0 4px 12px rgba(0,0,0,0.06)' : '0 1px 4px rgba(0,0,0,0.04)',
        position: 'relative',
        cursor: 'pointer',
      }}
    >
      {/* ── Image Section ── */}
      <div style={{ position: 'relative', overflow: 'hidden', aspectRatio: '1', background: '#f8fafc' }}>
        <img
          src={images[imgIdx]}
          alt={product.name}
          loading="lazy"
          style={{
            width: '100%', height: '100%', objectFit: 'cover',
            transition: 'transform 600ms cubic-bezier(0.25,0.46,0.45,0.94), opacity 250ms',
            transform: hovered ? 'scale(1.08)' : 'scale(1)',
          }}
        />

        {/* Gradient overlay on hover */}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to top, rgba(0,0,0,0.4) 0%, transparent 50%)',
          opacity: hovered ? 1 : 0,
          transition: 'opacity 300ms',
          pointerEvents: 'none',
        }} />

        {/* Badges */}
        <div style={{ position: 'absolute', top: '0.625rem', left: '0.625rem', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
          {product.isStock && (
            <span style={{ padding: '0.1875rem 0.5rem', borderRadius: '0.375rem', fontSize: '0.625rem', fontWeight: 800, background: 'linear-gradient(135deg, #fef3c7, #fde68a)', color: '#92400e', letterSpacing: '0.03em' }}>IN STOCK</span>
          )}
          {product.badge && !product.isStock && (
            <span style={{ padding: '0.1875rem 0.5rem', borderRadius: '0.375rem', fontSize: '0.625rem', fontWeight: 800, background: product.badge === 'Hot Deal' ? 'linear-gradient(135deg,#fee2e2,#fecaca)' : product.badge === 'New' ? 'linear-gradient(135deg,#dbeafe,#bfdbfe)' : 'linear-gradient(135deg,#d1fae5,#a7f3d0)', color: product.badge === 'Hot Deal' ? '#991b1b' : product.badge === 'New' ? '#1e40af' : '#065f46' }}>{product.badge}</span>
          )}
          {product.discount && (
            <span style={{ padding: '0.1875rem 0.5rem', borderRadius: '0.375rem', fontSize: '0.625rem', fontWeight: 800, background: '#ef4444', color: 'white' }}>-{product.discount}%</span>
          )}
        </div>

        {/* Floating action bar — slides in on hover */}
        <div style={{
          position: 'absolute', top: '0.625rem', right: '0.625rem',
          display: 'flex', flexDirection: 'column', gap: '0.375rem',
          transform: hovered ? 'translateX(0)' : 'translateX(48px)',
          opacity: hovered ? 1 : 0,
          transition: 'transform 300ms cubic-bezier(0.34,1.56,0.64,1), opacity 250ms',
        }}>
          {/* Wishlist */}
          <button
            onClick={e => { e.stopPropagation(); onWishlistToggle(product.id); }}
            title="Save to Wishlist"
            style={{ width: 34, height: 34, borderRadius: '50%', background: 'rgba(255,255,255,0.95)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.12)', transition: 'transform 150ms, background 150ms' }}
            onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.15)')}
            onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
          >
            <Heart style={{ width: 15, height: 15, color: isWishlisted ? '#ef4444' : '#64748b', fill: isWishlisted ? '#ef4444' : 'none' }} />
          </button>
          {/* Quick View */}
          <button
            onClick={e => { e.stopPropagation(); onQuickView(product); }}
            title="Quick View"
            style={{ width: 34, height: 34, borderRadius: '50%', background: 'rgba(255,255,255,0.95)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.12)', transition: 'transform 150ms, background 150ms' }}
            onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.15)')}
            onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
          >
            <Eye style={{ width: 15, height: 15, color: '#64748b' }} />
          </button>
          {/* Bookmark */}
          <button
            title="Save for Later"
            style={{ width: 34, height: 34, borderRadius: '50%', background: 'rgba(255,255,255,0.95)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.12)', transition: 'transform 150ms' }}
            onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.15)')}
            onMouseLeave={e => (e.currentTarget.style.transform = 'scale(1)')}
          >
            <Bookmark style={{ width: 15, height: 15, color: '#64748b' }} />
          </button>
        </div>

        {/* Slide-up Add to Cart button */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          transform: hovered ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 300ms cubic-bezier(0.34,1.56,0.64,1)',
        }}>
          <button
            onClick={handleAdd}
            style={{
              width: '100%', padding: '0.75rem', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: '0.875rem',
              background: added ? 'linear-gradient(135deg, #16a34a, #15803d)' : 'linear-gradient(135deg, #06b6d4, #0891b2)',
              color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              transition: 'background 300ms',
            }}
          >
            {added
              ? <><Check style={{ width: 16, height: 16 }} /> Added to Cart!</>
              : <><ShoppingCart style={{ width: 16, height: 16 }} /> Add to Cart</>
            }
          </button>
        </div>
      </div>

      {/* ── Content Section ── */}
      <Link href={`/products/${product.id}`} style={{ textDecoration: 'none', display: 'block' }}>
        <div style={{ padding: '0.875rem 1rem 1rem' }}>
          {/* Verified label + factory */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.25rem' }}>
            <MapPin style={{ width: 11, height: 11, color: '#06b6d4' }} />
            <span style={{ fontSize: '0.625rem', fontWeight: 700, color: '#06b6d4', textTransform: 'uppercase', letterSpacing: '0.06em' }}>IFROF Verified</span>
          </div>
          {product.factoryId ? (
            <Link href={`/factory/${product.factoryId}`} style={{ textDecoration: 'none' }}>
              <span style={{ fontSize: '0.7rem', color: '#e53e3e', fontWeight: 600, display: 'block', marginBottom: '0.2rem' }}>{product.factory}</span>
            </Link>
          ) : (
            <span style={{ fontSize: '0.7rem', color: '#94a3b8', display: 'block', marginBottom: '0.2rem' }}>{product.factory}</span>
          )}

          {/* Product name */}
          <h3 style={{
            fontFamily: 'Sora, sans-serif', fontSize: '0.875rem', fontWeight: 700, color: '#0f172a',
            marginBottom: '0.375rem', lineHeight: 1.35,
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
            transition: 'color 200ms',
            ...(hovered ? { color: '#06b6d4' } : {}),
          }}>{product.name}</h3>

          {/* Rating */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginBottom: '0.5rem' }}>
            <div style={{ display: 'flex', gap: '0.0625rem' }}>
              {[1,2,3,4,5].map(s => (
                <Star key={s} style={{ width: 11, height: 11, color: '#f59e0b', fill: s <= Math.round(product.rating) ? '#f59e0b' : 'none' }} />
              ))}
            </div>
            <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#374151' }}>{product.rating.toFixed(1)}</span>
            <span style={{ fontSize: '0.6875rem', color: '#94a3b8' }}>({product.reviews.toLocaleString()})</span>
          </div>

          {/* Price row */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.375rem', marginBottom: '0.25rem' }}>
            <span style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.125rem', fontWeight: 900, color: '#0f172a' }}>${product.price.toFixed(2)}</span>
            {product.originalPrice && (
              <span style={{ fontSize: '0.8125rem', color: '#94a3b8', textDecoration: 'line-through' }}>${product.originalPrice.toFixed(2)}</span>
            )}
            <span style={{ fontSize: '0.6875rem', color: '#94a3b8' }}>/{product.unit}</span>
          </div>

          {/* Min order + stock */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.6875rem', color: '#64748b', fontWeight: 600 }}>Min. {product.minOrder} {product.unit}</span>
            <span style={{ fontSize: '0.6875rem', color: product.stock > 100 ? '#16a34a' : product.stock > 0 ? '#d97706' : '#dc2626', fontWeight: 700 }}>
              {product.stock > 100 ? `${product.stock.toLocaleString()} avail.` : product.stock > 0 ? `Only ${product.stock} left` : 'Out of stock'}
            </span>
          </div>
        </div>
      </Link>
    </div>
  );
}

/* ─── List Card ────────────────────────────────────────────────── */
function ListCard({ product, isWishlisted, onWishlistToggle, onAddToCart, onQuickView }: ProductCardProps & { onQuickView: (p: ProductCardData) => void }) {
  const [hovered, setHovered] = useState(false);
  const [added, setAdded] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: 'white', borderRadius: '1rem', overflow: 'hidden',
        border: `1.5px solid ${hovered ? '#06b6d4' : '#e8edf3'}`,
        transition: 'border-color 200ms, box-shadow 200ms, transform 200ms',
        transform: hovered ? 'translateX(4px)' : 'translateX(0)',
        boxShadow: hovered ? '0 8px 24px rgba(6,182,212,0.1)' : '0 1px 4px rgba(0,0,0,0.04)',
        display: 'flex', alignItems: 'stretch', gap: 0,
      }}
    >
      {/* Image */}
      <Link href={`/products/${product.id}`} style={{ flexShrink: 0, display: 'block', position: 'relative', overflow: 'hidden', width: 160, height: 160 }}>
        <img
          src={product.image} alt={product.name} loading="lazy"
          style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 500ms', transform: hovered ? 'scale(1.06)' : 'scale(1)' }}
        />
        {product.discount && (
          <span style={{ position: 'absolute', top: '0.5rem', left: '0.5rem', padding: '0.125rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.625rem', fontWeight: 800, background: '#ef4444', color: 'white' }}>-{product.discount}%</span>
        )}
      </Link>

      {/* Content */}
      <div style={{ flex: 1, padding: '1rem 1.25rem', display: 'flex', flexDirection: 'column', gap: '0.375rem', minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
          <span style={{ fontSize: '0.625rem', fontWeight: 700, color: '#06b6d4', textTransform: 'uppercase', letterSpacing: '0.06em' }}>IFROF Verified</span>
          {product.badge && <span style={{ padding: '0.0625rem 0.375rem', borderRadius: '0.25rem', fontSize: '0.625rem', fontWeight: 700, background: '#fef3c7', color: '#92400e' }}>{product.badge}</span>}
        </div>
        <Link href={`/products/${product.id}`} style={{ textDecoration: 'none' }}>
          <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1rem', fontWeight: 700, color: hovered ? '#06b6d4' : '#0f172a', lineHeight: 1.3, transition: 'color 200ms', margin: 0 }}>{product.name}</h3>
        </Link>
        {product.factoryId ? (
          <Link href={`/factory/${product.factoryId}`} style={{ textDecoration: 'none' }}>
            <span style={{ fontSize: '0.75rem', color: '#e53e3e', fontWeight: 600 }}>{product.factory}</span>
          </Link>
        ) : (
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{product.factory}</span>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
          {[1,2,3,4,5].map(s => <Star key={s} style={{ width: 12, height: 12, color: '#f59e0b', fill: s <= Math.round(product.rating) ? '#f59e0b' : 'none' }} />)}
          <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#374151' }}>{product.rating.toFixed(1)}</span>
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>({product.reviews.toLocaleString()})</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem' }}>
          <span style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 900, color: '#0f172a' }}>${product.price.toFixed(2)}</span>
          {product.originalPrice && <span style={{ fontSize: '0.875rem', color: '#94a3b8', textDecoration: 'line-through' }}>${product.originalPrice.toFixed(2)}</span>}
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>/{product.unit}</span>
        </div>
        <div style={{ display: 'flex', gap: '1rem', fontSize: '0.75rem', color: '#64748b' }}>
          <span>Min. {product.minOrder} {product.unit}</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}><MapPin style={{ width: 11, height: 11 }} />{product.location}</span>
          <span style={{ color: product.stock > 0 ? '#16a34a' : '#dc2626', fontWeight: 700 }}>{product.stock > 0 ? `${product.stock.toLocaleString()} in stock` : 'Out of stock'}</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.25rem', marginTop: '0.125rem' }}>
          {product.tags.slice(0, 3).map((t, i) => <span key={i} style={{ padding: '0.125rem 0.5rem', borderRadius: '2rem', background: '#f1f5f9', color: '#475569', fontSize: '0.6875rem', fontWeight: 600 }}>{t}</span>)}
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '1rem', justifyContent: 'center', borderLeft: '1px solid #f1f5f9', flexShrink: 0 }}>
        <button
          onClick={handleAdd}
          style={{ padding: '0.625rem 1.25rem', borderRadius: '0.625rem', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: '0.8125rem', background: added ? 'linear-gradient(135deg,#16a34a,#15803d)' : 'linear-gradient(135deg,#06b6d4,#0891b2)', color: 'white', display: 'flex', alignItems: 'center', gap: '0.375rem', whiteSpace: 'nowrap', transition: 'background 300ms' }}
        >
          {added ? <><Check style={{ width: 14, height: 14 }} /> Added</> : <><ShoppingCart style={{ width: 14, height: 14 }} /> Add to Cart</>}
        </button>
        <button
          onClick={() => onQuickView(product)}
          style={{ padding: '0.5rem 1rem', borderRadius: '0.625rem', border: '1.5px solid #e2e8f0', background: 'white', cursor: 'pointer', fontWeight: 600, fontSize: '0.8125rem', color: '#475569', display: 'flex', alignItems: 'center', gap: '0.375rem', whiteSpace: 'nowrap', transition: 'all 150ms' }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = '#06b6d4'; (e.currentTarget as HTMLElement).style.color = '#06b6d4'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = '#e2e8f0'; (e.currentTarget as HTMLElement).style.color = '#475569'; }}
        >
          <Eye style={{ width: 14, height: 14 }} /> Quick View
        </button>
        <button
          onClick={() => onWishlistToggle(product.id)}
          style={{ padding: '0.5rem', borderRadius: '0.625rem', border: `1.5px solid ${isWishlisted ? '#ef4444' : '#e2e8f0'}`, background: isWishlisted ? 'rgba(239,68,68,0.06)' : 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 200ms' }}
        >
          <Heart style={{ width: 16, height: 16, color: isWishlisted ? '#ef4444' : '#94a3b8', fill: isWishlisted ? '#ef4444' : 'none' }} />
        </button>
      </div>
    </div>
  );
}

/* ─── Main Export ──────────────────────────────────────────────── */
export function ProductCard(props: ProductCardProps & { onQuickView: (p: ProductCardData) => void }) {
  if (props.viewMode === 'list') return <ListCard {...props} />;
  return <GridCard {...props} />;
}

/* ─── Quick View Modal Export ──────────────────────────────────── */
export { QuickViewModal };
