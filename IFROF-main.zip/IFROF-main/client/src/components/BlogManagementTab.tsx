/**
 * BlogManagementTab — Full blog management component for the Admin panel.
 * Create, edit, delete, and manage blog articles.
 */
import { useState, useRef } from 'react';
import { Plus, Edit, Trash2, Eye, Search, BookOpen, Upload, Link as LinkIcon } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export function BlogManagementTab() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'published' | 'archived'>('all');
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    coverImage: '',
    tags: '',
    featured: false,
    status: 'draft' as 'draft' | 'published' | 'archived',
    categoryId: 1,
    readTime: 5,
  });

  const [uploadingImage, setUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadImage = trpc.upload.image.useMutation();

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImage(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const result = await uploadImage.mutateAsync({ base64, mimeType: file.type, folder: 'blog' });
        setFormData(p => ({ ...p, coverImage: result.url }));
        toast.success('Image uploaded!');
      };
      reader.readAsDataURL(file);
    } catch {
      toast.error('Upload failed — enter URL manually.');
    } finally {
      setUploadingImage(false);
    }
  };

  const utils = trpc.useUtils();
  const { data: articlesData, isLoading } = trpc.blog.listArticles.useQuery({ limit: 100 } as any);
  const { data: categories } = trpc.blog.listCategories.useQuery();

  const createMutation = trpc.blog.create.useMutation({
    onSuccess: () => {
      utils.blog.listArticles.invalidate();
      setShowForm(false);
      resetForm();
      toast.success('Article created!');
    },
    onError: (e: any) => toast.error(e.message),
  });

  const updateMutation = trpc.blog.update.useMutation({
    onSuccess: () => {
      utils.blog.listArticles.invalidate();
      setShowForm(false);
      resetForm();
      toast.success('Article updated!');
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteMutation = trpc.blog.delete.useMutation({
    onSuccess: () => {
      utils.blog.listArticles.invalidate();
      toast.success('Article deleted.');
    },
    onError: (e: any) => toast.error(e.message),
  });

  const resetForm = () => {
    setFormData({ title: '', slug: '', excerpt: '', content: '', coverImage: '', tags: '', featured: false, status: 'draft', categoryId: 1, readTime: 5 });
    setEditingId(null);
  };

  const handleEdit = (item: any) => {
    const a = item.article;
    setFormData({
      title: a.title,
      slug: a.slug,
      excerpt: a.excerpt ?? '',
      content: a.content,
      coverImage: a.coverImage ?? '',
      tags: Array.isArray(a.tags) ? a.tags.join(', ') : (a.tags ?? ''),
      featured: Boolean(a.featured),
      status: a.status as 'draft' | 'published' | 'archived',
      categoryId: a.categoryId ?? 1,
      readTime: a.readTime ?? 5,
    });
    setEditingId(a.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const tagsArray = formData.tags.split(',').map(t => t.trim()).filter(Boolean);
    if (editingId) {
      updateMutation.mutate({ id: editingId, ...formData, tags: tagsArray });
    } else {
      createMutation.mutate({ ...formData, tags: tagsArray });
    }
  };

  const articles = (articlesData ?? []) as any[];
  const filtered = articles.filter(item => {
    const a = item.article;
    const matchSearch = !search || a.title.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.5rem 0.75rem', border: '1px solid #e2e8f0',
    borderRadius: 8, fontSize: '0.875rem', color: '#0f172a', background: 'white',
    outline: 'none', boxSizing: 'border-box',
  };
  const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: '0.8125rem', fontWeight: 600,
    color: '#475569', marginBottom: '0.375rem',
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <BookOpen style={{ width: 20, height: 20, color: '#06b6d4' }} /> Blog Management
        </h2>
        <button
          onClick={() => { resetForm(); setShowForm(!showForm); }}
          style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.5rem 1rem', background: showForm ? '#f1f5f9' : 'linear-gradient(135deg,#06b6d4,#0891b2)', color: showForm ? '#64748b' : 'white', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer' }}
        >
          <Plus style={{ width: 16, height: 16 }} /> {showForm ? 'Cancel' : 'New Article'}
        </button>
      </div>

      {/* Article Form */}
      {showForm && (
        <div style={{ background: 'white', border: '1px solid #e2e8f0', borderRadius: 12, padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
          <h3 style={{ fontFamily: 'Sora, sans-serif', fontWeight: 700, color: '#0f172a', marginBottom: '1.25rem', fontSize: '1rem' }}>
            {editingId ? 'Edit Article' : 'Create New Article'}
          </h3>
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
              <div>
                <label style={labelStyle}>Title *</label>
                <input
                  style={inputStyle} required value={formData.title}
                  onChange={e => {
                    const title = e.target.value;
                    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                    setFormData(p => ({ ...p, title, slug }));
                  }}
                  placeholder="Article title..."
                />
              </div>
              <div>
                <label style={labelStyle}>Slug *</label>
                <input style={inputStyle} required value={formData.slug} onChange={e => setFormData(p => ({ ...p, slug: e.target.value }))} placeholder="article-slug" />
              </div>
            </div>

            <div style={{ marginBottom: '1rem' }}>
              <label style={labelStyle}>Excerpt</label>
              <input style={inputStyle} value={formData.excerpt} onChange={e => setFormData(p => ({ ...p, excerpt: e.target.value }))} placeholder="Short description shown in listings..." />
            </div>

            <div style={{ marginBottom: '1rem' }}>
              <label style={labelStyle}>Content * (Markdown supported)</label>
              <textarea
                style={{ ...inputStyle, minHeight: 200, resize: 'vertical', fontFamily: 'monospace' }}
                required value={formData.content}
                onChange={e => setFormData(p => ({ ...p, content: e.target.value }))}
                placeholder="Write your article content here... Use ## for headings, > for quotes, - for lists"
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
              <div>
                <label style={labelStyle}>Cover Image</label>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input style={{ ...inputStyle, flex: 1 }} value={formData.coverImage} onChange={e => setFormData(p => ({ ...p, coverImage: e.target.value }))} placeholder="https://... or upload file" />
                  <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleImageFileChange} />
                  <button type="button" onClick={() => fileInputRef.current?.click()} disabled={uploadingImage} style={{ padding: '0.5rem 0.75rem', borderRadius: 8, border: '1px solid #e2e8f0', background: '#f8fafc', cursor: 'pointer', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.3rem', whiteSpace: 'nowrap' }}>
                    <Upload size={14} /> {uploadingImage ? 'Uploading...' : 'Upload'}
                  </button>
                </div>
                {formData.coverImage && <img src={formData.coverImage} alt="preview" style={{ marginTop: '0.5rem', height: 60, borderRadius: 6, objectFit: 'cover' }} />}
              </div>
              <div>
                <label style={labelStyle}>Tags (comma separated)</label>
                <input style={inputStyle} value={formData.tags} onChange={e => setFormData(p => ({ ...p, tags: e.target.value }))} placeholder="sourcing, china, trade" />
              </div>
              <div>
                <label style={labelStyle}>Read Time (minutes)</label>
                <input style={inputStyle} type="number" min={1} max={60} value={formData.readTime} onChange={e => setFormData(p => ({ ...p, readTime: Number(e.target.value) }))} />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
              <div>
                <label style={labelStyle}>Category</label>
                <select style={inputStyle} value={formData.categoryId} onChange={e => setFormData(p => ({ ...p, categoryId: Number(e.target.value) }))}>
                  {(categories ?? []).map((c: any) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                  {(!categories || categories.length === 0) && <option value={1}>General</option>}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Status</label>
                <select style={inputStyle} value={formData.status} onChange={e => setFormData(p => ({ ...p, status: e.target.value as any }))}>
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', paddingTop: '1.5rem' }}>
                <input type="checkbox" id="featured-check" checked={formData.featured} onChange={e => setFormData(p => ({ ...p, featured: e.target.checked }))} style={{ accentColor: '#06b6d4', width: 16, height: 16 }} />
                <label htmlFor="featured-check" style={{ fontSize: '0.875rem', fontWeight: 600, color: '#475569', cursor: 'pointer' }}>Featured Article</label>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <button type="button" onClick={() => { setShowForm(false); resetForm(); }} style={{ padding: '0.5rem 1.25rem', border: '1px solid #e2e8f0', borderRadius: 8, background: 'white', color: '#64748b', fontWeight: 600, cursor: 'pointer', fontSize: '0.875rem' }}>
                Cancel
              </button>
              <button type="submit" disabled={createMutation.isPending || updateMutation.isPending} style={{ padding: '0.5rem 1.5rem', background: 'linear-gradient(135deg,#06b6d4,#0891b2)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer', fontSize: '0.875rem', opacity: (createMutation.isPending || updateMutation.isPending) ? 0.7 : 1 }}>
                {createMutation.isPending || updateMutation.isPending ? 'Saving...' : editingId ? 'Update Article' : 'Create Article'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <Search style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, color: '#94a3b8' }} />
          <input style={{ ...inputStyle, paddingLeft: '2rem' }} placeholder="Search articles..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {(['all', 'published', 'draft', 'archived'] as const).map(s => (
          <button key={s} onClick={() => setStatusFilter(s)} style={{ padding: '0.4rem 0.875rem', borderRadius: 20, border: '1px solid', borderColor: statusFilter === s ? '#06b6d4' : '#e2e8f0', background: statusFilter === s ? 'rgba(6,182,212,0.08)' : 'white', color: statusFilter === s ? '#06b6d4' : '#64748b', fontWeight: 600, fontSize: '0.8125rem', cursor: 'pointer', textTransform: 'capitalize' }}>
            {s}
          </button>
        ))}
      </div>

      {/* Articles Table */}
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>Loading articles...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#94a3b8', background: 'white', borderRadius: 12, border: '1px solid #f1f5f9' }}>
          <BookOpen style={{ width: 40, height: 40, margin: '0 auto 1rem', opacity: 0.3 }} />
          <p>No articles found</p>
        </div>
      ) : (
        <div style={{ background: 'white', borderRadius: 12, border: '1px solid #f1f5f9', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                {['Title', 'Category', 'Status', 'Views', 'Featured', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '0.75rem 1rem', textAlign: 'left', fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: '1px solid #f1f5f9' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item: any, i: number) => {
                const a = item.article;
                const cat = item.category;
                return (
                  <tr key={a.id} style={{ borderBottom: i < filtered.length - 1 ? '1px solid #f8fafc' : 'none' }}>
                    <td style={{ padding: '0.875rem 1rem', maxWidth: 280 }}>
                      <div style={{ fontWeight: 600, color: '#0f172a', fontSize: '0.875rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.title}</div>
                      <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: 2 }}>{a.slug}</div>
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <span style={{ fontSize: '0.8125rem', color: '#475569' }}>{cat?.name ?? 'General'}</span>
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <span style={{ padding: '0.2rem 0.625rem', borderRadius: 20, fontSize: '0.75rem', fontWeight: 700, background: a.status === 'published' ? 'rgba(16,185,129,0.1)' : a.status === 'draft' ? 'rgba(245,158,11,0.1)' : 'rgba(148,163,184,0.1)', color: a.status === 'published' ? '#059669' : a.status === 'draft' ? '#d97706' : '#64748b' }}>
                        {a.status}
                      </span>
                    </td>
                    <td style={{ padding: '0.875rem 1rem', fontSize: '0.875rem', color: '#475569' }}>{(a.viewCount ?? 0).toLocaleString()}</td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      {a.featured ? <span style={{ color: '#f59e0b', fontSize: '1rem' }}>★</span> : <span style={{ color: '#e2e8f0', fontSize: '1rem' }}>☆</span>}
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <div style={{ display: 'flex', gap: '0.375rem' }}>
                        <a href={`/blog/${a.slug}`} target="_blank" rel="noopener noreferrer" style={{ padding: '0.3rem', borderRadius: 6, background: '#f1f5f9', color: '#64748b', display: 'flex', alignItems: 'center', cursor: 'pointer', textDecoration: 'none' }}>
                          <Eye style={{ width: 14, height: 14 }} />
                        </a>
                        <button onClick={() => handleEdit(item)} style={{ padding: '0.3rem', borderRadius: 6, background: 'rgba(6,182,212,0.08)', color: '#06b6d4', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                          <Edit style={{ width: 14, height: 14 }} />
                        </button>
                        <button onClick={() => { if (window.confirm('Delete this article?')) deleteMutation.mutate({ id: a.id }); }} style={{ padding: '0.3rem', borderRadius: 6, background: 'rgba(239,68,68,0.08)', color: '#ef4444', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                          <Trash2 style={{ width: 14, height: 14 }} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
