import { useEffect, useState } from "react";
import { LogIn, UserPlus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

interface AuthDialogProps {
  title?: string;
  logo?: string;
  open?: boolean;
  onLogin: () => void;
  onOpenChange?: (open: boolean) => void;
  onClose?: () => void;
}

export function AuthDialog({
  title,
  logo,
  open = false,
  onLogin,
  onOpenChange,
  onClose,
}: AuthDialogProps) {
  const [internalOpen, setInternalOpen] = useState(open);

  useEffect(() => {
    if (!onOpenChange) {
      setInternalOpen(open);
    }
  }, [open, onOpenChange]);

  const handleOpenChange = (nextOpen: boolean) => {
    if (onOpenChange) {
      onOpenChange(nextOpen);
    } else {
      setInternalOpen(nextOpen);
    }
    if (!nextOpen) {
      onClose?.();
    }
  };

  const handleRegister = () => {
    handleOpenChange(false);
    window.location.href = "/register";
  };

  const handleGoogleLogin = () => {
    handleOpenChange(false);
    window.location.href = "/api/auth/google";
  };

  return (
    <Dialog
      open={onOpenChange ? open : internalOpen}
      onOpenChange={handleOpenChange}
    >
      <DialogContent className="bg-white rounded-2xl w-[420px] shadow-xl border border-gray-100 p-0 gap-0 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-br from-slate-900 to-cyan-900 px-6 pt-8 pb-6 text-center relative">
          <button
            onClick={() => handleOpenChange(false)}
            className="absolute top-3 right-3 text-white/60 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/10"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          {logo ? (
            <div className="w-14 h-14 bg-white rounded-xl border border-white/20 flex items-center justify-center mx-auto mb-3 shadow-lg">
              <img src={logo} alt="App logo" className="w-9 h-9 rounded-md" />
            </div>
          ) : (
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 shadow-lg shadow-cyan-500/30 mb-3">
              <span className="text-xl font-bold text-white">IF</span>
            </div>
          )}

          <DialogTitle className="text-lg font-bold text-white leading-snug">
            {title || "Sign in to continue"}
          </DialogTitle>
          <DialogDescription className="text-sm text-cyan-100/80 mt-1 leading-relaxed">
            You need to be signed in to access this feature.
          </DialogDescription>
        </div>

        {/* Actions */}
        <div className="px-6 py-5 space-y-3">
          {/* Google Sign-In */}
          <button
            onClick={handleGoogleLogin}
            className="w-full h-11 bg-white hover:bg-gray-50 border-2 border-gray-200 hover:border-gray-300 text-gray-700 font-semibold rounded-xl text-sm shadow-sm transition-all flex items-center justify-center gap-2.5"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-gray-200"></div>
            <span className="text-xs text-gray-400">or</span>
            <div className="flex-1 h-px bg-gray-200"></div>
          </div>

          <Button
            onClick={onLogin}
            className="w-full h-11 bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800 text-white rounded-xl font-semibold text-sm shadow-md shadow-cyan-200 transition-all"
          >
            <LogIn className="w-4 h-4 mr-2" />
            Sign In with Email
          </Button>

          <Button
            onClick={handleRegister}
            variant="outline"
            className="w-full h-11 border-gray-200 text-gray-700 hover:bg-gray-50 rounded-xl font-semibold text-sm transition-all"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Create a Free Account
          </Button>
        </div>

        <div className="px-6 pb-5 text-center">
          <p className="text-xs text-gray-400">
            By continuing, you agree to our{" "}
            <a href="#" className="underline hover:text-gray-600">Terms of Service</a>
            {" "}and{" "}
            <a href="#" className="underline hover:text-gray-600">Privacy Policy</a>.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
