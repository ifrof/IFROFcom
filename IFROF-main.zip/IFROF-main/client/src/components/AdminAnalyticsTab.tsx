import { TrendingUp, Users, Factory, AlertTriangle } from 'lucide-react';
import { trpc } from '@/lib/trpc';

export function AdminAnalyticsTab() {
  const { data: stats } = trpc.admin.getStats.useQuery();

  const statCards = [
    { icon: Users, label: 'Total Users', value: stats?.users || 0, change: '+12%' },
    { icon: Factory, label: 'Total Factories', value: stats?.factories || 0, change: '+8%' },
    { icon: TrendingUp, label: 'Pending Verifications', value: stats?.pendingVerifications || 0, change: '' },
    { icon: AlertTriangle, label: 'Open Risk Flags', value: stats?.openRiskFlags || 0, change: '' },
  ];

  return (
    <div style={{ padding: '1.5rem' }}>
      <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 800, color: '#0f172a', marginBottom: '1.5rem', margin: 0 }}>Analytics Dashboard</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
        {statCards.map(({ icon: Icon, label, value, change }) => (
          <div key={label} style={{ background: 'white', padding: '1.25rem', borderRadius: '1rem', border: '1px solid #e2e8f0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.75rem' }}>
              <div style={{ width: 40, height: 40, borderRadius: '0.75rem', background: 'linear-gradient(135deg, rgba(6,182,212,0.1), rgba(139,92,246,0.1))', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon style={{ width: 20, height: 20, color: '#06b6d4' }} />
              </div>
              {change && <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#16a34a' }}>{change}</span>}
            </div>
            <p style={{ fontSize: '0.875rem', color: '#64748b', margin: '0 0 0.5rem' }}>{label}</p>
            <p style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.75rem', fontWeight: 900, color: '#0f172a', margin: 0 }}>{value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
