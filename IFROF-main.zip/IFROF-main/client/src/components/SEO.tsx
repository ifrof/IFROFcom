import { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article';
  author?: string;
  publishedTime?: string;
  modifiedTime?: string;
  tags?: string[];
}

/**
 * SEO Component - Dynamically updates meta tags for better search engine visibility
 * Supports Open Graph (Facebook) and Twitter Cards
 */
export function SEO({
  title,
  description,
  keywords,
  image,
  url,
  type = 'website',
  author,
  publishedTime,
  modifiedTime,
  tags,
}: SEOProps) {
  const siteName = 'IFROF';
  const defaultImage = 'https://ifrof.com/og-image.png';
  const fullTitle = title ? `${title} | ${siteName}` : siteName;
  const fullUrl = url || (typeof window !== 'undefined' ? window.location.href : 'https://ifrof.com');
  const ogImage = image || defaultImage;

  useEffect(() => {
    // Update document title
    document.title = fullTitle;

    // Helper function to set or update meta tag
    const setMetaTag = (property: string, content: string, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${property}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, property);
        document.head.appendChild(element);
      }
      
      element.setAttribute('content', content);
    };

    // Basic meta tags
    setMetaTag('description', description);
    if (keywords) {
      setMetaTag('keywords', keywords);
    }

    // Open Graph tags (Facebook, LinkedIn)
    setMetaTag('og:title', title, true);
    setMetaTag('og:description', description, true);
    setMetaTag('og:type', type, true);
    setMetaTag('og:url', fullUrl, true);
    setMetaTag('og:image', ogImage, true);
    setMetaTag('og:site_name', siteName, true);

    // Twitter Card tags
    setMetaTag('twitter:card', 'summary_large_image');
    setMetaTag('twitter:title', title);
    setMetaTag('twitter:description', description);
    setMetaTag('twitter:image', ogImage);

    // Article-specific tags
    if (type === 'article') {
      if (author) {
        setMetaTag('article:author', author, true);
      }
      if (publishedTime) {
        setMetaTag('article:published_time', publishedTime, true);
      }
      if (modifiedTime) {
        setMetaTag('article:modified_time', modifiedTime, true);
      }
      if (tags && tags.length > 0) {
        tags.forEach(tag => {
          const tagElement = document.createElement('meta');
          tagElement.setAttribute('property', 'article:tag');
          tagElement.setAttribute('content', tag);
          document.head.appendChild(tagElement);
        });
      }
    }

    // Canonical URL
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', fullUrl);

    // Cleanup function to remove article tags when component unmounts
    return () => {
      if (type === 'article' && tags) {
        document.querySelectorAll('meta[property="article:tag"]').forEach(el => el.remove());
      }
    };
  }, [title, description, keywords, image, url, type, author, publishedTime, modifiedTime, tags, fullTitle, fullUrl, ogImage, siteName]);

  return null; // This component doesn't render anything
}

/**
 * Organization Structured Data — injected once on mount, gives Google rich signals.
 */
export function OrganizationSchema() {
  useEffect(() => {
    const id = 'ifrof-org-schema';
    if (document.getElementById(id)) return;
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.id = id;
    script.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'IFROF',
      url: 'https://ifrof.com',
      logo: 'https://ifrof.com/og-image.png',
      description: 'AI-powered B2B factory sourcing platform connecting global buyers with verified Chinese manufacturers.',
      contactPoint: {
        '@type': 'ContactPoint',
        email: 'support@ifrof.com',
        contactType: 'customer support',
        availableLanguage: ['Arabic', 'English', 'Chinese'],
      },
      sameAs: [
        'https://linkedin.com/company/ifrof',
        'https://twitter.com/ifrof',
      ],
    });
    document.head.appendChild(script);
    return () => { document.getElementById(id)?.remove(); };
  }, []);
  return null;
}

/**
 * Structured Data (JSON-LD) Component for Articles
 */
interface ArticleStructuredDataProps {
  headline: string;
  description: string;
  image: string;
  datePublished: string;
  dateModified?: string;
  author: string;
  url: string;
}

export function ArticleStructuredData({
  headline,
  description,
  image,
  datePublished,
  dateModified,
  author,
  url,
}: ArticleStructuredDataProps) {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline,
    description,
    image,
    datePublished,
    dateModified: dateModified || datePublished,
    author: {
      '@type': 'Person',
      name: author,
    },
    publisher: {
      '@type': 'Organization',
      name: 'IFROF',
      logo: {
        '@type': 'ImageObject',
        url: 'https://ifrof.com/logo.png', // Update with actual logo URL
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': url,
    },
  };

  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(structuredData);
    script.id = 'article-structured-data';
    document.head.appendChild(script);

    return () => {
      const existingScript = document.getElementById('article-structured-data');
      if (existingScript) {
        existingScript.remove();
      }
    };
  }, [structuredData]);

  return null;
}
