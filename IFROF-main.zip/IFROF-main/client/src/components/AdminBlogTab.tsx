import { useState } from 'react';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import { trpc } from '@/lib/trpc';

export function AdminBlogTab() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ title: '', slug: '', content: '', excerpt: '', featured: false, status: 'draft' });

  const { data: articles } = trpc.blog.listArticles.useQuery({ limit: 50 });
  const createMutation = trpc.blog.create.useMutation();
  const updateMutation = trpc.blog.update.useMutation();
  const deleteMutation = trpc.blog.delete.useMutation();

  const handleSave = async () => {
    if (editingId) {
      await updateMutation.mutateAsync({ id: editingId, ...formData, status: formData.status as 'draft' | 'published' | 'archived' });
    } else {
      await createMutation.mutateAsync({ ...formData, categoryId: 1, status: formData.status as 'draft' | 'published' | 'archived' });
    }
    setFormData({ title: '', slug: '', content: '', excerpt: '', featured: false, status: 'draft' });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div style={{ padding: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 800, color: '#0f172a', margin: 0 }}>Blog Articles</h3>
        <button onClick={() => { setShowForm(!showForm); setEditingId(null); }} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.625rem 1.25rem', borderRadius: '0.75rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 700 }}>
          <Plus style={{ width: 16, height: 16 }} /> New Article
        </button>
      </div>

      {showForm && (
        <div style={{ background: '#f8fafc', padding: '1.5rem', borderRadius: '1rem', marginBottom: '1.5rem', border: '1px solid #e2e8f0' }}>
          <input placeholder="Title" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} style={{ width: '100%', padding: '0.625rem', marginBottom: '0.75rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', fontFamily: 'Sora, sans-serif' }} />
          <input placeholder="Slug" value={formData.slug} onChange={e => setFormData({ ...formData, slug: e.target.value })} style={{ width: '100%', padding: '0.625rem', marginBottom: '0.75rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', fontFamily: 'Sora, sans-serif' }} />
          <textarea placeholder="Content" value={formData.content} onChange={e => setFormData({ ...formData, content: e.target.value })} style={{ width: '100%', padding: '0.625rem', marginBottom: '0.75rem', border: '1px solid #e2e8f0', borderRadius: '0.5rem', minHeight: '200px', fontFamily: 'Sora, sans-serif' }} />
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button onClick={handleSave} style={{ padding: '0.625rem 1.25rem', background: '#16a34a', color: 'white', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: 700 }}>Save</button>
            <button onClick={() => setShowForm(false)} style={{ padding: '0.625rem 1.25rem', background: '#e2e8f0', color: '#374151', border: 'none', borderRadius: '0.5rem', cursor: 'pointer', fontWeight: 700 }}>Cancel</button>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {articles?.map(item => (
          <div key={item.article.id} style={{ background: 'white', padding: '1rem', borderRadius: '0.75rem', border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div><h4 style={{ margin: 0, fontWeight: 700 }}>{item.article.title}</h4></div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button onClick={() => { setEditingId(item.article.id); setShowForm(true); }} style={{ width: 36, height: 36, borderRadius: '0.5rem', background: '#f1f5f9', border: 'none', cursor: 'pointer' }}><Edit2 style={{ width: 14, height: 14 }} /></button>
              <button onClick={() => deleteMutation.mutate({ id: item.article.id })} style={{ width: 36, height: 36, borderRadius: '0.5rem', background: '#fee2e2', border: 'none', cursor: 'pointer' }}><Trash2 style={{ width: 14, height: 14, color: '#dc2626' }} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
