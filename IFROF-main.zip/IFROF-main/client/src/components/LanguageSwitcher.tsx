import { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import i18n from '../i18n';

const languages = [
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
];

export function LanguageSwitcher() {
  const [currentLang, setCurrentLang] = useState('ar');
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('ifrof_language') || 'ar';
    setCurrentLang(saved);
  }, []);

  const handleLanguageChange = (code: string) => {
    localStorage.setItem('ifrof_language', code);
    document.documentElement.lang = code;
    document.documentElement.dir = code === 'ar' ? 'rtl' : 'ltr';
    i18n.changeLanguage(code);
    setCurrentLang(code);
    setIsOpen(false);
  };

  const current = languages.find(l => l.code === currentLang);

  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setIsOpen(!isOpen)} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', borderRadius: '0.75rem', background: 'transparent', border: '1px solid #e2e8f0', cursor: 'pointer', fontWeight: 600, color: '#0f172a' }}>
        <span style={{ fontSize: '1.25rem' }}>{current?.flag}</span>
        <span>{current?.name}</span>
        <ChevronDown style={{ width: 16, height: 16, transition: 'transform 0.2s', transform: isOpen ? 'rotate(180deg)' : 'rotate(0)' }} />
      </button>

      {isOpen && (
        <div style={{ position: 'absolute', top: 'calc(100% + 0.5rem)', right: 0, background: 'white', border: '1px solid #e2e8f0', borderRadius: '0.75rem', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', zIndex: 50, minWidth: '180px', overflow: 'hidden' }}>
          {languages.map(lang => (
            <button key={lang.code} onClick={() => handleLanguageChange(lang.code)} style={{ width: '100%', padding: '0.75rem 1rem', background: currentLang === lang.code ? '#f0f9ff' : 'white', border: 'none', cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: '0.75rem', fontWeight: currentLang === lang.code ? 700 : 500, color: currentLang === lang.code ? '#06b6d4' : '#374151', transition: 'background 0.2s', borderBottom: lang.code !== languages[languages.length - 1].code ? '1px solid #f1f5f9' : 'none' }}>
              <span style={{ fontSize: '1.25rem' }}>{lang.flag}</span>
              <span>{lang.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
