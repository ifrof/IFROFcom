import { useEffect, useState } from "react";
import { WifiOff } from "lucide-react";

export function NetworkStatus() {
  const [online, setOnline] = useState(navigator.onLine);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    const goOnline = () => {
      setOnline(true);
      if (wasOffline) {
        // Brief delay so the "back online" banner shows before vanishing
        setTimeout(() => setWasOffline(false), 3000);
      }
    };
    const goOffline = () => {
      setOnline(false);
      setWasOffline(true);
    };

    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, [wasOffline]);

  if (online && !wasOffline) return null;

  return (
    <div
      style={{
        position: "fixed",
        bottom: 16,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 9999,
        display: "flex",
        alignItems: "center",
        gap: "0.5rem",
        padding: "0.625rem 1.25rem",
        borderRadius: "0.75rem",
        background: online ? "#059669" : "#dc2626",
        color: "white",
        fontSize: "0.875rem",
        fontWeight: 600,
        fontFamily: "DM Sans, sans-serif",
        boxShadow: "0 8px 32px rgba(0,0,0,0.2)",
        animation: "navFadeIn 0.25s ease",
      }}
    >
      {!online && <WifiOff style={{ width: 16, height: 16 }} />}
      {online ? "Back online — reconnecting…" : "You are offline"}
    </div>
  );
}
