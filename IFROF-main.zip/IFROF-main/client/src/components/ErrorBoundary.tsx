import { cn } from "@/lib/utils";
import { AlertTriangle, RotateCcw, ArrowLeft } from "lucide-react";
import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
  /** When provided, boundary resets automatically on key change (e.g. route path) */
  resetKey?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidUpdate(prevProps: Props) {
    // Auto-reset when the resetKey changes (e.g. user navigates to a different page)
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false, error: null });
    }
  }

  private handleRetry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      const isChunkError =
        this.state.error?.message?.includes("Failed to fetch dynamically imported module") ||
        this.state.error?.message?.includes("Loading chunk") ||
        this.state.error?.message?.includes("Loading CSS chunk");

      return (
        <div className="flex items-center justify-center min-h-[60vh] p-8 bg-gray-50">
          <div className="flex flex-col items-center w-full max-w-2xl p-8">
            <AlertTriangle
              size={48}
              className="text-red-500 mb-6 flex-shrink-0"
            />

            <h2 className="text-xl font-semibold mb-2">
              {isChunkError
                ? "A new version is available"
                : "An unexpected error occurred"}
            </h2>

            <p className="text-sm text-gray-500 mb-6 text-center max-w-md">
              {isChunkError
                ? "The page failed to load — this usually happens after an update. Reload to get the latest version."
                : "Something went wrong while rendering this page. You can try again or go back."}
            </p>

            {!isChunkError && this.state.error?.stack && (
              <div className="p-4 w-full rounded bg-gray-100 overflow-auto mb-6 max-h-48">
                <pre className="text-xs text-gray-600 whitespace-break-spaces">
                  {this.state.error.stack}
                </pre>
              </div>
            )}

            <div className="flex items-center gap-3">
              <button
                onClick={() => window.history.back()}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg",
                  "bg-gray-100 text-gray-700",
                  "hover:bg-gray-200 cursor-pointer transition-colors"
                )}
              >
                <ArrowLeft size={16} />
                Go Back
              </button>

              <button
                onClick={isChunkError ? () => window.location.reload() : this.handleRetry}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg",
                  "bg-cyan-600 text-white",
                  "hover:bg-cyan-700 cursor-pointer transition-colors"
                )}
              >
                <RotateCcw size={16} />
                {isChunkError ? "Reload Page" : "Try Again"}
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
