import React, { createContext, useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  minOrder: number;
}

interface CartContextType {
  items: CartItem[];
  total: number;
  itemCount: number;
  addItem: (item: CartItem) => Promise<void>;
  removeItem: (cartItemId: string) => Promise<void>;
  updateQuantity: (cartItemId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  isLoading: boolean;
}

export const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch cart from backend
  const { data: cart, refetch } = trpc.cart.getCart.useQuery(undefined, {
    enabled: true,
  });

  const addItemMutation = trpc.cart.addItem.useMutation();
  const removeItemMutation = trpc.cart.removeItem.useMutation();
  const updateQuantityMutation = trpc.cart.updateQuantity.useMutation();
  const clearCartMutation = trpc.cart.clearCart.useMutation();

  // Sync cart data from backend
  useEffect(() => {
    if (cart) {
      setItems(cart.items as unknown as CartItem[]);
      setIsLoading(false);
    }
  }, [cart]);

  const addItem = async (newItem: CartItem) => {
    try {
      await addItemMutation.mutateAsync({
        productId: parseInt(newItem.productId),
        quantity: newItem.quantity,
      });
      await refetch();
    } catch {
      // Silently handle — mutation error state available to callers
    }
  };

  const removeItem = async (cartItemId: string) => {
    try {
      await removeItemMutation.mutateAsync({ cartItemId: parseInt(cartItemId) });
      await refetch();
    } catch {
      // Silently handle — mutation error state available to callers
    }
  };

  const updateQuantity = async (cartItemId: string, quantity: number) => {
    try {
      await updateQuantityMutation.mutateAsync({
        cartItemId: parseInt(cartItemId),
        quantity,
      });
      await refetch();
    } catch {
      // Silently handle — mutation error state available to callers
    }
  };

  const clearCart = async () => {
    try {
      await clearCartMutation.mutateAsync();
      await refetch();
    } catch {
      // Silently handle — mutation error state available to callers
    }
  };

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = items.reduce((count, item) => count + item.quantity, 0);

  return (
    <CartContext.Provider value={{ items, total, itemCount, addItem, removeItem, updateQuantity, clearCart, isLoading }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = React.useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
