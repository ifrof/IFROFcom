import React, { createContext, useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';

export interface WishlistItem {
  id: number;
  productId: number;
  name: string;
  price: number;
  image: string;
  rating: number;
}

interface WishlistContextType {
  items: WishlistItem[];
  count: number;
  addItem: (productId: number) => Promise<void>;
  removeItem: (wishlistItemId: number) => Promise<void>;
  isInWishlist: (productId: number) => boolean;
  isLoading: boolean;
}

export const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch wishlist from backend
  const { data: wishlist, refetch } = trpc.wishlist.getWishlist.useQuery(undefined, {
    enabled: true,
  });

  const addItemMutation = trpc.wishlist.addItem.useMutation();
  const removeItemMutation = trpc.wishlist.removeItem.useMutation();

  // Sync wishlist data from backend
  useEffect(() => {
    if (wishlist) {
      setItems(wishlist.items as unknown as WishlistItem[]);
      setIsLoading(false);
    }
  }, [wishlist]);

  const addItem = async (productId: number) => {
    try {
      await addItemMutation.mutateAsync({ productId });
      await refetch();
    } catch {
      // Silently handle — tRPC error state is available to callers
    }
  };

  const removeItem = async (wishlistItemId: number) => {
    try {
      await removeItemMutation.mutateAsync({ wishlistItemId });
      await refetch();
    } catch {
      // Silently handle — tRPC error state is available to callers
    }
  };

  const isInWishlist = (productId: number) => {
    return items.some(item => item.productId === productId);
  };

  return (
    <WishlistContext.Provider value={{ items, count: items.length, addItem, removeItem, isInWishlist, isLoading }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = React.useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within WishlistProvider');
  }
  return context;
}
