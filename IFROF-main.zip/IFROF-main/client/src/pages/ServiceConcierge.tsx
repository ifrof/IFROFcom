import React, { useState } from 'react';
import { SEO } from '@/components/SEO';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import {
  MessageCircle, CheckCircle, ArrowRight, Users, Globe, Shield,
  Zap, Star, Phone, Mail, ChevronDown, ChevronUp, Briefcase,
  MessageSquare,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function ServiceConcierge() {
  const { t } = useTranslation();
  const [form, setForm] = useState({ name: '', email: '', company: '', productType: '', monthlyVolume: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const submitInquiry = trpc.services.submitInquiry.useMutation({
    onSuccess: () => { setSubmitted(true); toast.success('Your inquiry has been received! We will contact you within 24 hours.'); },
    onError: () => toast.error('Something went wrong. Please try again or reach us on Secure Chat.'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry.mutate({ serviceType: 'concierge', ...form });
  };

  const steps = [
    { num: '01', title: 'Tell Us What You Need', desc: 'Share your product requirements, target price, and quantity via Secure Chat or our form. No lengthy sign-up required.' },
    { num: '02', title: 'We Source & Verify', desc: 'Our team identifies 3–5 verified factories, negotiates pricing, and sends you a curated shortlist with full factory passports.' },
    { num: '03', title: 'You Choose & We Execute', desc: 'Select your preferred factory. We handle samples, quality control, and shipping coordination end-to-end.' },
    { num: '04', title: 'Pay Only on Success', desc: 'Our 5–10% commission is charged only when your order is confirmed and shipped. Zero upfront fees.' },
  ];

  const benefits = [
    { icon: Globe, title: 'White-Label Ready', desc: 'We operate invisibly. Your brand, your relationship. We are your silent sourcing arm.' },
    { icon: Shield, title: 'Verified Factories Only', desc: 'Every factory we work with has passed our 7-point verification process. No middlemen, no agents.' },
    { icon: Zap, title: 'Results in 48–72 Hours', desc: 'From inquiry to curated factory shortlist in under 3 business days. Speed is our competitive advantage.' },
    { icon: Users, title: 'Dedicated Account Manager', desc: 'One point of contact. Fluent in English, Arabic, and Chinese. Available via secure platform 7 days a week.' },
  ];

  const faqs = [
    { q: 'What is the commission structure?', a: 'We charge 5% for orders above $50,000 and 10% for orders below $50,000. The commission is included in the final factory price — you never pay us separately.' },
    { q: 'Do you work with any product category?', a: 'We specialize in consumer goods, electronics, apparel, packaging, and industrial parts. If you are unsure, send us a message and we will tell you within 2 hours if we can help.' },
    { q: 'How is this different from a sourcing agent?', a: 'Traditional agents are paid by factories, creating a conflict of interest. We are paid by you, so our loyalty is entirely to your business. We also provide full factory verification reports.' },
    { q: 'What is the minimum order value?', a: 'We work with orders starting from $5,000. For orders below this threshold, our Factory Finder tool ($9.9/search) may be a better fit.' },
    { q: 'Can I stay anonymous to the factory?', a: 'Yes. We can act as the buyer of record, keeping your brand and business identity completely private from the factory.' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#0f172a', color: '#f8fafc' }}>
      <SEO
        title="Sourcing Concierge — Dedicated Import Agent"
        description="IFROF's concierge team handles factory sourcing, negotiation, QC, and logistics on your behalf. No language barriers. No scams. Just results."
        keywords="sourcing agent China, import concierge, factory negotiation, procurement service, IFROF concierge"
        url="https://ifrof.com/services/concierge"
      />
      {/* Hero */}
      <section style={{ padding: '6rem 1.5rem 4rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 0%, rgba(6,182,212,0.18), transparent 65%)' }} />
        <div style={{ maxWidth: '800px', margin: '0 auto', position: 'relative' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(6,182,212,0.12)', border: '1px solid rgba(6,182,212,0.3)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.5rem', fontSize: '0.875rem', color: '#22d3ee', fontWeight: 600 }}>
            <Briefcase size={14} /> White-Label Sourcing Concierge
          </div>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, lineHeight: 1.15, marginBottom: '1.5rem', letterSpacing: '-0.03em' }}>
            Your Invisible Sourcing Team.<br />
            <span style={{ background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              5–10% Commission. Zero Upfront.
            </span>
          </h1>
          <p style={{ fontSize: '1.125rem', color: 'var(--color-subtle)', lineHeight: 1.7, marginBottom: '2.5rem', maxWidth: '600px', margin: '0 auto 2.5rem' }}>
            We source, verify, and negotiate with Chinese factories on your behalf. You stay anonymous. You pay only when your order ships.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link
              href="/rfq"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: '#fff', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', textDecoration: 'none', boxShadow: '0 4px 20px rgba(6,182,212,0.3)' }}
            >
              <MessageSquare size={18} /> Start Secure Sourcing
            </Link>
            <a href="#inquiry-form" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.15)', color: '#f8fafc', borderRadius: 'var(--radius-lg)', fontWeight: 600, fontSize: '1rem', textDecoration: 'none' }}>
              Fill Inquiry Form <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </section>

      {/* Social Proof Bar */}
      <div style={{ background: 'rgba(255,255,255,0.04)', borderTop: '1px solid rgba(255,255,255,0.07)', borderBottom: '1px solid rgba(255,255,255,0.07)', padding: '1.25rem 1.5rem' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', display: 'flex', justifyContent: 'center', gap: '3rem', flexWrap: 'wrap' }}>
          {[['$12M+', 'GMV Sourced'], ['200+', 'Verified Factories'], ['48h', 'Avg. Shortlist Time'], ['98%', 'Client Retention']].map(([val, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#22d3ee' }}>{val}</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--color-muted)', marginTop: '0.2rem' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <section style={{ padding: '5rem 1.5rem', maxWidth: '1000px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: 800, textAlign: 'center', marginBottom: '0.75rem' }}>How It Works</h2>
        <p style={{ color: 'var(--color-muted)', textAlign: 'center', marginBottom: '3.5rem' }}>From inquiry to shipment in 4 simple steps.</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
          {steps.map((s) => (
            <div key={s.num} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.75rem' }}>
              <div style={{ fontSize: '2.5rem', fontWeight: 900, color: 'rgba(6,182,212,0.25)', lineHeight: 1, marginBottom: '1rem' }}>{s.num}</div>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '0.5rem' }}>{s.title}</h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-muted)', lineHeight: 1.6 }}>{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Benefits */}
      <section style={{ padding: '4rem 1.5rem', background: 'rgba(255,255,255,0.02)', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
          <h2 style={{ fontSize: '2rem', fontWeight: 800, textAlign: 'center', marginBottom: '3rem' }}>Why Choose Our Concierge</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.5rem' }}>
            {benefits.map((b) => (
              <div key={b.title} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.75rem' }}>
                <div style={{ width: '2.5rem', height: '2.5rem', borderRadius: 'var(--radius-lg)', background: 'rgba(6,182,212,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                  <b.icon size={18} color="#22d3ee" />
                </div>
                <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '0.5rem' }}>{b.title}</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-muted)', lineHeight: 1.6 }}>{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Inquiry Form */}
      <section id="inquiry-form" style={{ padding: '5rem 1.5rem', maxWidth: '680px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: 800, textAlign: 'center', marginBottom: '0.75rem' }}>Start Your Sourcing Request</h2>
        <p style={{ color: 'var(--color-muted)', textAlign: 'center', marginBottom: '2.5rem' }}>We respond within 24 hours. No commitment required.</p>
        {submitted ? (
          <div style={{ textAlign: 'center', padding: '3rem', background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 'var(--radius-xl)' }}>
            <CheckCircle size={48} color="#10b981" style={{ marginBottom: '1rem' }} />
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>Inquiry Received!</h3>
            <p style={{ color: 'var(--color-muted)' }}>Our team will reach out within 24 hours. You can also reach us directly on Secure Chat for faster response.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Your name', required: true },
              { key: 'email', label: 'Email Address', type: 'email', placeholder: 'you@company.com', required: true },
              { key: 'company', label: 'Company / Brand', type: 'text', placeholder: 'Your company name', required: false },
              { key: 'productType', label: 'Product Type', type: 'text', placeholder: 'e.g. Bluetooth headphones, cotton t-shirts', required: true },
              { key: 'monthlyVolume', label: 'Estimated Monthly Order Value (USD)', type: 'text', placeholder: 'e.g. $10,000', required: false },
            ].map((f) => (
              <div key={f.key}>
                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>{f.label}</label>
                <input
                  type={f.type}
                  placeholder={f.placeholder}
                  required={f.required}
                  value={(form as any)[f.key]}
                  onChange={(e) => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }}
                />
              </div>
            ))}
            <div>
              <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>Additional Details</label>
              <textarea
                placeholder="Specifications, certifications needed, target price, delivery timeline..."
                rows={4}
                value={form.message}
                onChange={(e) => setForm(prev => ({ ...prev, message: e.target.value }))}
                style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', resize: 'vertical', boxSizing: 'border-box' }}
              />
            </div>
            <button
              type="submit"
              disabled={submitInquiry.isPending}
              style={{ padding: '0.875rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: '#fff', border: 'none', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', opacity: submitInquiry.isPending ? 0.7 : 1 }}
            >
              {submitInquiry.isPending ? 'Sending...' : 'Submit Sourcing Request'}
            </button>
            <p style={{ textAlign: 'center', fontSize: '0.8rem', color: '#475569' }}>
              All communication and payments are handled exclusively through the IFROF platform to ensure your safety and escrow protection. <Link href="/rfq" style={{ color: '#06b6d4' }}>Start a secure chat</Link> with our concierge team today.
            </p>
          </form>
        )}
      </section>

      {/* FAQ */}
      <section style={{ padding: '4rem 1.5rem', maxWidth: '720px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>Frequently Asked Questions</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map((faq, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '0.875rem', overflow: 'hidden' }}>
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1.125rem 1.5rem', background: 'none', border: 'none', color: '#f8fafc', fontWeight: 600, fontSize: '0.95rem', cursor: 'pointer', textAlign: 'left', gap: '1rem' }}
              >
                {faq.q}
                {openFaq === i ? <ChevronUp size={16} color="#64748b" /> : <ChevronDown size={16} color="#64748b" />}
              </button>
              {openFaq === i && (
                <div style={{ padding: '0 1.5rem 1.25rem', fontSize: '0.875rem', color: 'var(--color-subtle)', lineHeight: 1.7 }}>{faq.a}</div>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
