/**
 * ForumThread.tsx — Thread detail page with comments, voting, and replies
 */
import { useState } from 'react';
import { Link, useLocation, useParams } from 'wouter';
import {
  ThumbsUp, ThumbsDown, Eye, Clock, MessageCircle, ArrowRight,
  Loader, AlertCircle, Send, Pin, Lock, ChevronLeft, Share2,
  Flag, CornerDownRight, Users, Shield, Globe, Truck,
  Package, Star, Lightbulb, HelpCircle, MessageSquare,
  CheckCircle, Bookmark,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/contexts/AuthContext';
import { AuthDialog } from '@/components/AuthDialog';

/* ── Forum Categories ── */
const FORUM_CATEGORIES: Record<string, { label: string; icon: React.ElementType; color: string; bgColor: string }> = {
  'general': { label: 'نقاشات عامة', icon: MessageSquare, color: '#06b6d4', bgColor: 'rgba(6,182,212,0.1)' },
  'sourcing': { label: 'التوريد والمصانع', icon: Globe, color: '#8b5cf6', bgColor: 'rgba(139,92,246,0.1)' },
  'shipping': { label: 'الشحن والجمارك', icon: Truck, color: '#f59e0b', bgColor: 'rgba(245,158,11,0.1)' },
  'quality': { label: 'الجودة والفحص', icon: Shield, color: '#10b981', bgColor: 'rgba(16,185,129,0.1)' },
  'payment': { label: 'الدفع والتمويل', icon: Package, color: '#ec4899', bgColor: 'rgba(236,72,153,0.1)' },
  'success-stories': { label: 'قصص نجاح', icon: Star, color: '#eab308', bgColor: 'rgba(234,179,8,0.1)' },
  'tips': { label: 'نصائح وإرشادات', icon: Lightbulb, color: '#06b6d4', bgColor: 'rgba(6,182,212,0.1)' },
  'help': { label: 'مساعدة وأسئلة', icon: HelpCircle, color: '#64748b', bgColor: 'rgba(100,116,139,0.1)' },
};

/* ── Time Ago Helper ── */
function timeAgo(date: Date | string | null | undefined): string {
  if (!date) return '';
  const now = new Date();
  const d = new Date(date);
  const diff = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (diff < 60) return 'الآن';
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} ساعة`;
  if (diff < 604800) return `منذ ${Math.floor(diff / 86400)} يوم`;
  return d.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' });
}

/* ── Comment Component ── */
function CommentItem({
  comment,
  user,
  onReply,
  depth = 0,
}: {
  comment: any;
  user: any;
  onReply: (parentId: number) => void;
  depth?: number;
}) {
  return (
    <div className={`${depth > 0 ? 'mr-8 border-r-2 border-cyan-100 pr-4' : ''}`}>
      <div className="py-4">
        {/* Author info */}
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center shrink-0">
            <span className="text-xs font-bold text-white">{(user?.name || 'U')[0]}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-gray-900">{user?.name || 'مستخدم'}</span>
              <span className="text-xs text-gray-400">{timeAgo(comment.createdAt)}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap mr-11">
          {comment.content}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4 mt-2 mr-11">
          <button className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-cyan-600 transition-colors">
            <ThumbsUp className="w-3 h-3" />
            <span>{comment.upvotes || 0}</span>
          </button>
          <button
            onClick={() => onReply(comment.id)}
            className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-cyan-600 transition-colors"
          >
            <CornerDownRight className="w-3 h-3" />
            رد
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Main Thread Page ── */
export default function ForumThread() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [showAuthDialog, setShowAuthDialog] = useState(false);

  const postId = Number(params.id);

  const postQuery = trpc.forum.getPostById.useQuery(
    { postId },
    { enabled: !isNaN(postId) && postId > 0 }
  );

  const commentsQuery = trpc.forum.getComments.useQuery(
    { postId },
    { enabled: !isNaN(postId) && postId > 0 }
  );

  const voteMutation = trpc.forum.vote.useMutation({
    onSuccess: () => {
      postQuery.refetch();
    },
  });

  const createComment = trpc.forum.createComment.useMutation({
    onSuccess: () => {
      setCommentText('');
      setReplyingTo(null);
      commentsQuery.refetch();
      postQuery.refetch();
    },
  });

  const handleVote = (voteType: 'up' | 'down') => {
    if (!isAuthenticated) {
      setShowAuthDialog(true);
      return;
    }
    voteMutation.mutate({ postId, voteType });
  };

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      setShowAuthDialog(true);
      return;
    }
    if (!commentText.trim()) return;
    createComment.mutate({
      postId,
      content: commentText.trim(),
      parentId: replyingTo || undefined,
    });
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
    } catch {
      // Fallback
    }
  };

  // Loading state
  if (postQuery.isLoading) {
    return (
      <div className="min-h-screen bg-gray-50/80 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader className="w-8 h-8 animate-spin text-cyan-500" />
          <p className="text-sm text-gray-500">جارٍ تحميل المنشور...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (postQuery.isError || !postQuery.data) {
    return (
      <div className="min-h-screen bg-gray-50/80 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">المنشور غير موجود</h2>
          <p className="text-sm text-gray-500 mb-6">ربما تم حذف هذا المنشور أو أن الرابط غير صحيح.</p>
          <Link
            href="/community"
            className="inline-flex items-center gap-2 px-6 py-3 bg-cyan-600 text-white font-bold rounded-xl hover:bg-cyan-700 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة للمجتمع
          </Link>
        </div>
      </div>
    );
  }

  const { post, user: postAuthor } = postQuery.data;
  const comments = commentsQuery.data || [];
  const category = FORUM_CATEGORIES[post.categorySlug] || FORUM_CATEGORIES['general'];
  const CategoryIcon = category.icon;
  const score = (post.upvotes || 0) - (post.downvotes || 0);

  // Organize comments: top-level and replies
  const topLevelComments = comments.filter((c: any) => !c.comment.parentId);
  const repliesMap = new Map<number, any[]>();
  comments.forEach((c: any) => {
    if (c.comment.parentId) {
      const existing = repliesMap.get(c.comment.parentId) || [];
      existing.push(c);
      repliesMap.set(c.comment.parentId, existing);
    }
  });

  return (
    <div className="min-h-screen bg-gray-50/80" dir="rtl" style={{ fontFamily: '"DM Sans", Tajawal, sans-serif' }}>
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/community" className="hover:text-cyan-600 transition-colors font-medium">
              المجتمع
            </Link>
            <ChevronLeft className="w-3.5 h-3.5" />
            <span
              className="font-medium"
              style={{ color: category.color }}
            >
              {category.label}
            </span>
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="text-gray-400 truncate max-w-[200px]">{post.title}</span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Post Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mb-6">
          {/* Post Header */}
          <div className="px-6 py-5 border-b border-gray-50">
            <div className="flex items-center gap-3 mb-4 flex-wrap">
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold"
                style={{ background: category.bgColor, color: category.color }}
              >
                <CategoryIcon className="w-3.5 h-3.5" />
                {category.label}
              </span>
              {post.isPinned === 1 && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-600 text-xs font-bold">
                  <Pin className="w-3 h-3" /> مثبّت
                </span>
              )}
              {post.isLocked === 1 && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gray-100 text-gray-500 text-xs font-bold">
                  <Lock className="w-3 h-3" /> مغلق
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 leading-tight mb-4">
              {post.title}
            </h1>

            {/* Author + Meta */}
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center">
                  <span className="text-sm font-bold text-white">{(postAuthor?.name || 'U')[0]}</span>
                </div>
                <div>
                  <div className="text-sm font-bold text-gray-900">{postAuthor?.name || 'مستخدم'}</div>
                  <div className="text-xs text-gray-400">{timeAgo(post.createdAt)}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {post.views || 0} مشاهدة</span>
                <span className="flex items-center gap-1"><MessageCircle className="w-3 h-3" /> {post.commentCount || 0} تعليق</span>
              </div>
            </div>
          </div>

          {/* Post Content */}
          <div className="px-6 py-6">
            <div className="prose prose-gray max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap text-[15px]">
              {post.content}
            </div>

            {/* Tags */}
            {post.tags && (() => {
              try {
                const tags = typeof post.tags === 'string' ? JSON.parse(post.tags) : post.tags;
                if (Array.isArray(tags) && tags.length > 0) {
                  return (
                    <div className="flex flex-wrap gap-2 mt-6 pt-4 border-t border-gray-50">
                      {tags.map((tag: string, i: number) => (
                        <span key={i} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-lg text-xs font-medium">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  );
                }
              } catch { /* ignore */ }
              return null;
            })()}
          </div>

          {/* Post Actions Bar */}
          <div className="px-6 py-4 border-t border-gray-50 bg-gray-50/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Vote buttons */}
              <button
                onClick={() => handleVote('up')}
                disabled={voteMutation.isPending}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-gray-200 hover:border-green-300 hover:bg-green-50 text-gray-600 hover:text-green-600 transition-all text-sm font-medium"
              >
                <ThumbsUp className="w-4 h-4" />
                {post.upvotes || 0}
              </button>
              <div className="text-lg font-black text-gray-800 px-2">{score >= 0 ? `+${score}` : score}</div>
              <button
                onClick={() => handleVote('down')}
                disabled={voteMutation.isPending}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-gray-200 hover:border-red-300 hover:bg-red-50 text-gray-600 hover:text-red-600 transition-all text-sm font-medium"
              >
                <ThumbsDown className="w-4 h-4" />
                {post.downvotes || 0}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-gray-200 hover:bg-gray-50 text-gray-500 text-sm font-medium transition-all"
              >
                <Share2 className="w-3.5 h-3.5" />
                مشاركة
              </button>
              <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white border border-gray-200 hover:bg-gray-50 text-gray-500 text-sm font-medium transition-all">
                <Bookmark className="w-3.5 h-3.5" />
                حفظ
              </button>
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {/* Comments Header */}
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-cyan-500" />
              التعليقات
              <span className="text-sm font-normal text-gray-400">({comments.length})</span>
            </h2>
          </div>

          {/* Comment Form */}
          {post.isLocked !== 1 && (
            <div className="px-6 py-4 border-b border-gray-50">
              {replyingTo && (
                <div className="flex items-center gap-2 mb-2 text-xs text-cyan-600 bg-cyan-50 px-3 py-1.5 rounded-lg">
                  <CornerDownRight className="w-3 h-3" />
                  <span>الرد على تعليق</span>
                  <button
                    onClick={() => setReplyingTo(null)}
                    className="mr-auto text-gray-400 hover:text-gray-600"
                  >
                    إلغاء
                  </button>
                </div>
              )}
              <form onSubmit={handleSubmitComment} className="flex gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-white">{isAuthenticated ? (user?.name || 'U')[0] : '?'}</span>
                </div>
                <div className="flex-1">
                  <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder={isAuthenticated ? 'شارك رأيك أو أضف تعليقاً...' : 'سجّل دخولك للتعليق...'}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm resize-none"
                    onClick={() => {
                      if (!isAuthenticated) setShowAuthDialog(true);
                    }}
                  />
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-gray-400">كن محترماً ومهنياً في تعليقاتك</p>
                    <button
                      type="submit"
                      disabled={createComment.isPending || !commentText.trim() || !isAuthenticated}
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-all"
                    >
                      {createComment.isPending ? (
                        <Loader className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Send className="w-3.5 h-3.5" />
                      )}
                      إرسال
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {post.isLocked === 1 && (
            <div className="px-6 py-4 border-b border-gray-50 bg-gray-50 text-center">
              <p className="text-sm text-gray-500 flex items-center justify-center gap-2">
                <Lock className="w-4 h-4" />
                هذا المنشور مغلق ولا يمكن إضافة تعليقات جديدة.
              </p>
            </div>
          )}

          {/* Comments List */}
          <div className="divide-y divide-gray-50">
            {commentsQuery.isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader className="w-6 h-6 animate-spin text-cyan-500" />
              </div>
            ) : comments.length === 0 ? (
              <div className="py-12 text-center">
                <MessageCircle className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-gray-500 font-medium">لا توجد تعليقات بعد</p>
                <p className="text-xs text-gray-400 mt-1">كن أول من يعلّق على هذا المنشور</p>
              </div>
            ) : (
              topLevelComments.map((item: any) => (
                <div key={item.comment.id} className="px-6">
                  <CommentItem
                    comment={item.comment}
                    user={item.user}
                    onReply={(parentId) => {
                      if (!isAuthenticated) {
                        setShowAuthDialog(true);
                        return;
                      }
                      setReplyingTo(parentId);
                    }}
                  />
                  {/* Replies */}
                  {repliesMap.get(item.comment.id)?.map((reply: any) => (
                    <CommentItem
                      key={reply.comment.id}
                      comment={reply.comment}
                      user={reply.user}
                      onReply={(parentId) => {
                        if (!isAuthenticated) {
                          setShowAuthDialog(true);
                          return;
                        }
                        setReplyingTo(parentId);
                      }}
                      depth={1}
                    />
                  ))}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Back to community */}
        <div className="mt-6 text-center">
          <Link
            href="/community"
            className="inline-flex items-center gap-2 text-sm text-cyan-600 hover:text-cyan-700 font-semibold transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة إلى المجتمع
          </Link>
        </div>
      </div>

      {/* Auth Dialog */}
      <AuthDialog
        title="سجّل دخولك للمشاركة"
        open={showAuthDialog}
        onOpenChange={setShowAuthDialog}
        onLogin={() => {
          setShowAuthDialog(false);
          setLocation('/login');
        }}
      />
    </div>
  );
}
