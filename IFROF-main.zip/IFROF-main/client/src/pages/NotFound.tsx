/**
 * NotFound — صفحة 404 بالعربية
 */
import { Link } from "wouter";
import { Home, BookOpen } from "lucide-react";

export default function NotFound() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0c1a2e 100%)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "2rem 1.5rem", direction: "rtl",
      fontFamily: "DM Sans, Tajawal, sans-serif",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 30%, rgba(6,182,212,0.1), transparent 60%)" }} />
      <div style={{ maxWidth: 480, width: "100%", textAlign: "center", position: "relative" }}>
        <div style={{ fontSize: "8rem", fontWeight: 900, lineHeight: 1, background: "linear-gradient(135deg, #06b6d4, rgba(6,182,212,0.3))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", marginBottom: "1rem", letterSpacing: "-0.05em" }}>
          404
        </div>
        <h1 style={{ fontSize: "1.75rem", fontWeight: 900, color: "#f1f5f9", marginBottom: "1rem" }}>
          الصفحة غير موجودة
        </h1>
        <p style={{ color: "#94a3b8", fontSize: "1rem", lineHeight: 1.75, marginBottom: "2.5rem" }}>
          عذراً، الصفحة التي تبحث عنها غير موجودة أو ربما تم نقلها.
          يمكنك العودة للرئيسية أو تصفّح مقالاتنا الاحترافية.
        </p>
        <div style={{ display: "flex", gap: "0.75rem", justifyContent: "center", flexWrap: "wrap" }}>
          <Link href="/" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", padding: "0.75rem 1.75rem", background: "linear-gradient(135deg, #06b6d4, #0891b2)", color: "#fff", borderRadius: "0.75rem", fontWeight: 700, textDecoration: "none", fontSize: "0.9375rem" }}>
            <Home size={16} /> الرئيسية
          </Link>
          <Link href="/blog" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", padding: "0.75rem 1.75rem", background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.15)", color: "#f1f5f9", borderRadius: "0.75rem", fontWeight: 700, textDecoration: "none", fontSize: "0.9375rem" }}>
            <BookOpen size={16} /> تصفّح المقالات
          </Link>
        </div>
      </div>
    </div>
  );
}
