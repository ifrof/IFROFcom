import React, { useState } from "react";
import { SEO } from '@/components/SEO';
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  Container,
  Users,
  TrendingDown,
  MapPin,
  Calendar,
  Package,
  CheckCircle,
  Clock,
  ChevronRight,
  Ship,
  Globe,
  DollarSign,
  AlertCircle,
  ArrowRight,
  Loader2,
  Star,
  BarChart3,
  Layers,
  MessageSquare,
} from "lucide-react";
import { useTranslation } from "react-i18next";

// ── Helpers ──────────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string; bg: string }> = {
    open:     { label: "مفتوح للحجز",   color: "#22c55e", bg: "rgba(34,197,94,0.12)" },
    filling:  { label: "يمتلئ بسرعة",   color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
    full:     { label: "مكتمل",          color: "#ef4444", bg: "rgba(239,68,68,0.12)" },
    departed: { label: "في الطريق",      color: "#06b6d4", bg: "rgba(6,182,212,0.12)" },
    arrived:  { label: "وصل",            color: "#8b5cf6", bg: "rgba(139,92,246,0.12)" },
    closed:   { label: "مغلق",           color: "#6b7280", bg: "rgba(107,114,128,0.12)" },
  };
  const s = map[status] ?? map.open;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: "0.3rem",
      padding: "0.25rem 0.75rem", borderRadius: "2rem",
      fontSize: "0.75rem", fontWeight: 700,
      color: s.color, background: s.bg,
      border: `1px solid ${s.color}33`,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.color, display: "inline-block" }} />
      {s.label}
    </span>
  );
}

function ProgressBar({ percent }: { percent: number }) {
  const color = percent >= 90 ? "#ef4444" : percent >= 60 ? "#f59e0b" : "#22c55e";
  return (
    <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: "2rem", height: 8, overflow: "hidden" }}>
      <div style={{
        width: `${Math.min(percent, 100)}%`, height: "100%",
        background: `linear-gradient(90deg, ${color}, ${color}cc)`,
        borderRadius: "2rem", transition: "width 0.5s ease",
      }} />
    </div>
  );
}

function formatDate(d: string | Date | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("ar-EG", { year: "numeric", month: "short", day: "numeric" });
}

// ── Join Modal ────────────────────────────────────────────────────────────────

function JoinModal({
  shipment,
  onClose,
}: {
  shipment: any;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    cbmNeeded: 1,
    productDescription: "",
    productCategory: "",
    estimatedWeightKg: "",
    specialRequirements: "",
    contactName: "",
    contactEmail: "",
    contactPhone: "",
    companyName: "",
    notes: "",
  });
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const joinMutation = trpc.groupShipping.joinShipment.useMutation({
    onSuccess: (data) => {
      setSuccess(data.message);
      setError(null);
    },
    onError: (err) => {
      setError(err.message);
    },
  });

  const pricePerCbm = (shipment.pricePerCbm / 100);
  const estimatedTotal = (form.cbmNeeded * pricePerCbm).toFixed(0);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.contactName || !form.contactEmail || !form.productDescription) {
      setError("يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    joinMutation.mutate({
      shipmentId: shipment.id,
      cbmNeeded: form.cbmNeeded,
      productDescription: form.productDescription,
      productCategory: form.productCategory || undefined,
      estimatedWeightKg: form.estimatedWeightKg ? Number(form.estimatedWeightKg) : undefined,
      specialRequirements: form.specialRequirements || undefined,
      contactName: form.contactName,
      contactEmail: form.contactEmail,
      contactPhone: form.contactPhone || undefined,
      companyName: form.companyName || undefined,
      notes: form.notes || undefined,
    });
  }

  const inputStyle: React.CSSProperties = {
    width: "100%", padding: "0.75rem 1rem", borderRadius: "0.625rem",
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
    color: "#f1f5f9", fontSize: "0.9rem", outline: "none",
    fontFamily: "DM Sans, sans-serif", boxSizing: "border-box",
  };
  const labelStyle: React.CSSProperties = {
    display: "block", fontSize: "0.8rem", fontWeight: 600,
    color: "#94a3b8", marginBottom: "0.4rem",
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 1000,
      background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "1rem",
    }} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: "linear-gradient(145deg, #0f172a, #1e293b)",
        border: "1px solid rgba(255,255,255,0.1)",
        borderRadius: "1.25rem", padding: "2rem",
        width: "100%", maxWidth: "560px",
        maxHeight: "90vh", overflowY: "auto",
        direction: "rtl",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1.5rem" }}>
          <div>
            <h2 style={{ fontSize: "1.25rem", fontWeight: 800, color: "#f1f5f9", margin: 0 }}>
              احجز مكانك في الحاوية
            </h2>
            <p style={{ fontSize: "0.85rem", color: "#64748b", marginTop: "0.25rem" }}>
              {shipment.title}
            </p>
          </div>
          <button onClick={onClose} style={{
            background: "rgba(255,255,255,0.06)", border: "none", borderRadius: "0.5rem",
            color: "#94a3b8", cursor: "pointer", padding: "0.4rem 0.75rem", fontSize: "1rem",
          }}>✕</button>
        </div>

        {success ? (
          <div style={{ textAlign: "center", padding: "2rem 1rem" }}>
            <CheckCircle size={48} color="#22c55e" style={{ margin: "0 auto 1rem" }} />
            <h3 style={{ color: "#22c55e", fontSize: "1.1rem", fontWeight: 700, marginBottom: "0.75rem" }}>
              تم الحجز بنجاح!
            </h3>
            <p style={{ color: "#94a3b8", lineHeight: 1.7, fontSize: "0.9rem" }}>{success}</p>
            <button onClick={onClose} style={{
              marginTop: "1.5rem", padding: "0.75rem 2rem",
              background: "linear-gradient(135deg, #06b6d4, #0284c7)",
              color: "#fff", border: "none", borderRadius: "0.75rem",
              fontWeight: 700, cursor: "pointer", fontSize: "0.95rem",
            }}>
              إغلاق
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {/* CBM Selector */}
            <div style={{ background: "rgba(6,182,212,0.08)", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.875rem", padding: "1.25rem", marginBottom: "1.5rem" }}>
              <label style={labelStyle}>الحجم المطلوب (CBM) *</label>
              <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                <input
                  type="range"
                  min={Number(shipment.minCbm)}
                  max={Math.min(Number(shipment.maxCbm), (shipment.availableCbm / 10).toFixed(1) as any)}
                  step="0.5"
                  value={form.cbmNeeded}
                  onChange={(e) => setForm({ ...form, cbmNeeded: Number(e.target.value) })}
                  style={{ flex: 1, accentColor: "#06b6d4" }}
                />
                <div style={{ textAlign: "center", minWidth: "80px" }}>
                  <div style={{ fontSize: "1.5rem", fontWeight: 800, color: "#06b6d4" }}>{form.cbmNeeded}</div>
                  <div style={{ fontSize: "0.7rem", color: "#64748b" }}>CBM</div>
                </div>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.75rem" }}>
                <span style={{ fontSize: "0.8rem", color: "#64748b" }}>
                  الحد الأدنى: {shipment.minCbm} CBM
                </span>
                <span style={{ fontSize: "0.9rem", fontWeight: 700, color: "#22c55e" }}>
                  التكلفة التقديرية: ${estimatedTotal}
                </span>
              </div>
            </div>

            {/* Product Info */}
            <div style={{ marginBottom: "1rem" }}>
              <label style={labelStyle}>وصف البضاعة *</label>
              <textarea
                value={form.productDescription}
                onChange={(e) => setForm({ ...form, productDescription: e.target.value })}
                placeholder="مثال: ملابس أطفال قطنية، 500 قطعة في كراتين..."
                rows={3}
                style={{ ...inputStyle, resize: "vertical" }}
                required
              />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
              <div>
                <label style={labelStyle}>فئة المنتج</label>
                <input
                  type="text"
                  value={form.productCategory}
                  onChange={(e) => setForm({ ...form, productCategory: e.target.value })}
                  placeholder="ملابس، إلكترونيات..."
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>الوزن التقديري (كجم)</label>
                <input
                  type="number"
                  value={form.estimatedWeightKg}
                  onChange={(e) => setForm({ ...form, estimatedWeightKg: e.target.value })}
                  placeholder="500"
                  style={inputStyle}
                />
              </div>
            </div>

            <div style={{ marginBottom: "1.25rem" }}>
              <label style={labelStyle}>متطلبات خاصة</label>
              <input
                type="text"
                value={form.specialRequirements}
                onChange={(e) => setForm({ ...form, specialRequirements: e.target.value })}
                placeholder="هش، يحتاج تبريد، خطر..."
                style={inputStyle}
              />
            </div>

            {/* Contact Info */}
            <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: "1.25rem", marginBottom: "1rem" }}>
              <p style={{ fontSize: "0.8rem", color: "#64748b", marginBottom: "1rem", fontWeight: 600 }}>
                بيانات التواصل
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", marginBottom: "1rem" }}>
                <div>
                  <label style={labelStyle}>الاسم الكامل *</label>
                  <input
                    type="text"
                    value={form.contactName}
                    onChange={(e) => setForm({ ...form, contactName: e.target.value })}
                    placeholder="محمد أحمد"
                    style={inputStyle}
                    required
                  />
                </div>
                <div>
                  <label style={labelStyle}>البريد الإلكتروني *</label>
                  <input
                    type="email"
                    value={form.contactEmail}
                    onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
                    placeholder="you@company.com"
                    style={inputStyle}
                    required
                  />
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                <div>
                  <label style={labelStyle}>رقم الهاتف / واتساب</label>
                  <input
                    type="tel"
                    value={form.contactPhone}
                    onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
                    placeholder="+966 5x xxx xxxx"
                    style={inputStyle}
                  />
                </div>
                <div>
                  <label style={labelStyle}>اسم الشركة</label>
                  <input
                    type="text"
                    value={form.companyName}
                    onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                    placeholder="شركة الاستيراد"
                    style={inputStyle}
                  />
                </div>
              </div>
            </div>

            {error && (
              <div style={{
                background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)",
                borderRadius: "0.625rem", padding: "0.75rem 1rem",
                color: "#f87171", fontSize: "0.85rem", marginBottom: "1rem",
                display: "flex", alignItems: "center", gap: "0.5rem",
              }}>
                <AlertCircle size={16} /> {error}
              </div>
            )}

            <button
              type="submit"
              disabled={joinMutation.isPending}
              style={{
                width: "100%", padding: "0.875rem",
                background: "linear-gradient(135deg, #06b6d4, #0284c7)",
                color: "#fff", border: "none", borderRadius: "0.75rem",
                fontWeight: 700, fontSize: "1rem", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem",
                opacity: joinMutation.isPending ? 0.7 : 1,
              }}
            >
              {joinMutation.isPending ? (
                <><Loader2 size={18} style={{ animation: "spin 1s linear infinite" }} /> جاري الحجز...</>
              ) : (
                <><CheckCircle size={18} /> تأكيد الحجز — ${estimatedTotal}</>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// ── Shipment Card ─────────────────────────────────────────────────────────────

function ShipmentCard({ shipment, onJoin }: { shipment: any; onJoin: () => void }) {
  const canJoin = shipment.status === "open" || shipment.status === "filling";
  const availableCbm = (shipment.availableCbm / 10).toFixed(1);

  return (
    <div style={{
      background: "linear-gradient(145deg, rgba(15,23,42,0.9), rgba(30,41,59,0.9))",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: "1.25rem", overflow: "hidden",
      transition: "transform 0.2s, border-color 0.2s",
    }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.transform = "translateY(-3px)";
        (e.currentTarget as HTMLElement).style.borderColor = "rgba(6,182,212,0.3)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
        (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.08)";
      }}
    >
      {/* Header */}
      <div style={{ padding: "1.5rem 1.5rem 1rem", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "0.75rem" }}>
          <StatusBadge status={shipment.status} />
          <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", fontSize: "0.8rem", color: "#64748b" }}>
            <Container size={14} />
            <span>{shipment.containerType.toUpperCase()}</span>
          </div>
        </div>
        <h3 style={{ fontSize: "1.05rem", fontWeight: 700, color: "#f1f5f9", margin: "0 0 0.5rem", lineHeight: 1.4 }}>
          {shipment.title}
        </h3>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", color: "#64748b", fontSize: "0.85rem" }}>
          <MapPin size={13} />
          <span>{shipment.originCity}، {shipment.originCountry}</span>
          <ArrowRight size={13} />
          <span style={{ color: "#06b6d4", fontWeight: 600 }}>{shipment.destinationCity}، {shipment.destinationCountry}</span>
        </div>
      </div>

      {/* Fill Progress */}
      <div style={{ padding: "1rem 1.5rem" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
          <span style={{ fontSize: "0.8rem", color: "#64748b" }}>امتلاء الحاوية</span>
          <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "#f1f5f9" }}>{shipment.fillPercent}%</span>
        </div>
        <ProgressBar percent={shipment.fillPercent} />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.5rem" }}>
          <span style={{ fontSize: "0.75rem", color: "#64748b" }}>
            {shipment.participantsCount} مستورد انضم
          </span>
          <span style={{ fontSize: "0.75rem", color: "#22c55e", fontWeight: 600 }}>
            {availableCbm} CBM متاح
          </span>
        </div>
      </div>

      {/* Stats */}
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
        gap: "0", borderTop: "1px solid rgba(255,255,255,0.06)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}>
        {[
          { icon: DollarSign, label: "السعر/CBM", value: `$${shipment.pricePerCbmUsd}` },
          { icon: Calendar, label: "آخر حجز", value: formatDate(shipment.cutoffDate) },
          { icon: Ship, label: "الوصول", value: formatDate(shipment.estimatedArrival) },
        ].map((stat, i) => (
          <div key={stat.label} style={{
            padding: "0.875rem 1rem", textAlign: "center",
            borderRight: i < 2 ? "1px solid rgba(255,255,255,0.06)" : "none",
          }}>
            <stat.icon size={14} color="#64748b" style={{ margin: "0 auto 0.3rem" }} />
            <div style={{ fontSize: "0.9rem", fontWeight: 700, color: "#f1f5f9" }}>{stat.value}</div>
            <div style={{ fontSize: "0.7rem", color: "#475569" }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Included Services */}
      {shipment.includedServicesList?.length > 0 && (
        <div style={{ padding: "0.875rem 1.5rem", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem" }}>
            {shipment.includedServicesList.map((s: string) => (
              <span key={s} style={{
                fontSize: "0.7rem", padding: "0.2rem 0.6rem",
                background: "rgba(6,182,212,0.08)", color: "#22d3ee",
                borderRadius: "2rem", border: "1px solid rgba(6,182,212,0.15)",
              }}>
                ✓ {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* CTA */}
      <div style={{ padding: "1rem 1.5rem" }}>
        {canJoin ? (
          <button
            onClick={onJoin}
            style={{
              width: "100%", padding: "0.75rem",
              background: "linear-gradient(135deg, #06b6d4, #0284c7)",
              color: "#fff", border: "none", borderRadius: "0.75rem",
              fontWeight: 700, fontSize: "0.9rem", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem",
            }}
          >
            <Package size={16} /> احجز مكانك الآن
          </button>
        ) : (
          <div style={{
            textAlign: "center", padding: "0.75rem",
            color: "#475569", fontSize: "0.85rem", fontWeight: 600,
          }}>
            {shipment.status === "full" ? "الحاوية مكتملة" :
              shipment.status === "departed" ? "الشحنة في الطريق" :
                shipment.status === "arrived" ? "الشحنة وصلت" : "مغلق"}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function ServiceGroupShipping() {
  const [selectedShipment, setSelectedShipment] = useState<any | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterDest, setFilterDest] = useState<string>("");

  const { data: shipments = [], isLoading } = trpc.groupShipping.listShipments.useQuery({
    limit: 50,
  });

  const { data: stats } = trpc.groupShipping.getStats.useQuery();

  const filtered = shipments.filter((s: any) => {
    if (filterStatus !== "all" && s.status !== filterStatus) return false;
    if (filterDest && !s.destinationCountry.toLowerCase().includes(filterDest.toLowerCase())) return false;
    return true;
  });

  // Unique destinations
  const destinations = Array.from(new Set(shipments.map((s: any) => s.destinationCountry)));

  return (
    <div style={{ minHeight: "100vh", background: "#020817", color: "#f1f5f9", direction: "rtl", fontFamily: "DM Sans, sans-serif" }}>
      <SEO
        title="الشحن الجماعي — اخفض تكاليف الشحن من الصين"
        description="اشحن بضائعك مع مستوردين آخرين وادفع أقل. شحن جماعي LCL من المصانع الصينية إلى منطقة الخليج وأوروبا وأمريكا. IFROF يدير اللوجستيات بالكامل."
        keywords="شحن جماعي من الصين, LCL shipping, تقليل تكاليف الشحن, شحن الخليج, IFROF group shipping"
        url="https://ifrof.com/services/group-shipping"
      />
      {/* Hero */}
      <section style={{
        padding: "5rem 1.5rem 4rem",
        background: "linear-gradient(180deg, rgba(6,182,212,0.08) 0%, transparent 100%)",
        textAlign: "center", position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 0%, rgba(6,182,212,0.12), transparent 65%)" }} />
        <div style={{ maxWidth: "800px", margin: "0 auto", position: "relative" }}>
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "0.5rem",
            background: "rgba(6,182,212,0.12)", border: "1px solid rgba(6,182,212,0.3)",
            borderRadius: "2rem", padding: "0.375rem 1rem", marginBottom: "1.5rem",
            fontSize: "0.875rem", color: "#22d3ee", fontWeight: 600,
          }}>
            <Container size={14} /> خدمة الشحن الجماعي بالحاوية
          </div>

          <h1 style={{
            fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 800,
            lineHeight: 1.15, marginBottom: "1.5rem", letterSpacing: "-0.03em",
          }}>
            اشحن مع مستوردين آخرين.<br />
            <span style={{ background: "linear-gradient(135deg, #06b6d4, #22c55e)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              وفّر حتى 65% من تكلفة الشحن.
            </span>
          </h1>

          <p style={{
            fontSize: "1.1rem", color: "#94a3b8", lineHeight: 1.7,
            marginBottom: "2.5rem", maxWidth: "600px", margin: "0 auto 2.5rem",
          }}>
            لا تدفع ثمن حاوية كاملة وحدك. انضم إلى مستوردين آخرين في نفس الوجهة، اشتركوا في حاوية واحدة، ووفّروا معاً. نحن ننسق كل شيء.
          </p>

          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#shipments" style={{
              display: "inline-flex", alignItems: "center", gap: "0.5rem",
              padding: "0.875rem 2rem",
              background: "linear-gradient(135deg, #06b6d4, #0284c7)",
              color: "#fff", borderRadius: "0.875rem",
              fontWeight: 700, fontSize: "1rem", textDecoration: "none",
              boxShadow: "0 4px 20px rgba(6,182,212,0.3)",
            }}>
              <Ship size={18} /> استعرض الشحنات المتاحة
            </a>
            <Link href="/rfq" style={{
              display: "inline-flex", alignItems: "center", gap: "0.5rem",
              padding: "0.875rem 2rem", background: "rgba(255,255,255,0.06)",
              color: "#f1f5f9", borderRadius: "0.875rem",
              fontWeight: 700, fontSize: "1rem", textDecoration: "none",
              border: "1px solid rgba(255,255,255,0.1)",
            }}>
              <MessageSquare size={18} /> تحدث مع فريقنا
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <div style={{
        background: "rgba(255,255,255,0.03)", borderTop: "1px solid rgba(255,255,255,0.07)",
        borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "1.5rem",
      }}>
        <div style={{
          maxWidth: "900px", margin: "0 auto",
          display: "flex", justifyContent: "center", gap: "3rem", flexWrap: "wrap",
        }}>
          {[
            { val: stats?.activeShipments ?? "—", label: "شحنات مفتوحة الآن" },
            { val: stats?.totalParticipants ?? "—", label: "مستورد انضم" },
            { val: stats?.completedShipments ?? "—", label: "شحنة مكتملة" },
            { val: `${stats?.avgSavingsPercent ?? 65}%`, label: "متوسط التوفير" },
          ].map(({ val, label }) => (
            <div key={label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: "1.75rem", fontWeight: 800, color: "#06b6d4" }}>{val}</div>
              <div style={{ fontSize: "0.8rem", color: "#64748b", marginTop: "0.2rem" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <section style={{ padding: "5rem 1.5rem", maxWidth: "1000px", margin: "0 auto" }}>
        <h2 style={{ fontSize: "1.75rem", fontWeight: 800, textAlign: "center", marginBottom: "0.75rem" }}>
          كيف يعمل الشحن الجماعي؟
        </h2>
        <p style={{ textAlign: "center", color: "#64748b", marginBottom: "3rem", maxWidth: "500px", margin: "0 auto 3rem" }}>
          أربع خطوات بسيطة تفصلك عن توفير آلاف الدولارات في كل شحنة
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1.25rem" }}>
          {[
            { icon: Globe, title: "اختر وجهتك", desc: "استعرض الشحنات المجدولة إلى بلدك واختر الموعد المناسب لك.", color: "#06b6d4" },
            { icon: Layers, title: "احجز حجمك (CBM)", desc: "حدد الحجم الذي تحتاجه بالمتر المكعب. الحد الأدنى 1 CBM فقط.", color: "#22c55e" },
            { icon: Package, title: "أرسل بضاعتك", desc: "أرسل بضاعتك إلى مستودعنا في الصين وسنتولى الباقي.", color: "#f59e0b" },
            { icon: CheckCircle, title: "استلم في بلدك", desc: "تتبع شحنتك لحظة بلحظة حتى تصل إلى ميناء وجهتك.", color: "#8b5cf6" },
          ].map((step, i) => (
            <div key={step.title} style={{
              background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "1.25rem", padding: "1.75rem", position: "relative",
            }}>
              <div style={{
                width: "2.5rem", height: "2.5rem", borderRadius: "0.75rem",
                background: `${step.color}18`, display: "flex",
                alignItems: "center", justifyContent: "center", marginBottom: "1rem",
              }}>
                <step.icon size={18} color={step.color} />
              </div>
              <div style={{
                position: "absolute", top: "1.5rem", left: "1.5rem",
                fontSize: "2rem", fontWeight: 900, color: "rgba(255,255,255,0.04)",
              }}>
                {String(i + 1).padStart(2, "0")}
              </div>
              <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "0.5rem" }}>{step.title}</h3>
              <p style={{ fontSize: "0.875rem", color: "#64748b", lineHeight: 1.6 }}>{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why Group Shipping */}
      <section style={{
        padding: "4rem 1.5rem",
        background: "rgba(255,255,255,0.02)",
        borderTop: "1px solid rgba(255,255,255,0.06)",
      }}>
        <div style={{ maxWidth: "1000px", margin: "0 auto" }}>
          <h2 style={{ fontSize: "1.75rem", fontWeight: 800, textAlign: "center", marginBottom: "3rem" }}>
            لماذا الشحن الجماعي أذكى؟
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "1.5rem" }}>
            {[
              {
                icon: TrendingDown, color: "#22c55e",
                title: "تكلفة أقل بكثير",
                desc: "حاوية 40 قدم تكلف ~$3,000 شحناً. إذا اشترك فيها 10 مستوردين، يدفع كل واحد $300 فقط عوضاً عن $3,000.",
              },
              {
                icon: Users, color: "#06b6d4",
                title: "مجتمع مستوردين موثوق",
                desc: "كل المشاركين في الحاوية موثقون في المنصة. لا مخاطر، لا مفاجآت، ونحن نضمن الشفافية الكاملة.",
              },
              {
                icon: BarChart3, color: "#f59e0b",
                title: "مثالي للكميات الصغيرة",
                desc: "إذا كانت بضاعتك أقل من 10 CBM، الشحن الجماعي هو الخيار الأمثل بدلاً من LCL التقليدي.",
              },
              {
                icon: Star, color: "#8b5cf6",
                title: "خدمة شاملة",
                desc: "نتولى التخليص الجمركي، وثائق الشحن، التتبع، والتنسيق مع جميع المشاركين.",
              },
            ].map((item) => (
              <div key={item.title} style={{
                display: "flex", gap: "1rem",
                background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: "1rem", padding: "1.5rem",
              }}>
                <div style={{
                  width: "2.5rem", height: "2.5rem", borderRadius: "0.75rem",
                  background: `${item.color}15`, display: "flex",
                  alignItems: "center", justifyContent: "center", flexShrink: 0,
                }}>
                  <item.icon size={18} color={item.color} />
                </div>
                <div>
                  <h3 style={{ fontSize: "0.95rem", fontWeight: 700, marginBottom: "0.4rem" }}>{item.title}</h3>
                  <p style={{ fontSize: "0.85rem", color: "#64748b", lineHeight: 1.6 }}>{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shipments List */}
      <section id="shipments" style={{ padding: "5rem 1.5rem", maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "2rem", flexWrap: "wrap", gap: "1rem" }}>
          <div>
            <h2 style={{ fontSize: "1.75rem", fontWeight: 800, marginBottom: "0.5rem" }}>
              الشحنات المتاحة
            </h2>
            <p style={{ color: "#64748b", fontSize: "0.9rem" }}>
              {filtered.length} شحنة متاحة — احجز مكانك قبل امتلاء الحاوية
            </p>
          </div>

          {/* Filters */}
          <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              style={{
                padding: "0.5rem 1rem", borderRadius: "0.625rem",
                background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                color: "#f1f5f9", fontSize: "0.85rem", cursor: "pointer",
              }}
            >
              <option value="all">كل الحالات</option>
              <option value="open">مفتوح</option>
              <option value="filling">يمتلئ</option>
              <option value="full">مكتمل</option>
              <option value="departed">في الطريق</option>
              <option value="arrived">وصل</option>
            </select>

            <input
              type="text"
              value={filterDest}
              onChange={(e) => setFilterDest(e.target.value)}
              placeholder="ابحث بالوجهة..."
              style={{
                padding: "0.5rem 1rem", borderRadius: "0.625rem",
                background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
                color: "#f1f5f9", fontSize: "0.85rem", outline: "none",
                fontFamily: "DM Sans, sans-serif",
              }}
            />
          </div>
        </div>

        {isLoading ? (
          <div style={{ textAlign: "center", padding: "4rem", color: "#64748b" }}>
            <Loader2 size={32} style={{ animation: "spin 1s linear infinite", margin: "0 auto 1rem" }} />
            <p>جاري تحميل الشحنات...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div style={{
            textAlign: "center", padding: "5rem 2rem",
            background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: "1.25rem",
          }}>
            <Container size={48} color="#334155" style={{ margin: "0 auto 1.5rem" }} />
            <h3 style={{ fontSize: "1.25rem", fontWeight: 700, color: "#475569", marginBottom: "0.75rem" }}>
              لا توجد شحنات متاحة حالياً
            </h3>
            <p style={{ color: "#334155", marginBottom: "1.5rem", maxWidth: "400px", margin: "0 auto 1.5rem" }}>
              سجّل اهتمامك وسنخبرك فور فتح شحنة جديدة إلى وجهتك
            </p>
            <Link href="/rfq" style={{
              display: "inline-flex", alignItems: "center", gap: "0.5rem",
              padding: "0.75rem 1.5rem",
              background: "linear-gradient(135deg, #06b6d4, #0284c7)",
              color: "#fff", borderRadius: "0.75rem",
              fontWeight: 700, textDecoration: "none",
            }}>
              <MessageSquare size={16} /> أخبرنا بوجهتك
            </Link>
          </div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))",
            gap: "1.5rem",
          }}>
            {filtered.map((shipment: any) => (
              <ShipmentCard
                key={shipment.id}
                shipment={shipment}
                onJoin={() => setSelectedShipment(shipment)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Pricing Comparison */}
      <section style={{
        padding: "5rem 1.5rem",
        background: "rgba(255,255,255,0.02)",
        borderTop: "1px solid rgba(255,255,255,0.06)",
      }}>
        <div style={{ maxWidth: "800px", margin: "0 auto" }}>
          <h2 style={{ fontSize: "1.75rem", fontWeight: 800, textAlign: "center", marginBottom: "0.75rem" }}>
            مقارنة التكاليف
          </h2>
          <p style={{ textAlign: "center", color: "#64748b", marginBottom: "2.5rem" }}>
            مثال واقعي: شحن 5 CBM من غوانغتشو إلى دبي
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1rem" }}>
            {[
              { label: "حاوية كاملة (FCL)", price: "$3,200", note: "تدفع الحاوية كاملة", color: "#ef4444", bad: true },
              { label: "شحن LCL تقليدي", price: "$850", note: "رسوم إضافية مخفية", color: "#f59e0b", bad: false },
              { label: "شحن جماعي IFROF", price: "$380", note: "شامل كل الخدمات", color: "#22c55e", bad: false, best: true },
            ].map((opt) => (
              <div key={opt.label} style={{
                background: opt.best ? "rgba(34,197,94,0.08)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${opt.best ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.07)"}`,
                borderRadius: "1rem", padding: "1.5rem", textAlign: "center",
                position: "relative",
              }}>
                {opt.best && (
                  <div style={{
                    position: "absolute", top: "-12px", left: "50%", transform: "translateX(-50%)",
                    background: "#22c55e", color: "#fff", fontSize: "0.7rem", fontWeight: 700,
                    padding: "0.2rem 0.75rem", borderRadius: "2rem",
                  }}>
                    الأوفر
                  </div>
                )}
                <div style={{ fontSize: "0.85rem", color: "#64748b", marginBottom: "0.75rem" }}>{opt.label}</div>
                <div style={{ fontSize: "2rem", fontWeight: 800, color: opt.color, marginBottom: "0.5rem" }}>{opt.price}</div>
                <div style={{ fontSize: "0.75rem", color: "#475569" }}>{opt.note}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section style={{ padding: "5rem 1.5rem", maxWidth: "800px", margin: "0 auto" }}>
        <h2 style={{ fontSize: "1.75rem", fontWeight: 800, textAlign: "center", marginBottom: "3rem" }}>
          أسئلة شائعة
        </h2>
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {[
            {
              q: "ما الحد الأدنى للحجم الذي يمكنني حجزه؟",
              a: "الحد الأدنى هو 1 متر مكعب (CBM). هذا يجعل الخدمة مثالية حتى للمستوردين الصغار والمبتدئين.",
            },
            {
              q: "ماذا يحدث إذا لم تمتلئ الحاوية قبل تاريخ الإقلاع؟",
              a: "نحتفظ بالحق في تأجيل الشحنة لأسبوع أو دمجها مع شحنة أخرى. في حالة الإلغاء، يُسترد المبلغ كاملاً.",
            },
            {
              q: "هل يمكنني شحن أي نوع من البضائع؟",
              a: "معظم البضائع العامة مقبولة. البضائع الخطرة، المواد الكيميائية، والأسلحة غير مقبولة. تواصل معنا للاستفسار عن منتجك.",
            },
            {
              q: "كيف يتم التخليص الجمركي؟",
              a: "نوفر وثائق الشحن الكاملة لكل مشارك. التخليص الجمركي في بلدك مسؤوليتك، لكننا نساعدك بالتوثيق اللازم.",
            },
            {
              q: "كيف أتتبع شحنتي؟",
              a: "بعد تأكيد الحجز، ستصلك تحديثات منتظمة عبر البريد الإلكتروني وعبر لوحة التحكم في حسابك.",
            },
          ].map((faq, i) => (
            <div key={i} style={{
              background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
              borderRadius: "0.875rem", padding: "1.25rem 1.5rem",
            }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700, marginBottom: "0.6rem", color: "#f1f5f9" }}>
                {faq.q}
              </h3>
              <p style={{ fontSize: "0.875rem", color: "#64748b", lineHeight: 1.7, margin: 0 }}>
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Bottom */}
      <section style={{
        padding: "5rem 1.5rem", textAlign: "center",
        background: "linear-gradient(180deg, transparent, rgba(6,182,212,0.06))",
        borderTop: "1px solid rgba(255,255,255,0.06)",
      }}>
        <div style={{ maxWidth: "600px", margin: "0 auto" }}>
          <h2 style={{ fontSize: "2rem", fontWeight: 800, marginBottom: "1rem" }}>
            جاهز لتوفير تكاليف الشحن؟
          </h2>
          <p style={{ color: "#64748b", marginBottom: "2rem", lineHeight: 1.7 }}>
            انضم إلى مئات المستوردين الذين يشحنون بذكاء مع IFROF. احجز مكانك في الشحنة القادمة اليوم.
          </p>
          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#shipments" style={{
              display: "inline-flex", alignItems: "center", gap: "0.5rem",
              padding: "0.875rem 2rem",
              background: "linear-gradient(135deg, #06b6d4, #0284c7)",
              color: "#fff", borderRadius: "0.875rem",
              fontWeight: 700, fontSize: "1rem", textDecoration: "none",
              boxShadow: "0 4px 20px rgba(6,182,212,0.3)",
            }}>
              <Ship size={18} /> احجز الآن
            </a>
            <Link href="/rfq" style={{
              display: "inline-flex", alignItems: "center", gap: "0.5rem",
              padding: "0.875rem 2rem", background: "rgba(255,255,255,0.06)",
              color: "#f1f5f9", borderRadius: "0.875rem",
              fontWeight: 700, fontSize: "1rem", textDecoration: "none",
              border: "1px solid rgba(255,255,255,0.1)",
            }}>
              <MessageSquare size={18} /> تحدث مع فريقنا
            </Link>
          </div>
        </div>
      </section>

      {/* Join Modal */}
      {selectedShipment && (
        <JoinModal
          shipment={selectedShipment}
          onClose={() => setSelectedShipment(null)}
        />
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
