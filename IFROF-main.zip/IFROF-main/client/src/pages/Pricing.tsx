import { Check, Crown, Zap, Search, Shield, Star, ArrowLeft, Package, MessageSquare, FileText, Lock } from 'lucide-react';
import { Link, useSearch } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { trackPurchaseIntent } from '@/lib/analytics';
import { SEO } from '@/components/SEO';

export default function Pricing() {
  const { user } = useAuth();
  const searchParams = new URLSearchParams(useSearch());
  const success = searchParams.get('success') === 'true';
  const packSuccess = searchParams.get('pack_success') === 'true';

  const createSubscription = trpc.revenue.createSubscriptionCheckout.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) window.location.href = data.checkoutUrl;
    },
  });
  const createPack = trpc.revenue.createPackCheckout.useMutation({
    onSuccess: (data) => {
      if (data.checkoutUrl) window.location.href = data.checkoutUrl;
    },
  });

  const handleSubscribe = (plan: 'basic' | 'pro') => {
    if (!user) {
      window.location.href = '/login';
      return;
    }
    const price = plan === 'basic' ? 9.9 : 49.9;
    trackPurchaseIntent(plan, price);
    createSubscription.mutate({ plan });
  };
  const createPortal = trpc.revenue.createPortalSession.useMutation({
    onSuccess: (data) => {
      if (data.portalUrl) window.location.href = data.portalUrl;
    },
  });

  const currentPlan = user?.plan ?? 'free';

  const subscriptionPlans = [
    {
      key: 'free' as const,
      name: 'مجاني',
      price: 0,
      period: 'مجاني للأبد',
      badge: null,
      description: 'استكشف المنصة وانضم إلى المجتمع',
      icon: Zap,
      color: '#06b6d4',
      gradient: 'linear-gradient(135deg, #06b6d4, #0891b2)',
      features: [
        'تصفح السوق والمنتدى',
        'عرض ملفات المصانع',
        'إرسال طلبات أسعار (3 مطابقات مجانية)',
        'البحث الأساسي عن المنتجات',
        'دعم المجتمع',
      ],
      popular: false,
    },
    {
      key: 'basic' as const,
      name: 'أساسي',
      price: 9.9,
      period: 'شهر',
      badge: 'الأكثر شعبية',
      description: 'ابحث عن المصانع الموثقة بالذكاء الاصطناعي',
      icon: Search,
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
      features: [
        'كل ما في المجاني',
        'إرسال طلبات أسعار غير محدودة',
        'المراسلة مع المصانع',
        'عرض جواز المصنع (أدلة الثقة)',
        'بحث عن المصانع بالذكاء الاصطناعي',
        'دعم ذو أولوية',
      ],
      popular: true,
    },
    {
      key: 'pro' as const,
      name: 'احترافي',
      price: 49.9,
      period: 'شهر',
      badge: 'أفضل قيمة',
      description: 'بحث متقدم + أدوات حصرية',
      icon: Crown,
      color: '#f59e0b',
      gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
      features: [
        'كل ما في الأساسي',
        'تقييمات المصانع الموثقة',
        'مطابقة ذات أولوية (أعلى القائمة)',
        'مراسلات غير محدودة',
        'تقارير أدلة الثقة المتقدمة',
        'حماية الطلبات (ضمان تجريبي)',
        'مدير حساب مخصص',
      ],
      popular: false,
    },
  ];

  const faqs = [
    { q: 'ما المتضمن في الخطة المجانية؟', a: 'يمكنك تصفح السوق، وعرض ملفات المصانع، وإرسال ما يصل إلى 3 طلبات أسعار مع مطابقات مجانية، والمشاركة في منتدى المجتمع. إنها طريقة رائعة لاستكشاف المنصة.' },
    { q: 'هل يمكنني الترقية أو التخفيض في أي وقت؟', a: 'نعم! يمكنك الترقية فوراً وسيتم احتساب الفاتورة بالتناسب. للتخفيض، يمكنك إدارة اشتراكك من خلال بوابة الفوترة.' },
    { q: 'ما هي حزمة المطابقة الموثقة؟', a: 'هي عملية شراء لمرة واحدة (19.90$) تمنحك رصيداً واحداً لمراجعة مصنع موثق. مثالية إذا لم تكن بحاجة إلى اشتراك شهري ولكنك تريد تحققاً عميقاً لمصنع معين.' },
    { q: 'كيف تعمل حماية الطلبات؟', a: 'متاحة في خطة الاحترافي، حماية الطلبات هي خدمة الضمان المُدارة. يتم الاحتفاظ بدفعتك بأمان حتى تؤكد استلام البضائع بشكل مرضٍ. حالياً في المرحلة التجريبية.' },
    { q: 'هل أحتاج للدفع مقابل البحث عن المصانع؟', a: 'يحصل مشتركو الأساسي والاحترافي على بحث المصانع بالذكاء الاصطناعي مُضمناً. يمكن للمستخدمين المجانيين تصفح السوق وإرسال طلبات الأسعار.' },
  ];

  return (
    <div style={{ paddingTop: '5rem', minHeight: '100vh', background: 'var(--color-bg)', direction: 'rtl' }}>
      <SEO
        title="الأسعار والباقات"
        description="ابدأ مجاناً واشترك في الخطة التي تناسبك. بحث المصانع بالذكاء الاصطناعي، طلبات أسعار غير محدودة، وحماية الطلبات. اشتراكات تبدأ من $9.9/شهر."
        keywords="أسعار منصة التوريد, باقات استيراد, بحث مصانع صينية, IFROF pricing"
        url="https://ifrof.com/pricing"
      />
      {/* Success banner */}
      {(success || packSuccess) && (
        <div style={{ background: '#ecfdf5', padding: '1rem', textAlign: 'center', borderBottom: '1px solid #d1fae5' }}>
          <p style={{ color: '#059669', fontWeight: 700, fontSize: '0.95rem' }}>
            {success ? 'تم تفعيل الاشتراك! مرحباً بك في خطتك الجديدة.' : 'تم شراء حزمة المطابقة الموثقة! تمت إضافة الرصيد إلى حسابك.'}
          </p>
        </div>
      )}

      {/* Hero */}
      <section style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)', padding: '4rem 0 3rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 50%, rgba(139,92,246,0.15), transparent 70%)' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.5rem' }}>
            <Star className="w-4 h-4" style={{ color: '#a78bfa' }} />
            <span style={{ color: '#a78bfa', fontSize: '0.875rem', fontWeight: 600 }}>أسعار بسيطة وشفافة</span>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, color: 'white', marginBottom: '1rem' }}>
            استورد بذكاء.<br />
            <span style={{ background: 'linear-gradient(135deg, #8b5cf6, #f59e0b)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              اختر خطتك.
            </span>
          </h1>
          <p style={{ color: 'var(--color-subtle)', fontSize: '1.125rem', maxWidth: '560px', margin: '0 auto' }}>
            ابدأ مجاناً، وقم بالترقية عندما تكون جاهزاً. يمكنك الإلغاء في أي وقت.
          </p>
        </div>
      </section>

      {/* Value Proposition Banner */}
      <section style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '2rem 0' }}>
        <div className="container" style={{ maxWidth: '960px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.5rem', textAlign: 'center' }}>
            {[
              { icon: '🏭', title: '12,000+ مصنع موثق', sub: 'ليس وسطاء — مصانع حقيقية مع تقارير تدقيق' },
              { icon: '🔒', title: 'حماية ضمان الدفع', sub: 'أموالك محفوظة حتى تؤكد استلام البضاعة' },
              { icon: '🤖', title: 'مطابقة بالذكاء الاصطناعي', sub: 'يحلل متطلباتك ويجد أفضل 3 موردين' },
              { icon: '⚡', title: 'نتائج خلال 48 ساعة', sub: 'متوسط وقت الحصول على عروض الأسعار' },
            ].map(({ icon, title, sub }) => (
              <div key={title} style={{ padding: '0.5rem' }}>
                <div style={{ fontSize: '1.75rem', marginBottom: '0.5rem' }}>{icon}</div>
                <div style={{ fontWeight: 700, color: 'var(--color-ink)', fontSize: '0.9rem', marginBottom: '0.25rem' }}>{title}</div>
                <div style={{ color: 'var(--color-muted)', fontSize: '0.8rem', lineHeight: 1.5 }}>{sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subscription Plans */}
      <section style={{ padding: '4rem 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem', maxWidth: '1100px', margin: '0 auto' }}>
            {subscriptionPlans.map((plan) => {
              const isCurrent = currentPlan === plan.key;

              return (
                <div
                  key={plan.key}
                  style={{
                    background: 'white',
                    borderRadius: '1.25rem',
                    border: plan.popular ? '2px solid #8b5cf6' : isCurrent ? '2px solid #06b6d4' : '1px solid #e2e8f0',
                    padding: '2rem',
                    position: 'relative',
                    boxShadow: plan.popular ? '0 20px 60px rgba(139,92,246,0.15)' : '0 4px 20px rgba(0,0,0,0.05)',
                    transform: plan.popular ? 'scale(1.02)' : 'scale(1)',
                  }}
                >
                  {plan.badge && (
                    <div style={{ position: 'absolute', top: '-1rem', left: '50%', transform: 'translateX(-50%)', background: plan.gradient, borderRadius: '2rem', padding: '0.25rem 1rem', fontSize: '0.75rem', fontWeight: 700, color: 'white', whiteSpace: 'nowrap' }}>
                      {plan.badge}
                    </div>
                  )}

                  {isCurrent && (
                    <div style={{ position: 'absolute', top: '-1rem', right: '1rem', background: '#06b6d4', borderRadius: '2rem', padding: '0.25rem 0.75rem', fontSize: '0.7rem', fontWeight: 700, color: 'white' }}>
                      الخطة الحالية
                    </div>
                  )}

                  {/* Header */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                    <div style={{ width: '2.5rem', height: '2.5rem', borderRadius: 'var(--radius-lg)', background: plan.gradient, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <plan.icon className="w-5 h-5" style={{ color: 'white' }} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, color: 'var(--color-ink)', fontSize: '1rem' }}>{plan.name}</div>
                      <div style={{ color: 'var(--color-muted)', fontSize: '0.8rem' }}>{plan.description}</div>
                    </div>
                  </div>

                  {/* Price */}
                  <div style={{ marginBottom: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.25rem' }}>
                      {plan.price > 0 && <span style={{ color: 'var(--color-muted)', fontSize: '1.25rem' }}>$</span>}
                      <span style={{ fontSize: plan.price === 0 ? '2.5rem' : '2.25rem', fontWeight: 800, color: plan.price === 0 ? '#06b6d4' : '#0f172a', fontFamily: 'Sora' }}>
                        {plan.price === 0 ? 'مجاني' : plan.price}
                      </span>
                      {plan.price > 0 && <span style={{ color: 'var(--color-subtle)', fontSize: '0.875rem' }}>/ {plan.period}</span>}
                    </div>
                  </div>

                  {/* CTA */}
                  {isCurrent ? (
                    user?.stripeCustomerId ? (
                      <button
                        onClick={() => createPortal.mutate()}
                        disabled={createPortal.isPending}
                        style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                          width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-lg)', marginBottom: '1.5rem',
                          fontWeight: 700, fontSize: '0.9rem', border: '2px solid #06b6d4',
                          background: 'white', color: '#06b6d4', cursor: 'pointer',
                        }}
                      >
                        {createPortal.isPending ? 'جاري التحميل...' : 'إدارة الاشتراك'}
                      </button>
                    ) : (
                      <div style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-lg)', marginBottom: '1.5rem',
                        fontWeight: 600, fontSize: '0.875rem', border: '2px solid #e2e8f0',
                        background: '#f8fafc', color: '#64748b',
                      }}>
                        ✓ خطتك الحالية — مجاني
                      </div>
                    )
                  ) : plan.key === 'free' ? (
                    <Link href="/register"
                      style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                        width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-lg)', marginBottom: '1.5rem',
                        fontWeight: 700, fontSize: '0.9rem', textDecoration: 'none',
                        background: 'var(--color-bg-2)', color: 'var(--color-ink-3)',
                      }}
                    >
                      ابدأ مجاناً <ArrowLeft className="w-4 h-4" />
                    </Link>
                  ) : (
                    <button
                      onClick={() => handleSubscribe(plan.key as 'basic' | 'pro')}
                      disabled={createSubscription.isPending}
                      style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                        width: '100%', padding: '0.75rem', borderRadius: 'var(--radius-lg)', marginBottom: '1.5rem',
                        fontWeight: 700, fontSize: '0.9rem', border: 'none', cursor: 'pointer',
                        background: plan.gradient, color: 'white',
                        opacity: createSubscription.isPending ? 0.7 : 1,
                      }}
                    >
                      {createSubscription.isPending ? 'جاري التحويل...' : `اشترك — $${plan.price}/شهر`}
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                  )}

                  {/* Features */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                    {plan.features.map((f) => (
                      <div key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.625rem' }}>
                        <Check className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: plan.color }} />
                        <span style={{ color: 'var(--color-ink-3)', fontSize: '0.875rem' }}>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Security / Payment Trust Bar */}
      <div style={{ textAlign: 'center', padding: '0 0 2rem' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '1.5rem', flexWrap: 'wrap', justifyContent: 'center', padding: '0.75rem 2rem', background: 'white', borderRadius: '3rem', border: '1px solid #e2e8f0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#64748b', fontSize: '0.8rem', fontWeight: 600 }}>
            <Lock className="w-3.5 h-3.5" style={{ color: '#10b981' }} />
            مدفوعات آمنة عبر Stripe
          </div>
          <div style={{ width: 1, height: 16, background: '#e2e8f0' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#64748b', fontSize: '0.8rem', fontWeight: 600 }}>
            <Shield className="w-3.5 h-3.5" style={{ color: '#8b5cf6' }} />
            مشفر بـ SSL
          </div>
          <div style={{ width: 1, height: 16, background: '#e2e8f0' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#64748b', fontSize: '0.8rem', fontWeight: 600 }}>
            <Check className="w-3.5 h-3.5" style={{ color: '#06b6d4' }} />
            إلغاء في أي وقت
          </div>
          <div style={{ width: 1, height: 16, background: '#e2e8f0' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#64748b', fontSize: '0.8rem', fontWeight: 600 }}>
            <Shield className="w-3.5 h-3.5" style={{ color: '#f59e0b' }} />
            PCI DSS متوافق
          </div>
        </div>
      </div>

      {/* Verified Match Pack */}
      <section style={{ padding: '3rem 0', background: 'white' }}>
        <div className="container" style={{ maxWidth: '700px' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0f172a, #1e293b)',
            borderRadius: '1.25rem',
            padding: '2rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '1.5rem',
          }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <Package className="w-5 h-5" style={{ color: '#f59e0b' }} />
                <span style={{ color: 'white', fontWeight: 700, fontSize: '1.1rem' }}>حزمة المطابقة الموثقة</span>
                <span style={{ background: 'rgba(245,158,11,0.2)', color: '#fbbf24', padding: '0.125rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.7rem', fontWeight: 700 }}>لمرة واحدة</span>
              </div>
              <p style={{ color: 'var(--color-subtle)', fontSize: '0.875rem', maxWidth: '400px' }}>
                لا تحتاج اشتراك؟ اشترِ رصيد مراجعة مصنع موثق واحد مقابل 19.90$.
              </p>
              {user && (user.verifiedMatchPackCredits ?? 0) > 0 && (
                <p style={{ color: '#34d399', fontSize: '0.8rem', fontWeight: 600, marginTop: '0.25rem' }}>
                  لديك {user.verifiedMatchPackCredits} رصيد(أرصدة) متبقية
                </p>
              )}
            </div>
            <button
              onClick={() => {
                if (!user) { window.location.href = '/login'; return; }
                trackPurchaseIntent('verified_match_pack', 19.9);
                createPack.mutate();
              }}
              disabled={createPack.isPending}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.75rem 1.5rem', borderRadius: 'var(--radius-lg)', border: 'none',
                background: 'linear-gradient(135deg, #f59e0b, #d97706)', color: 'white',
                fontWeight: 700, fontSize: '0.9rem', cursor: 'pointer', whiteSpace: 'nowrap',
                opacity: createPack.isPending ? 0.7 : 1,
              }}
            >
              {createPack.isPending ? 'جاري التحويل...' : 'شراء الحزمة — 19.90$'}
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section style={{ background: 'var(--color-bg)', padding: '4rem 0' }}>
        <div className="container" style={{ maxWidth: '900px' }}>
          <h2 style={{ textAlign: 'center', fontFamily: 'Sora', fontSize: '1.75rem', fontWeight: 800, color: 'var(--color-ink)', marginBottom: '2rem' }}>مقارنة المميزات</h2>
          <div style={{ background: 'white', borderRadius: 'var(--radius-xl)', overflow: 'hidden', border: '1px solid var(--color-border)' }}>
            {[
              { feature: 'طلبات الأسعار', free: '3 إجمالي', basic: 'غير محدود', pro: 'غير محدود + أولوية' },
              { feature: 'مطابقات المصانع', free: '3 لكل طلب', basic: '3 لكل طلب', pro: '5 لكل طلب + أولوية' },
              { feature: 'المراسلات', free: '-', basic: 'غير محدود', pro: 'غير محدود' },
              { feature: 'جواز المصنع', free: 'عرض أساسي', basic: 'أدلة الثقة الكاملة', pro: 'كامل + مراجعة موثقة' },
              { feature: 'بحث المصانع بالذكاء الاصطناعي', free: '-', basic: 'مُضمن', pro: 'مُضمن (مستوى احترافي)' },
              { feature: 'حماية الطلبات', free: '-', basic: '-', pro: 'وصول تجريبي للضمان' },
              { feature: 'الدعم', free: 'مجتمعي', basic: 'بريد إلكتروني ذو أولوية', pro: 'مدير حساب مخصص' },
            ].map((row, i, arr) => (
              <div key={row.feature} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1fr', borderBottom: i < arr.length - 1 ? '1px solid #e2e8f0' : 'none' }}>
                <div style={{ padding: '0.875rem 1rem', fontWeight: 600, color: 'var(--color-ink)', background: 'var(--color-bg)', fontSize: '0.85rem' }}>{row.feature}</div>
                <div style={{ padding: '0.875rem 1rem', color: 'var(--color-muted)', fontSize: '0.85rem', borderRight: '1px solid #e2e8f0', textAlign: 'center' }}>{row.free}</div>
                <div style={{ padding: '0.875rem 1rem', color: '#7c3aed', fontSize: '0.85rem', fontWeight: 600, borderRight: '1px solid #e2e8f0', textAlign: 'center' }}>{row.basic}</div>
                <div style={{ padding: '0.875rem 1rem', color: '#d97706', fontSize: '0.85rem', fontWeight: 600, borderRight: '1px solid #e2e8f0', textAlign: 'center' }}>{row.pro}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section style={{ padding: '4rem 0', background: 'white' }}>
        <div className="container" style={{ maxWidth: '700px' }}>
          <h2 style={{ textAlign: 'center', fontFamily: 'Sora', fontSize: '1.75rem', fontWeight: 800, color: 'var(--color-ink)', marginBottom: '2rem' }}>الأسئلة الشائعة</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {faqs.map((faq) => (
              <div key={faq.q} style={{ background: 'var(--color-bg)', borderRadius: 'var(--radius-xl)', padding: '1.5rem', border: '1px solid var(--color-border)' }}>
                <div style={{ fontWeight: 700, color: 'var(--color-ink)', marginBottom: '0.5rem', fontSize: '0.95rem' }}>س: {faq.q}</div>
                <div style={{ color: 'var(--color-muted)', fontSize: '0.875rem', lineHeight: 1.7 }}>{faq.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
