import { Link } from 'wouter';
import { XCircle, ShoppingCart, ArrowLeft } from 'lucide-react';

export default function CheckoutCancel() {
  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', display: 'flex', alignItems: 'center', justifyContent: 'center', direction: 'rtl' }}>
      <div style={{ maxWidth: 520, margin: '0 auto', padding: '2rem 1.5rem', textAlign: 'center' }}>
        <div style={{
          background: 'white', borderRadius: '1.25rem', padding: '3rem 2.5rem',
          boxShadow: '0 4px 24px rgba(0,0,0,0.06)',
        }}>
          <div style={{
            width: 80, height: 80, borderRadius: '50%',
            background: 'linear-gradient(135deg, rgba(239,68,68,0.1), rgba(239,68,68,0.05))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 1.5rem',
          }}>
            <XCircle style={{ width: 40, height: 40, color: '#ef4444' }} />
          </div>

          <h1 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
            تم إلغاء الدفع
          </h1>
          <p style={{ color: '#64748b', fontSize: '0.9375rem', lineHeight: 1.7, marginBottom: '2rem' }}>
            لم يتم إتمام الدفع. لم يتم خصم أي مبلغ. عناصر سلة التسوق الخاصة بك لا تزال محفوظة إذا كنت ترغب في المحاولة مرة أخرى.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <Link href="/cart" style={{
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              padding: '0.875rem 2rem', borderRadius: '0.75rem',
              background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white',
              textDecoration: 'none', fontWeight: 700, fontSize: '0.9375rem',
            }}>
              <ShoppingCart style={{ width: 18, height: 18 }} /> العودة إلى السلة
            </Link>
            <Link href="/marketplace" style={{
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              padding: '0.875rem 2rem', borderRadius: '0.75rem',
              border: '1.5px solid #e2e8f0', background: 'white', color: '#0f172a',
              textDecoration: 'none', fontWeight: 600, fontSize: '0.9375rem',
            }}>
              متابعة التسوق <ArrowLeft style={{ width: 16, height: 16 }} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
