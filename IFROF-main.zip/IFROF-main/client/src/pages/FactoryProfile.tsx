/**
 * FactoryProfile - INTERNAL ADMIN PAGE ONLY
 * Buyers are redirected to marketplace. Admins use the Admin Dashboard.
 */
import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Lock, ArrowRight } from "lucide-react";

export default function FactoryProfile() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (user && user.role !== "admin") {
      navigate("/marketplace");
    }
  }, [user, navigate]);

  if (user?.role === "admin") {
    return (
      <div style={{ minHeight: "100vh", background: "#f8fafc", display: "flex", alignItems: "center", justifyContent: "center", paddingTop: "4rem" }}>
        <div style={{ maxWidth: "480px", textAlign: "center", padding: "2rem" }}>
          <h1 style={{ fontFamily: "Sora, sans-serif", fontSize: "1.5rem", fontWeight: 800, color: "#0f172a", marginBottom: "0.75rem" }}>
            Supplier Profiles Moved to Admin Dashboard
          </h1>
          <p style={{ color: "#64748b", lineHeight: 1.7, marginBottom: "2rem" }}>
            All supplier data is now managed under <strong>Admin Dashboard &gt; Suppliers</strong> to keep it confidential from buyers.
          </p>
          <Link href="/admin" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", background: "linear-gradient(135deg, #06b6d4, #0891b2)", color: "white", padding: "0.75rem 1.5rem", borderRadius: "0.75rem", fontWeight: 700, textDecoration: "none" }}>
            Go to Admin Dashboard <ArrowRight style={{ width: 16, height: 16 }} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc", display: "flex", alignItems: "center", justifyContent: "center", paddingTop: "4rem" }}>
      <div style={{ maxWidth: "400px", textAlign: "center", padding: "2rem" }}>
        <div style={{ width: "4rem", height: "4rem", borderRadius: "50%", background: "rgba(239,68,68,0.08)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 1.5rem" }}>
          <Lock style={{ width: 28, height: 28, color: "#ef4444" }} />
        </div>
        <h1 style={{ fontFamily: "Sora, sans-serif", fontSize: "1.5rem", fontWeight: 800, color: "#0f172a", marginBottom: "0.75rem" }}>
          Page Not Available
        </h1>
        <p style={{ color: "#64748b", lineHeight: 1.7, marginBottom: "2rem" }}>
          Supplier information is kept confidential as part of our buyer protection policy.
        </p>
        <Link href="/marketplace" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", background: "linear-gradient(135deg, #06b6d4, #0891b2)", color: "white", padding: "0.75rem 1.5rem", borderRadius: "0.75rem", fontWeight: 700, textDecoration: "none" }}>
          Browse Marketplace <ArrowRight style={{ width: 16, height: 16 }} />
        </Link>
      </div>
    </div>
  );
}
