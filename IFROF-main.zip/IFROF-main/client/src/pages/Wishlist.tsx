import { Link } from 'wouter';
import { trpc } from '@/lib/trpc';
import { Heart, Trash2, ShoppingCart, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

export default function Wishlist() {
  const { data, isLoading, refetch } = trpc.wishlist.getWishlist.useQuery();
  const removeItemMutation = trpc.wishlist.removeItem.useMutation({ onSuccess: () => refetch() });
  const addCartMutation = trpc.cart.addItem.useMutation();
  const { addItem } = useCart();

  const items = data?.items ?? [];

  if (isLoading) {
    return (
      <div style={{ paddingTop: '6rem', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <Heart size={48} style={{ margin: '0 auto 1rem', opacity: 0.4 }} />
          <p>جارٍ تحميل المفضلة...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ paddingTop: '5rem', minHeight: '100vh', background: '#f8fafc', direction: 'rtl' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '2rem 1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '2rem' }}>
          <Heart size={28} style={{ color: '#e53e3e' }} />
          <h1 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#1e293b', margin: 0 }}>المنتجات المحفوظة</h1>
          {items.length > 0 && (
            <span style={{ background: '#e53e3e', color: '#fff', borderRadius: '9999px', padding: '0.15rem 0.6rem', fontSize: '0.85rem', fontWeight: 600 }}>
              {items.length}
            </span>
          )}
        </div>

        {items.length === 0 ? (
          <div style={{ background: '#fff', borderRadius: 16, padding: '4rem 2rem', textAlign: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
            <Heart size={64} style={{ color: '#cbd5e1', margin: '0 auto 1.5rem' }} />
            <h2 style={{ color: '#334155', marginBottom: '0.5rem' }}>لا توجد منتجات محفوظة</h2>
            <p style={{ color: '#64748b', marginBottom: '2rem' }}>اضغط على أيقونة القلب في أي منتج لحفظه هنا.</p>
            <Link href="/marketplace">
              <button style={{ background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 10, padding: '0.75rem 2rem', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
                تصفح السوق
              </button>
            </Link>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.25rem' }}>
            {items.map((row: any) => {
              const wishlistItem = row.wishlistItem;
              const product = row.product;
              const factory = row.factory;
              if (!product) return null;
              const price = product.price / 100;
              const images = (() => { try { return JSON.parse(product.images || '[]'); } catch { return []; } })();
              const img = images[0] || 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=400&h=400&fit=crop';

              return (
                <div key={wishlistItem.id} style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.06)', display: 'flex', flexDirection: 'column' }}>
                  <Link href={`/products/${product.id}`}>
                    <img src={img} alt={product.name} style={{ width: '100%', height: 200, objectFit: 'cover', cursor: 'pointer' }} />
                  </Link>
                  <div style={{ padding: '1rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <Link href={`/products/${product.id}`}>
                      <p style={{ fontWeight: 600, color: '#1e293b', marginBottom: '0.25rem', cursor: 'pointer', fontSize: '0.95rem' }}>{product.name}</p>
                    </Link>
                    {factory && (
                      <Link href={`/factory/${factory.id}`}>
                        <p style={{ fontSize: '0.8rem', color: '#e53e3e', marginBottom: '0.5rem', cursor: 'pointer' }}>{factory.name}</p>
                      </Link>
                    )}
                    <p style={{ fontSize: '1.15rem', fontWeight: 700, color: '#16a34a', marginBottom: '0.75rem' }}>${price.toFixed(2)}</p>

                    <div style={{ display: 'flex', gap: '0.5rem', marginTop: 'auto' }}>
                      <button
                        onClick={() => {
                          addCartMutation.mutate({ productId: product.id, quantity: 1 });
                          addItem({ id: product.id.toString(), productId: product.id.toString(), name: product.name, price, quantity: 1, image: img, seller: factory?.name || 'IFROF', minOrder: product.minOrder || 1 });
                        }}
                        style={{ flex: 1, background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 8, padding: '0.6rem', fontWeight: 600, cursor: 'pointer', fontSize: '0.85rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem' }}
                      >
                        <ShoppingCart size={14} /> أضف للسلة
                      </button>
                      <button
                        onClick={() => removeItemMutation.mutate({ wishlistItemId: wishlistItem.id })}
                        style={{ background: 'none', border: '1px solid #fca5a5', color: '#ef4444', borderRadius: 8, padding: '0.6rem 0.75rem', cursor: 'pointer' }}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {items.length > 0 && (
          <div style={{ marginTop: '2rem', textAlign: 'center' }}>
            <Link href="/marketplace">
              <button style={{ background: 'none', border: '1px solid #e2e8f0', color: '#475569', borderRadius: 10, padding: '0.75rem 2rem', fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                متابعة التسوق <ArrowRight size={16} />
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
