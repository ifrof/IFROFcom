/**
 * Notifications.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function Notifications() {
  return (
    <ComingSoon
      title="الإشعارات"
      description="تابع آخر تحديثات طلباتك وشحناتك — قريباً."
      icon="🔔"
      features={["تنبيهات حالة الطلبات", "إشعارات الشحن والتسليم", "تحديثات عروض الأسعار"]}
      backHref="/"
      primaryCta={{ label: 'تتبع طلباتك', href: '/dashboard' }}
    />
  );
}
