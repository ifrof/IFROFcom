import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import { TrendingUp, ArrowRight, BarChart3, Globe, Zap, Package, Factory, Star } from 'lucide-react';

const TREND_CATEGORIES = [
  {
    icon: Package,
    title: 'أكثر فئات المنتجات طلباً',
    description: 'أكثر فئات المنتجات المطلوبة في سوقنا هذا الربع.',
    items: ['المنسوجات والملابس', 'مستحضرات التجميل والعناية بالبشرة', 'الأغذية والمشروبات', 'مواد البناء', 'إكسسوارات الإلكترونيات'],
    color: '#06b6d4',
  },
  {
    icon: Globe,
    title: 'الأسواق الناشئة',
    description: 'أسرع وجهات التوريد نمواً بناءً على طلب المشترين.',
    items: ['فيتنام', 'المغرب', 'بنغلاديش', 'إندونيسيا', 'مصر'],
    color: '#8b5cf6',
  },
  {
    icon: Factory,
    title: 'اتجاهات التصنيع',
    description: 'ما تستثمر فيه المصانع للبقاء في المنافسة.',
    items: ['التغليف المستدام', 'خدمات العلامة الخاصة', 'مرونة الحد الأدنى للطلب', 'العينات الرقمية', 'شهادات الأيزو'],
    color: '#f59e0b',
  },
  {
    icon: BarChart3,
    title: 'رؤى المشترين',
    description: 'كيف يغيّر المشترون سلوكهم في التوريد.',
    items: ['الدفع بالضمان أولاً', 'عينة قبل الكمية', 'التوريد من مصانع متعددة', 'تغليف جاهز للعلامة التجارية', 'التركيز على البيع المباشر'],
    color: '#10b981',
  },
];

export default function Trends() {
  const { t } = useTranslation();

  return (
    <div style={{ background: '#f8fafc', minHeight: '100vh', direction: 'rtl' }}>
      {/* Header */}
      <section style={{
        padding: '4rem 0 3rem',
        background: 'linear-gradient(150deg, #060d1a 0%, #0c1a2e 40%, #0a1628 100%)',
        color: 'white', textAlign: 'center',
      }}>
        <div className="container" style={{ maxWidth: 760, margin: '0 auto', padding: '0 1.5rem' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(6,182,212,0.15)', border: '1px solid rgba(6,182,212,0.25)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.25rem', fontSize: '0.8125rem', color: '#67e8f9', fontWeight: 600 }}>
            <TrendingUp style={{ width: 14, height: 14 }} /> رؤى الصناعة
          </div>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('nav.trends', 'اتجاهات التوريد')}
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: '1.0625rem', lineHeight: 1.6 }}>
            ابقَ في المقدمة مع أحدث الرؤى حول التوريد العالمي والتصنيع والتجارة.
          </p>
        </div>
      </section>

      {/* Content */}
      <div className="container" style={{ maxWidth: 1000, margin: '0 auto', padding: '2.5rem 1.5rem 4rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(440px, 1fr))', gap: '1.5rem' }}>
          {TREND_CATEGORIES.map((cat) => (
            <div key={cat.title} style={{
              background: 'white', borderRadius: '1rem', padding: '2rem',
              boxShadow: '0 1px 3px rgba(0,0,0,0.06)', border: '1px solid #f1f5f9',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
                <div style={{
                  width: 40, height: 40, borderRadius: '0.625rem',
                  background: `${cat.color}14`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <cat.icon style={{ width: 20, height: 20, color: cat.color }} />
                </div>
                <h2 style={{ fontSize: '1.125rem', fontWeight: 700, color: '#0f172a' }}>{cat.title}</h2>
              </div>
              <p style={{ color: '#64748b', fontSize: '0.875rem', lineHeight: 1.6, marginBottom: '1.25rem' }}>
                {cat.description}
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {cat.items.map((item, i) => (
                  <div key={item} style={{
                    display: 'flex', alignItems: 'center', gap: '0.625rem',
                    padding: '0.5rem 0.75rem', borderRadius: '0.5rem', background: '#f8fafc',
                    fontSize: '0.875rem', color: '#334155',
                  }}>
                    <span style={{ fontWeight: 700, color: cat.color, fontSize: '0.75rem', minWidth: 18 }}>
                      #{i + 1}
                    </span>
                    {item}
                    {i === 0 && <Star style={{ width: 14, height: 14, color: '#f59e0b', marginRight: 'auto' }} />}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div style={{
          marginTop: '3rem', textAlign: 'center',
          background: 'linear-gradient(135deg, #f0fdfa, #ecfeff)', borderRadius: '1rem',
          padding: '2.5rem 2rem', border: '1px solid #ccfbf1',
        }}>
          <Zap style={{ width: 28, height: 28, color: '#0891b2', margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.5rem' }}>
            مستعد للتوريد بذكاء؟
          </h3>
          <p style={{ color: '#64748b', fontSize: '0.9375rem', marginBottom: '1.5rem' }}>
            أرسل طلب عرض سعر ودع فريقنا يجد لك أفضل المصانع.
          </p>
          <Link href="/rfq" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            padding: '0.875rem 2rem', borderRadius: '0.75rem',
            background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white',
            textDecoration: 'none', fontWeight: 700, fontSize: '0.9375rem',
          }}>
            ابدأ الآن <ArrowRight style={{ width: 16, height: 16 }} />
          </Link>
        </div>
      </div>
    </div>
  );
}
