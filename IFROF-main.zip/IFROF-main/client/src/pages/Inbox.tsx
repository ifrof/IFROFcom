/**
 * Inbox.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function Inbox() {
  return (
    <ComingSoon
      title="صندوق الرسائل"
      description="تواصل مباشر مع الموردين والمصانع الصينية — قريباً."
      icon="📬"
      features={["رسائل مباشرة مع الموردين", "ترجمة فورية للعربية والصينية", "مشاركة الملفات والوثائق"]}
      backHref="/"
      primaryCta={{ label: 'تواصل عبر الكونسيرج', href: '/services/concierge' }}
    />
  );
}
