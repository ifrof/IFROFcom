/**
 * Checkout.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function Checkout() {
  return (
    <ComingSoon
      title="إتمام الطلب"
      description="إتمام عملية الشراء بأمان — قريباً."
      icon="💳"
      features={[]}
      backHref="/cart"
    />
  );
}
