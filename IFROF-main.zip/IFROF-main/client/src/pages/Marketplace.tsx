import { useState, useMemo } from 'react';
import { Search, Package, Zap, TrendingDown, Grid3X3, List } from 'lucide-react';
import { SEO } from '@/components/SEO';
import { useCart } from '../contexts/CartContext';
import { trpc } from '@/lib/trpc';
import { ProductCard, QuickViewModal, type ProductCardData } from '../components/ProductCard';

interface Product {
  id: number;
  name: string;
  factory: string;
  factoryId?: number;
  location: string;
  price: number;
  originalPrice?: number;
  minOrder: number;
  unit: string;
  category: string;
  rating: number;
  reviews: number;
  image: string;
  isStock: boolean;
  discount?: number;
  badge?: string;
  stock: number;
  tags: string[];
}

// Mock data removed - now using tRPC API

export default function Marketplace() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [showStockOnly, setShowStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState('relevance');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [quickViewProduct, setQuickViewProduct] = useState<ProductCardData | null>(null);
  const { addItem } = useCart();

  // Fetch products from database
  const { data: productsData, isLoading: productsLoading } = trpc.products.list.useQuery({limit: 50});


  // Fetch categories from database
  const { data: categoriesData } = trpc.categories.list.useQuery();

  // Transform database products to match UI interface
  const allProducts: Product[] = useMemo(() => {
    if (!productsData) return [];
    return productsData.map(p => ({
      id: p.id,
      name: p.name,
      factory: p.factory?.name || 'مورد IFROF موثق',
      factoryId: p.factory?.id ?? undefined,
      location: 'الصين',
      price: p.price / 100, // Convert cents to dollars
      originalPrice: p.originalPrice ? p.originalPrice / 100 : undefined,
      minOrder: p.minOrder || 1,
      unit: p.unit || 'قطعة',
      category: p.category?.name || 'غير مصنف',
      rating: p.rating ? p.rating / 10 : 0, // Convert 0-100 to 0-10
      reviews: p.reviewCount || 0,
      image: p.images[0] || 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=400&h=400&fit=crop',
      isStock: (p.stockQuantity || 0) > 0,
      discount: p.originalPrice ? Math.round((1 - p.price / p.originalPrice) * 100) : undefined,
      badge: p.featured && p.featured !== 'none' ? p.featured.replace('_', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : undefined,
      stock: p.stockQuantity || 0,
      tags: p.tags,
    }));
  }, [productsData]);

  const CATEGORIES = useMemo(() => {
    if (!categoriesData) return ['الكل'];
    return ['الكل', ...categoriesData.map(c => c.name)];
  }, [categoriesData]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    let result = allProducts.filter(p => {
      if (selectedCategory !== 'الكل' && p.category !== selectedCategory) return false;
      if (showStockOnly && !p.isStock) return false;
      if (q && !p.name.toLowerCase().includes(q) && !p.factory.toLowerCase().includes(q) && !p.category.toLowerCase().includes(q) && !p.tags.some(t => t.toLowerCase().includes(q))) return false;
      return true;
    });
    switch (sortBy) {
      case 'price-low': result.sort((a, b) => a.price - b.price); break;
      case 'price-high': result.sort((a, b) => b.price - a.price); break;
      case 'rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'reviews': result.sort((a, b) => b.reviews - a.reviews); break;
    }
    return result;
  }, [allProducts, selectedCategory, showStockOnly, sortBy, searchQuery]);

  const toggleWishlist = (id: number) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleAddToCart = (product: Product) => {
    addItem({ id: product.id.toString(), productId: product.id.toString(), name: product.name, price: product.price, quantity: product.minOrder, image: product.image, seller: product.factory, minOrder: product.minOrder });
  };

  return (
    <div style={{ paddingTop: '5rem', direction: 'rtl' }}>
      <SEO
        title="السوق — منتجات مصانع صينية موثقة"
        description="تصفح آلاف المنتجات من مصانع صينية موثقة. أسعار شفافة، حد أدنى للطلب، وحماية الدفع عبر الضمان. استورد بثقة مع IFROF."
        keywords="سوق الاستيراد, منتجات صينية, مصانع موثقة, استيراد بالجملة, IFROF marketplace"
        url="https://ifrof.com/marketplace"
      />
      {/* Hero */}
      <section style={{ background: 'linear-gradient(135deg, #0a1628 0%, #0f2847 50%, #0a1628 100%)', padding: '4rem 0 3rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 70% 50%, rgba(245,158,11,0.1) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '700px' }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.375rem 1rem', borderRadius: '2rem', background: 'rgba(245,158,11,0.15)', color: '#fbbf24', fontSize: '0.8125rem', fontWeight: 600, marginBottom: '1.5rem', border: '1px solid rgba(245,158,11,0.25)' }}>
              <Zap style={{ width: 16, height: 16 }} /> أسعار IFROF الموثقة
            </div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, color: 'white', lineHeight: 1.15, marginBottom: '1rem' }}>
              السوق <span className="gradient-text-warm">العالمي</span>
            </h1>
            <p style={{ color: 'var(--color-subtle)', fontSize: '1.0625rem', lineHeight: 1.7, marginBottom: '2rem' }}>
              استورد المنتجات مباشرة من المصانع الصينية الموثقة. صفقات تصفية مخزون حتى 50% خصم مع شحن فوري.
            </p>

            {/* Search */}
            <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '0.375rem', display: 'flex', gap: '0.375rem', border: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0 1rem' }}>
                <Search style={{ width: 20, height: 20, color: 'var(--color-muted)', flexShrink: 0 }} />
                <input type="text" placeholder="البحث عن منتجات..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'white', fontSize: '0.9375rem', fontFamily: 'var(--font-body)' }} />
              </div>
              <button className="btn-amber" style={{ borderRadius: 'var(--radius-lg)' }}>بحث</button>
            </div>

            {/* Stats */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem', marginTop: '1.5rem' }}>
              {/* Stats will be populated from real data */}
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section style={{ background: 'var(--color-bg)', padding: '2rem 0 4rem' }}>
        <div className="container">
          {/* Filter Bar */}
          <div style={{ background: 'white', borderRadius: 'var(--radius-xl)', padding: '1rem 1.5rem', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '0.75rem', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
              {CATEGORIES.map(cat => (
                <button key={cat} onClick={() => setSelectedCategory(cat)} style={{ padding: '0.375rem 0.875rem', borderRadius: '2rem', fontSize: '0.8125rem', fontWeight: 500, border: 'none', cursor: 'pointer', transition: 'all 200ms', background: selectedCategory === cat ? '#f59e0b' : '#f1f5f9', color: selectedCategory === cat ? '#0f172a' : '#475569' }}>
                  {cat}
                </button>
              ))}
            </div>
            <div style={{ flex: 1 }} />
            <button onClick={() => setShowStockOnly(!showStockOnly)} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.375rem 0.875rem', borderRadius: '2rem', fontSize: '0.8125rem', fontWeight: 600, border: 'none', cursor: 'pointer', background: showStockOnly ? '#fef3c7' : '#f1f5f9', color: showStockOnly ? '#92400e' : '#475569' }}>
              <TrendingDown style={{ width: 14, height: 14 }} /> صفقات المخزون
            </button>
            <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: '0.375rem 0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', fontSize: '0.8125rem', color: '#475569', background: 'white', cursor: 'pointer' }}>
              <option value="relevance">ترتيب: الأنسب</option>
              <option value="price-low">السعر: من الأقل للأعلى</option>
              <option value="price-high">السعر: من الأعلى للأقل</option>
              <option value="rating">الأعلى تقييماً</option>
              <option value="reviews">الأكثر مبيعاً</option>
            </select>
            <div style={{ display: 'flex', gap: '0.25rem', background: 'var(--color-bg-2)', borderRadius: 'var(--radius-md)', padding: '0.125rem' }}>
              <button onClick={() => setViewMode('grid')} style={{ padding: '0.375rem', borderRadius: '0.375rem', border: 'none', cursor: 'pointer', background: viewMode === 'grid' ? 'white' : 'transparent', color: viewMode === 'grid' ? '#0f172a' : '#94a3b8', boxShadow: viewMode === 'grid' ? '0 1px 2px rgba(0,0,0,0.1)' : 'none' }}>
                <Grid3X3 style={{ width: 16, height: 16 }} />
              </button>
              <button onClick={() => setViewMode('list')} style={{ padding: '0.375rem', borderRadius: '0.375rem', border: 'none', cursor: 'pointer', background: viewMode === 'list' ? 'white' : 'transparent', color: viewMode === 'list' ? '#0f172a' : '#94a3b8', boxShadow: viewMode === 'list' ? '0 1px 2px rgba(0,0,0,0.1)' : 'none' }}>
                <List style={{ width: 16, height: 16 }} />
              </button>
            </div>
          </div>

          {/* Stock Deals Banner */}
          {showStockOnly && (
            <div style={{ background: 'linear-gradient(135deg, #fffbeb, #fef3c7)', border: '1px solid #fde68a', borderRadius: 'var(--radius-lg)', padding: '0.75rem 1rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <TrendingDown style={{ width: 18, height: 18, color: '#d97706' }} />
              <p style={{ color: '#92400e', fontWeight: 600, fontSize: '0.875rem' }}>عرض عناصر تصفية المخزون - خصم يصل إلى 50%! كميات محدودة.</p>
            </div>
          )}

          {/* Results Count */}
          <p style={{ color: 'var(--color-muted)', fontSize: '0.9375rem', marginBottom: '1rem' }}>
            <strong style={{ color: 'var(--color-ink)' }}>{filteredProducts.length}</strong> منتج تم العثور عليه
          </p>

          {/* Product Grid */}
          {viewMode === 'grid' ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1.25rem' }}>
              {filteredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  viewMode="grid"
                  isWishlisted={wishlist.includes(product.id)}
                  onWishlistToggle={toggleWishlist}
                  onAddToCart={handleAddToCart}
                  onQuickView={setQuickViewProduct}
                />
              ))}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
              {filteredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  viewMode="list"
                  isWishlisted={wishlist.includes(product.id)}
                  onWishlistToggle={toggleWishlist}
                  onAddToCart={handleAddToCart}
                  onQuickView={setQuickViewProduct}
                />
              ))}
            </div>
          )}
          {filteredProducts.length === 0 && (
            <div style={{ textAlign: 'center', padding: '4rem 0' }}>
              <Package style={{ width: 48, height: 48, margin: '0 auto 1rem', color: '#cbd5e1' }} />
              <h3 style={{ color: 'var(--color-muted)', fontSize: '1.125rem', marginBottom: '0.5rem', fontFamily: 'var(--font-display)' }}>لم يتم العثور على منتجات</h3>
              <p style={{ color: 'var(--color-subtle)' }}>حاول تعديل البحث أو الفلاتر</p>
            </div>
          )}

          {/* Load More */}
          <div style={{ textAlign: 'center', marginTop: '3rem' }}>
            <button className="btn-outline" style={{ padding: '0.75rem 2rem' }}>تحميل المزيد من المنتجات</button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: 'linear-gradient(135deg, #0f172a, #1e293b)', padding: '4rem 0', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 50%, rgba(6,182,212,0.1) 0%, transparent 60%)' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: 'white', marginBottom: '1rem' }}>
            لم تجد ما تبحث عنه؟
          </h2>
          <p style={{ color: 'var(--color-subtle)', fontSize: '1.0625rem', maxWidth: '500px', margin: '0 auto 2rem' }}>
            أرسل طلب توريد وسيجد فريقنا أفضل مورد لك خلال 24 ساعة.
          </p>
          <a href="/rfq" className="btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', fontSize: '1rem', fontWeight: 700 }}>
            إرسال طلب توريد
          </a>
        </div>
      </section>

      {/* Quick View Modal */}
      {quickViewProduct && (
        <QuickViewModal
          product={quickViewProduct}
          isWishlisted={wishlist.includes(quickViewProduct.id)}
          onWishlistToggle={toggleWishlist}
          onAddToCart={handleAddToCart}
          onClose={() => setQuickViewProduct(null)}
        />
      )}
    </div>
  );
}
