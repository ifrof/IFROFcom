/**
 * Admin Offers Management Page
 * Create, edit, publish, pin, and delete offer posts for the social feed.
 */
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import {
  Plus, Edit2, Trash2, Eye, EyeOff, Pin, PinOff,
  Tag, Star, Megaphone, Lightbulb, Calendar, TrendingUp,
  ThumbsUp, MessageCircle, Share2, CheckCircle, Clock,
  AlertCircle, Save, X, Image, Link,
} from 'lucide-react';

type OfferType = 'deal' | 'new_product' | 'announcement' | 'tip' | 'event';
type OfferStatus = 'draft' | 'published' | 'archived';

interface OfferFormData {
  title: string;
  content: string;
  imageUrl: string;
  linkUrl: string;
  linkLabel: string;
  tags: string;
  offerType: OfferType;
  discountPercent: string;
  originalPrice: string;
  salePrice: string;
  validUntil: string;
  status: OfferStatus;
  pinned: boolean;
}

const OFFER_TYPE_OPTIONS: Array<{ value: OfferType; label: string; icon: React.ElementType; color: string }> = [
  { value: 'deal',         label: 'Deal',         icon: Tag,       color: '#16a34a' },
  { value: 'new_product',  label: 'New Product',  icon: Star,      color: '#7c3aed' },
  { value: 'announcement', label: 'Announcement', icon: Megaphone, color: '#0891b2' },
  { value: 'tip',          label: 'Tip',          icon: Lightbulb, color: '#d97706' },
  { value: 'event',        label: 'Event',        icon: Calendar,  color: '#db2777' },
];

const EMPTY_FORM: OfferFormData = {
  title: '',
  content: '',
  imageUrl: '',
  linkUrl: '',
  linkLabel: '',
  tags: '',
  offerType: 'deal',
  discountPercent: '',
  originalPrice: '',
  salePrice: '',
  validUntil: '',
  status: 'draft',
  pinned: false,
};

function StatusBadge({ status }: { status: OfferStatus }) {
  const config = {
    published: { color: '#16a34a', bg: '#dcfce7', icon: CheckCircle, label: 'Published' },
    draft:     { color: '#d97706', bg: '#fef3c7', icon: Clock,        label: 'Draft' },
    archived:  { color: '#64748b', bg: '#f1f5f9', icon: EyeOff,       label: 'Archived' },
  }[status];
  const Icon = config.icon;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: '0.25rem',
      padding: '0.2rem 0.625rem', borderRadius: '1rem',
      background: config.bg, color: config.color,
      fontSize: '0.75rem', fontWeight: 700,
    }}>
      <Icon style={{ width: 10, height: 10 }} />
      {config.label}
    </span>
  );
}

export default function AdminOffers() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<OfferFormData>(EMPTY_FORM);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const utils = trpc.useUtils();
  const { data: offers, isLoading } = trpc.offers.adminList.useQuery({});

  const createOffer = trpc.offers.create.useMutation({
    onSuccess: () => {
      setSuccess('Offer created successfully!');
      setShowForm(false);
      setForm(EMPTY_FORM);
      utils.offers.adminList.invalidate();
      utils.offers.list.invalidate();
    },
    onError: (err) => setError(err.message),
  });

  const updateOffer = trpc.offers.update.useMutation({
    onSuccess: () => {
      setSuccess('Offer updated!');
      setShowForm(false);
      setEditingId(null);
      setForm(EMPTY_FORM);
      utils.offers.adminList.invalidate();
      utils.offers.list.invalidate();
    },
    onError: (err) => setError(err.message),
  });

  const deleteOffer = trpc.offers.delete.useMutation({
    onSuccess: () => {
      setSuccess('Offer deleted.');
      utils.offers.adminList.invalidate();
      utils.offers.list.invalidate();
    },
    onError: (err) => setError(err.message),
  });

  const handleEdit = (offer: NonNullable<typeof offers>[number]) => {
    setEditingId(offer.id);
    setForm({
      title: offer.title,
      content: offer.content,
      imageUrl: offer.imageUrl ?? '',
      linkUrl: offer.linkUrl ?? '',
      linkLabel: offer.linkLabel ?? '',
      tags: Array.isArray(offer.tags) ? offer.tags.join(', ') : '',
      offerType: offer.offerType as OfferType,
      discountPercent: offer.discountPercent ? String(offer.discountPercent) : '',
      originalPrice: offer.originalPrice ? String(offer.originalPrice / 100) : '',
      salePrice: offer.salePrice ? String(offer.salePrice / 100) : '',
      validUntil: offer.validUntil ? new Date(offer.validUntil).toISOString().slice(0, 16) : '',
      status: (offer.status ?? "draft") as OfferStatus,
      pinned: offer.pinned,
    });
    setShowForm(true);
    setError('');
  };

  const handleSubmit = () => {
    setError('');
    if (!form.title.trim() || !form.content.trim()) {
      setError('Title and content are required.');
      return;
    }

    const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean);
    const discountPercent = form.discountPercent ? parseInt(form.discountPercent) : undefined;
    const originalPrice = form.originalPrice ? Math.round(parseFloat(form.originalPrice) * 100) : undefined;
    const salePrice = form.salePrice ? Math.round(parseFloat(form.salePrice) * 100) : undefined;
    const validUntil = form.validUntil ? new Date(form.validUntil).toISOString() : undefined;

    if (editingId) {
      updateOffer.mutate({
        id: editingId,
        title: form.title,
        content: form.content,
        imageUrl: form.imageUrl || null,
        linkUrl: form.linkUrl || null,
        linkLabel: form.linkLabel || null,
        tags,
        offerType: form.offerType,
        discountPercent: discountPercent ?? null,
        originalPrice: originalPrice ?? null,
        salePrice: salePrice ?? null,
        validUntil: validUntil ?? null,
        status: form.status,
        pinned: form.pinned,
      });
    } else {
      createOffer.mutate({
        title: form.title,
        content: form.content,
        imageUrl: form.imageUrl || undefined,
        linkUrl: form.linkUrl || undefined,
        linkLabel: form.linkLabel || undefined,
        tags,
        offerType: form.offerType,
        discountPercent,
        originalPrice,
        salePrice,
        validUntil,
        status: (form.status === 'archived' ? 'draft' : form.status) as 'draft' | 'published',
        pinned: form.pinned,
      });
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingId(null);
    setForm(EMPTY_FORM);
    setError('');
  };

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.625rem 0.875rem',
    border: '1.5px solid #e2e8f0', borderRadius: '0.625rem',
    fontSize: '0.9375rem', outline: 'none',
    fontFamily: 'DM Sans, sans-serif', boxSizing: 'border-box',
    transition: 'border-color 150ms',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block', fontSize: '0.8125rem', fontWeight: 700,
    color: '#374151', marginBottom: '0.375rem',
    fontFamily: 'DM Sans, sans-serif',
  };

  return (
    <div style={{ background: '#f8fafc', minHeight: '100vh', padding: '2rem 1rem' }}>
      <div className="container" style={{ maxWidth: 900 }}>

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
          <div>
            <h1 style={{ fontFamily: 'Sora, sans-serif', fontWeight: 800, fontSize: '1.5rem', color: '#0f172a', margin: 0 }}>
              Offers Management
            </h1>
            <p style={{ color: '#64748b', fontSize: '0.9375rem', margin: '0.25rem 0 0' }}>
              Publish daily deals and announcements to the social feed
            </p>
          </div>
          <button
            onClick={() => { setShowForm(true); setEditingId(null); setForm(EMPTY_FORM); setError(''); }}
            style={{
              display: 'flex', alignItems: 'center', gap: '0.5rem',
              padding: '0.625rem 1.25rem', borderRadius: '0.75rem',
              background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
              color: 'white', fontWeight: 700, fontSize: '0.9375rem',
              border: 'none', cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(6,182,212,0.3)',
            }}
          >
            <Plus style={{ width: 18, height: 18 }} />
            New Offer
          </button>
        </div>

        {/* Alerts */}
        {success && (
          <div style={{
            background: '#dcfce7', border: '1px solid #86efac', borderRadius: '0.75rem',
            padding: '0.75rem 1rem', marginBottom: '1rem',
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            color: '#16a34a', fontWeight: 600, fontSize: '0.875rem',
          }}>
            <CheckCircle style={{ width: 16, height: 16 }} />
            {success}
            <button onClick={() => setSuccess('')} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: '#16a34a' }}>
              <X style={{ width: 14, height: 14 }} />
            </button>
          </div>
        )}

        {error && (
          <div style={{
            background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: '0.75rem',
            padding: '0.75rem 1rem', marginBottom: '1rem',
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            color: '#dc2626', fontWeight: 600, fontSize: '0.875rem',
          }}>
            <AlertCircle style={{ width: 16, height: 16 }} />
            {error}
          </div>
        )}

        {/* Create / Edit Form */}
        {showForm && (
          <div style={{
            background: 'white', borderRadius: '1rem',
            border: '1px solid #e2e8f0',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            padding: '1.5rem', marginBottom: '1.5rem',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
              <h2 style={{ fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '1.125rem', color: '#0f172a', margin: 0 }}>
                {editingId ? 'Edit Offer' : 'Create New Offer'}
              </h2>
              <button onClick={handleCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8' }}>
                <X style={{ width: 20, height: 20 }} />
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              {/* Title */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={labelStyle}>Title *</label>
                <input
                  value={form.title}
                  onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                  placeholder="e.g. 30% Off All Electronics This Week!"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Content */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={labelStyle}>Content *</label>
                <textarea
                  value={form.content}
                  onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                  placeholder="Write your offer details here…"
                  rows={4}
                  style={{ ...inputStyle, resize: 'vertical' }}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Type */}
              <div>
                <label style={labelStyle}>Offer Type</label>
                <select
                  value={form.offerType}
                  onChange={e => setForm(f => ({ ...f, offerType: e.target.value as OfferType }))}
                  style={inputStyle}
                >
                  {OFFER_TYPE_OPTIONS.map(o => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
              </div>

              {/* Status */}
              <div>
                <label style={labelStyle}>Status</label>
                <select
                  value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value as OfferStatus }))}
                  style={inputStyle}
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              {/* Discount */}
              <div>
                <label style={labelStyle}>Discount % (optional)</label>
                <input
                  type="number"
                  min="0" max="100"
                  value={form.discountPercent}
                  onChange={e => setForm(f => ({ ...f, discountPercent: e.target.value }))}
                  placeholder="e.g. 30"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Valid Until */}
              <div>
                <label style={labelStyle}>Valid Until (optional)</label>
                <input
                  type="datetime-local"
                  value={form.validUntil}
                  onChange={e => setForm(f => ({ ...f, validUntil: e.target.value }))}
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Original Price */}
              <div>
                <label style={labelStyle}>Original Price USD (optional)</label>
                <input
                  type="number" min="0" step="0.01"
                  value={form.originalPrice}
                  onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))}
                  placeholder="e.g. 99.99"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Sale Price */}
              <div>
                <label style={labelStyle}>Sale Price USD (optional)</label>
                <input
                  type="number" min="0" step="0.01"
                  value={form.salePrice}
                  onChange={e => setForm(f => ({ ...f, salePrice: e.target.value }))}
                  placeholder="e.g. 69.99"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Image URL */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={labelStyle}>
                  <Image style={{ width: 13, height: 13, display: 'inline', marginRight: 4 }} />
                  Image URL (optional)
                </label>
                <input
                  value={form.imageUrl}
                  onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))}
                  placeholder="https://example.com/image.jpg"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Link URL */}
              <div>
                <label style={labelStyle}>
                  <Link style={{ width: 13, height: 13, display: 'inline', marginRight: 4 }} />
                  CTA Link URL (optional)
                </label>
                <input
                  value={form.linkUrl}
                  onChange={e => setForm(f => ({ ...f, linkUrl: e.target.value }))}
                  placeholder="https://ifrof.com/marketplace"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Link Label */}
              <div>
                <label style={labelStyle}>CTA Button Label</label>
                <input
                  value={form.linkLabel}
                  onChange={e => setForm(f => ({ ...f, linkLabel: e.target.value }))}
                  placeholder="Shop Now"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Tags */}
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={labelStyle}>Tags (comma-separated)</label>
                <input
                  value={form.tags}
                  onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                  placeholder="electronics, sale, summer"
                  style={inputStyle}
                  onFocus={e => { e.target.style.borderColor = '#06b6d4'; }}
                  onBlur={e => { e.target.style.borderColor = '#e2e8f0'; }}
                />
              </div>

              {/* Pinned toggle */}
              <div style={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={form.pinned}
                    onChange={e => setForm(f => ({ ...f, pinned: e.target.checked }))}
                    style={{ width: 16, height: 16, cursor: 'pointer' }}
                  />
                  <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#374151' }}>
                    <Pin style={{ width: 13, height: 13, display: 'inline', marginRight: 4 }} />
                    Pin this offer to the top of the feed
                  </span>
                </label>
              </div>
            </div>

            {/* Submit */}
            <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.25rem', justifyContent: 'flex-end' }}>
              <button
                onClick={handleCancel}
                style={{
                  padding: '0.625rem 1.25rem', borderRadius: '0.625rem',
                  border: '1.5px solid #e2e8f0', background: 'white',
                  color: '#64748b', fontWeight: 600, cursor: 'pointer',
                  fontSize: '0.9375rem',
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                disabled={createOffer.isPending || updateOffer.isPending}
                style={{
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  padding: '0.625rem 1.5rem', borderRadius: '0.625rem',
                  background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
                  color: 'white', fontWeight: 700, cursor: 'pointer',
                  border: 'none', fontSize: '0.9375rem',
                  opacity: (createOffer.isPending || updateOffer.isPending) ? 0.7 : 1,
                }}
              >
                <Save style={{ width: 16, height: 16 }} />
                {editingId ? 'Save Changes' : (form.status === 'published' ? 'Publish Now' : 'Save Draft')}
              </button>
            </div>
          </div>
        )}

        {/* Offers Table */}
        <div style={{
          background: 'white', borderRadius: '1rem',
          border: '1px solid #e2e8f0',
          overflow: 'hidden',
        }}>
          <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '1rem', color: '#0f172a', margin: 0 }}>
              All Offers ({offers?.length ?? 0})
            </h2>
          </div>

          {isLoading ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: '#94a3b8' }}>Loading…</div>
          ) : !offers || offers.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: '#94a3b8' }}>
              No offers yet. Create your first one!
            </div>
          ) : (
            <div>
              {offers.map((offer, idx) => {
                const typeConfig = OFFER_TYPE_OPTIONS.find(o => o.value === offer.offerType);
                const TypeIcon = typeConfig?.icon ?? Tag;
                return (
                  <div
                    key={offer.id}
                    style={{
                      padding: '1rem 1.25rem',
                      borderBottom: idx < offers.length - 1 ? '1px solid #f1f5f9' : 'none',
                      display: 'flex', alignItems: 'flex-start', gap: '1rem',
                    }}
                  >
                    {/* Type icon */}
                    <div style={{
                      width: 40, height: 40, borderRadius: '0.625rem',
                      background: '#f8fafc', border: '1px solid #e2e8f0',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, color: typeConfig?.color ?? '#64748b',
                    }}>
                      <TypeIcon style={{ width: 18, height: 18 }} />
                    </div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                        <span style={{
                          fontWeight: 700, fontSize: '0.9375rem', color: '#0f172a',
                          fontFamily: 'DM Sans, sans-serif',
                          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}>
                          {offer.title}
                        </span>
                        {offer.pinned && (
                          <Pin style={{ width: 13, height: 13, color: '#0891b2', flexShrink: 0 }} />
                        )}
                        <StatusBadge status={offer.status as OfferStatus} />
                      </div>
                      <p style={{
                        fontSize: '0.8125rem', color: '#64748b', margin: '0.25rem 0',
                        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }}>
                        {offer.content.slice(0, 100)}{offer.content.length > 100 ? '…' : ''}
                      </p>
                      <div style={{ display: 'flex', gap: '1rem', fontSize: '0.75rem', color: '#94a3b8' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                          <ThumbsUp style={{ width: 11, height: 11 }} />
                          {offer.likesCount}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                          <MessageCircle style={{ width: 11, height: 11 }} />
                          {offer.commentsCount}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                          <Share2 style={{ width: 11, height: 11 }} />
                          {offer.sharesCount}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                          <Eye style={{ width: 11, height: 11 }} />
                          {offer.viewsCount}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
                      <button
                        onClick={() => handleEdit(offer as Parameters<typeof handleEdit>[0])}
                        title="Edit"
                        style={{
                          width: 34, height: 34, borderRadius: '0.5rem',
                          border: '1.5px solid #e2e8f0', background: 'white',
                          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                          color: '#64748b',
                        }}
                      >
                        <Edit2 style={{ width: 14, height: 14 }} />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm('Delete this offer?')) {
                            deleteOffer.mutate({ id: offer.id });
                          }
                        }}
                        title="Delete"
                        style={{
                          width: 34, height: 34, borderRadius: '0.5rem',
                          border: '1.5px solid #fee2e2', background: '#fff5f5',
                          cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                          color: '#ef4444',
                        }}
                      >
                        <Trash2 style={{ width: 14, height: 14 }} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
