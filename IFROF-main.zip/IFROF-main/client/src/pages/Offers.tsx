/**
 * Offers.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function Offers() {
  return (
    <ComingSoon
      title="العروض الحصرية"
      description="عروض وصفقات حصرية من أفضل المصانع الصينية — قريباً."
      icon="🏷️"
      features={["عروض محدودة الوقت", "خصومات على الكميات الكبيرة", "صفقات حصرية للأعضاء"]}
      backHref="/"
      primaryCta={{ label: 'تصفح السوق', href: '/marketplace' }}
    />
  );
}
