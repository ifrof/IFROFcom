import React, { useState } from 'react';
import { SEO } from '@/components/SEO';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import {
  Palette, CheckCircle, ArrowRight, Package, Globe, Shield,
  Truck, Star, FileText, Layers, ChevronDown, ChevronUp, MessageCircle,
  MessageSquare,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function ServiceBrandLaunch() {
  const { t } = useTranslation();
  const [form, setForm] = useState({ name: '', email: '', brandName: '', productCategory: '', budget: '', timeline: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<'starter' | 'full'>('full');

  const submitInquiry = trpc.services.submitInquiry.useMutation({
    onSuccess: () => { setSubmitted(true); toast.success('Brand launch inquiry received! We will send you a detailed proposal within 48 hours.'); },
    onError: () => toast.error('Something went wrong. Please try again or use the secure chat for assistance.'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry.mutate({ serviceType: 'brand_launch', ...form });
  };

  const packages = [
    {
      key: 'starter' as const,
      name: 'Starter Brand',
      price: '$15,000',
      priceNote: 'Fixed Package',
      color: '#8b5cf6',
      gradient: 'linear-gradient(135deg, #8b5cf6, #7c3aed)',
      features: [
        'Trademark registration (1 country)',
        'Product manufacturing (1 SKU)',
        'Basic packaging design',
        'Sea freight shipping',
        'Quality control inspection',
        'Shipping documents',
      ],
    },
    {
      key: 'full' as const,
      name: 'Full Brand Launch',
      price: '$25,000',
      priceNote: 'Fixed Package',
      color: '#f59e0b',
      gradient: 'linear-gradient(135deg, #f59e0b, #d97706)',
      popular: true,
      features: [
        'Trademark registration (3 countries)',
        'Product manufacturing (up to 3 SKUs)',
        'Premium packaging design + mockups',
        'Air or sea freight (your choice)',
        'Full quality control & lab testing',
        'All shipping & customs documents',
        'Amazon/Shopify listing optimization',
        'Dedicated brand manager',
      ],
    },
  ];

  const timeline = [
    { week: 'Week 1–2', title: 'Discovery & Strategy', desc: 'Brand brief, trademark search, factory shortlisting, and packaging concept approval.' },
    { week: 'Week 3–4', title: 'Trademark & Manufacturing', desc: 'Trademark filing initiated. Factory confirmed. Production begins.' },
    { week: 'Week 5–8', title: 'Production & QC', desc: 'Manufacturing in progress. Quality control inspection at factory. Sample approval.' },
    { week: 'Week 9–12', title: 'Shipping & Delivery', desc: 'Goods shipped with full documentation. Customs clearance. Delivery to your warehouse.' },
  ];

  const faqs = [
    { q: 'What is included in the fixed package price?', a: 'Everything listed in the package — trademark, manufacturing, packaging, shipping, and QC. There are no hidden fees. If your order requires additional SKUs or countries, we provide a custom quote.' },
    { q: 'Do I own the trademark?', a: 'Yes, 100%. The trademark is registered in your name. We handle the paperwork and filing, but you are the legal owner.' },
    { q: 'Can I choose my own factory?', a: 'Yes. If you already have a factory relationship, we can manage the process with them. Alternatively, we source a verified factory from our network at no additional cost.' },
    { q: 'What product categories do you support?', a: 'Consumer electronics, apparel & accessories, beauty & personal care, home goods, sports & outdoor, and food packaging. Contact us if your category is not listed.' },
    { q: 'What happens if there is a quality issue?', a: 'Our QC inspection and lab testing are designed to catch issues before shipment. If a defect passes through, we work with the factory to resolve it at no additional cost to you.' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#0f172a', color: '#f8fafc' }}>
      <SEO
        title="Brand Launch — Private Label Manufacturing from China"
        description="Launch your own brand with private label manufacturing from verified Chinese factories. Custom packaging, quality control, and full logistics handled by IFROF."
        keywords="private label China, brand launch manufacturing, OEM ODM China, custom product sourcing, IFROF brand"
        url="https://ifrof.com/services/brand-launch"
      />
      {/* Hero */}
      <section style={{ padding: '6rem 1.5rem 4rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 0%, rgba(245,158,11,0.15), transparent 65%)' }} />
        <div style={{ maxWidth: '820px', margin: '0 auto', position: 'relative' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.3)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.5rem', fontSize: '0.875rem', color: '#fbbf24', fontWeight: 600 }}>
            <Palette size={14} /> Brand Launch Service
          </div>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, lineHeight: 1.15, marginBottom: '1.5rem', letterSpacing: '-0.03em' }}>
            From Idea to Shelf.<br />
            <span style={{ background: 'linear-gradient(135deg, #f59e0b, #ef4444)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Trademark. Manufacture. Ship.
            </span>
          </h1>
          <p style={{ fontSize: '1.125rem', color: 'var(--color-subtle)', lineHeight: 1.7, marginBottom: '2.5rem', maxWidth: '620px', margin: '0 auto 2.5rem' }}>
            We handle everything from trademark registration to factory production, premium packaging, and international shipping. Fixed price. No surprises.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link
              href="/rfq"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'linear-gradient(135deg, #f59e0b, #d97706)', color: '#fff', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', textDecoration: 'none', boxShadow: '0 4px 20px rgba(245,158,11,0.3)' }}
            >
              <MessageSquare size={18} /> Start Secure Sourcing
            </Link>
            <a href="#packages" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.15)', color: '#f8fafc', borderRadius: 'var(--radius-lg)', fontWeight: 600, fontSize: '1rem', textDecoration: 'none' }}>
              View Packages <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </section>

      {/* What's Included Icons */}
      <section style={{ padding: '4rem 1.5rem', maxWidth: '900px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>Everything Included. One Fixed Price.</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1.25rem' }}>
          {[
            { icon: FileText, label: 'Trademark Registration', color: '#8b5cf6' },
            { icon: Layers, label: 'Product Manufacturing', color: '#06b6d4' },
            { icon: Package, label: 'Premium Packaging', color: '#f59e0b' },
            { icon: Shield, label: 'Quality Control & Lab Tests', color: '#10b981' },
            { icon: Truck, label: 'International Shipping', color: '#ef4444' },
            { icon: Globe, label: 'Customs Clearance Docs', color: '#6366f1' },
          ].map((item) => (
            <div key={item.label} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.5rem', textAlign: 'center' }}>
              <div style={{ width: '2.75rem', height: '2.75rem', borderRadius: '0.875rem', background: `${item.color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 0.875rem' }}>
                <item.icon size={20} color={item.color} />
              </div>
              <p style={{ fontSize: '0.875rem', fontWeight: 600, color: '#cbd5e1' }}>{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Packages */}
      <section id="packages" style={{ padding: '4rem 1.5rem', background: 'rgba(255,255,255,0.02)', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>Choose Your Package</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
            {packages.map((pkg) => (
              <div
                key={pkg.key}
                onClick={() => setSelectedPackage(pkg.key)}
                style={{ background: selectedPackage === pkg.key ? 'rgba(255,255,255,0.07)' : 'rgba(255,255,255,0.03)', border: `2px solid ${selectedPackage === pkg.key ? pkg.color : 'rgba(255,255,255,0.08)'}`, borderRadius: 'var(--radius-xl)', padding: '2rem', cursor: 'pointer', position: 'relative', transition: 'all 0.2s' }}
              >
                {pkg.popular && (
                  <div style={{ position: 'absolute', top: '-0.75rem', left: '50%', transform: 'translateX(-50%)', background: pkg.gradient, color: '#fff', fontSize: '0.75rem', fontWeight: 700, padding: '0.25rem 0.875rem', borderRadius: '2rem' }}>
                    Most Popular
                  </div>
                )}
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: '0.25rem' }}>{pkg.name}</h3>
                <div style={{ fontSize: '2.25rem', fontWeight: 900, color: pkg.color, marginBottom: '0.25rem' }}>{pkg.price}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--color-muted)', marginBottom: '1.5rem' }}>{pkg.priceNote}</div>
                <ul style={{ listStyle: 'none', padding: 0, display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
                  {pkg.features.map((f) => (
                    <li key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.875rem', color: 'var(--color-subtle)' }}>
                      <CheckCircle size={14} color="#10b981" style={{ marginTop: '0.15rem', flexShrink: 0 }} /> {f}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section style={{ padding: '5rem 1.5rem', maxWidth: '900px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>12-Week Launch Timeline</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem' }}>
          {timeline.map((t, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.5rem' }}>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#f59e0b', marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t.week}</div>
              <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '0.5rem' }}>{t.title}</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--color-muted)', lineHeight: 1.6 }}>{t.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Inquiry Form */}
      <section id="inquiry-form" style={{ padding: '5rem 1.5rem', maxWidth: '680px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '0.75rem' }}>Start Your Brand Journey</h2>
        <p style={{ color: 'var(--color-muted)', textAlign: 'center', marginBottom: '2.5rem' }}>We will send a detailed proposal within 48 hours.</p>
        {submitted ? (
          <div style={{ textAlign: 'center', padding: '3rem', background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 'var(--radius-xl)' }}>
            <CheckCircle size={48} color="#10b981" style={{ marginBottom: '1rem' }} />
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>Proposal Incoming!</h3>
            <p style={{ color: 'var(--color-muted)' }}>Our brand specialists will send you a detailed proposal within 48 hours.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Your name', required: true },
              { key: 'email', label: 'Email Address', type: 'email', placeholder: 'you@company.com', required: true },
              { key: 'brandName', label: 'Brand Name (or idea)', type: 'text', placeholder: 'e.g. NovaTech, PureLeaf', required: false },
              { key: 'productCategory', label: 'Product Category', type: 'text', placeholder: 'e.g. Skincare, Electronics, Apparel', required: true },
              { key: 'timeline', label: 'Target Launch Date', type: 'text', placeholder: 'e.g. Q3 2026', required: false },
            ].map((f) => (
              <div key={f.key}>
                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder} required={f.required} value={(form as any)[f.key]}
                  onChange={(e) => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }} />
              </div>
            ))}
            <div>
              <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>Package Selected</label>
              <select value={selectedPackage} onChange={(e) => setSelectedPackage(e.target.value as any)}
                style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }}>
                <option value="starter">Starter Brand — $15,000</option>
                <option value="full">Full Brand Launch — $25,000</option>
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>Additional Details</label>
              <textarea placeholder="Tell us about your brand vision, target market, and any specific requirements..."
                rows={4} value={form.message} onChange={(e) => setForm(prev => ({ ...prev, message: e.target.value }))}
                style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', resize: 'vertical', boxSizing: 'border-box' }} />
            </div>
            <button type="submit" disabled={submitInquiry.isPending}
              style={{ padding: '0.875rem', background: 'linear-gradient(135deg, #f59e0b, #d97706)', color: '#fff', border: 'none', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', opacity: submitInquiry.isPending ? 0.7 : 1 }}>
              {submitInquiry.isPending ? 'Sending...' : 'Request Brand Launch Proposal'}
            </button>
          </form>
        )}
      </section>

      {/* FAQ */}
      <section style={{ padding: '4rem 1.5rem', maxWidth: '720px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>Frequently Asked Questions</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map((faq, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '0.875rem', overflow: 'hidden' }}>
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1.125rem 1.5rem', background: 'none', border: 'none', color: '#f8fafc', fontWeight: 600, fontSize: '0.95rem', cursor: 'pointer', textAlign: 'left', gap: '1rem' }}>
                {faq.q}
                {openFaq === i ? <ChevronUp size={16} color="#64748b" /> : <ChevronDown size={16} color="#64748b" />}
              </button>
              {openFaq === i && <div style={{ padding: '0 1.5rem 1.25rem', fontSize: '0.875rem', color: 'var(--color-subtle)', lineHeight: 1.7 }}>{faq.a}</div>}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
