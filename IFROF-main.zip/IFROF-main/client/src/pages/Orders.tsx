import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Package, Truck, CheckCircle, Clock, AlertCircle, Download,
  Search, MapPin, ChevronDown, ChevronUp, RefreshCw, ExternalLink,
  Anchor, Plane, Train, Zap, Eye, X,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

type StatusFilter = 'all' | 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export default function Orders() {
  const { t } = useTranslation();
  const [selectedStatus, setSelectedStatus] = useState<StatusFilter>('all');
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
  const [trackingDialogOpen, setTrackingDialogOpen] = useState(false);
  const [trackingInput, setTrackingInput] = useState('');
  const [trackingSearch, setTrackingSearch] = useState('');

  // tRPC: fetch user orders
  const { data: orders = [], isLoading, refetch } = trpc.orders.list.useQuery(undefined, {
    refetchInterval: 60_000,
  });

  // tRPC: fetch user's shipments for progress bars
  const { data: shipmentsData = [] } = trpc.shipment.list.useQuery(undefined, {
    refetchInterval: 60_000,
  });

  // tRPC: track by tracking number (only fires when search is triggered)
  const trackQuery = trpc.shipment.getByTracking.useQuery(
    { trackingNumber: trackingSearch },
    {
      enabled: trackingSearch.length > 3,
      retry: false,
    }
  );

  const filteredOrders = selectedStatus === 'all'
    ? orders
    : orders.filter((order: any) => order.status === selectedStatus);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':     return <Clock className="w-5 h-5 text-amber-500" />;
      case 'confirmed':   return <CheckCircle className="w-5 h-5 text-blue-500" />;
      case 'processing':  return <RefreshCw className="w-5 h-5 text-purple-500" />;
      case 'shipped':     return <Truck className="w-5 h-5 text-blue-500" />;
      case 'delivered':   return <CheckCircle className="w-5 h-5 text-emerald-500" />;
      case 'cancelled':   return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:            return null;
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending:    t('orders.status.pending', 'Pending'),
      confirmed:  t('orders.status.confirmed', 'Confirmed'),
      processing: t('orders.status.processing', 'Processing'),
      shipped:    t('orders.status.shipped', 'Shipped'),
      delivered:  t('orders.status.delivered', 'Delivered'),
      cancelled:  t('orders.status.cancelled', 'Cancelled'),
    };
    return labels[status] ?? status.charAt(0).toUpperCase() + status.slice(1);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':     return 'bg-amber-100 text-amber-800';
      case 'confirmed':   return 'bg-blue-100 text-blue-800';
      case 'processing':  return 'bg-purple-100 text-purple-800';
      case 'shipped':     return 'bg-cyan-100 text-cyan-800';
      case 'delivered':   return 'bg-emerald-100 text-emerald-800';
      case 'cancelled':   return 'bg-red-100 text-red-800';
      default:            return 'bg-gray-100 text-gray-800';
    }
  };

  const getShipmentStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending:          t('tracking.status.pending', 'Pending'),
      picked_up:        t('tracking.status.picked_up', 'Picked Up'),
      in_transit:       t('tracking.status.in_transit', 'In Transit'),
      customs:          t('tracking.status.customs', 'In Customs'),
      out_for_delivery: t('tracking.status.out_for_delivery', 'Out for Delivery'),
      delivered:        t('tracking.status.delivered', 'Delivered'),
      exception:        t('tracking.status.exception', 'Exception'),
    };
    return labels[status] ?? status;
  };

  const getShipmentStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending:          'bg-amber-100 text-amber-800',
      picked_up:        'bg-cyan-100 text-cyan-800',
      in_transit:       'bg-blue-100 text-blue-800',
      customs:          'bg-purple-100 text-purple-800',
      out_for_delivery: 'bg-emerald-100 text-emerald-800',
      delivered:        'bg-emerald-100 text-emerald-800',
      exception:        'bg-red-100 text-red-800',
    };
    return colors[status] ?? 'bg-gray-100 text-gray-800';
  };

  const getMethodIcon = (method: string) => {
    const icons: Record<string, React.ElementType> = {
      sea: Anchor, air: Plane, rail: Train, express: Zap,
    };
    const Icon = icons[method] ?? Truck;
    return <Icon className="w-4 h-4" />;
  };

  const getShipmentProgress = (status: string) => {
    const progressMap: Record<string, number> = {
      pending: 5, picked_up: 20, in_transit: 55, customs: 70,
      out_for_delivery: 90, delivered: 100, exception: 50,
    };
    return progressMap[status] ?? 0;
  };

  const getOrderShipment = (orderId: number) =>
    shipmentsData.find(({ shipment }: any) => shipment.orderId === orderId);

  const statusFilters: StatusFilter[] = ['all', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="container py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold">{t('orders.title', 'My Orders')}</h1>
              <p className="text-gray-600 mt-2">{t('orders.subtitle', 'Track and manage your orders')}</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setTrackingDialogOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-cyan-500 text-white rounded-lg font-semibold hover:bg-cyan-600 transition-colors"
              >
                <Search className="w-4 h-4" />
                {t('orders.trackShipment', 'Track Shipment')}
              </button>
              <button
                onClick={() => refetch()}
                className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                {t('common.refresh', 'Refresh')}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-8">
        {/* Filter Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {statusFilters.map((status) => (
            <button
              key={status}
              onClick={() => setSelectedStatus(status)}
              className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                selectedStatus === status
                  ? 'bg-cyan-500 text-white'
                  : 'bg-white text-gray-700 border border-gray-200 hover:border-cyan-500'
              }`}
            >
              {status === 'all' ? t('common.all', 'All') : getStatusLabel(status)}
              {status !== 'all' && (
                <span className="ml-1.5 text-xs opacity-70">
                  ({orders.filter((o: any) => o.status === status).length})
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <div className="w-12 h-12 border-4 border-cyan-200 border-t-cyan-500 rounded-full animate-spin mx-auto mb-4" />
            <p className="text-gray-600">{t('common.loading', 'Loading your orders...')}</p>
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{t('orders.noOrders', 'No orders found')}</h3>
            <p className="text-gray-600">
              {selectedStatus !== 'all'
                ? t('orders.noOrdersFiltered', "You don't have any {{status}} orders yet.", { status: getStatusLabel(selectedStatus) })
                : t('orders.noOrdersYet', "You haven't placed any orders yet.")}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order: any) => {
              const isExpanded = expandedOrder === order.id;
              const orderShipment = getOrderShipment(order.id);
              const shipmentProgress = orderShipment ? getShipmentProgress(orderShipment.shipment.status ?? 'pending') : 0;

              return (
                <div key={order.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
                  <div className="p-6">
                    <div className="grid md:grid-cols-5 gap-6 items-center">
                      {/* Order Info */}
                      <div>
                        <p className="text-sm text-gray-600 mb-1">{t('orders.col.orderId', 'Order ID')}</p>
                        <p className="font-semibold text-gray-900">{order.orderNumber}</p>
                        <p className="text-xs text-gray-600 mt-1">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>

                      {/* Payment */}
                      <div>
                        <p className="text-sm text-gray-600 mb-1">{t('orders.col.payment', 'Payment')}</p>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                          order.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' :
                          order.paymentStatus === 'failed' ? 'bg-red-100 text-red-800' :
                          order.paymentStatus === 'refunded' ? 'bg-purple-100 text-purple-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {order.paymentStatus?.charAt(0).toUpperCase() + (order.paymentStatus?.slice(1) ?? '')}
                        </span>
                        <p className="text-xs text-gray-600 mt-1">{order.paymentMethod ?? '—'}</p>
                      </div>

                      {/* Status */}
                      <div>
                        <p className="text-sm text-gray-600 mb-1">{t('orders.col.status', 'Status')}</p>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(order.status ?? 'pending')}
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status ?? 'pending')}`}>
                            {getStatusLabel(order.status ?? 'pending')}
                          </span>
                        </div>
                      </div>

                      {/* Total */}
                      <div>
                        <p className="text-sm text-gray-600 mb-1">{t('orders.col.total', 'Total')}</p>
                        <p className="text-2xl font-bold text-cyan-600">
                          ${(order.totalAmount / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </p>
                        {order.currency && order.currency !== 'USD' && (
                          <p className="text-xs text-gray-500">{order.currency}</p>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 justify-end">
                        <button
                          onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm flex items-center gap-1.5"
                        >
                          <Eye className="w-4 h-4" />
                          {isExpanded ? t('orders.hideDetails', 'Hide') : t('orders.viewDetails', 'Details')}
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>

                    {/* Tracking Number */}
                    {order.trackingNumber && (
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="flex items-center gap-3">
                          <Truck className="w-4 h-4 text-cyan-500 flex-shrink-0" />
                          <p className="text-sm text-gray-600">{t('orders.trackingNumber', 'Tracking Number')}:</p>
                          <code className="bg-gray-100 px-3 py-1 rounded text-sm font-mono text-gray-900">
                            {order.trackingNumber}
                          </code>
                          <button
                            onClick={() => {
                              setTrackingInput(order.trackingNumber ?? '');
                              setTrackingSearch(order.trackingNumber ?? '');
                              setTrackingDialogOpen(true);
                            }}
                            className="text-cyan-600 hover:text-cyan-700 font-medium text-sm flex items-center gap-1"
                          >
                            {t('orders.track', 'Track')} <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Shipment Progress */}
                    {orderShipment && (
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getMethodIcon(orderShipment.shipment.method ?? 'sea')}
                            <span className="text-sm font-semibold text-gray-700">{orderShipment.shipment.carrier}</span>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getShipmentStatusColor(orderShipment.shipment.status ?? 'pending')}`}>
                              {getShipmentStatusLabel(orderShipment.shipment.status ?? 'pending')}
                            </span>
                          </div>
                          {orderShipment.shipment.estimatedDelivery && (
                            <span className="text-xs text-gray-500">
                              {t('orders.estDelivery', 'Est.')}: {new Date(orderShipment.shipment.estimatedDelivery).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${shipmentProgress}%` }}
                          />
                        </div>
                        {orderShipment.shipment.lastLocation && (
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <MapPin className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-500">{orderShipment.shipment.lastLocation}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="border-t border-gray-200 bg-gray-50 p-6 rounded-b-lg">
                      <div className="grid md:grid-cols-2 gap-6">
                        {/* Shipping Address */}
                        {order.shippingAddress && (
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-cyan-500" />
                              {t('orders.shippingAddress', 'Shipping Address')}
                            </h4>
                            <div className="bg-white rounded-lg p-4 border border-gray-200 text-sm text-gray-700 space-y-1">
                              {(() => {
                                try {
                                  const addr = typeof order.shippingAddress === 'string'
                                    ? JSON.parse(order.shippingAddress)
                                    : order.shippingAddress;
                                  return (
                                    <>
                                      <p className="font-semibold">{addr.fullName}</p>
                                      <p>{addr.address}</p>
                                      <p>{addr.city}, {addr.state} {addr.zipCode}</p>
                                      <p>{addr.country}</p>
                                      {addr.phone && <p className="text-gray-500">{addr.phone}</p>}
                                    </>
                                  );
                                } catch {
                                  return <p>{String(order.shippingAddress)}</p>;
                                }
                              })()}
                            </div>
                          </div>
                        )}

                        {/* Shipment Timeline */}
                        {orderShipment && (
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                              <Truck className="w-4 h-4 text-cyan-500" />
                              {t('orders.shipmentTimeline', 'Shipment Timeline')}
                            </h4>
                            <div className="bg-white rounded-lg p-4 border border-gray-200">
                              <div className="space-y-3">
                                {[
                                  { status: 'pending',          label: t('tracking.status.pending', 'Pending') },
                                  { status: 'picked_up',        label: t('tracking.status.picked_up', 'Picked Up') },
                                  { status: 'in_transit',       label: t('tracking.status.in_transit', 'In Transit') },
                                  { status: 'customs',          label: t('tracking.status.customs', 'In Customs') },
                                  { status: 'out_for_delivery', label: t('tracking.status.out_for_delivery', 'Out for Delivery') },
                                  { status: 'delivered',        label: t('tracking.status.delivered', 'Delivered') },
                                ].map((step) => {
                                  const currentStatus = orderShipment.shipment.status ?? 'pending';
                                  const statusOrder = ['pending', 'picked_up', 'in_transit', 'customs', 'out_for_delivery', 'delivered'];
                                  const currentIdx = statusOrder.indexOf(currentStatus);
                                  const stepIdx = statusOrder.indexOf(step.status);
                                  const isDone = stepIdx <= currentIdx;
                                  const isCurrent = step.status === currentStatus;

                                  return (
                                    <div key={step.status} className="flex items-center gap-3">
                                      <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${isDone ? 'bg-cyan-500' : 'bg-gray-200'}`}>
                                        {isDone && <CheckCircle className="w-3.5 h-3.5 text-white" />}
                                      </div>
                                      <span className={`text-sm ${isCurrent ? 'font-semibold text-cyan-600' : isDone ? 'text-gray-700' : 'text-gray-400'}`}>
                                        {step.label}
                                        {isCurrent && orderShipment.shipment.lastLocation && (
                                          <span className="text-xs text-gray-400 ml-2">— {orderShipment.shipment.lastLocation}</span>
                                        )}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Notes */}
                        {order.notes && (
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">{t('orders.notes', 'Notes')}</h4>
                            <div className="bg-white rounded-lg p-4 border border-gray-200 text-sm text-gray-700">
                              {order.notes}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Tracking Dialog */}
      <Dialog open={trackingDialogOpen} onOpenChange={setTrackingDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Truck className="w-5 h-5 text-cyan-500" />
              {t('orders.trackShipment', 'Track Shipment')}
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            {/* Search Input */}
            <div className="flex gap-2 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={t('orders.enterTrackingNumber', 'Enter tracking number...')}
                  value={trackingInput}
                  onChange={e => setTrackingInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && setTrackingSearch(trackingInput)}
                  className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
              <button
                onClick={() => setTrackingSearch(trackingInput)}
                className="px-4 py-2.5 bg-cyan-500 text-white rounded-lg font-semibold hover:bg-cyan-600 transition-colors text-sm"
              >
                {t('orders.track', 'Track')}
              </button>
            </div>

            {/* Tracking Result */}
            {trackingSearch.length > 3 && (
              trackQuery.isLoading ? (
                <div className="text-center py-8">
                  <div className="w-8 h-8 border-3 border-cyan-200 border-t-cyan-500 rounded-full animate-spin mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">{t('tracking.searching', 'Searching...')}</p>
                </div>
              ) : trackQuery.error ? (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                  <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
                  <p className="text-red-700 font-semibold text-sm">{t('tracking.notFound', 'Shipment not found')}</p>
                  <p className="text-red-500 text-xs mt-1">{t('tracking.checkNumber', 'Please check the tracking number and try again.')}</p>
                </div>
              ) : trackQuery.data ? (
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-cyan-50 to-blue-50 border border-cyan-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getMethodIcon(trackQuery.data.shipment.method ?? 'sea')}
                        <span className="font-semibold text-gray-900">{trackQuery.data.shipment.carrier}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getShipmentStatusColor(trackQuery.data.shipment.status ?? 'pending')}`}>
                        {getShipmentStatusLabel(trackQuery.data.shipment.status ?? 'pending')}
                      </span>
                    </div>
                    <div className="mb-3">
                      <div className="w-full bg-white rounded-full h-2.5 border border-cyan-100">
                        <div
                          className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2.5 rounded-full transition-all"
                          style={{ width: `${getShipmentProgress(trackQuery.data.shipment.status ?? 'pending')}%` }}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-gray-500 text-xs">{t('tracking.from', 'From')}</p>
                        <p className="font-medium text-gray-900">{trackQuery.data.shipment.origin ?? '—'}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs">{t('tracking.to', 'To')}</p>
                        <p className="font-medium text-gray-900">{trackQuery.data.shipment.destination ?? '—'}</p>
                      </div>
                      {trackQuery.data.shipment.lastLocation && (
                        <div className="col-span-2">
                          <p className="text-gray-500 text-xs">{t('tracking.currentLocation', 'Current Location')}</p>
                          <p className="font-medium text-gray-900 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-cyan-500" />
                            {trackQuery.data.shipment.lastLocation}
                          </p>
                        </div>
                      )}
                      {trackQuery.data.shipment.estimatedDelivery && (
                        <div className="col-span-2">
                          <p className="text-gray-500 text-xs">{t('tracking.estimatedDelivery', 'Estimated Delivery')}</p>
                          <p className="font-medium text-gray-900">
                            {new Date(trackQuery.data.shipment.estimatedDelivery).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Events Timeline */}
                  {trackQuery.data.events && trackQuery.data.events.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3 text-sm">{t('tracking.timeline', 'Tracking Timeline')}</h4>
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {trackQuery.data.events.map((event: any, idx: number) => (
                          <div key={event.id} className="flex gap-3 text-sm">
                            <div className="flex flex-col items-center">
                              <div className={`w-2.5 h-2.5 rounded-full mt-1 flex-shrink-0 ${idx === 0 ? 'bg-cyan-500' : 'bg-gray-300'}`} />
                              {idx < trackQuery.data!.events.length - 1 && (
                                <div className="w-0.5 bg-gray-200 flex-1 mt-1" />
                              )}
                            </div>
                            <div className="pb-2">
                              <p className="font-medium text-gray-900">{event.description}</p>
                              {event.location && <p className="text-gray-500 text-xs">{event.location}</p>}
                              <p className="text-gray-400 text-xs">{new Date(event.timestamp).toLocaleString()}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : null
            )}

            {/* My Active Shipments */}
            {!trackingSearch && shipmentsData.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 text-sm">{t('orders.myShipments', 'My Active Shipments')}</h4>
                <div className="space-y-2">
                  {shipmentsData
                    .filter(({ shipment }: any) => shipment.status !== 'delivered')
                    .slice(0, 5)
                    .map(({ shipment }: any) => (
                      <button
                        key={shipment.id}
                        onClick={() => {
                          setTrackingInput(shipment.trackingNumber ?? '');
                          setTrackingSearch(shipment.trackingNumber ?? '');
                        }}
                        className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-left"
                      >
                        <div className="flex items-center gap-2">
                          {getMethodIcon(shipment.method ?? 'sea')}
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{shipment.carrier}</p>
                            <p className="text-xs text-gray-500 font-mono">{shipment.trackingNumber}</p>
                          </div>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getShipmentStatusColor(shipment.status ?? 'pending')}`}>
                          {getShipmentStatusLabel(shipment.status ?? 'pending')}
                        </span>
                      </button>
                    ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
