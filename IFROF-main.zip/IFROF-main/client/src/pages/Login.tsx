import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Mail, Lock, Eye, EyeOff, Loader, Shield, Zap, Globe, ArrowRight, AlertCircle } from 'lucide-react';
import { getLoginUrl } from '@/const';
import { trpc } from '@/lib/trpc';

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check for OAuth error in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const err = params.get('error');
    if (err) {
      const messages: Record<string, string> = {
        google_denied: 'تم رفض تسجيل الدخول عبر Google. يرجى المحاولة مرة أخرى.',
        token_exchange: 'فشل في المصادقة مع Google. يرجى المحاولة مرة أخرى.',
        no_access_token: 'لم نتمكن من الحصول على بيانات حسابك. يرجى المحاولة مرة أخرى.',
        user_info_failed: 'فشل في الحصول على معلومات الحساب. يرجى المحاولة مرة أخرى.',
        callback_failed: 'حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.',
      };
      setError(messages[err] || 'حدث خطأ أثناء تسجيل الدخول.');
      // Clean URL
      window.history.replaceState({}, '', '/login');
    }
  }, []);

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  // If already authenticated, redirect to home
  useEffect(() => {
    if (meQuery.data) {
      setLocation('/');
    }
  }, [meQuery.data, setLocation]);

  // If OAuth is configured, redirect to OAuth provider
  const oauthUrl = getLoginUrl();
  const isOAuthConfigured = oauthUrl !== '/login';

  const handleOAuthLogin = () => {
    window.location.href = oauthUrl;
  };

  const handleGoogleLogin = () => {
    window.location.href = '/api/auth/google';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('يرجى ملء جميع الحقول للمتابعة.');
      return;
    }

    if (isOAuthConfigured) {
      handleOAuthLogin();
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'فشل تسجيل الدخول');
      }

      await meQuery.refetch();
      setLocation('/');
    } catch (err: any) {
      setError(err.message || 'لم نتمكن من تسجيل دخولك. يرجى التحقق من بياناتك والمحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (meQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-cyan-900 to-slate-900">
        <div className="flex flex-col items-center gap-4 text-white">
          <Loader className="w-8 h-8 animate-spin text-cyan-400" />
          <p className="text-sm text-cyan-100/70">جارٍ التحقق من الجلسة...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-cyan-900 to-slate-900 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        {/* Brand header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 shadow-md shadow-cyan-400/20 mb-4">
            <span className="text-2xl font-bold text-white">IF</span>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">IFROF</h1>
          <p className="text-cyan-100/80">توريد عالمي، موثّق ومحمي</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200">
          {/* Feature highlights */}
          <div className="bg-gradient-to-r from-cyan-50 to-cyan-100/60 px-8 py-4 border-b border-gray-100">
            <div className="flex flex-col gap-2.5">
              <FeatureItem icon={Shield} color="cyan">أكثر من 50,000 مصنع موثق حول العالم</FeatureItem>
              <FeatureItem icon={Zap} color="amber">صفقات تصفية مخزون فورية</FeatureItem>
              <FeatureItem icon={Globe} color="blue">حماية ضمان عالمية على جميع الطلبات</FeatureItem>
            </div>
          </div>

          {/* Form area */}
          <div className="px-8 py-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">مرحباً بعودتك</h2>
              <p className="text-gray-500 mt-1 text-sm">سجّل دخولك للوصول إلى حسابك</p>
            </div>

            {error && (
              <div className="mb-5 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm flex items-start gap-3">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Google Sign-In Button */}
            <button
              onClick={handleGoogleLogin}
              className="w-full mb-4 bg-white hover:bg-gray-50 border border-gray-200 hover:border-gray-300 text-gray-700 font-semibold py-3 rounded-xl shadow-sm transition-all flex items-center justify-center gap-3 active:scale-95"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              المتابعة عبر Google
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-1 h-px bg-gray-200"></div>
              <span className="text-xs text-gray-400 font-medium">أو</span>
              <div className="flex-1 h-px bg-gray-200"></div>
            </div>

            {isOAuthConfigured ? (
              <div className="space-y-4">
                <button
                  onClick={handleOAuthLogin}
                  className="w-full bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800 text-white font-semibold py-3 rounded-xl shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-3 active:scale-95"
                >
                  <Mail className="w-5 h-5" />
                  المتابعة عبر البريد الإلكتروني
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">
                    البريد الإلكتروني
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      id="email"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="بريدك@example.com"
                      className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all text-sm"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                      كلمة المرور
                    </label>
                    <Link href="/forgot-password" className="text-xs text-cyan-600 hover:text-cyan-700 font-medium">
                      نسيت كلمة المرور؟
                    </Link>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="أدخل كلمة المرور"
                      className="w-full pl-9 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all text-sm"
                      disabled={isSubmitting}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      disabled={isSubmitting}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-xl shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-95 mt-2"
                >
                  {isSubmitting ? (
                    <>
                      <Loader className="w-4 h-4 animate-spin" />
                      جارٍ تسجيل الدخول...
                    </>
                  ) : (
                    <>
                      تسجيل الدخول
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Footer links */}
            <div className="mt-6 space-y-3">
              <p className="text-center text-sm text-gray-600">
                ليس لديك حساب؟{' '}
                <Link href="/register" className="text-cyan-600 hover:text-cyan-700 font-semibold">
                  أنشئ حساباً مجاناً
                </Link>
              </p>
              <p className="text-center text-xs text-gray-400">
                بتسجيل دخولك، أنت توافق على{' '}
                <a href="/page/terms-and-conditions" target="_blank" rel="noopener noreferrer" className="underline hover:text-gray-600">شروط الخدمة</a>
                {' '}و{' '}
                <a href="/page/privacy-policy" target="_blank" rel="noopener noreferrer" className="underline hover:text-gray-600">سياسة الخصوصية</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureItem({ icon: Icon, color, children }: { icon: React.ElementType; color: string; children: React.ReactNode }) {
  const colors: Record<string, string> = {
    cyan: 'bg-cyan-100 text-cyan-600',
    amber: 'bg-amber-100 text-amber-600',
    blue: 'bg-blue-100 text-blue-600',
  };

  return (
    <div className="flex items-center gap-3 text-sm text-gray-700">
      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${colors[color]}`}>
        <Icon className="w-3.5 h-3.5" />
      </div>
      <span>{children}</span>
    </div>
  );
}