/**
 * TermsAndConditions.tsx — Terms of Service page for IFROF
 */
import { Link } from 'wouter';
import { FileText, ChevronLeft } from 'lucide-react';

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: '"DM Sans", sans-serif' }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 to-cyan-900 py-16 px-4 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 mb-4">
          <FileText className="w-7 h-7 text-cyan-400" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white mb-3">Terms of Service</h1>
        <p className="text-cyan-100/70 text-sm max-w-lg mx-auto">
          Last updated: March 2026
        </p>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="prose prose-gray max-w-none space-y-8 text-gray-700 text-[15px] leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">1. Acceptance of Terms</h2>
            <p>
              By accessing and using IFROF ("the Platform") at <strong>https://ifrof.com</strong>, you agree to be bound
              by these Terms of Service. If you do not agree to these terms, please do not use the Platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">2. Description of Service</h2>
            <p>
              IFROF is a global B2B trade platform that connects importers with verified manufacturers and suppliers.
              Our services include factory discovery, product sourcing, escrow payments, group shipping, brand launch
              support, and a community forum for importers.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">3. User Accounts</h2>
            <p>
              To access certain features, you must create an account. You are responsible for maintaining the
              confidentiality of your account credentials and for all activities that occur under your account.
              You agree to provide accurate and complete information during registration.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">4. Acceptable Use</h2>
            <p>You agree not to:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Use the Platform for any unlawful purpose or in violation of any regulations</li>
              <li>Post false, misleading, or fraudulent information</li>
              <li>Attempt to gain unauthorized access to any part of the Platform</li>
              <li>Interfere with or disrupt the integrity or performance of the Platform</li>
              <li>Engage in any form of harassment, abuse, or discrimination</li>
              <li>Use automated tools to scrape or extract data without permission</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">5. Transactions and Payments</h2>
            <p>
              IFROF facilitates transactions between buyers and suppliers. All payments processed through our escrow
              service are subject to our Escrow Terms. We are not responsible for the quality, safety, or legality
              of items listed on the Platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">6. Intellectual Property</h2>
            <p>
              All content on the Platform, including text, graphics, logos, and software, is the property of IFROF
              or its content suppliers and is protected by intellectual property laws. You may not reproduce, distribute,
              or create derivative works without our express written permission.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">7. Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, IFROF shall not be liable for any indirect, incidental, special,
              consequential, or punitive damages arising from your use of the Platform. Our total liability shall not
              exceed the amount you paid us in the twelve months preceding the claim.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">8. Termination</h2>
            <p>
              We reserve the right to suspend or terminate your account at any time for violation of these Terms or
              for any other reason at our sole discretion. You may terminate your account at any time by contacting us.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">9. Changes to Terms</h2>
            <p>
              We may update these Terms from time to time. We will notify you of significant changes by posting the
              new Terms on this page and updating the "Last updated" date. Your continued use of the Platform after
              changes constitutes acceptance of the new Terms.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">10. Contact Us</h2>
            <p>For questions about these Terms, please contact us at:</p>
            <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-100">
              <p><strong>IFROF</strong></p>
              <p>Email: <a href="mailto:ifrof4@gmail.com" className="text-cyan-600 hover:underline">ifrof4@gmail.com</a></p>
              <p>Website: <a href="https://ifrof.com" className="text-cyan-600 hover:underline">https://ifrof.com</a></p>
            </div>
          </section>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-100 flex items-center gap-4">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-cyan-600 hover:text-cyan-700 font-semibold">
            <ChevronLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <Link href="/page/privacy-policy" className="text-sm text-gray-500 hover:text-gray-700">
            Privacy Policy →
          </Link>
        </div>
      </div>
    </div>
  );
}
