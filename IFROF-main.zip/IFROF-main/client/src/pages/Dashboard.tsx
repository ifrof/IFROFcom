import { useState, useEffect } from 'react';
import { useSearch } from 'wouter';
import { useTranslation } from 'react-i18next';
import { trpc } from '@/lib/trpc';
import {
  Package, Truck, DollarSign, TrendingUp, Ship, Plane, Train, Zap,
  Calculator, MapPin, Weight, Box, ArrowRight, Clock, CheckCircle,
  AlertCircle, FileText, Download, Eye, Search, Filter, ChevronRight,
  Globe, Building2, CreditCard, MapPinned, Anchor, BarChart3, Bell,
  ChevronDown, ChevronUp, ExternalLink,
} from 'lucide-react';

interface ShippingQuote {
  method: string;
  icon: any;
  duration: string;
  cost: number;
  customs: number;
  insurance: number;
  total: number;
  recommended?: boolean;
}

type TabId = 'overview' | 'orders' | 'shipments' | 'calculator' | 'documents' | 'factories';

export default function Dashboard() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const searchStr = useSearch();
  const isWelcome = new URLSearchParams(searchStr).get('welcome') === '1';
  const [showWelcome, setShowWelcome] = useState(isWelcome);

  useEffect(() => {
    if (isWelcome) {
      // Auto-dismiss after 8 seconds
      const t = setTimeout(() => setShowWelcome(false), 8000);
      return () => clearTimeout(t);
    }
  }, [isWelcome]);
  const [weight, setWeight] = useState('100');
  const [length, setLength] = useState('50');
  const [width, setWidth] = useState('40');
  const [height, setHeight] = useState('30');
  const [origin, setOrigin] = useState('Shenzhen, China');
  const [destination, setDestination] = useState('Los Angeles, USA');
  const [quotes, setQuotes] = useState<ShippingQuote[]>([]);
  const [calculated, setCalculated] = useState(false);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [orderFilter, setOrderFilter] = useState('all');
  const [trackingSearch, setTrackingSearch] = useState('');

  const calcRates = trpc.shipping.calculateRates.useMutation({
    onSuccess: (data) => {
      const icons = [Ship, Plane, Zap];
      setQuotes(data.rates.map((r, i) => ({
        method: `${r.carrier} ${r.service}`,
        icon: icons[i] ?? Truck,
        duration: `${r.estimatedDays} days`,
        cost: r.rate,
        customs: Math.round(r.rate * 0.1),
        insurance: Math.round(r.rate * 0.02),
        total: Math.round(r.rate * 1.12),
        recommended: i === 0,
      })));
      setCalculated(true);
    },
  });

  const calculateShipping = () => {
    const w = parseFloat(weight);
    const l = parseFloat(length);
    const wd = parseFloat(width);
    const h = parseFloat(height);
    calcRates.mutate({
      weight: w > 0 ? w : 1,
      dimensions: l > 0 && wd > 0 && h > 0 ? { length: l, width: wd, height: h } : undefined,
      origin,
      destination,
    });
  };

  const stats = [
    { icon: Package, label: t('dashboard.activeOrders', 'Active Orders'), value: '12', change: '+3 this week', color: '#06b6d4', bg: 'rgba(6,182,212,0.08)' },
    { icon: Truck, label: t('dashboard.inTransit', 'In Transit'), value: '8', change: '+2 shipments', color: '#f59e0b', bg: 'rgba(245,158,11,0.08)' },
    { icon: DollarSign, label: t('dashboard.totalSpent', 'Total Spent'), value: '$45.2K', change: '+12% vs last month', color: '#10b981', bg: 'rgba(16,185,129,0.08)' },
    { icon: TrendingUp, label: t('dashboard.savings', 'Savings'), value: '$8.3K', change: '+18% saved', color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)' },
  ];

  const orders = [
    { id: 'ORD-2026-0045', product: 'Bluetooth Earbuds (5000 pcs)', factory: 'Shenzhen TechParts Co.', status: 'shipped', date: 'Feb 16, 2026', amount: '$12,450', tracking: 'DHL-8294716352', estimatedDelivery: 'Mar 5, 2026', statusColor: '#06b6d4', statusBg: 'rgba(6,182,212,0.1)', paymentStatus: 'paid' },
    { id: 'ORD-2026-0044', product: 'LED Strip Lights (2000 pcs)', factory: 'Guangzhou Lighting Ltd.', status: 'delivered', date: 'Feb 12, 2026', amount: '$4,890', tracking: 'FEDEX-5839201746', estimatedDelivery: 'Feb 20, 2026', statusColor: '#10b981', statusBg: 'rgba(16,185,129,0.1)', paymentStatus: 'paid' },
    { id: 'ORD-2026-0043', product: 'Phone Cases (10000 pcs)', factory: 'Yiwu Accessories Factory', status: 'processing', date: 'Feb 10, 2026', amount: '$8,200', tracking: '', estimatedDelivery: 'Mar 15, 2026', statusColor: '#f59e0b', statusBg: 'rgba(245,158,11,0.1)', paymentStatus: 'paid' },
    { id: 'ORD-2026-0042', product: 'USB-C Cables (3000 pcs)', factory: 'Ningbo Cable Tech', status: 'delivered', date: 'Feb 5, 2026', amount: '$2,340', tracking: 'MAERSK-7461928305', estimatedDelivery: 'Feb 18, 2026', statusColor: '#10b981', statusBg: 'rgba(16,185,129,0.1)', paymentStatus: 'paid' },
    { id: 'ORD-2026-0041', product: 'Wireless Chargers (1500 pcs)', factory: 'Shanghai Power Tech', status: 'pending', date: 'Feb 3, 2026', amount: '$5,670', tracking: '', estimatedDelivery: 'Mar 20, 2026', statusColor: '#94a3b8', statusBg: 'rgba(148,163,184,0.1)', paymentStatus: 'pending' },
    { id: 'ORD-2026-0040', product: 'Smart Watches (800 pcs)', factory: 'Shenzhen WearTech', status: 'cancelled', date: 'Jan 28, 2026', amount: '$15,200', tracking: '', estimatedDelivery: '', statusColor: '#ef4444', statusBg: 'rgba(239,68,68,0.1)', paymentStatus: 'refunded' },
  ];

  const shipmentData = [
    { id: 'SHP-001', tracking: 'DHL-8294716352', carrier: 'DHL Express', method: 'Air', origin: 'Shenzhen, China', destination: 'Los Angeles, USA', status: 'in_transit', progress: 65, lastLocation: 'Anchorage, Alaska', lastUpdate: '2 hours ago', estimatedDelivery: 'Mar 5, 2026', orderId: 'ORD-2026-0045' },
    { id: 'SHP-002', tracking: 'MAERSK-3847261', carrier: 'Maersk Line', method: 'Sea', origin: 'Shanghai, China', destination: 'Hamburg, Germany', status: 'customs', progress: 80, lastLocation: 'Hamburg Port', lastUpdate: '5 hours ago', estimatedDelivery: 'Mar 1, 2026', orderId: 'ORD-2026-0046' },
    { id: 'SHP-003', tracking: 'FEDEX-9283746', carrier: 'FedEx', method: 'Express', origin: 'Guangzhou, China', destination: 'Dubai, UAE', status: 'out_for_delivery', progress: 95, lastLocation: 'Dubai Distribution Center', lastUpdate: '30 min ago', estimatedDelivery: 'Feb 24, 2026', orderId: 'ORD-2026-0047' },
  ];

  const documents = [
    { id: 1, name: 'Bill of Lading - ORD-2026-0045', type: 'bill_of_lading', order: 'ORD-2026-0045', date: 'Feb 16, 2026', size: '245 KB' },
    { id: 2, name: 'Commercial Invoice - ORD-2026-0045', type: 'commercial_invoice', order: 'ORD-2026-0045', date: 'Feb 16, 2026', size: '128 KB' },
    { id: 3, name: 'Packing List - ORD-2026-0044', type: 'packing_list', order: 'ORD-2026-0044', date: 'Feb 12, 2026', size: '89 KB' },
    { id: 4, name: 'Customs Declaration - ORD-2026-0043', type: 'customs_declaration', order: 'ORD-2026-0043', date: 'Feb 10, 2026', size: '312 KB' },
    { id: 5, name: 'Certificate of Origin - ORD-2026-0042', type: 'certificate_of_origin', order: 'ORD-2026-0042', date: 'Feb 5, 2026', size: '156 KB' },
    { id: 6, name: 'Insurance Certificate - ORD-2026-0045', type: 'insurance_cert', order: 'ORD-2026-0045', date: 'Feb 16, 2026', size: '98 KB' },
  ];

  const savedFactories = [
    { id: 1, name: 'Shenzhen TechParts Co.', category: 'Electronics', verified: true, trustScore: 92, city: 'Shenzhen', orders: 5, totalSpent: '$32,450', bankName: 'Bank of China', bankAccount: '****6789', swiftCode: 'BKCHCNBJ' },
    { id: 2, name: 'Guangzhou Lighting Ltd.', category: 'Lighting', verified: true, trustScore: 88, city: 'Guangzhou', orders: 3, totalSpent: '$14,200', bankName: 'ICBC', bankAccount: '****3456', swiftCode: 'ICBKCNBJ' },
    { id: 3, name: 'Yiwu Accessories Factory', category: 'Accessories', verified: true, trustScore: 85, city: 'Yiwu', orders: 2, totalSpent: '$8,200', bankName: 'China Merchants Bank', bankAccount: '****7890', swiftCode: 'CMBCCNBS' },
    { id: 4, name: 'Ningbo Cable Tech', category: 'Cables & Wiring', verified: false, trustScore: 72, city: 'Ningbo', orders: 1, totalSpent: '$2,340', bankName: 'Agricultural Bank of China', bankAccount: '****1234', swiftCode: 'ABOCCNBJ' },
  ];

  const tabs: { id: TabId; label: string; icon: any }[] = [
    { id: 'overview', label: t('dashboard.overview', 'Overview'), icon: BarChart3 },
    { id: 'orders', label: t('dashboard.orders', 'Orders'), icon: Package },
    { id: 'shipments', label: t('dashboard.shipments', 'Shipments'), icon: Truck },
    { id: 'calculator', label: t('dashboard.calculator', 'Shipping Calculator'), icon: Calculator },
    { id: 'documents', label: t('dashboard.documents', 'Documents'), icon: FileText },
    { id: 'factories', label: t('dashboard.factories', 'My Factories'), icon: Building2 },
  ];

  const filteredOrders = orderFilter === 'all' ? orders : orders.filter(o => o.status === orderFilter);

  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.625rem 0.875rem', borderRadius: '0.5rem', border: '1.5px solid #e2e8f0', fontSize: '0.875rem', fontFamily: 'DM Sans, sans-serif', color: '#0f172a', outline: 'none', transition: 'border-color 200ms', background: 'white' };
  const cardStyle: React.CSSProperties = { background: 'white', borderRadius: '0.75rem', padding: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', border: '1px solid #f1f5f9' };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle style={{ width: 14, height: 14 }} />;
      case 'shipped': case 'in_transit': return <Truck style={{ width: 14, height: 14 }} />;
      case 'customs': return <Globe style={{ width: 14, height: 14 }} />;
      case 'out_for_delivery': return <MapPinned style={{ width: 14, height: 14 }} />;
      case 'processing': return <AlertCircle style={{ width: 14, height: 14 }} />;
      case 'cancelled': return <AlertCircle style={{ width: 14, height: 14 }} />;
      default: return <Clock style={{ width: 14, height: 14 }} />;
    }
  };

  return (
    <div style={{ paddingTop: '5rem', minHeight: '100vh', background: 'var(--color-bg)' }}>
      {/* Welcome banner for new signups */}
      {showWelcome && (
        <div style={{
          background: 'linear-gradient(135deg, #0c4a6e, #0e7490)',
          padding: '1rem 1.5rem',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          gap: '1rem', flexWrap: 'wrap',
          borderBottom: '1px solid rgba(6,182,212,0.3)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
            <span style={{ fontSize: '1.5rem' }}>🎉</span>
            <div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: '0.95rem', fontFamily: 'Sora, sans-serif' }}>
                مرحباً بك في IFROF!
              </div>
              <div style={{ color: 'rgba(255,255,255,0.75)', fontSize: '0.8125rem', marginTop: '0.125rem' }}>
                حسابك جاهز. ابدأ بالبحث عن مصانع موثقة أو تصفّح السوق.
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <a href="/factory-finder" style={{
              padding: '0.5rem 1.25rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
              color: 'white', borderRadius: '0.625rem', textDecoration: 'none',
              fontWeight: 700, fontSize: '0.8125rem', whiteSpace: 'nowrap',
            }}>ابحث عن مصنع ←</a>
            <button
              onClick={() => setShowWelcome(false)}
              style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.6)', cursor: 'pointer', padding: '0.25rem', fontSize: '1.25rem', lineHeight: 1 }}
              aria-label="إغلاق"
            >×</button>
          </div>
        </div>
      )}
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 60%, #0c1a2e 100%)', padding: '2.5rem 0', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'radial-gradient(circle at 80% 50%, rgba(6,182,212,0.15), transparent 60%)' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <h1 style={{ fontFamily: 'Sora, sans-serif', fontSize: '2rem', fontWeight: 800, color: 'white', margin: '0 0 0.5rem' }}>
            {t('dashboard.title', 'Dashboard')}
          </h1>
          <p style={{ fontSize: '1rem', color: '#94a3b8' }}>
            {t('dashboard.subtitle', 'Manage your orders, shipments, documents, and calculate shipping costs')}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background: 'white', borderBottom: '1px solid #e2e8f0', position: 'sticky', top: '4rem', zIndex: 40 }}>
        <div className="container tabs-bar">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
            >
              <tab.icon style={{ width: 16, height: 16 }} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1200px' }}>

        {/* ============ OVERVIEW TAB ============ */}
        {activeTab === 'overview' && (
          <>
            {/* Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
              {stats.map((stat, i) => (
                <div key={i} className='card-stat hover-lift' style={{ cursor: 'pointer' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                    <div style={{ width: '40px', height: '40px', borderRadius: '0.625rem', background: stat.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <stat.icon style={{ width: 20, height: 20, color: stat.color }} />
                    </div>
                  </div>
                  <div style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.75rem', fontWeight: 800, color: '#0f172a', lineHeight: 1 }}>{stat.value}</div>
                  <div style={{ fontSize: '0.8125rem', color: '#64748b', marginTop: '0.25rem' }}>{stat.label}</div>
                  <div style={{ fontSize: '0.6875rem', color: '#10b981', marginTop: '0.375rem', fontWeight: 600 }}>{stat.change}</div>
                </div>
              ))}
            </div>

            {/* Quick Actions + Recent Activity */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '2rem' }}>
              {/* Recent Orders */}
              <div className='card-flat' style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                    {t('dashboard.recentOrders', 'Recent Orders')}
                  </h3>
                  <button onClick={() => setActiveTab('orders')} style={{ fontSize: '0.8125rem', color: '#06b6d4', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>
                    {t('dashboard.viewAll', 'View All')} →
                  </button>
                </div>
                {orders.slice(0, 4).map((order, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 0', borderBottom: i < 3 ? '1px solid #f1f5f9' : 'none' }}>
                    <div>
                      <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>{order.id}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{order.product.substring(0, 30)}...</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', fontWeight: 600, color: order.statusColor, background: order.statusBg, padding: '0.2rem 0.5rem', borderRadius: '1rem' }}>
                        {getStatusIcon(order.status)}
                        {order.status}
                      </span>
                      <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#0f172a', marginTop: '0.25rem' }}>{order.amount}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Active Shipments */}
              <div className='card-flat' style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                    {t('dashboard.activeShipments', 'Active Shipments')}
                  </h3>
                  <button onClick={() => setActiveTab('shipments')} style={{ fontSize: '0.8125rem', color: '#06b6d4', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}>
                    {t('dashboard.viewAll', 'View All')} →
                  </button>
                </div>
                {shipmentData.map((s, i) => (
                  <div key={i} style={{ padding: '0.75rem 0', borderBottom: i < shipmentData.length - 1 ? '1px solid #f1f5f9' : 'none' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                      <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a' }}>{s.carrier} - {s.tracking}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{s.lastUpdate}</div>
                    </div>
                    <div style={{ width: '100%', height: '6px', background: '#f1f5f9', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ width: `${s.progress}%`, height: '100%', background: 'linear-gradient(90deg, #06b6d4, #0891b2)', borderRadius: '3px', transition: 'width 0.5s' }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '0.375rem' }}>
                      <span style={{ fontSize: '0.6875rem', color: '#64748b' }}>{s.lastLocation}</span>
                      <span style={{ fontSize: '0.6875rem', color: '#06b6d4', fontWeight: 600 }}>ETA: {s.estimatedDelivery}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notifications Banner */}
            <div style={{ ...cardStyle, background: 'linear-gradient(135deg, rgba(6,182,212,0.05), rgba(6,182,212,0.02))', border: '1px solid rgba(6,182,212,0.15)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '0.625rem', background: 'rgba(6,182,212,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Bell style={{ width: 20, height: 20, color: '#06b6d4' }} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>
                    {t('dashboard.notifTitle', '3 shipments require attention')}
                  </div>
                  <div style={{ fontSize: '0.8125rem', color: '#64748b' }}>
                    {t('dashboard.notifDesc', 'Customs clearance needed for 2 shipments, 1 delivery confirmation pending.')}
                  </div>
                </div>
                <button style={{ padding: '0.5rem 1rem', borderRadius: '0.5rem', background: '#06b6d4', color: 'white', border: 'none', fontSize: '0.8125rem', fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                  {t('dashboard.reviewNow', 'Review Now')}
                </button>
              </div>
            </div>
          </>
        )}

        {/* ============ ORDERS TAB ============ */}
        {activeTab === 'orders' && (
          <div>
            {/* Order Filters */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'white', padding: '0.375rem', borderRadius: '0.5rem', border: '1px solid #e2e8f0' }}>
                {['all', 'pending', 'processing', 'shipped', 'delivered', 'cancelled'].map(f => (
                  <button key={f} onClick={() => setOrderFilter(f)} style={{
                    padding: '0.375rem 0.75rem', borderRadius: '0.375rem', border: 'none', fontSize: '0.8125rem', fontWeight: 600, cursor: 'pointer',
                    background: orderFilter === f ? '#06b6d4' : 'transparent',
                    color: orderFilter === f ? 'white' : '#64748b',
                    transition: 'all 200ms', textTransform: 'capitalize',
                  }}>
                    {f === 'all' ? t('dashboard.all', 'All') : f}
                  </button>
                ))}
              </div>
              <div style={{ flex: 1 }} />
              <div style={{ fontSize: '0.8125rem', color: '#64748b' }}>{filteredOrders.length} {t('dashboard.ordersFound', 'orders')}</div>
            </div>

            {/* Orders List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {filteredOrders.map((order) => (
                <div key={order.id} className='card-flat' style={{ padding: '1.5rem' }}>
                  <div
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
                    onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ width: '40px', height: '40px', borderRadius: '0.625rem', background: order.statusBg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        {getStatusIcon(order.status)}
                      </div>
                      <div>
                        <div style={{ fontSize: '0.9375rem', fontWeight: 700, color: '#0f172a' }}>{order.id}</div>
                        <div style={{ fontSize: '0.8125rem', color: '#64748b' }}>{order.product}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{order.amount}</div>
                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{order.date}</div>
                      </div>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', fontWeight: 600, color: order.statusColor, background: order.statusBg, padding: '0.3rem 0.75rem', borderRadius: '1rem', textTransform: 'capitalize' }}>
                        {getStatusIcon(order.status)}
                        {order.status}
                      </span>
                      {expandedOrder === order.id ? <ChevronUp style={{ width: 16, height: 16, color: '#64748b' }} /> : <ChevronDown style={{ width: 16, height: 16, color: '#64748b' }} />}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {expandedOrder === order.id && (
                    <div style={{ marginTop: '1.25rem', paddingTop: '1.25rem', borderTop: '1px solid #f1f5f9' }}>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                        <div>
                          <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#64748b', marginBottom: '0.25rem', textTransform: 'uppercase' }}>{t('dashboard.factory', 'Factory')}</div>
                          <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>{order.factory}</div>
                        </div>
                        <div>
                          <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#64748b', marginBottom: '0.25rem', textTransform: 'uppercase' }}>{t('dashboard.tracking', 'Tracking')}</div>
                          <div style={{ fontSize: '0.875rem', fontWeight: 600, color: order.tracking ? '#06b6d4' : '#94a3b8' }}>
                            {order.tracking || t('dashboard.noTracking', 'Not available yet')}
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#64748b', marginBottom: '0.25rem', textTransform: 'uppercase' }}>{t('dashboard.estimatedDelivery', 'Est. Delivery')}</div>
                          <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>{order.estimatedDelivery || 'N/A'}</div>
                        </div>
                        <div>
                          <div style={{ fontSize: '0.75rem', fontWeight: 600, color: '#64748b', marginBottom: '0.25rem', textTransform: 'uppercase' }}>{t('dashboard.payment', 'Payment')}</div>
                          <span style={{
                            fontSize: '0.75rem', fontWeight: 600, padding: '0.2rem 0.5rem', borderRadius: '0.25rem', textTransform: 'capitalize',
                            color: order.paymentStatus === 'paid' ? '#10b981' : order.paymentStatus === 'refunded' ? '#f59e0b' : '#64748b',
                            background: order.paymentStatus === 'paid' ? 'rgba(16,185,129,0.1)' : order.paymentStatus === 'refunded' ? 'rgba(245,158,11,0.1)' : 'rgba(148,163,184,0.1)',
                          }}>
                            {order.paymentStatus}
                          </span>
                        </div>
                      </div>

                      {/* Order Timeline */}
                      {order.tracking && (
                        <div style={{ marginTop: '1.25rem' }}>
                          <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a', marginBottom: '0.75rem' }}>{t('dashboard.orderTimeline', 'Order Timeline')}</div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0' }}>
                            {['Order Placed', 'Confirmed', 'Processing', 'Shipped', 'Delivered'].map((step, idx) => {
                              const stepMap: Record<string, number> = { pending: 0, confirmed: 1, processing: 2, shipped: 3, delivered: 4 };
                              const currentStep = stepMap[order.status] ?? 0;
                              const isActive = idx <= currentStep;
                              return (
                                <div key={idx} style={{ flex: 1, textAlign: 'center' }}>
                                  <div style={{ display: 'flex', alignItems: 'center' }}>
                                    {idx > 0 && <div style={{ flex: 1, height: '2px', background: isActive ? '#06b6d4' : '#e2e8f0' }} />}
                                    <div style={{
                                      width: '24px', height: '24px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                                      background: isActive ? '#06b6d4' : '#e2e8f0', color: isActive ? 'white' : '#94a3b8', fontSize: '0.6875rem', fontWeight: 700,
                                    }}>
                                      {isActive ? <CheckCircle style={{ width: 14, height: 14 }} /> : idx + 1}
                                    </div>
                                    {idx < 4 && <div style={{ flex: 1, height: '2px', background: idx < currentStep ? '#06b6d4' : '#e2e8f0' }} />}
                                  </div>
                                  <div style={{ fontSize: '0.625rem', color: isActive ? '#0f172a' : '#94a3b8', marginTop: '0.375rem', fontWeight: isActive ? 600 : 400 }}>{step}</div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============ SHIPMENTS TAB ============ */}
        {activeTab === 'shipments' && (
          <div>
            {/* Tracking Search */}
            <div style={{ ...cardStyle, marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: '#94a3b8' }} />
                  <input
                    type="text"
                    value={trackingSearch}
                    onChange={e => setTrackingSearch(e.target.value)}
                    placeholder={t('dashboard.searchTracking', 'Enter tracking number to search...')}
                    style={{ ...inputStyle, paddingLeft: '2.25rem' }}
                  />
                </div>
                <button style={{ padding: '0.625rem 1.25rem', borderRadius: '0.5rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontSize: '0.875rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                  <Search style={{ width: 16, height: 16 }} />
                  {t('dashboard.track', 'Track')}
                </button>
              </div>
            </div>

            {/* Shipments Grid */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {shipmentData.map((s) => (
                <div key={s.id} className='card-flat' style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1rem' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                        <span style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{s.carrier}</span>
                        <span style={{ fontSize: '0.75rem', color: '#64748b', background: '#f1f5f9', padding: '0.125rem 0.5rem', borderRadius: '0.25rem' }}>{s.method}</span>
                      </div>
                      <div style={{ fontSize: '0.8125rem', color: '#06b6d4', fontWeight: 600 }}>{s.tracking}</div>
                    </div>
                    <span style={{
                      fontSize: '0.75rem', fontWeight: 600, padding: '0.3rem 0.75rem', borderRadius: '1rem', textTransform: 'capitalize',
                      color: s.status === 'in_transit' ? '#06b6d4' : s.status === 'customs' ? '#f59e0b' : '#10b981',
                      background: s.status === 'in_transit' ? 'rgba(6,182,212,0.1)' : s.status === 'customs' ? 'rgba(245,158,11,0.1)' : 'rgba(16,185,129,0.1)',
                    }}>
                      {s.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Route */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#0f172a' }}>
                      <MapPin style={{ width: 14, height: 14, color: '#06b6d4' }} />
                      {s.origin}
                    </div>
                    <ArrowRight style={{ width: 16, height: 16, color: '#94a3b8' }} />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#0f172a' }}>
                      <MapPin style={{ width: 14, height: 14, color: '#f59e0b' }} />
                      {s.destination}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div style={{ marginBottom: '0.75rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.375rem' }}>
                      <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{t('dashboard.progress', 'Progress')}: {s.progress}%</span>
                      <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{s.lastUpdate}</span>
                    </div>
                    <div style={{ width: '100%', height: '8px', background: '#f1f5f9', borderRadius: '4px', overflow: 'hidden' }}>
                      <div style={{ width: `${s.progress}%`, height: '100%', background: 'linear-gradient(90deg, #06b6d4, #0891b2)', borderRadius: '4px', transition: 'width 0.5s' }} />
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#64748b' }}>
                      <MapPinned style={{ width: 14, height: 14 }} />
                      {t('dashboard.lastLocation', 'Last')}: <span style={{ fontWeight: 600, color: '#0f172a' }}>{s.lastLocation}</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#06b6d4', fontWeight: 600 }}>
                      <Clock style={{ width: 14, height: 14 }} />
                      ETA: {s.estimatedDelivery}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============ CALCULATOR TAB ============ */}
        {activeTab === 'calculator' && (
          <div className='card-flat' style={{ padding: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '0.5rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Calculator style={{ width: 18, height: 18, color: 'white' }} />
              </div>
              <div>
                <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                  {t('dashboard.shippingCalculator', 'Shipping Calculator')}
                </h2>
                <p style={{ fontSize: '0.8125rem', color: '#64748b', margin: 0 }}>
                  {t('dashboard.calcDesc', 'Get instant quotes for all shipping methods')}
                </p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', fontWeight: 600, color: '#334155', marginBottom: '0.375rem' }}>
                  <MapPin style={{ width: 14, height: 14, color: '#06b6d4' }} /> {t('dashboard.origin', 'Origin')}
                </label>
                <select value={origin} onChange={e => setOrigin(e.target.value)} className='input'>
                  <option>Shenzhen, China</option>
                  <option>Shanghai, China</option>
                  <option>Guangzhou, China</option>
                  <option>Ningbo, China</option>
                  <option>Yiwu, China</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', fontWeight: 600, color: '#334155', marginBottom: '0.375rem' }}>
                  <MapPin style={{ width: 14, height: 14, color: '#f59e0b' }} /> {t('dashboard.destination', 'Destination')}
                </label>
                <select value={destination} onChange={e => setDestination(e.target.value)} className='input'>
                  <option>Los Angeles, USA</option>
                  <option>New York, USA</option>
                  <option>London, UK</option>
                  <option>Dubai, UAE</option>
                  <option>Sydney, Australia</option>
                  <option>Hamburg, Germany</option>
                  <option>Riyadh, Saudi Arabia</option>
                  <option>Tokyo, Japan</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', fontWeight: 600, color: '#334155', marginBottom: '0.375rem' }}>
                  <Weight style={{ width: 14, height: 14, color: '#8b5cf6' }} /> {t('dashboard.weight', 'Weight (kg)')}
                </label>
                <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className='input' />
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', fontWeight: 600, color: '#334155', marginBottom: '0.375rem' }}>
                  <Box style={{ width: 14, height: 14, color: '#10b981' }} /> {t('dashboard.dimensions', 'Dimensions (L x W x H cm)')}
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem' }}>
                  <input type="number" value={length} onChange={e => setLength(e.target.value)} placeholder="L" className='input' />
                  <input type="number" value={width} onChange={e => setWidth(e.target.value)} placeholder="W" className='input' />
                  <input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="H" className='input' />
                </div>
              </div>
            </div>

            <button onClick={calculateShipping} style={{ width: '100%', padding: '0.75rem', borderRadius: '0.625rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '0.9375rem', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', boxShadow: '0 4px 12px rgba(6,182,212,0.3)' }}>
              <Calculator style={{ width: 18, height: 18 }} /> {t('dashboard.calculateBtn', 'Calculate Shipping Costs')}
            </button>

            {calculated && quotes.length > 0 && (
              <div style={{ marginTop: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                  <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>
                    {t('dashboard.shippingQuotes', 'Shipping Quotes')}
                  </h3>
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{origin} → {destination}</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '0.75rem' }}>
                  {quotes.map((quote, idx) => (
                    <div key={idx} style={{ padding: '1.25rem', borderRadius: '0.75rem', border: quote.recommended ? '2px solid #06b6d4' : '1.5px solid #e2e8f0', background: quote.recommended ? 'rgba(6,182,212,0.03)' : 'white', position: 'relative', cursor: 'pointer', transition: 'all 200ms' }}>
                      {quote.recommended && (
                        <div style={{ position: 'absolute', top: '-0.5rem', right: '0.75rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', fontSize: '0.625rem', fontWeight: 700, padding: '0.125rem 0.5rem', borderRadius: '0.25rem', textTransform: 'uppercase' }}>Best Value</div>
                      )}
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '0.75rem' }}>
                        <div style={{ width: '32px', height: '32px', borderRadius: '0.5rem', background: 'rgba(6,182,212,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <quote.icon style={{ width: 16, height: 16, color: '#06b6d4' }} />
                        </div>
                        <div>
                          <div style={{ fontFamily: 'Sora, sans-serif', fontSize: '0.875rem', fontWeight: 700, color: '#0f172a' }}>{quote.method}</div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', color: '#64748b' }}>
                            <Clock style={{ width: 12, height: 12 }} /> {quote.duration}
                          </div>
                        </div>
                      </div>
                      <div style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.5rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>${quote.total.toLocaleString()}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b', display: 'flex', flexDirection: 'column', gap: '0.125rem' }}>
                        <span>{t('dashboard.shipping', 'Shipping')}: ${quote.cost.toLocaleString()}</span>
                        <span>{t('dashboard.customs', 'Customs')}: ${quote.customs.toLocaleString()}</span>
                        <span>{t('dashboard.insurance', 'Insurance')}: ${quote.insurance.toLocaleString()}</span>
                      </div>
                      <button style={{ width: '100%', marginTop: '0.75rem', padding: '0.5rem', borderRadius: '0.5rem', background: quote.recommended ? 'linear-gradient(135deg, #06b6d4, #0891b2)' : '#f1f5f9', color: quote.recommended ? 'white' : '#334155', border: 'none', fontSize: '0.8125rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.375rem' }}>
                        {t('dashboard.select', 'Select')} <ArrowRight style={{ width: 14, height: 14 }} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============ DOCUMENTS TAB ============ */}
        {activeTab === 'documents' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                {t('dashboard.shippingDocuments', 'Shipping Documents')}
              </h2>
              <button style={{ padding: '0.5rem 1rem', borderRadius: '0.5rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontSize: '0.8125rem', fontWeight: 600, cursor: 'pointer' }}>
                {t('dashboard.uploadDoc', 'Upload Document')}
              </button>
            </div>

            <div className='card-flat' style={{ padding: '1.5rem' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    {[t('dashboard.docName', 'Document'), t('dashboard.docType', 'Type'), t('dashboard.docOrder', 'Order'), t('dashboard.docDate', 'Date'), t('dashboard.docSize', 'Size'), t('dashboard.docActions', 'Actions')].map(h => (
                      <th key={h} style={{ textAlign: 'left', padding: '0.75rem 0.5rem', fontSize: '0.75rem', fontWeight: 600, color: '#64748b', borderBottom: '1px solid #f1f5f9', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {documents.map((doc) => (
                    <tr key={doc.id} style={{ cursor: 'pointer', transition: 'background 200ms' }} onMouseEnter={e => (e.currentTarget.style.background = '#f8fafc')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ padding: '0.875rem 0.5rem', borderBottom: '1px solid #f8fafc' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <FileText style={{ width: 16, height: 16, color: '#06b6d4' }} />
                          <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#0f172a' }}>{doc.name}</span>
                        </div>
                      </td>
                      <td style={{ padding: '0.875rem 0.5rem', borderBottom: '1px solid #f8fafc' }}>
                        <span style={{ fontSize: '0.75rem', color: '#64748b', background: '#f1f5f9', padding: '0.2rem 0.5rem', borderRadius: '0.25rem', textTransform: 'capitalize' }}>
                          {doc.type.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td style={{ padding: '0.875rem 0.5rem', fontSize: '0.8125rem', color: '#06b6d4', fontWeight: 600, borderBottom: '1px solid #f8fafc' }}>{doc.order}</td>
                      <td style={{ padding: '0.875rem 0.5rem', fontSize: '0.8125rem', color: '#64748b', borderBottom: '1px solid #f8fafc' }}>{doc.date}</td>
                      <td style={{ padding: '0.875rem 0.5rem', fontSize: '0.8125rem', color: '#64748b', borderBottom: '1px solid #f8fafc' }}>{doc.size}</td>
                      <td style={{ padding: '0.875rem 0.5rem', borderBottom: '1px solid #f8fafc' }}>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                          <button style={{ padding: '0.375rem', borderRadius: '0.375rem', background: '#f1f5f9', border: 'none', cursor: 'pointer' }} title="View">
                            <Eye style={{ width: 14, height: 14, color: '#64748b' }} />
                          </button>
                          <button style={{ padding: '0.375rem', borderRadius: '0.375rem', background: '#f1f5f9', border: 'none', cursor: 'pointer' }} title="Download">
                            <Download style={{ width: 14, height: 14, color: '#64748b' }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ============ FACTORIES TAB ============ */}
        {activeTab === 'factories' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                {t('dashboard.myFactories', 'My Factories & Banking Info')}
              </h2>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1rem' }}>
              {savedFactories.map((factory) => (
                <div key={factory.id} style={{ ...cardStyle, transition: 'all 300ms', cursor: 'pointer' }} onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(0,0,0,0.08)'; }} onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 1px 3px rgba(0,0,0,0.06)'; }}>
                  {/* Factory Header */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <div style={{ width: '44px', height: '44px', borderRadius: '0.625rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: '1rem' }}>
                        {factory.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ fontSize: '0.9375rem', fontWeight: 700, color: '#0f172a' }}>{factory.name}</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.75rem', color: '#64748b' }}>
                          <MapPin style={{ width: 12, height: 12 }} /> {factory.city}, China
                        </div>
                      </div>
                    </div>
                    {factory.verified && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.6875rem', fontWeight: 600, color: '#10b981', background: 'rgba(16,185,129,0.1)', padding: '0.25rem 0.5rem', borderRadius: '1rem' }}>
                        <CheckCircle style={{ width: 12, height: 12 }} /> Verified
                      </div>
                    )}
                  </div>

                  {/* Stats */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
                    <div style={{ textAlign: 'center', padding: '0.5rem', background: '#f8fafc', borderRadius: '0.375rem' }}>
                      <div style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{factory.trustScore}</div>
                      <div style={{ fontSize: '0.625rem', color: '#64748b' }}>{t('dashboard.trustScore', 'Trust Score')}</div>
                    </div>
                    <div style={{ textAlign: 'center', padding: '0.5rem', background: '#f8fafc', borderRadius: '0.375rem' }}>
                      <div style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{factory.orders}</div>
                      <div style={{ fontSize: '0.625rem', color: '#64748b' }}>{t('dashboard.orders', 'Orders')}</div>
                    </div>
                    <div style={{ textAlign: 'center', padding: '0.5rem', background: '#f8fafc', borderRadius: '0.375rem' }}>
                      <div style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>{factory.totalSpent}</div>
                      <div style={{ fontSize: '0.625rem', color: '#64748b' }}>{t('dashboard.spent', 'Spent')}</div>
                    </div>
                  </div>

                  {/* Bank Info */}
                  <div style={{ background: '#f8fafc', borderRadius: '0.5rem', padding: '0.75rem', marginBottom: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.75rem', fontWeight: 600, color: '#0f172a', marginBottom: '0.5rem' }}>
                      <CreditCard style={{ width: 14, height: 14, color: '#06b6d4' }} />
                      {t('dashboard.bankingInfo', 'Banking Information')}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.375rem' }}>
                      <div>
                        <div style={{ fontSize: '0.625rem', color: '#94a3b8', textTransform: 'uppercase' }}>{t('dashboard.bank', 'Bank')}</div>
                        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a' }}>{factory.bankName}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.625rem', color: '#94a3b8', textTransform: 'uppercase' }}>{t('dashboard.account', 'Account')}</div>
                        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a' }}>{factory.bankAccount}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.625rem', color: '#94a3b8', textTransform: 'uppercase' }}>SWIFT</div>
                        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a' }}>{factory.swiftCode}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.625rem', color: '#94a3b8', textTransform: 'uppercase' }}>{t('dashboard.category', 'Category')}</div>
                        <div style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#0f172a' }}>{factory.category}</div>
                      </div>
                    </div>
                  </div>

                  <button style={{ width: '100%', padding: '0.5rem', borderRadius: '0.5rem', background: '#f1f5f9', color: '#334155', border: 'none', fontSize: '0.8125rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.375rem' }}>
                    {t('dashboard.viewProfile', 'View Factory Profile')} <ExternalLink style={{ width: 14, height: 14 }} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
