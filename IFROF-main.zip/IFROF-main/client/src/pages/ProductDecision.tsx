import { useState } from "react";
import { useNavigate } from "wouter";
import { trpc } from "../lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Loader2, TrendingUp, AlertTriangle, Zap, DollarSign, Copy, ArrowRight, Sparkles, Rocket } from "lucide-react";

export default function ProductDecision() {
  const [query, setQuery] = useState("");
  const [, navigate] = useNavigate();
  const [generatedPage, setGeneratedPage] = useState<any>(null);
  const [generatedAd, setGeneratedAd] = useState<any>(null);
  const [readyToLaunch, setReadyToLaunch] = useState(false);
  const startFlowMutation = trpc.unified.startFlow.useMutation();
  const generatePageMutation = trpc.unified.generateProductPage.useMutation();
  const generateAdMutation = trpc.unified.generateAd.useMutation();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    try {
      await startFlowMutation.mutateAsync({ query });
    } catch (error) {
      console.error("Search failed:", error);
    }
  };

  const result = startFlowMutation.data;
  const isLoading = startFlowMutation.isPending;
  const error = startFlowMutation.error;

  const handleGenerateProductPage = async () => {
    if (!result) return;
    try {
      const page = await generatePageMutation.mutateAsync({
        productId: result.product.id,
        productName: result.product.name,
        description: result.analysis.description,
        features: result.analysis.keyFeatures,
      });
      setGeneratedPage(page);
    } catch (err) {
      console.error("Failed to generate product page:", err);
    }
  };

  const handleGenerateAd = async () => {
    if (!result) return;
    try {
      const ad = await generateAdMutation.mutateAsync({
        productName: result.product.name,
        description: result.analysis.description,
        features: result.analysis.keyFeatures,
      });
      setGeneratedAd(ad);
    } catch (err) {
      console.error("Failed to generate ad:", err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Find Your Next Product
          </h1>
          <p className="text-gray-600">
            AI-powered search with verified suppliers and profit insights
          </p>
        </div>

        {/* Search Form */}
        <Card className="mb-8 shadow-md">
          <CardContent className="pt-6">
            <form onSubmit={handleSearch} className="flex gap-2">
              <Input
                type="text"
                placeholder="e.g., LED bulbs, USB cables, ceramic mugs..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                disabled={isLoading || generatedPage || generatedAd || readyToLaunch}
                className="flex-1"
              />
              <Button
                type="submit"
                disabled={isLoading || !query.trim() || generatedPage || generatedAd || readyToLaunch}
                className="px-6 bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Search"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Error State */}
        {error && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex gap-3 items-start">
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-900">Search Failed</h3>
                  <p className="text-red-700 text-sm mt-1">
                    {error.message || "An error occurred while processing your request."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Result State */}
        {result && !generatedPage && !generatedAd && !readyToLaunch && (
          <div className="space-y-6">
            {/* Main Result Card */}
            <Card className="shadow-lg border-2 border-green-200 bg-white">
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Your Product</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">Verified opportunity ready to launch</p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-600" />
                </div>
              </CardHeader>
              <CardContent className="pt-8">
                <div className="grid lg:grid-cols-3 gap-8">
                  {/* Left: Product */}
                  <div className="lg:col-span-1">
                    {result.product.image && (
                      <img
                        src={result.product.image}
                        alt={result.product.name}
                        className="w-full h-48 object-cover rounded-lg mb-4 bg-gray-100"
                      />
                    )}
                    <h2 className="text-xl font-bold text-gray-900 mb-3">
                      {result.product.name}
                    </h2>
                    <div className="space-y-2 bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Your Cost</p>
                      <p className="text-3xl font-bold text-blue-600">
                        ${result.product.costPrice}
                      </p>
                      <p className="text-xs text-gray-500">{result.product.currency}</p>
                    </div>
                  </div>

                  {/* Middle: Supplier & Profit Breakdown */}
                  <div className="lg:col-span-1 space-y-4">
                    {/* Supplier */}
                    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-semibold text-gray-700">Supplier</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <p className="font-semibold text-gray-900 text-sm">
                          {result.supplier.name}
                        </p>
                        <div className="flex items-center gap-2">
                          <div className="flex-1">
                            <p className="text-xs text-gray-600">Trust Score</p>
                            <p className="font-bold text-blue-600">
                              {result.supplier.trustScore}%
                            </p>
                          </div>
                          <div className="flex-1">
                            <p className="text-xs text-gray-600">Status</p>
                            <p className={`font-bold text-xs ${
                              result.supplier.verified
                                ? "text-green-600"
                                : "text-yellow-600"
                            }`}>
                              {result.supplier.verified ? "✓ Verified" : "Pending"}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Profit Breakdown */}
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-green-600" />
                          Profit Breakdown
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between items-center py-2 border-b border-green-200">
                          <span className="text-sm text-gray-700">Your Cost</span>
                          <span className="font-semibold text-gray-900">${result.product.costPrice}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-green-200">
                          <span className="text-sm text-gray-700">Suggested Retail</span>
                          <span className="font-semibold text-gray-900">${result.analysis.retailPrice}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 bg-green-100 px-2 rounded">
                          <span className="text-sm font-semibold text-gray-900">Profit per Unit</span>
                          <span className="font-bold text-green-600 text-lg">${result.analysis.profitEstimate}</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-2">
                          Margin: <span className="font-semibold text-green-700">{result.analysis.marginPercent}%</span>
                        </p>
                      </CardContent>
                    </Card>

                    {/* Confidence Score with Justification */}
                    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-semibold text-gray-700">Confidence Score</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-end gap-3">
                          <p className="text-3xl font-bold text-purple-600">
                            {result.analysis.confidenceScore}
                          </p>
                          <p className="text-xs text-gray-600 pb-1">/100</p>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{ width: `${result.analysis.confidenceScore}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-700 leading-relaxed mt-3 p-2 bg-white rounded border border-purple-200">
                          {result.analysis.confidenceJustification}
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Right: Why This Product */}
                  <div className="lg:col-span-1">
                    <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <Zap className="h-4 w-4 text-amber-500" />
                      Why This Product
                    </h3>
                    <div className="space-y-3">
                      {result.analysis.reasons.map((reason: string, idx: number) => (
                        <div key={idx} className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <p className="text-sm text-gray-700 leading-relaxed">
                            <span className="font-semibold text-amber-700">{idx + 1}.</span> {reason}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Description Section */}
                <div className="border-t mt-8 pt-8">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Product Overview</h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    {result.analysis.description}
                  </p>

                  {result.analysis.keyFeatures && result.analysis.keyFeatures.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">Key Features:</h4>
                      <ul className="grid grid-cols-2 gap-2">
                        {result.analysis.keyFeatures.map((feature: string, idx: number) => (
                          <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                            <span className="text-green-600 font-bold mt-0.5">•</span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Final Decision */}
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-lg p-6 text-center mt-8">
                  <p className="text-white text-lg font-bold">
                    {result.analysis.decision}
                  </p>
                </div>

                {/* Single Action Button */}
                <div className="pt-6">
                  <Button
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-semibold py-3 text-lg"
                    onClick={handleGenerateProductPage}
                    disabled={generatePageMutation.isPending}
                  >
                    {generatePageMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <ArrowRight className="mr-2 h-5 w-5" />
                        Generate Product Page
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Generated Page Preview */}
        {generatedPage && !generatedAd && !readyToLaunch && (
          <Card className="shadow-lg border-2 border-blue-200 bg-white">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50 border-b">
              <CardTitle className="text-2xl text-gray-900">Your Product Page</CardTitle>
            </CardHeader>
            <CardContent className="pt-8">
              <div className="space-y-6">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">{generatedPage.headline}</h2>
                  <p className="text-lg text-gray-700 leading-relaxed mb-6">{generatedPage.body}</p>
                </div>

                {generatedPage.bulletPoints && generatedPage.bulletPoints.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Key Highlights:</h3>
                    <ul className="space-y-2">
                      {generatedPage.bulletPoints.map((point: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-3">
                          <span className="text-green-600 font-bold mt-1">✓</span>
                          <span className="text-gray-700">{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {generatedPage.tags && generatedPage.tags.length > 0 && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">SEO Tags:</h3>
                    <div className="flex flex-wrap gap-2">
                      {generatedPage.tags.map((tag: string, idx: number) => (
                        <span key={idx} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t mt-8 pt-6 flex gap-3">
                <Button
                  className="flex-1 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold"
                  onClick={handleGenerateAd}
                  disabled={generateAdMutation.isPending}
                >
                  {generateAdMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-5 w-5" />
                      Generate Ad
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    const content = `${generatedPage.headline}\n\n${generatedPage.body}\n\nTags: ${generatedPage.tags.join(', ')}`;
                    navigator.clipboard.writeText(content);
                    alert('Product page copied to clipboard!');
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Generated Ad Preview */}
        {generatedAd && !readyToLaunch && (
          <Card className="shadow-lg border-2 border-orange-200 bg-white">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-red-50 border-b">
              <CardTitle className="text-2xl text-gray-900 flex items-center gap-2">
                <Sparkles className="h-6 w-6 text-orange-600" />
                Your Ad
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-8">
              <div className="space-y-8">
                {/* Hook */}
                <div className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-200 rounded-lg p-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">Hook</h3>
                  <p className="text-2xl font-bold text-gray-900">{generatedAd.hook}</p>
                </div>

                {/* Headline */}
                <div className="bg-gradient-to-r from-red-50 to-pink-50 border-2 border-red-200 rounded-lg p-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-2">Ad Headline</h3>
                  <p className="text-xl font-bold text-gray-900">{generatedAd.headline}</p>
                </div>

                {/* Script */}
                <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Ad Script</h3>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{generatedAd.script}</p>
                </div>
              </div>

              <div className="border-t mt-8 pt-6 flex gap-3">
                <Button
                  className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold"
                  onClick={() => setReadyToLaunch(true)}
                >
                  <Rocket className="mr-2 h-5 w-5" />
                  Ready to Launch
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    const content = `Hook: ${generatedAd.hook}\n\nHeadline: ${generatedAd.headline}\n\nScript:\n${generatedAd.script}`;
                    navigator.clipboard.writeText(content);
                    alert('Ad copied to clipboard!');
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Ad
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ready to Launch */}
        {readyToLaunch && (
          <Card className="shadow-lg border-2 border-purple-200 bg-white">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50 border-b">
              <CardTitle className="text-3xl text-gray-900 flex items-center gap-3">
                <Rocket className="h-8 w-8 text-purple-600" />
                Ready to Launch
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-8">
              <div className="space-y-8">
                {/* Checklist */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Launch Checklist</h3>
                  
                  {/* Item 1 */}
                  <div className="flex items-center gap-4 p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Product Selected</p>
                      <p className="text-sm text-gray-600">{result?.product.name}</p>
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div className="flex items-center gap-4 p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Product Page Ready</p>
                      <p className="text-sm text-gray-600">{generatedPage?.headline}</p>
                    </div>
                  </div>

                  {/* Item 3 */}
                  <div className="flex items-center gap-4 p-4 bg-green-50 border-2 border-green-200 rounded-lg">
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Ad Ready</p>
                      <p className="text-sm text-gray-600">{generatedAd?.hook}</p>
                    </div>
                  </div>
                </div>

                {/* Main Message */}
                <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-8 text-center">
                  <p className="text-white text-3xl font-bold mb-2">
                    You are ready to start selling.
                  </p>
                  <p className="text-purple-100 text-lg">
                    All your materials are prepared. Take your product to market with confidence.
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setReadyToLaunch(false);
                      setGeneratedAd(null);
                      setGeneratedPage(null);
                      setQuery("");
                      startFlowMutation.reset();
                    }}
                  >
                    Start Over
                  </Button>
                  <Button
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                    onClick={() => navigate("/")}
                  >
                    Back to Home
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {!result && !isLoading && !error && !generatedPage && !generatedAd && !readyToLaunch && (
          <Card className="text-center py-16">
            <CardContent>
              <p className="text-gray-600 text-lg">
                Enter a product name or category above to get started
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
