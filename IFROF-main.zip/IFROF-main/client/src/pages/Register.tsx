import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import {
  Mail, Lock, User, Building2, Eye, EyeOff, Loader, CheckCircle,
  ArrowLeft, AlertCircle, ArrowRight, Check
} from 'lucide-react';
import { getLoginUrl } from '@/const';
import { trpc } from '@/lib/trpc';
import { trackRegistration } from '@/lib/analytics';

function getPasswordStrength(password: string): { score: number; label: string; color: string } {
  if (!password) return { score: 0, label: '', color: '' };
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return { score, label: 'ضعيفة', color: 'bg-red-500' };
  if (score <= 2) return { score, label: 'مقبولة', color: 'bg-amber-500' };
  if (score <= 3) return { score, label: 'جيدة', color: 'bg-yellow-400' };
  return { score, label: 'قوية', color: 'bg-emerald-500' };
}

export default function Register() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<'role' | 'form'>('role');
  const [role, setRole] = useState<'buyer' | 'factory' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (meQuery.data) {
      setLocation('/');
    }
  }, [meQuery.data, setLocation]);

  const oauthUrl = getLoginUrl();
  const isOAuthConfigured = oauthUrl !== '/login';

  const handleRoleSelect = (selectedRole: 'buyer' | 'factory') => {
    if (selectedRole === 'factory') {
      // Factories are added by admin only — redirect buyer registration
      return;
    }
    setRole(selectedRole);
    if (isOAuthConfigured) {
      window.location.href = oauthUrl;
      return;
    }
    setStep('form');
  };

  const passwordStrength = getPasswordStrength(password);
  const passwordsMatch = confirmPassword.length > 0 && password === confirmPassword;
  const passwordsMismatch = confirmPassword.length > 0 && password !== confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!name.trim()) {
      setError(`Please enter your ${role === 'buyer' ? 'full name' : 'company name'}.`);
      return;
    }

    if (!email.trim()) {
      setError('Please enter a valid email address.');
      return;
    }

    if (!password) {
      setError('Please choose a password.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter your password.');
      return;
    }

    if (!agreedToTerms) {
      setError('Please agree to the Terms of Service to create your account.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password, name, role }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Registration failed');
      }

      setSuccess('Your account has been created! Redirecting you now...');
      trackRegistration(role ?? undefined);
      await meQuery.refetch();
      setTimeout(() => setLocation('/dashboard?welcome=1'), 1200);
    } catch (err: any) {
      setError(err.message || 'We could not create your account. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (meQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-cyan-900 to-slate-900">
        <div className="flex flex-col items-center gap-4 text-white">
          <Loader className="w-8 h-8 animate-spin text-cyan-400" />
          <p className="text-sm text-cyan-100/70">جارٍ التحقق من الجلسة...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-cyan-900 to-slate-900 flex items-center justify-center py-12 px-4">
      <div className="w-full max-w-md">
        {/* Brand header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 shadow-md shadow-cyan-400/20 mb-4">
            <span className="text-2xl font-bold text-white">IF</span>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">IFROF</h1>
          <p className="text-cyan-100/80">انضم إلى ثورة التجارة بين الشركات</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200">
          {/* Step indicator */}
          <div className="px-8 py-4 border-b border-gray-100 bg-gray-50/60">
            <div className="flex items-center gap-3">
              <StepDot step={1} label="اختر الدور" active={step === 'role'} completed={step === 'form'} />
              <div className={`flex-1 h-px transition-colors ${step === 'form' ? 'bg-cyan-500' : 'bg-gray-200'}`} />
              <StepDot step={2} label="بياناتك" active={step === 'form'} completed={false} />
            </div>
          </div>

          <div className="px-8 py-8">
            {step === 'role' ? (
              <>
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">أنشئ حسابك</h2>
                  <p className="text-gray-500 mt-1 text-sm">كيف ستستخدم IFROF؟</p>
                </div>

                <div className="space-y-3">
                  {/* Buyer Option */}
                  <button
                    onClick={() => handleRoleSelect('buyer')}
                    className="w-full p-4 border border-gray-200 hover:border-cyan-500 hover:bg-cyan-50/50 rounded-xl transition-all text-left group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-cyan-100 group-hover:bg-cyan-200 rounded-lg flex items-center justify-center shrink-0 transition-colors">
                        <User className="w-5 h-5 text-cyan-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 group-hover:text-cyan-700 transition-colors">
                          أنا مشتري
                        </h3>
                        <p className="text-sm text-gray-500 mt-0.5">
                          استورد منتجات من مصانع دولية موثقة
                        </p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-cyan-500 shrink-0 transition-colors" />
                    </div>
                  </button>

                  {/* Factory — admin-only */}
                  <div className="w-full p-4 border border-dashed border-gray-200 rounded-xl bg-gray-50 text-left opacity-75">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center shrink-0">
                        <Building2 className="w-5 h-5 text-amber-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-500">
                          مصنع / مورّد
                        </h3>
                        <p className="text-sm text-gray-400 mt-0.5">
                          يُضاف المصانع من قِبل فريق IFROF فقط — تواصل معنا عبر الدردشة.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Divider */}
                <div className="flex items-center gap-3 my-5">
                  <div className="flex-1 h-px bg-gray-200"></div>
                  <span className="text-xs text-gray-400 font-medium">أو سجّل بسرعة عبر</span>
                  <div className="flex-1 h-px bg-gray-200"></div>
                </div>

                {/* Google Sign-Up */}
                <button
                  onClick={() => { window.location.href = '/api/auth/google'; }}
                  className="w-full bg-white hover:bg-gray-50 border border-gray-200 hover:border-gray-300 text-gray-700 font-semibold py-3 rounded-xl shadow-sm transition-all flex items-center justify-center gap-3 active:scale-95"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  </svg>
                  المتابعة عبر Google
                </button>

                <p className="text-center text-sm text-gray-600 mt-6">
                  لديك حساب بالفعل؟{' '}
                  <Link href="/login" className="text-cyan-600 hover:text-cyan-700 font-semibold">
                    تسجيل الدخول
                  </Link>
                </p>
              </>
            ) : (
              <>
                {/* Back button */}
                <button
                  onClick={() => { setStep('role'); setError(''); }}
                  className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-800 mb-5 transition-colors group"
                >
                  <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
                  رجوع
                </button>

                <div className="mb-6">
                  <div className="flex items-center gap-2.5 mb-1">
                    {role === 'buyer' ? (
                      <div className="w-6 h-6 bg-cyan-100 rounded-md flex items-center justify-center">
                        <User className="w-3 h-3 text-cyan-600" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 bg-amber-100 rounded-md flex items-center justify-center">
                        <Building2 className="w-3 h-3 text-amber-600" />
                      </div>
                    )}
                    <span className="text-sm font-medium text-gray-500">
                      {role === 'buyer' ? 'حساب مشتري' : 'حساب مصنع / مورّد'}
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900">بياناتك</h2>
                  <p className="text-gray-500 mt-1 text-sm">أكمل بياناتك لإتمام الإعداد</p>
                </div>

                {error && (
                  <div className="mb-5 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex items-start gap-3">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {success && (
                  <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 text-sm flex items-center gap-3">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>{success}</span>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1.5">
                      {role === 'buyer' ? 'الاسم الكامل' : 'اسم الشركة'}
                    </label>
                    <div className="relative">
                      {role === 'buyer' ? (
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      ) : (
                        <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      )}
                      <input
                        id="name"
                        type="text"
                        autoComplete={role === 'buyer' ? 'name' : 'organization'}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={role === 'buyer' ? 'مثال: أحمد محمد' : 'مثال: شركة الصناعات المتحدة'}
                        className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all text-sm"
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1.5">
                      البريد الإلكتروني
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        id="email"
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="بريدك@example.com"
                        className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all text-sm"
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1.5">
                      كلمة المرور
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="6 أحرف على الأقل"
                        className="w-full pl-9 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all text-sm"
                        disabled={isSubmitting}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                        disabled={isSubmitting}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {/* Password strength */}
                    {password.length > 0 && (
                      <div className="mt-2 space-y-1.5">
                        <div className="flex gap-1">
                          {[1, 2, 3, 4].map((i) => (
                            <div
                              key={i}
                              className={`h-1 flex-1 rounded-full transition-all ${
                                i <= passwordStrength.score ? passwordStrength.color : 'bg-gray-200'
                              }`}
                            />
                          ))}
                        </div>
                        {passwordStrength.label && (
                          <p className="text-xs text-gray-500">
                            قوة كلمة المرور: <span className="font-medium text-gray-700">{passwordStrength.label}</span>
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1.5">
                      تأكيد كلمة المرور
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        id="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="أعد إدخال كلمة المرور"
                        className={`w-full pl-9 pr-12 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:border-transparent transition-all text-sm ${
                          passwordsMismatch
                            ? 'border-red-300 focus:ring-red-400'
                            : passwordsMatch
                            ? 'border-emerald-400 focus:ring-emerald-400'
                            : 'border-gray-300 focus:ring-cyan-500'
                        }`}
                        disabled={isSubmitting}
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                        disabled={isSubmitting}
                      >
                        {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      {passwordsMatch && (
                        <Check className="absolute right-10 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                      )}
                    </div>
                    {passwordsMismatch && (
                      <p className="mt-1.5 text-xs text-red-600">كلمتا المرور غير متطابقتين</p>
                    )}
                  </div>

                  {/* Terms checkbox */}
                  <label className="flex items-start gap-3 cursor-pointer group">
                    <div className="relative mt-0.5">
                      <input
                        type="checkbox"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="sr-only peer"
                        disabled={isSubmitting}
                      />
                      <div className="w-4 h-4 border border-gray-300 rounded peer-checked:bg-cyan-600 peer-checked:border-cyan-600 transition-all flex items-center justify-center group-hover:border-cyan-400">
                        {agreedToTerms && <Check className="w-2.5 h-2.5 text-white" strokeWidth={3} />}
                      </div>
                    </div>
                    <span className="text-sm text-gray-600 leading-tight">
                      أوافق على{' '}
                      <a href="/page/terms-and-conditions" target="_blank" rel="noopener noreferrer" className="text-cyan-600 hover:text-cyan-700 underline">شروط الخدمة</a>
                      {' '}و{' '}
                      <a href="/page/privacy-policy" target="_blank" rel="noopener noreferrer" className="text-cyan-600 hover:text-cyan-700 underline">سياسة الخصوصية</a>
                    </span>
                  </label>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-cyan-600 to-cyan-700 hover:from-cyan-700 hover:to-cyan-800 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-xl shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 active:scale-95 mt-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        جارٍ إنشاء حسابك...
                      </>
                    ) : (
                      <>
                        إنشاء حساب
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>

                <p className="text-center text-sm text-gray-600 mt-5">
                  لديك حساب بالفعل؟{' '}
                  <Link href="/login" className="text-cyan-600 hover:text-cyan-700 font-semibold">
                    تسجيل الدخول
                  </Link>
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StepDot({
  step,
  label,
  active,
  completed,
}: {
  step: number;
  label: string;
  active: boolean;
  completed: boolean;
}) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
          completed
            ? 'bg-cyan-600 text-white'
            : active
            ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-200'
            : 'bg-gray-200 text-gray-500'
        }`}
      >
        {completed ? <Check className="w-3 h-3" strokeWidth={3} /> : step}
      </div>
      <span className={`text-[10px] font-medium whitespace-nowrap ${active ? 'text-cyan-700' : 'text-gray-400'}`}>
        {label}
      </span>
    </div>
  );
}