import { Link } from 'wouter';
import { trpc } from '@/lib/trpc';
import { ShoppingCart, Trash2, Plus, Minus, ArrowRight, Package } from 'lucide-react';

export default function Cart() {
  const { data, isLoading, refetch } = trpc.cart.getCart.useQuery();
  const removeItemMutation = trpc.cart.removeItem.useMutation({ onSuccess: () => refetch() });
  const updateQtyMutation = trpc.cart.updateQuantity.useMutation({ onSuccess: () => refetch() });
  const clearCartMutation = trpc.cart.clearCart.useMutation({ onSuccess: () => refetch() });

  const items = data?.items ?? [];
  const total = items.reduce((sum: number, row: any) => {
    const price = row.product?.price ?? 0;
    const qty = row.cartItem?.quantity ?? 0;
    return sum + (price / 100) * qty;
  }, 0);

  if (isLoading) {
    return (
      <div style={{ paddingTop: '6rem', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <ShoppingCart size={48} style={{ margin: '0 auto 1rem', opacity: 0.4 }} />
          <p>جارٍ تحميل السلة...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ paddingTop: '5rem', minHeight: '100vh', background: '#f8fafc', direction: 'rtl' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '2rem 1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '2rem' }}>
          <ShoppingCart size={28} style={{ color: '#e53e3e' }} />
          <h1 style={{ fontSize: '1.75rem', fontWeight: 700, color: '#1e293b', margin: 0 }}>سلة المشتريات</h1>
          {items.length > 0 && (
            <span style={{ background: '#e53e3e', color: '#fff', borderRadius: '9999px', padding: '0.15rem 0.6rem', fontSize: '0.85rem', fontWeight: 600 }}>
              {items.length}
            </span>
          )}
        </div>

        {items.length === 0 ? (
          <div style={{ background: '#fff', borderRadius: 16, padding: '4rem 2rem', textAlign: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
            <ShoppingCart size={64} style={{ color: '#cbd5e1', margin: '0 auto 1.5rem' }} />
            <h2 style={{ color: '#334155', marginBottom: '0.5rem' }}>السلة فارغة</h2>
            <p style={{ color: '#64748b', marginBottom: '2rem' }}>لم تُضف أي منتجات بعد. ابدأ التسوق من السوق.</p>
            <Link href="/marketplace">
              <button style={{ background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 10, padding: '0.75rem 2rem', fontWeight: 600, cursor: 'pointer', fontSize: '1rem' }}>
                تصفح السوق
              </button>
            </Link>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '1.5rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {items.map((row: any) => {
                const item = row.cartItem;
                const product = row.product;
                const factory = row.factory;
                if (!product) return null;
                const price = product.price / 100;
                const images = (() => { try { return JSON.parse(product.images || '[]'); } catch { return []; } })();
                const img = images[0] || 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=200&h=200&fit=crop';

                return (
                  <div key={item.id} style={{ background: '#fff', borderRadius: 14, padding: '1.25rem', boxShadow: '0 1px 4px rgba(0,0,0,0.06)', display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    <Link href={`/products/${product.id}`}>
                      <img src={img} alt={product.name} style={{ width: 90, height: 90, objectFit: 'cover', borderRadius: 10, flexShrink: 0, cursor: 'pointer' }} />
                    </Link>
                    <div style={{ flex: 1 }}>
                      <Link href={`/products/${product.id}`}>
                        <p style={{ fontWeight: 600, color: '#1e293b', marginBottom: '0.25rem', cursor: 'pointer' }}>{product.name}</p>
                      </Link>
                      {factory && (
                        <Link href={`/factory/${factory.id}`}>
                          <p style={{ fontSize: '0.82rem', color: '#e53e3e', marginBottom: '0.5rem', cursor: 'pointer' }}>{factory.name}</p>
                        </Link>
                      )}
                      <p style={{ fontSize: '1.1rem', fontWeight: 700, color: '#16a34a' }}>${price.toFixed(2)}</p>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: '#f1f5f9', borderRadius: 8, padding: '0.25rem' }}>
                        <button
                          onClick={() => updateQtyMutation.mutate({ cartItemId: item.id, quantity: item.quantity - 1 })}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '0.25rem', color: '#475569' }}
                        >
                          <Minus size={14} />
                        </button>
                        <span style={{ minWidth: 28, textAlign: 'center', fontWeight: 600, fontSize: '0.95rem' }}>{item.quantity}</span>
                        <button
                          onClick={() => updateQtyMutation.mutate({ cartItemId: item.id, quantity: item.quantity + 1 })}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '0.25rem', color: '#475569' }}
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                      <p style={{ fontSize: '0.9rem', fontWeight: 600, color: '#334155' }}>${(price * item.quantity).toFixed(2)}</p>
                      <button
                        onClick={() => removeItemMutation.mutate({ cartItemId: item.id })}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', padding: '0.25rem' }}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                );
              })}

              <button
                onClick={() => clearCartMutation.mutate()}
                style={{ alignSelf: 'flex-start', background: 'none', border: '1px solid #fca5a5', color: '#ef4444', borderRadius: 8, padding: '0.5rem 1rem', cursor: 'pointer', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}
              >
                <Trash2 size={14} /> إفراغ السلة
              </button>
            </div>

            <div style={{ background: '#fff', borderRadius: 16, padding: '1.5rem', boxShadow: '0 1px 4px rgba(0,0,0,0.06)', height: 'fit-content', position: 'sticky', top: '6rem' }}>
              <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#1e293b', marginBottom: '1.25rem' }}>ملخص الطلب</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginBottom: '1.25rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b', fontSize: '0.9rem' }}>
                  <span>المنتجات ({items.length})</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b', fontSize: '0.9rem' }}>
                  <span>الشحن</span>
                  <span style={{ color: '#16a34a' }}>يُحسب عند الدفع</span>
                </div>
                <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '0.75rem', display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1.1rem', color: '#1e293b' }}>
                  <span>المجموع</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <Link href="/checkout">
                <button style={{ width: '100%', background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 10, padding: '0.875rem', fontWeight: 700, cursor: 'pointer', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                  إتمام الطلب <ArrowRight size={16} />
                </button>
              </Link>
              <Link href="/marketplace">
                <button style={{ width: '100%', background: 'none', border: '1px solid #e2e8f0', color: '#475569', borderRadius: 10, padding: '0.75rem', fontWeight: 600, cursor: 'pointer', fontSize: '0.9rem', marginTop: '0.75rem' }}>
                  متابعة التسوق
                </button>
              </Link>
              <div style={{ marginTop: '1rem', background: '#f0fdf4', borderRadius: 8, padding: '0.75rem', display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
                <Package size={16} style={{ color: '#16a34a', flexShrink: 0, marginTop: 2 }} />
                <p style={{ fontSize: '0.8rem', color: '#166534', margin: 0 }}>جميع المنتجات من موردين موثوقين ومعتمدين.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
