/**
 * RfqWizard.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function RfqWizard() {
  return (
    <ComingSoon
      title="طلب عروض الأسعار"
      description="أرسل طلب عرض سعر لمئات الموردين الموثوقين في الصين دفعةً واحدة — قريباً."
      icon="📋"
      features={["إرسال RFQ لموردين متعددين", "مقارنة العروض تلقائياً", "التفاوض المباشر عبر المنصة", "ضمان جودة الموردين"]}
      backHref="/"
      primaryCta={{ label: 'ابحث عن مصنع الآن', href: '/factory-finder' }}
    />
  );
}
