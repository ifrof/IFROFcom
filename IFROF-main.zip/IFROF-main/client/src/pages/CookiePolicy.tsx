/**
 * CookiePolicy.tsx — Cookie Policy page for IFROF
 */
import { Link } from 'wouter';
import { Cookie, ChevronLeft } from 'lucide-react';

export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: '"DM Sans", sans-serif' }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 to-cyan-900 py-16 px-4 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 mb-4">
          <Cookie className="w-7 h-7 text-cyan-400" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white mb-3">Cookie Policy</h1>
        <p className="text-cyan-100/70 text-sm max-w-lg mx-auto">
          Last updated: March 2026
        </p>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="prose prose-gray max-w-none space-y-8 text-gray-700 text-[15px] leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">1. What Are Cookies?</h2>
            <p>
              Cookies are small text files that are stored on your device when you visit a website. They help the
              website remember your preferences and improve your experience on subsequent visits.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">2. How We Use Cookies</h2>
            <p>IFROF uses the following types of cookies:</p>
            <div className="mt-3 space-y-3">
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-1">Essential Cookies</h3>
                <p className="text-sm">Required for the Platform to function. These include your session cookie that keeps you logged in.</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-1">Preference Cookies</h3>
                <p className="text-sm">Remember your settings such as language preference and display options.</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
                <h3 className="font-bold text-gray-900 mb-1">Analytics Cookies</h3>
                <p className="text-sm">Help us understand how visitors interact with the Platform so we can improve it.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">3. Managing Cookies</h2>
            <p>
              You can control and manage cookies through your browser settings. Most browsers allow you to refuse
              cookies or delete existing ones. Note that disabling essential cookies may prevent you from logging in
              or using key features of the Platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">4. Third-Party Cookies</h2>
            <p>
              We may use third-party services such as Google Analytics that set their own cookies. These are governed
              by the respective third parties' privacy policies.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">5. Contact Us</h2>
            <p>For questions about our cookie practices, contact us at:</p>
            <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-100">
              <p><strong>IFROF</strong></p>
              <p>Email: <a href="mailto:ifrof4@gmail.com" className="text-cyan-600 hover:underline">ifrof4@gmail.com</a></p>
            </div>
          </section>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-100 flex items-center gap-4">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-cyan-600 hover:text-cyan-700 font-semibold">
            <ChevronLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <Link href="/page/privacy-policy" className="text-sm text-gray-500 hover:text-gray-700">
            Privacy Policy →
          </Link>
        </div>
      </div>
    </div>
  );
}
