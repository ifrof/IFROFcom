import { useState } from 'react';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import { ChevronDown, MessageSquare, Search } from 'lucide-react';

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ borderBottom: '1px solid #e2e8f0' }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '1.25rem 0', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
        }}
      >
        <span style={{ fontWeight: 600, fontSize: '1.0625rem', color: '#0f172a', paddingRight: '1rem' }}>{q}</span>
        <ChevronDown style={{
          width: 20, height: 20, color: '#64748b', flexShrink: 0,
          transition: 'transform 200ms', transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
        }} />
      </button>
      {open && (
        <div style={{ paddingBottom: '1.25rem', color: '#475569', lineHeight: 1.7, fontSize: '0.9375rem' }}>
          {a}
        </div>
      )}
    </div>
  );
}

export default function Faq() {
  const { t } = useTranslation();
  const [search, setSearch] = useState('');

  const FAQ_ITEMS = [
    { q: t('home.faq_1_q'), a: t('home.faq_1_a') },
    { q: t('home.faq_2_q'), a: t('home.faq_2_a') },
    { q: t('home.faq_3_q'), a: t('home.faq_3_a') },
    { q: t('home.faq_4_q'), a: t('home.faq_4_a') },
    { q: t('home.faq_5_q'), a: t('home.faq_5_a') },
    { q: t('home.faq_6_q'), a: t('home.faq_6_a') },
    { q: t('home.faq_7_q'), a: t('home.faq_7_a') },
  ];

  const filtered = search.trim()
    ? FAQ_ITEMS.filter(item =>
        item.q.toLowerCase().includes(search.toLowerCase()) ||
        item.a.toLowerCase().includes(search.toLowerCase())
      )
    : FAQ_ITEMS;

  return (
    <div style={{ background: '#f8fafc', minHeight: '100vh' }}>
      {/* Header */}
      <section style={{
        padding: '4rem 0 3rem',
        background: 'linear-gradient(150deg, #060d1a 0%, #0c1a2e 40%, #0a1628 100%)',
        color: 'white', textAlign: 'center',
      }}>
        <div className="container" style={{ maxWidth: 720, margin: '0 auto', padding: '0 1.5rem' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            {t('home.faq_title')}
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: '1.0625rem', lineHeight: 1.6 }}>
            {t('home.faq_subtitle')}
          </p>
        </div>
      </section>

      {/* Content */}
      <div className="container" style={{ maxWidth: 760, margin: '0 auto', padding: '2.5rem 1.5rem 4rem' }}>
        {/* Search */}
        <div style={{ position: 'relative', marginBottom: '2rem' }}>
          <Search style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: '#94a3b8' }} />
          <input
            type="text"
            placeholder={t('home.faq_title')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: '100%', padding: '0.875rem 1rem 0.875rem 2.75rem',
              borderRadius: '0.75rem', border: '1.5px solid #e2e8f0',
              fontSize: '0.9375rem', outline: 'none', background: 'white',
            }}
          />
        </div>

        {/* FAQ List */}
        <div style={{ background: 'white', borderRadius: '1rem', padding: '0.5rem 2rem', boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          {filtered.length > 0 ? (
            filtered.map((item, i) => <FAQItem key={i} q={item.q} a={item.a} />)
          ) : (
            <div style={{ padding: '3rem 0', textAlign: 'center', color: '#64748b' }}>
              No matching questions found.
            </div>
          )}
        </div>

        {/* CTA */}
        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <p style={{ color: '#64748b', marginBottom: '1rem', fontSize: '0.9375rem' }}>
            {t('home.faq_still_questions')}
          </p>
          <Link href="/inbox" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            padding: '0.875rem 2rem', borderRadius: '0.75rem',
            background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white',
            textDecoration: 'none', fontWeight: 700, fontSize: '0.9375rem',
          }}>
            <MessageSquare style={{ width: 18, height: 18 }} />
            {t('nav.liveChat', 'Live Chat')}
          </Link>
        </div>
      </div>
    </div>
  );
}
