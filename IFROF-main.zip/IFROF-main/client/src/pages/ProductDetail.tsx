/**
 * Product Detail Page - Shopify-style design
 * Professional product page with image gallery, specs, reviews, and add to cart
 */
import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { Star, Heart, Share2, ShoppingCart, Shield, Truck, RotateCcw, Check, ChevronLeft, ChevronRight, MapPin, Award, FileText, X } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { trpc } from '@/lib/trpc';

export default function ProductDetail() {
  const { id } = useParams();
  const productId = parseInt(id || '0');

  const { data: product, isLoading } = trpc.products.getById.useQuery({ id: productId });
  const { addItem } = useCart();
  const submitQuote = trpc.quotes.submit.useMutation();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [quoteForm, setQuoteForm] = useState({ name: '', email: '', phone: '', company: '', quantity: 1, message: '' });
  const [quoteSubmitted, setQuoteSubmitted] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading product...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">المنتج غير موجود</h2>
          <p className="text-slate-600 mb-4">The product you're looking for doesn't exist.</p>
          <Link href="/marketplace" className="text-cyan-600 hover:text-cyan-700 font-semibold">
            ← Back to Marketplace
          </Link>
        </div>
      </div>
    );
  }

  const images = product.images || [];
  const discount = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;

  const handleAddToCart = () => {
    addItem({
      id: product.id.toString(),
      productId: product.id.toString(),
      name: product.name,
      price: product.price / 100,
      quantity,
      image: images[0] || '',
      seller: product.factory?.name || 'Unknown',
      minOrder: product.minOrder || 1,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container py-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Link href="/" className="hover:text-cyan-600">Home</Link>
            <span>/</span>
            <Link href="/marketplace" className="hover:text-cyan-600">Marketplace</Link>
            <span>/</span>
            <Link href={`/marketplace?category=${product.category?.slug}`} className="hover:text-cyan-600">
              {product.category?.name}
            </Link>
            <span>/</span>
            <span className="text-slate-900 font-medium">{product.name}</span>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Images */}
          <div>
            {/* Main Image */}
            <div className="bg-white rounded-2xl overflow-hidden mb-4 relative group">
              <img
                src={images[selectedImage] || 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800&h=800&fit=crop'}
                alt={product.name}
                className="w-full aspect-square object-cover"
                loading="lazy"
                decoding="async"
              />
              {discount > 0 && (
                <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  -{discount}%
                </div>
              )}
              {product.featured && product.featured !== 'none' && (
                <div className="absolute top-4 right-4 bg-amber-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1">
                  <Award className="w-4 h-4" />
                  {product.featured.replace('_', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                </div>
              )}
              {/* Navigation Arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setSelectedImage((selectedImage - 1 + images.length) % images.length)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <ChevronLeft className="w-6 h-6 text-slate-900" />
                  </button>
                  <button
                    onClick={() => setSelectedImage((selectedImage + 1) % images.length)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <ChevronRight className="w-6 h-6 text-slate-900" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnail Gallery */}
            {images.length > 1 && (
              <div className="grid grid-cols-5 gap-2">
                {images.map((img: string, idx: number) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`bg-white rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === idx ? 'border-cyan-500 ring-2 ring-cyan-200' : 'border-transparent hover:border-slate-300'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full aspect-square object-cover" loading="lazy" decoding="async" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column - Product Info */}
          <div>
            {/* Factory Link */}
            <Link href={`/factory/${product.factory?.id}`} className="inline-flex items-center gap-2 text-sm text-slate-600 hover:text-cyan-600 mb-3">
              <MapPin className="w-4 h-4" />
              {product.factory?.name}
              {product.factory?.verified === 'verified' && (
                <Shield className="w-4 h-4 text-green-500" />
              )}
            </Link>

            {/* Product Name */}
            <h1 className="text-3xl font-bold text-slate-900 mb-4">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor((product.rating || 0) / 10) ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-slate-600">
                {((product.rating || 0) / 10).toFixed(1)} ({product.reviewCount || 0} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-bold text-slate-900">
                  ${(product.price / 100).toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-2xl text-slate-400 line-through">
                    ${(product.originalPrice / 100).toFixed(2)}
                  </span>
                )}
                <span className="text-sm text-slate-600">/ {product.unit}</span>
              </div>
              <p className="text-sm text-slate-600 mt-2">
                Minimum Order: <span className="font-semibold text-slate-900">{product.minOrder} {product.unit}</span>
              </p>
            </div>

            {/* Stock Status */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2 text-green-700">
                <Check className="w-5 h-5" />
                <span className="font-semibold">In Stock</span>
                <span className="text-sm">({product.stockQuantity?.toLocaleString()} units available)</span>
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-900 mb-2">Quantity</label>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(Math.max(product.minOrder || 1, quantity - 1))}
                  className="w-10 h-10 rounded-lg border-2 border-slate-300 hover:border-cyan-500 flex items-center justify-center font-bold text-slate-700"
                >
                  −
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(product.minOrder || 1, parseInt(e.target.value) || 1))}
                  className="w-20 h-10 text-center border-2 border-slate-300 rounded-lg font-semibold"
                />
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-lg border-2 border-slate-300 hover:border-cyan-500 flex items-center justify-center font-bold text-slate-700"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mb-4">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-4 px-6 rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                أضف إلى السلة
              </button>
            </div>
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => { setShowQuoteModal(true); setQuoteSubmitted(false); }}
                className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <FileText className="w-5 h-5" />
                طلب عرض سعر
              </button>
              <button
                onClick={() => setIsWishlisted(!isWishlisted)}
                className={`w-14 h-14 rounded-xl border-2 flex items-center justify-center transition-all ${
                  isWishlisted ? 'bg-red-50 border-red-500 text-red-500' : 'border-slate-300 text-slate-600 hover:border-red-500 hover:text-red-500'
                }`}
              >
                <Heart className={`w-6 h-6 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
              <button className="w-14 h-14 rounded-xl border-2 border-slate-300 text-slate-600 hover:border-cyan-500 hover:text-cyan-600 flex items-center justify-center transition-all">
                <Share2 className="w-6 h-6" />
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="text-center p-4 bg-white rounded-lg border">
                <Shield className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <p className="text-xs font-semibold text-slate-900">Buyer Protection</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg border">
                <Truck className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="text-xs font-semibold text-slate-900">Fast Shipping</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg border">
                <RotateCcw className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                <p className="text-xs font-semibold text-slate-900">Easy Returns</p>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white rounded-xl p-6 border">
              <h3 className="text-lg font-bold text-slate-900 mb-3">وصف المنتج</h3>
              <p className="text-slate-600 leading-relaxed">{product.description}</p>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-12 bg-white rounded-xl p-8 border">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Customer Reviews</h2>
          <div className="flex items-center gap-8 mb-8 pb-8 border-b">
            <div className="text-center">
              <div className="text-5xl font-bold text-slate-900 mb-2">
                {((product.rating || 0) / 10).toFixed(1)}
              </div>
              <div className="flex items-center gap-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-sm text-slate-600">{product.reviewCount || 0} reviews</p>
            </div>
            <div className="flex-1">
              {[5, 4, 3, 2, 1].map((stars, idx) => {
                const widths = [72, 18, 6, 3, 1];
                return (
                  <div key={stars} className="flex items-center gap-3 mb-2" style={{ direction: 'rtl' }}>
                    <span className="text-sm text-slate-600 w-12">{stars} نجوم</span>
                    <div className="flex-1 bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-amber-400 h-2 rounded-full"
                        style={{ width: `${widths[idx]}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-slate-600 w-12 text-left">{widths[idx]}%</span>
                  </div>
                );
              })}
            </div>
          </div>
          <p className="text-center text-slate-600" style={{ direction: 'rtl' }}>سيتم عرض التقييمات هنا قريباً</p>
        </div>
      </div>

      {/* Quote Request Modal */}
      {showQuoteModal && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: '#fff', borderRadius: 18, padding: '2rem', maxWidth: 480, width: '100%', direction: 'rtl', position: 'relative' }}>
            <button onClick={() => setShowQuoteModal(false)} style={{ position: 'absolute', top: '1rem', left: '1rem', background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}>
              <X size={20} />
            </button>
            {quoteSubmitted ? (
              <div style={{ textAlign: 'center', padding: '2rem 0' }}>
                <div style={{ width: 64, height: 64, background: '#f0fdf4', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
                  <Check size={32} style={{ color: '#16a34a' }} />
                </div>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 700, color: '#1e293b', marginBottom: '0.5rem' }}>تم إرسال طلبك!</h3>
                <p style={{ color: '#64748b' }}>سنتواصل معك خلال 24 ساعة بعرض السعر.</p>
                <button onClick={() => setShowQuoteModal(false)} style={{ marginTop: '1.5rem', background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 10, padding: '0.75rem 2rem', fontWeight: 600, cursor: 'pointer' }}>إغلاق</button>
              </div>
            ) : (
              <>
                <h3 style={{ fontSize: '1.2rem', fontWeight: 700, color: '#1e293b', marginBottom: '1.25rem' }}>طلب عرض سعر</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  <input placeholder="الاسم الكامل *" value={quoteForm.name} onChange={e => setQuoteForm(f => ({ ...f, name: e.target.value }))} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  <input placeholder="البريد الإلكتروني *" value={quoteForm.email} onChange={e => setQuoteForm(f => ({ ...f, email: e.target.value }))} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  <input placeholder="رقم الهاتف" value={quoteForm.phone} onChange={e => setQuoteForm(f => ({ ...f, phone: e.target.value }))} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  <input placeholder="اسم الشركة" value={quoteForm.company} onChange={e => setQuoteForm(f => ({ ...f, company: e.target.value }))} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  <input type="number" placeholder="الكمية المطلوبة *" min={1} value={quoteForm.quantity} onChange={e => setQuoteForm(f => ({ ...f, quantity: parseInt(e.target.value) || 1 }))} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  <textarea placeholder="ملاحظات إضافية..." value={quoteForm.message} onChange={e => setQuoteForm(f => ({ ...f, message: e.target.value }))} rows={3} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.9rem', outline: 'none', width: '100%', boxSizing: 'border-box', resize: 'none' }} />
                </div>
                <button
                  disabled={submitQuote.isPending || !quoteForm.name || !quoteForm.email}
                  onClick={async () => {
                    await submitQuote.mutateAsync({ productId, ...quoteForm });
                    setQuoteSubmitted(true);
                  }}
                  style={{ marginTop: '1.25rem', width: '100%', background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 10, padding: '0.875rem', fontWeight: 700, cursor: 'pointer', fontSize: '1rem', opacity: submitQuote.isPending ? 0.7 : 1 }}
                >
                  {submitQuote.isPending ? 'جارٍ الإرسال...' : 'إرسال الطلب'}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
