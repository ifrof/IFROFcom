import { useState } from 'react';
import { Link } from 'wouter';
import { User, Mail, MapPin, Phone, LogOut, Edit2, Check, Loader } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Profile() {
  const { user, isLoading, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    location: '',
    bio: ''
  });

  const handleSave = () => {
    // Profile updates will be handled via a real API endpoint when available
    setIsEditing(false);
  };

  const handleLogout = async () => {
    await logout();
    window.location.href = '/';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-cyan-500" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">يرجى تسجيل الدخول</h1>
          <Link href="/login" className="text-cyan-600 hover:text-cyan-700 font-semibold">
            الذهاب لتسجيل الدخول
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="container py-8">
          <h1 className="text-4xl font-bold">ملفي الشخصي</h1>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              {/* Avatar */}
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-cyan-500 to-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-12 h-12 text-white" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">{user.name || 'مستخدم'}</h2>
                <p className="text-sm text-gray-600 capitalize">{user.role}</p>
              </div>

              {/* Menu */}
              <nav className="space-y-2">
                <Link href="/orders" className="block w-full text-right px-4 py-2 hover:bg-gray-100 rounded-lg transition-colors font-medium text-gray-900">
                  طلباتي
                </Link>
                <Link href="/wishlist" className="block w-full text-right px-4 py-2 hover:bg-gray-100 rounded-lg transition-colors font-medium text-gray-900">
                  المفضلة
                </Link>
                <Link href="/settings" className="block w-full text-right px-4 py-2 hover:bg-gray-100 rounded-lg transition-colors font-medium text-gray-900">
                  الإعدادات
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full text-right px-4 py-2 hover:bg-red-50 rounded-lg transition-colors font-medium text-red-600 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  تسجيل الخروج
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Profile Information */}
            <div className="bg-white rounded-lg shadow p-8 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">معلومات الملف الشخصي</h2>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center gap-2 px-4 py-2 text-cyan-600 hover:text-cyan-700 font-semibold"
                  >
                    <Edit2 className="w-4 h-4" />
                    تعديل
                  </button>
                ) : (
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-lg"
                  >
                    <Check className="w-4 h-4" />
                    حفظ
                  </button>
                )}
              </div>

              <div className="space-y-6">
                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      الاسم الكامل
                    </div>
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  ) : (
                    <p className="text-gray-900">{user.name || 'غير متوفر'}</p>
                  )}
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      البريد الإلكتروني
                    </div>
                  </label>
                  <p className="text-gray-900">{user.email || 'غير متوفر'}</p>
                  <p className="text-xs text-gray-600 mt-1">لا يمكن تغيير البريد الإلكتروني</p>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      رقم الهاتف
                    </div>
                  </label>
                  {isEditing ? (
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (555) 000-0000"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  ) : (
                    <p className="text-gray-900">{formData.phone || 'غير متوفر'}</p>
                  )}
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      الموقع
                    </div>
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="المدينة، البلد"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  ) : (
                    <p className="text-gray-900">{formData.location || 'غير متوفر'}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Account Statistics */}
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="text-3xl font-bold text-cyan-600 mb-2">12</div>
                <p className="text-gray-600">إجمالي الطلبات</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="text-3xl font-bold text-emerald-600 mb-2">$45.2K</div>
                <p className="text-gray-600">إجمالي الإنفاق</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6 text-center">
                <div className="text-3xl font-bold text-amber-600 mb-2">98%</div>
                <p className="text-gray-600">معدل الرضا</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
