import { ComingSoon } from "@/components/ComingSoon";

export default function Forum() {
  return (
    <div className="py-20">
      <ComingSoon 
        title="Community Forum" 
        description="We're building a space for professional importers to connect, share experiences, and grow together."
      />
    </div>
  );
}
