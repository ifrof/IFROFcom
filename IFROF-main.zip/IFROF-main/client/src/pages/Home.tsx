/**
 * IFROF Home Page — v4.0 "Multilingual & Clear"
 * Fully internationalized with useTranslation(). Arabic-first, RTL-ready.
 * Sections:
 *   1. Hero
 *   2. Trust Bar
 *   3. Pain → Solution
 *   4. How It Works
 *   5. Services
 *   6. Stats
 *   7. Testimonials
 *   8. Comparison Table
 *   9. FAQ
 *  10. Final CTA
 */
import { Link } from 'wouter';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SEO } from '@/components/SEO';
import { trpc } from '@/lib/trpc';
import {
  ArrowRight, Shield, CheckCircle, Zap, Globe,
  Package, TrendingUp, Star, Clock, MessageSquare,
  Award, Lock, Search, ChevronRight, ChevronDown,
  DollarSign, AlertTriangle, ThumbsUp, Layers, X, Check,
  Flame, HeartHandshake, Factory, Sparkles, BadgeCheck, Repeat,
} from 'lucide-react';

// ─── Hooks ───────────────────────────────────────────────────────────────────

function useVisible(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setVisible(true); },
      { threshold },
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return { ref, isVisible: visible };
}

// ─── Animated Counter ────────────────────────────────────────────────────────

function Counter({ to, suffix = '', prefix = '' }: { to: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  const { ref, isVisible } = useVisible(0.4);
  useEffect(() => {
    if (!isVisible) return;
    let start = 0;
    const duration = 1800;
    const step = to / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= to) { setCount(to); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [isVisible, to]);
  return <span ref={ref}>{prefix}{count.toLocaleString()}{suffix}</span>;
}

// ─── Section Header ──────────────────────────────────────────────────────────

function SectionHeader({
  badge, badgeColor = '#06b6d4', badgeBg = 'rgba(6,182,212,0.08)', badgeBorder = 'rgba(6,182,212,0.2)',
  title, subtitle, center = true,
}: {
  badge?: string; badgeColor?: string; badgeBg?: string; badgeBorder?: string;
  title: React.ReactNode; subtitle?: string; center?: boolean;
}) {
  return (
    <div style={{ textAlign: center ? 'center' : undefined, marginBottom: '3.5rem' }}>
      {badge && (
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
          background: badgeBg, border: `1px solid ${badgeBorder}`,
          borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1rem',
        }}>
          <Sparkles style={{ width: 13, height: 13, color: badgeColor }} />
          <span style={{ color: badgeColor, fontSize: '0.8125rem', fontWeight: 700, letterSpacing: '0.02em' }}>{badge}</span>
        </div>
      )}
      <h2 style={{
        fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.875rem, 4vw, 3rem)',
        fontWeight: 800, color: '#0f172a', letterSpacing: '-0.025em',
        marginBottom: subtitle ? '1rem' : 0, lineHeight: 1.15,
      }}>{title}</h2>
      {subtitle && (
        <p style={{
          fontSize: '1.125rem', color: '#64748b', maxWidth: center ? 560 : '100%',
          margin: center ? '0 auto' : 0, lineHeight: 1.7,
        }}>{subtitle}</p>
      )}
    </div>
  );
}

// ─── Live Activity Feed ──────────────────────────────────────────────────────

function LiveActivityFeed() {
  const { t } = useTranslation();
  const items = [
    { flag: '🇸🇦', name: 'Ahmed K.', action: t('home.activity_1'), amount: '$12,400', time: '2m' },
    { flag: '🇺🇸', name: 'Sarah M.', action: t('home.activity_2'), amount: '8 weeks', time: '5m' },
    { flag: '🇩🇪', name: 'Thomas W.', action: t('home.activity_3'), amount: '$8,200', time: '9m' },
    { flag: '🇦🇪', name: 'Rania H.', action: t('home.activity_4'), amount: '65%', time: '12m' },
    { flag: '🇬🇧', name: 'James L.', action: t('home.activity_5'), amount: 'Shenzhen', time: '18m' },
    { flag: '🇫🇷', name: 'Amira B.', action: t('home.activity_6'), amount: 'Istanbul', time: '21m' },
    { flag: '🇦🇺', name: 'Liam T.', action: t('home.activity_7'), amount: '5,000', time: '25m' },
    { flag: '🇨🇦', name: 'Priya S.', action: t('home.activity_8'), amount: '48h', time: '31m' },
  ];

  const [current, setCurrent] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    const interval = setInterval(() => {
      setVisible(false);
      timeout = setTimeout(() => {
        setCurrent(c => (c + 1) % items.length);
        setVisible(true);
      }, 400);
    }, 3500);
    return () => { clearInterval(interval); clearTimeout(timeout); };
  }, [items.length]);

  const item = items[current];

  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: '0.75rem',
      background: 'rgba(255,255,255,0.06)', backdropFilter: 'blur(12px)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: '2rem', padding: '0.625rem 1.25rem',
      transition: 'opacity 400ms ease', opacity: visible ? 1 : 0,
      maxWidth: '100%',
    }}>
      <span style={{
        width: 8, height: 8, borderRadius: '50%', background: '#22c55e', flexShrink: 0,
        boxShadow: '0 0 0 3px rgba(34,197,94,0.25)', animation: 'pulse-dot 2s ease infinite',
      }} />
      <span style={{ fontSize: '0.8125rem', color: 'rgba(255,255,255,0.75)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        <strong style={{ color: 'white' }}>{item.flag} {item.name}</strong> {item.action}{' '}
        <strong style={{ color: '#22d3ee' }}>{item.amount}</strong>
      </span>
    </div>
  );
}

// ─── Testimonial Card ────────────────────────────────────────────────────────

function TestimonialCard({ quote, name, role, country, flag, result, avatar }: {
  quote: string; name: string; role: string; country: string; flag: string; result: string; avatar: string;
}) {
  return (
    <div style={{
      background: 'white', borderRadius: '1.25rem', padding: '2rem',
      border: '1px solid #e2e8f0', boxShadow: '0 4px 24px rgba(0,0,0,0.05)',
      display: 'flex', flexDirection: 'column', gap: '1.25rem',
      transition: 'transform 250ms, box-shadow 250ms',
    }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-6px)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 20px 48px rgba(0,0,0,0.1)'; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 4px 24px rgba(0,0,0,0.05)'; }}
    >
      <div style={{ display: 'flex', gap: '0.25rem' }}>
        {[1, 2, 3, 4, 5].map(i => <Star key={i} style={{ width: 15, height: 15, color: '#f59e0b', fill: '#f59e0b' }} />)}
      </div>
      <p style={{ fontSize: '0.9375rem', color: '#334155', lineHeight: 1.75, fontStyle: 'italic', flex: 1 }}>"{quote}"</p>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.75rem', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: 42, height: 42, borderRadius: '50%',
            background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontWeight: 800, fontSize: '1rem', fontFamily: 'Sora, sans-serif', flexShrink: 0,
          }}>{avatar}</div>
          <div>
            <div style={{ fontWeight: 700, color: '#0f172a', fontSize: '0.9375rem', fontFamily: 'Sora, sans-serif' }}>{name}</div>
            <div style={{ fontSize: '0.8125rem', color: '#64748b' }}>{role} · {flag} {country}</div>
          </div>
        </div>
        <div style={{
          padding: '0.3rem 0.875rem', borderRadius: '2rem',
          background: 'rgba(16,185,129,0.1)', color: '#059669',
          fontSize: '0.8125rem', fontWeight: 700, border: '1px solid rgba(16,185,129,0.2)', whiteSpace: 'nowrap',
        }}>{result}</div>
      </div>
    </div>
  );
}

// ─── FAQ Item ────────────────────────────────────────────────────────────────

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{
      border: '1px solid #e2e8f0', borderRadius: '0.875rem', overflow: 'hidden',
      transition: 'box-shadow 200ms', boxShadow: open ? '0 4px 20px rgba(6,182,212,0.1)' : 'none',
    }}>
      <button onClick={() => setOpen(v => !v)} style={{
        width: '100%', padding: '1.25rem 1.5rem',
        background: open ? 'linear-gradient(135deg, rgba(6,182,212,0.04), rgba(139,92,246,0.04))' : 'white',
        border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem',
        textAlign: 'start', transition: 'background 200ms',
      }}>
        <span style={{ fontWeight: 700, color: '#0f172a', fontSize: '1rem', fontFamily: 'Sora, sans-serif', lineHeight: 1.4 }}>{q}</span>
        <ChevronDown style={{ width: 18, height: 18, color: '#06b6d4', flexShrink: 0, transition: 'transform 250ms', transform: open ? 'rotate(180deg)' : 'rotate(0deg)' }} />
      </button>
      {open && (
        <div style={{ padding: '0 1.5rem 1.25rem', background: 'linear-gradient(135deg, rgba(6,182,212,0.02), rgba(139,92,246,0.02))', borderTop: '1px solid #f1f5f9' }}>
          <p style={{ fontSize: '0.9375rem', color: '#475569', lineHeight: 1.75, margin: '1rem 0 0' }}>{a}</p>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═════════════════════════════════════════════════════════════════════════════

export default function Home() {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const hero = useVisible(0.05);
  const trust = useVisible(0.12);
  const pain = useVisible(0.12);
  const how = useVisible(0.12);
  const services = useVisible(0.12);
  const stats = useVisible(0.12);
  const testi = useVisible(0.12);
  const compare = useVisible(0.12);
  const faq = useVisible(0.12);
  const cta = useVisible(0.12);
  const blog = useVisible(0.12);

  const { data: blogData } = trpc.blog.listArticles.useQuery(
    { status: 'published', limit: 3 },
    { staleTime: 5 * 60 * 1000 }
  );
  const blogPosts = blogData?.slice(0, 3) ?? [];


  const [activeService, setActiveService] = useState(0);

  const SERVICES = [
    {
      href: '/services/concierge', icon: HeartHandshake, color: '#06b6d4',
      badge: t('home.service_1_badge'), badgeBg: 'rgba(6,182,212,0.1)',
      title: t('home.service_1_title'), tagline: t('home.service_1_tagline'),
      desc: t('home.service_1_desc'), price: t('home.service_1_price'), priceNote: t('home.service_1_priceNote'),
      features: [t('home.service_1_f1'), t('home.service_1_f2'), t('home.service_1_f3'), t('home.service_1_f4'), t('home.service_1_f5'), t('home.service_1_f6')],
    },
    {
      href: '/services/brand-launch', icon: Award, color: '#8b5cf6',
      badge: t('home.service_2_badge'), badgeBg: 'rgba(139,92,246,0.1)',
      title: t('home.service_2_title'), tagline: t('home.service_2_tagline'),
      desc: t('home.service_2_desc'), price: t('home.service_2_price'), priceNote: t('home.service_2_priceNote'),
      features: [t('home.service_2_f1'), t('home.service_2_f2'), t('home.service_2_f3'), t('home.service_2_f4'), t('home.service_2_f5'), t('home.service_2_f6')],
    },
    {
      href: '/services/stock-liquidation', icon: TrendingUp, color: '#f59e0b',
      badge: t('home.service_3_badge'), badgeBg: 'rgba(245,158,11,0.1)',
      title: t('home.service_3_title'), tagline: t('home.service_3_tagline'),
      desc: t('home.service_3_desc'), price: t('home.service_3_price'), priceNote: t('home.service_3_priceNote'),
      features: [t('home.service_3_f1'), t('home.service_3_f2'), t('home.service_3_f3'), t('home.service_3_f4'), t('home.service_3_f5'), t('home.service_3_f6')],
    },
    {
      href: '/services/escrow', icon: Lock, color: '#10b981',
      badge: t('home.service_4_badge'), badgeBg: 'rgba(16,185,129,0.1)',
      title: t('home.service_4_title'), tagline: t('home.service_4_tagline'),
      desc: t('home.service_4_desc'), price: t('home.service_4_price'), priceNote: t('home.service_4_priceNote'),
      features: [t('home.service_4_f1'), t('home.service_4_f2'), t('home.service_4_f3'), t('home.service_4_f4'), t('home.service_4_f5'), t('home.service_4_f6')],
    },
  ];

  const PAIN_ITEMS = [
    { icon: AlertTriangle, color: '#ef4444', problem: t('home.pain_1_problem'), before: t('home.pain_1_before'), after: t('home.pain_1_after') },
    { icon: Package, color: '#f59e0b', problem: t('home.pain_2_problem'), before: t('home.pain_2_before'), after: t('home.pain_2_after') },
    { icon: Clock, color: '#8b5cf6', problem: t('home.pain_3_problem'), before: t('home.pain_3_before'), after: t('home.pain_3_after') },
    { icon: DollarSign, color: '#06b6d4', problem: t('home.pain_4_problem'), before: t('home.pain_4_before'), after: t('home.pain_4_after') },
    { icon: MessageSquare, color: '#10b981', problem: t('home.pain_5_problem'), before: t('home.pain_5_before'), after: t('home.pain_5_after') },
    { icon: Search, color: '#ec4899', problem: t('home.pain_6_problem'), before: t('home.pain_6_before'), after: t('home.pain_6_after') },
  ];

  const HOW_STEPS = [
    { num: '01', icon: MessageSquare, color: '#06b6d4', title: t('home.how_step_1_title'), desc: t('home.how_step_1_desc') },
    { num: '02', icon: Search, color: '#8b5cf6', title: t('home.how_step_2_title'), desc: t('home.how_step_2_desc') },
    { num: '03', icon: Shield, color: '#10b981', title: t('home.how_step_3_title'), desc: t('home.how_step_3_desc') },
    { num: '04', icon: Factory, color: '#f59e0b', title: t('home.how_step_4_title'), desc: t('home.how_step_4_desc') },
    { num: '05', icon: ThumbsUp, color: '#ec4899', title: t('home.how_step_5_title'), desc: t('home.how_step_5_desc') },
  ];

  const COMPARE_ROWS: [string, boolean, boolean | string, boolean | string][] = [
    [t('home.compare_row_1'), true, false, t('home.compare_sometimes')],
    [t('home.compare_row_2'), true, false, false],
    [t('home.compare_row_3'), true, false, t('home.compare_extra_cost')],
    [t('home.compare_row_4'), true, false, true],
    [t('home.compare_row_5'), true, false, true],
    [t('home.compare_row_6'), true, false, false],
    [t('home.compare_row_7'), true, false, false],
    [t('home.compare_row_8'), true, false, t('home.compare_varies')],
    [t('home.compare_row_9'), true, false, false],
  ];

  const FAQ_ITEMS = [
    { q: t('home.faq_1_q'), a: t('home.faq_1_a') },
    { q: t('home.faq_2_q'), a: t('home.faq_2_a') },
    { q: t('home.faq_3_q'), a: t('home.faq_3_a') },
    { q: t('home.faq_4_q'), a: t('home.faq_4_a') },
    { q: t('home.faq_5_q'), a: t('home.faq_5_a') },
    { q: t('home.faq_6_q'), a: t('home.faq_6_a') },
    { q: t('home.faq_7_q'), a: t('home.faq_7_a') },
  ];

  const COUNTRIES = [
    '🇸🇦 Saudi Arabia', '🇦🇪 UAE', '🇺🇸 USA', '🇬🇧 UK',
    '🇩🇪 Germany', '🇫🇷 France', '🇦🇺 Australia', '🇨🇦 Canada',
    '🇧🇷 Brazil', '🇿🇦 South Africa', '🇳🇬 Nigeria', '🇯🇴 Jordan',
  ];

  return (
    <div style={{ background: '#f8fafc', overflowX: 'hidden' }}>
      <SEO
        title="منصة التوريد العالمية | ابحث عن مصانع صينية موثقة"
        description="IFROF — منصة B2B لربط المستوردين العالميين بمصانع صينية موثقة. بحث بالذكاء الاصطناعي، طلبات أسعار، ضمان الدفع، وشحن جماعي. ابدأ مجاناً."
        keywords="مصانع صينية, استيراد من الصين, B2B sourcing, factory finder, verified suppliers, IFROF"
        url="https://ifrof.com"
      />
      <style>{`
        @keyframes floatUp { from { transform: translateY(0px); } to { transform: translateY(-10px); } }
        @keyframes pulse-dot { 0%,100% { box-shadow: 0 0 0 3px rgba(34,197,94,0.25); } 50% { box-shadow: 0 0 0 6px rgba(34,197,94,0.1); } }
        @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
        .animate-fade-up { animation: fadeUp 0.6s ease forwards; }
        .opacity-0 { opacity: 0; }
      `}</style>

      {/* ══════════════════════════════════════════════════════════════════════
          1. HERO
      ══════════════════════════════════════════════════════════════════════ */}
      <section style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        background: 'linear-gradient(150deg, #060d1a 0%, #0c1a2e 35%, #0a1628 65%, #0d1f38 100%)',
        position: 'relative', overflow: 'hidden', paddingTop: '5rem',
      }}>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(6,182,212,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.035) 1px, transparent 1px)', backgroundSize: '64px 64px' }} />
          <div style={{ position: 'absolute', top: '10%', right: '5%', width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle, rgba(6,182,212,0.1) 0%, transparent 65%)', filter: 'blur(40px)' }} />
          <div style={{ position: 'absolute', bottom: '5%', left: '0%', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 65%)', filter: 'blur(40px)' }} />
        </div>

        <div className="container" style={{ position: 'relative', zIndex: 1, padding: '4rem 1rem 5rem' }}>
          <div ref={hero.ref} style={{ maxWidth: 860, margin: '0 auto', textAlign: 'center' }}>

            {/* Badge */}
            <div className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ animationDelay: '0ms', marginBottom: '1.75rem' }}>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
                background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.2)',
                borderRadius: '2rem', padding: '0.5rem 1.25rem',
              }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#22c55e', animation: 'pulse-dot 2s ease infinite', flexShrink: 0 }} />
                <span style={{ color: '#67e8f9', fontSize: '0.8125rem', fontWeight: 700, letterSpacing: '0.04em' }}>
                  {t('home.hero_badge')}
                </span>
              </div>
            </div>

            {/* Headline */}
            <h1 className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
              animationDelay: '80ms', fontFamily: 'Sora, sans-serif', fontWeight: 800,
              fontSize: 'clamp(2.75rem, 7vw, 5rem)', lineHeight: 1.08, letterSpacing: '-0.035em',
              color: 'white', marginBottom: '1.75rem',
            }}>
              {t('home.hero_title_1')}{' '}
              <span style={{
                background: 'linear-gradient(135deg, #06b6d4 0%, #818cf8 50%, #06b6d4 100%)',
                backgroundSize: '200% auto', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                animation: 'shimmer 4s linear infinite',
              }}>
                {t('home.hero_title_2')}
              </span>
              <br />{t('home.hero_title_3')}
            </h1>

            {/* Sub-headline */}
            <p className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
              animationDelay: '160ms', fontSize: 'clamp(1.0625rem, 2.5vw, 1.3125rem)',
              color: 'rgba(255,255,255,0.6)', lineHeight: 1.75,
              maxWidth: 660, margin: '0 auto 2.5rem', fontFamily: 'DM Sans, sans-serif',
            }}>
              {t('home.hero_desc')}
            </p>

            {/* CTAs */}
            <div className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
              animationDelay: '240ms', display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '2.5rem',
            }}>
              <Link href="/rfq" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
                padding: '1.0625rem 2.5rem', borderRadius: '0.875rem',
                background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
                color: 'white', fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '1.0625rem',
                textDecoration: 'none', boxShadow: '0 16px 40px rgba(6,182,212,0.45)',
                transition: 'transform 200ms, box-shadow 200ms',
              }}>
                <Zap style={{ width: 18, height: 18 }} />
                {t('home.hero_cta_primary')}
                <ArrowRight style={{ width: 16, height: 16, transform: isRTL ? 'scaleX(-1)' : undefined }} />
              </Link>
              <Link href="/factory-finder" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
                padding: '1.0625rem 2.25rem', borderRadius: '0.875rem',
                background: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(12px)',
                color: 'rgba(255,255,255,0.9)', fontFamily: 'DM Sans, sans-serif', fontWeight: 600, fontSize: '1.0625rem',
                textDecoration: 'none', border: '1px solid rgba(255,255,255,0.12)', transition: 'background 200ms',
              }}>
                <Search style={{ width: 16, height: 16 }} />
                {t('home.hero_cta_secondary')}
              </Link>
            </div>

            {/* Trust micro-copy */}
            <div className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
              animationDelay: '300ms', display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '3rem',
            }}>
              {[
                { icon: Shield, text: t('home.hero_trust_1') },
                { icon: BadgeCheck, text: t('home.hero_trust_2') },
                { icon: Clock, text: t('home.hero_trust_3') },
                { icon: HeartHandshake, text: t('home.hero_trust_4') },
              ].map((item, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: 'rgba(255,255,255,0.45)', fontSize: '0.875rem', fontWeight: 500 }}>
                  <item.icon style={{ width: 14, height: 14, color: '#22d3ee' }} />
                  {item.text}
                </div>
              ))}
            </div>

            {/* Live Activity */}
            <div className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ animationDelay: '360ms', display: 'flex', justifyContent: 'center' }}>
              <LiveActivityFeed />
            </div>

            {/* Stats row */}
            <div className={hero.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
              animationDelay: '440ms', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
              gap: '1rem', maxWidth: 760, margin: '3.5rem auto 0',
            }}>
              {[
                { value: 2400, suffix: '+', label: t('home.hero_stat_1_label'), color: '#06b6d4' },
                { value: 8, suffix: 'M+', label: t('home.hero_stat_2_label'), color: '#10b981', prefix: '$' },
                { value: 340, suffix: '+', label: t('home.hero_stat_3_label'), color: '#8b5cf6' },
                { value: 60, suffix: '+', label: t('home.hero_stat_4_label'), color: '#f59e0b' },
              ].map((stat, i) => (
                <div key={i} style={{
                  background: 'rgba(255,255,255,0.04)', backdropFilter: 'blur(12px)',
                  border: '1px solid rgba(255,255,255,0.07)', borderRadius: '1rem', padding: '1.25rem', textAlign: 'center',
                }}>
                  <div style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.875rem', fontWeight: 800, color: stat.color, lineHeight: 1 }}>
                    <Counter to={stat.value} suffix={stat.suffix} prefix={stat.prefix ?? ''} />
                  </div>
                  <div style={{ fontSize: '0.8125rem', color: 'rgba(255,255,255,0.4)', marginTop: '0.375rem', fontWeight: 500 }}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{
          position: 'absolute', bottom: '2rem', left: '50%', transform: 'translateX(-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem',
          color: 'rgba(255,255,255,0.25)', fontSize: '0.75rem', animation: 'floatUp 2s ease-in-out infinite alternate',
        }}>
          <span>{t('home.scroll_to_explore')}</span>
          <ChevronDown style={{ width: 16, height: 16 }} />
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          2. TRUST BAR
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={trust.ref} style={{ padding: '3.5rem 0', background: 'white', borderBottom: '1px solid #f1f5f9' }}>
        <div className="container">
          <p style={{
            textAlign: 'center', fontSize: '0.75rem', fontWeight: 700,
            color: '#94a3b8', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: '1.75rem',
          }}>
            {t('home.trust_bar_title')}
          </p>
          <div className={trust.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap', alignItems: 'center',
          }}>
            {COUNTRIES.map((c, i) => (
              <div key={i} style={{
                padding: '0.4375rem 1rem', borderRadius: '2rem',
                background: '#f8fafc', border: '1px solid #e2e8f0',
                fontSize: '0.875rem', fontWeight: 600, color: '#475569', transition: 'all 150ms',
              }}>{c}</div>
            ))}
          </div>

          <div className={trust.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'flex', gap: '2rem', justifyContent: 'center', flexWrap: 'wrap', marginTop: '2.5rem',
          }}>
            {[
              { icon: Shield, color: '#10b981', label: t('home.trust_metric_1_label'), sub: t('home.trust_metric_1_sub') },
              { icon: Star, color: '#f59e0b', label: t('home.trust_metric_2_label'), sub: t('home.trust_metric_2_sub') },
              { icon: Clock, color: '#06b6d4', label: t('home.trust_metric_3_label'), sub: t('home.trust_metric_3_sub') },
              { icon: BadgeCheck, color: '#8b5cf6', label: t('home.trust_metric_4_label'), sub: t('home.trust_metric_4_sub') },
            ].map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '0.625rem', background: `${item.color}12`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <item.icon style={{ width: 17, height: 17, color: item.color }} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.9375rem', color: '#0f172a', fontFamily: 'Sora, sans-serif' }}>{item.label}</div>
                  <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{item.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          3. PAIN → SOLUTION
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={pain.ref} style={{ padding: '6rem 0', background: '#f8fafc' }}>
        <div className="container">
          <div className={pain.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader
              badge={t('home.pain_badge')} badgeColor="#ef4444" badgeBg="rgba(239,68,68,0.07)" badgeBorder="rgba(239,68,68,0.2)"
              title={<>{t('home.pain_title_1')}<br />{t('home.pain_title_2')}</>}
              subtitle={t('home.pain_subtitle')}
            />
          </div>

          <div className={pain.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem',
          }}>
            {PAIN_ITEMS.map((item, i) => (
              <div key={i} style={{
                background: 'white', borderRadius: '1.125rem', border: '1px solid #e2e8f0',
                overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,0.04)', transition: 'transform 250ms, box-shadow 250ms',
              }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-5px)'; (e.currentTarget as HTMLElement).style.boxShadow = `0 16px 40px ${item.color}18`; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 2px 12px rgba(0,0,0,0.04)'; }}
              >
                <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{ width: 40, height: 40, borderRadius: '0.75rem', background: `${item.color}12`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <item.icon style={{ width: 20, height: 20, color: item.color }} />
                  </div>
                  <h3 style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a', fontFamily: 'Sora, sans-serif', margin: 0 }}>{item.problem}</h3>
                </div>
                <div style={{ padding: '1.25rem 1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  <div style={{ padding: '0.875rem 1rem', borderRadius: '0.75rem', background: 'rgba(239,68,68,0.04)', border: '1px solid rgba(239,68,68,0.12)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', marginBottom: '0.375rem' }}>
                      <X style={{ width: 13, height: 13, color: '#ef4444', flexShrink: 0 }} />
                      <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#ef4444', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t('home.without_ifrof')}</span>
                    </div>
                    <p style={{ fontSize: '0.875rem', color: '#64748b', margin: 0, lineHeight: 1.6 }}>{item.before}</p>
                  </div>
                  <div style={{ padding: '0.875rem 1rem', borderRadius: '0.75rem', background: 'rgba(16,185,129,0.04)', border: '1px solid rgba(16,185,129,0.15)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', marginBottom: '0.375rem' }}>
                      <Check style={{ width: 13, height: 13, color: '#10b981', flexShrink: 0 }} />
                      <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#10b981', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t('home.with_ifrof')}</span>
                    </div>
                    <p style={{ fontSize: '0.875rem', color: '#334155', margin: 0, lineHeight: 1.6 }}>{item.after}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          4. HOW IT WORKS
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={how.ref} style={{ padding: '6rem 0', background: 'white' }}>
        <div className="container">
          <div className={how.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader badge={t('home.how_badge')} title={t('home.how_title')} subtitle={t('home.how_subtitle')} />
          </div>

          <div className={how.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '0', position: 'relative',
          }}>
            {HOW_STEPS.map((step, i) => (
              <div key={i} style={{ position: 'relative', textAlign: 'center', padding: '2.5rem 1.5rem 2rem' }}>
                <div style={{ position: 'relative', display: 'inline-block', marginBottom: '1.5rem' }}>
                  <div style={{
                    width: 80, height: 80, borderRadius: '50%',
                    background: `linear-gradient(135deg, ${step.color}, ${step.color}bb)`,
                    boxShadow: `0 12px 32px ${step.color}40`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto',
                  }}>
                    <step.icon style={{ width: 34, height: 34, color: 'white' }} />
                  </div>
                  <div style={{
                    position: 'absolute', top: -4, right: -4,
                    width: 26, height: 26, borderRadius: '50%',
                    background: 'white', border: `2.5px solid ${step.color}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '0.6875rem', fontWeight: 800, color: step.color, fontFamily: 'Sora, sans-serif',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  }}>{step.num}</div>
                </div>
                <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.0625rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.625rem' }}>{step.title}</h3>
                <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: 1.7, maxWidth: 220, margin: '0 auto' }}>{step.desc}</p>
              </div>
            ))}
          </div>

          <div className={how.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ textAlign: 'center', marginTop: '3rem' }}>
            <Link href="/rfq" style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
              padding: '0.9375rem 2.25rem', borderRadius: '0.875rem',
              background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
              color: 'white', fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '1.0625rem',
              textDecoration: 'none', boxShadow: '0 10px 28px rgba(6,182,212,0.35)',
            }}>
              {t('home.how_cta')} <ArrowRight style={{ width: 17, height: 17, transform: isRTL ? 'scaleX(-1)' : undefined }} />
            </Link>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          5. SERVICES
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={services.ref} style={{ padding: '6rem 0', background: '#f8fafc' }}>
        <div className="container">
          <div className={services.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader badge={t('home.services_badge')} title={t('home.services_title')} subtitle={t('home.services_subtitle')} />
          </div>

          <div className={services.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '2.5rem',
          }}>
            {SERVICES.map((s, i) => (
              <button key={i} onClick={() => setActiveService(i)} style={{
                display: 'flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.625rem 1.25rem', borderRadius: '2rem',
                border: `2px solid ${activeService === i ? s.color : '#e2e8f0'}`,
                background: activeService === i ? s.badgeBg : 'white',
                color: activeService === i ? s.color : '#64748b',
                fontWeight: 700, fontSize: '0.9375rem', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', transition: 'all 200ms',
              }}>
                <s.icon style={{ width: 16, height: 16 }} /> {s.title}
              </button>
            ))}
          </div>

          {SERVICES.map((service, i) => (
            <div key={i} style={{ display: activeService === i ? 'block' : 'none' }}>
              <div className={services.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
                background: 'white', borderRadius: '1.5rem', border: `2px solid ${service.color}25`,
                boxShadow: `0 20px 60px ${service.color}12`, overflow: 'hidden',
              }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 0 }}>
                  <div style={{ padding: '3rem', borderInlineEnd: '1px solid #f1f5f9' }}>
                    <div style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                      padding: '0.3rem 0.875rem', borderRadius: '2rem', background: service.badgeBg, color: service.color,
                      fontSize: '0.75rem', fontWeight: 700, marginBottom: '1.5rem',
                    }}>
                      <Flame style={{ width: 11, height: 11 }} /> {service.badge}
                    </div>
                    <div style={{
                      width: 60, height: 60, borderRadius: '1rem', background: `${service.color}15`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.25rem',
                    }}>
                      <service.icon style={{ width: 28, height: 28, color: service.color }} />
                    </div>
                    <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.625rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>{service.title}</h3>
                    <p style={{ fontSize: '1rem', color: service.color, fontWeight: 600, marginBottom: '1.25rem' }}>{service.tagline}</p>
                    <p style={{ fontSize: '0.9375rem', color: '#475569', lineHeight: 1.75, marginBottom: '2rem' }}>{service.desc}</p>
                    <div style={{
                      padding: '1.25rem', borderRadius: '0.875rem', background: `${service.color}08`,
                      border: `1px solid ${service.color}20`, marginBottom: '2rem',
                    }}>
                      <div style={{ fontSize: '1.5rem', fontWeight: 800, color: service.color, fontFamily: 'Sora, sans-serif' }}>{service.price}</div>
                      <div style={{ fontSize: '0.8125rem', color: '#64748b', marginTop: '0.25rem' }}>{service.priceNote}</div>
                    </div>
                    <Link href={service.href} style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                      padding: '0.875rem 1.875rem', borderRadius: '0.75rem',
                      background: `linear-gradient(135deg, ${service.color}, ${service.color}cc)`,
                      color: 'white', fontWeight: 700, fontSize: '1rem', textDecoration: 'none',
                      boxShadow: `0 8px 24px ${service.color}35`,
                    }}>
                      {t('home.get_started')} <ArrowRight style={{ width: 16, height: 16, transform: isRTL ? 'scaleX(-1)' : undefined }} />
                    </Link>
                  </div>
                  <div style={{ padding: '3rem', background: '#fafbfc' }}>
                    <h4 style={{
                      fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '0.875rem', color: '#94a3b8',
                      textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '1.5rem',
                    }}>{t('home.whats_included')}</h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                      {service.features.map((f, j) => (
                        <div key={j} style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
                          <div style={{
                            width: 28, height: 28, borderRadius: '50%', background: `${service.color}15`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                          }}>
                            <CheckCircle style={{ width: 14, height: 14, color: service.color }} />
                          </div>
                          <span style={{ fontSize: '0.9375rem', color: '#334155', fontWeight: 500 }}>{f}</span>
                        </div>
                      ))}
                    </div>
                    <div style={{
                      marginTop: '2.5rem', padding: '1.5rem', borderRadius: '1rem',
                      background: 'linear-gradient(135deg, rgba(16,185,129,0.06), rgba(6,182,212,0.06))',
                      border: '1px solid rgba(16,185,129,0.15)',
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '0.625rem' }}>
                        <Shield style={{ width: 18, height: 18, color: '#10b981' }} />
                        <span style={{ fontWeight: 700, color: '#0f172a', fontFamily: 'Sora, sans-serif' }}>{t('home.guarantee_title')}</span>
                      </div>
                      <p style={{ fontSize: '0.875rem', color: '#475569', margin: 0, lineHeight: 1.6 }}>{t('home.guarantee_desc')}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          6. STATS
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={stats.ref} style={{
        padding: '5rem 0', background: 'linear-gradient(135deg, #0c1a2e, #0f172a)', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(6,182,212,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.03) 1px, transparent 1px)', backgroundSize: '60px 60px', pointerEvents: 'none' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div className={stats.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '2rem', textAlign: 'center',
          }}>
            {[
              { value: 2400, suffix: '+', label: t('home.stats_1_label'), sub: t('home.stats_1_sub'), color: '#06b6d4' },
              { value: 8, suffix: 'M+', label: t('home.stats_2_label'), sub: t('home.stats_2_sub'), color: '#10b981', prefix: '$' },
              { value: 340, suffix: '+', label: t('home.stats_3_label'), sub: t('home.stats_3_sub'), color: '#8b5cf6' },
              { value: 0, suffix: '', label: t('home.stats_4_label'), sub: t('home.stats_4_sub'), color: '#f59e0b' },
              { value: 4, suffix: '.9', label: t('home.stats_5_label'), sub: t('home.stats_5_sub'), color: '#ec4899' },
              { value: 22, suffix: '%', label: t('home.stats_6_label'), sub: t('home.stats_6_sub'), color: '#f97316' },
            ].map((stat, i) => (
              <div key={i} style={{ padding: '1rem' }}>
                <div style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, color: stat.color, lineHeight: 1, marginBottom: '0.5rem' }}>
                  <Counter to={stat.value} suffix={stat.suffix} prefix={stat.prefix ?? ''} />
                </div>
                <div style={{ fontWeight: 700, color: 'white', fontSize: '1rem', marginBottom: '0.25rem', fontFamily: 'Sora, sans-serif' }}>{stat.label}</div>
                <div style={{ fontSize: '0.8125rem', color: 'rgba(255,255,255,0.35)' }}>{stat.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          7. TESTIMONIALS
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={testi.ref} style={{ padding: '6rem 0', background: 'white' }}>
        <div className="container">
          <div className={testi.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader
              badge={t('home.testimonials_badge')} badgeColor="#d97706" badgeBg="rgba(245,158,11,0.08)" badgeBorder="rgba(245,158,11,0.2)"
              title={t('home.testimonials_title')} subtitle={t('home.testimonials_subtitle')}
            />
          </div>
          <div className={testi.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem',
          }}>
            {[1, 2, 3, 4, 5, 6].map(n => (
              <TestimonialCard
                key={n}
                quote={t(`home.testimonial_${n}_text`)}
                name={t(`home.testimonial_${n}_author`)}
                role={t(`home.testimonial_${n}_role`)}
                country={t(`home.testimonial_${n}_country`)}
                flag={['🇸🇦', '🇺🇸', '🇳🇬', '🇦🇪', '🇩🇪', '🇫🇷'][n - 1]}
                result={t(`home.testimonial_${n}_result`)}
                avatar={['MA', 'SC', 'YO', 'RK', 'TW', 'AB'][n - 1]}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          8. COMPARISON TABLE
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={compare.ref} style={{ padding: '6rem 0', background: '#f8fafc' }}>
        <div className="container">
          <div className={compare.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader badge={t('home.compare_badge')} title={t('home.compare_title')} subtitle={t('home.compare_subtitle')} />
          </div>
          <div className={compare.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ overflowX: 'auto' }}>
            <table style={{
              width: '100%', borderCollapse: 'separate', borderSpacing: 0,
              background: 'white', borderRadius: '1.25rem', border: '1px solid #e2e8f0',
              boxShadow: '0 4px 24px rgba(0,0,0,0.05)', overflow: 'hidden', minWidth: 600,
            }}>
              <thead>
                <tr>
                  <th style={{ padding: '1.25rem 1.5rem', textAlign: 'start', background: '#f8fafc', borderBottom: '1px solid #e2e8f0', fontSize: '0.875rem', fontWeight: 700, color: '#64748b', fontFamily: 'Sora, sans-serif' }}>{t('home.compare_feature')}</th>
                  <th style={{ padding: '1.25rem 1.5rem', textAlign: 'center', background: 'linear-gradient(135deg, rgba(6,182,212,0.08), rgba(139,92,246,0.08))', borderBottom: '1px solid rgba(6,182,212,0.2)', fontSize: '0.9375rem', fontWeight: 800, color: '#0891b2', fontFamily: 'Sora, sans-serif' }}>IFROF</th>
                  <th style={{ padding: '1.25rem 1.5rem', textAlign: 'center', background: '#f8fafc', borderBottom: '1px solid #e2e8f0', fontSize: '0.875rem', fontWeight: 700, color: '#64748b', fontFamily: 'Sora, sans-serif' }}>{t('home.compare_open')}</th>
                  <th style={{ padding: '1.25rem 1.5rem', textAlign: 'center', background: '#f8fafc', borderBottom: '1px solid #e2e8f0', fontSize: '0.875rem', fontWeight: 700, color: '#64748b', fontFamily: 'Sora, sans-serif' }}>{t('home.compare_agent')}</th>
                </tr>
              </thead>
              <tbody>
                {COMPARE_ROWS.map(([feature, ifrof, openMarket, agent], i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? 'white' : '#fafbfc' }}>
                    <td style={{ padding: '1rem 1.5rem', fontSize: '0.9375rem', color: '#334155', fontWeight: 500, borderBottom: '1px solid #f1f5f9' }}>{feature}</td>
                    <td style={{ padding: '1rem 1.5rem', textAlign: 'center', borderBottom: '1px solid #f1f5f9', background: 'rgba(6,182,212,0.03)' }}>
                      {ifrof === true ? <CheckCircle style={{ width: 20, height: 20, color: '#10b981', display: 'inline' }} /> : <X style={{ width: 18, height: 18, color: '#ef4444', display: 'inline' }} />}
                    </td>
                    <td style={{ padding: '1rem 1.5rem', textAlign: 'center', borderBottom: '1px solid #f1f5f9' }}>
                      {openMarket === true ? <CheckCircle style={{ width: 20, height: 20, color: '#10b981', display: 'inline' }} /> : openMarket === false ? <X style={{ width: 18, height: 18, color: '#ef4444', display: 'inline' }} /> : <span style={{ fontSize: '0.8125rem', color: '#94a3b8', fontWeight: 600 }}>{openMarket}</span>}
                    </td>
                    <td style={{ padding: '1rem 1.5rem', textAlign: 'center', borderBottom: '1px solid #f1f5f9' }}>
                      {agent === true ? <CheckCircle style={{ width: 20, height: 20, color: '#10b981', display: 'inline' }} /> : agent === false ? <X style={{ width: 18, height: 18, color: '#ef4444', display: 'inline' }} /> : <span style={{ fontSize: '0.8125rem', color: '#94a3b8', fontWeight: 600 }}>{agent}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          9. FAQ
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={faq.ref} style={{ padding: '6rem 0', background: 'white' }}>
        <div className="container" style={{ maxWidth: 760 }}>
          <div className={faq.isVisible ? 'animate-fade-up' : 'opacity-0'}>
            <SectionHeader title={t('home.faq_title')} subtitle={t('home.faq_subtitle')} />
          </div>
          <div className={faq.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
            {FAQ_ITEMS.map((item, i) => <FAQItem key={i} q={item.q} a={item.a} />)}
          </div>
          <div className={faq.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ textAlign: 'center', marginTop: '2.5rem' }}>
            <p style={{ color: '#64748b', fontSize: '0.9375rem', marginBottom: '1rem' }}>{t('home.faq_still_questions')}</p>
            <Link href="/faq" style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
              color: '#0891b2', fontWeight: 700, fontSize: '0.9375rem', textDecoration: 'none',
            }}>
              {t('home.faq_view_all')} <ChevronRight style={{ width: 16, height: 16, transform: isRTL ? 'scaleX(-1)' : undefined }} />
            </Link>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════
          10. BLOG PREVIEW
      ══════════════════════════════════════════════════════════════════════ */}
      {blogPosts.length > 0 && (
        <section ref={blog.ref} style={{ padding: '5rem 0', background: '#f8fafc' }}>
          <div className="container">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
              <SectionHeader
                badge={t('nav.blog')}
                title={t('home.blog_title', 'آخر المقالات')}
                center={false}
              />
              <Link href="/blog" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
                color: '#0891b2', fontWeight: 700, fontSize: '0.9375rem', textDecoration: 'none',
              }}>
                {t('home.blog_view_all', 'عرض الكل')}
                <ChevronRight style={{ width: 16, height: 16, transform: isRTL ? 'scaleX(-1)' : undefined }} />
              </Link>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
              {blogPosts.map((post: any) => (
                <Link
                  key={post.id}
                  href={`/blog/${post.slug}`}
                  style={{ textDecoration: 'none', display: 'block' }}
                >
                  <div style={{
                    background: 'white', borderRadius: '1.25rem', overflow: 'hidden',
                    border: '1px solid #e2e8f0', transition: 'transform 200ms, box-shadow 200ms',
                    height: '100%',
                  }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 16px 48px rgba(0,0,0,0.1)'; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = ''; (e.currentTarget as HTMLElement).style.boxShadow = ''; }}
                  >
                    {post.coverImage && (
                      <img
                        src={post.coverImage}
                        alt={post.title}
                        style={{ width: '100%', height: 180, objectFit: 'cover' }}
                        loading="lazy"
                        decoding="async"
                      />
                    )}
                    <div style={{ padding: '1.5rem' }}>
                      {post.readTime && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#94a3b8', fontSize: '0.8125rem', marginBottom: '0.75rem' }}>
                          <Clock style={{ width: 13, height: 13 }} />
                          {post.readTime} min read
                        </div>
                      )}
                      <h3 style={{
                        fontFamily: 'Sora, sans-serif', fontWeight: 700,
                        fontSize: '1.125rem', color: '#0f172a', marginBottom: '0.625rem',
                        lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical', overflow: 'hidden',
                      }}>{post.title}</h3>
                      {post.excerpt && (
                        <p style={{
                          fontSize: '0.9375rem', color: '#64748b', lineHeight: 1.65,
                          display: '-webkit-box', WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical', overflow: 'hidden',
                        }}>{post.excerpt}</p>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          11. FINAL CTA
      ══════════════════════════════════════════════════════════════════════ */}
      <section ref={cta.ref} style={{
        padding: '8rem 0',
        background: 'linear-gradient(150deg, #060d1a 0%, #0c1a2e 40%, #0a1628 70%, #0d1f38 100%)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(6,182,212,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.03) 1px, transparent 1px)', backgroundSize: '64px 64px' }} />
          <div style={{ position: 'absolute', top: '10%', right: '5%', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle, rgba(6,182,212,0.12) 0%, transparent 65%)', filter: 'blur(40px)' }} />
          <div style={{ position: 'absolute', bottom: '5%', left: '0%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle, rgba(139,92,246,0.1) 0%, transparent 65%)', filter: 'blur(40px)' }} />
        </div>

        <div className="container" style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div className={cta.isVisible ? 'animate-fade-up' : 'opacity-0'} style={{ maxWidth: 760, margin: '0 auto' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
              background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.2)',
              borderRadius: '2rem', padding: '0.5rem 1.25rem', marginBottom: '2rem',
            }}>
              <Layers style={{ width: 14, height: 14, color: '#22d3ee' }} />
              <span style={{ color: '#67e8f9', fontSize: '0.8125rem', fontWeight: 700, letterSpacing: '0.04em' }}>{t('home.cta_badge')}</span>
            </div>

            <h2 style={{
              fontFamily: 'Sora, sans-serif', fontWeight: 800,
              fontSize: 'clamp(2.25rem, 5vw, 4rem)', color: 'white', letterSpacing: '-0.03em',
              marginBottom: '1.5rem', lineHeight: 1.1,
            }}>
              {t('home.cta_title_1')}<br />
              <span style={{
                background: 'linear-gradient(135deg, #06b6d4 0%, #818cf8 50%, #06b6d4 100%)',
                backgroundSize: '200% auto', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                animation: 'shimmer 4s linear infinite',
              }}>
                {t('home.cta_title_2')}
              </span>
            </h2>

            <p style={{
              fontSize: 'clamp(1rem, 2.5vw, 1.25rem)', color: 'rgba(255,255,255,0.55)', lineHeight: 1.75,
              maxWidth: 580, margin: '0 auto 3rem', fontFamily: 'DM Sans, sans-serif',
            }}>
              {t('home.cta_desc')}
            </p>

            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '2.5rem' }}>
              <Link href="/rfq" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
                padding: '1.125rem 2.75rem', borderRadius: '0.875rem',
                background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
                color: 'white', fontFamily: 'DM Sans, sans-serif', fontWeight: 700, fontSize: '1.125rem',
                textDecoration: 'none', boxShadow: '0 16px 48px rgba(6,182,212,0.45)', transition: 'transform 200ms, box-shadow 200ms',
              }}>
                <Zap style={{ width: 20, height: 20 }} />
                {t('home.cta_primary')}
                <ArrowRight style={{ width: 18, height: 18, transform: isRTL ? 'scaleX(-1)' : undefined }} />
              </Link>
              <Link href="/services/escrow" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.625rem',
                padding: '1.125rem 2.5rem', borderRadius: '0.875rem',
                background: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(12px)',
                color: 'rgba(255,255,255,0.9)', fontFamily: 'DM Sans, sans-serif', fontWeight: 600, fontSize: '1.125rem',
                textDecoration: 'none', border: '1px solid rgba(255,255,255,0.12)',
              }}>
                <Lock style={{ width: 18, height: 18 }} />
                {t('home.cta_secondary')}
              </Link>
            </div>

            <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              {[
                { icon: Shield, text: t('home.cta_guarantee_1') },
                { icon: Lock, text: t('home.cta_guarantee_2') },
                { icon: Repeat, text: t('home.cta_guarantee_3') },
                { icon: Clock, text: t('home.cta_guarantee_4') },
              ].map((item, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: 'rgba(255,255,255,0.35)', fontSize: '0.875rem' }}>
                  <item.icon style={{ width: 13, height: 13, color: 'rgba(255,255,255,0.25)' }} />
                  {item.text}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
