/**
 * Admin Operations Tabs
 * Three internal-only tabs for the Managed Sourcing Agent model:
 *   1. SuppliersTab   — Internal supplier/factory database (never shown to buyers)
 *   2. RfqQuotesTab   — All buyer RFQs + Quote Builder (admin creates & sends quotes)
 *   3. CrmTab         — Customer relationship management: buyer list, notes, history
 */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Factory, Search, Plus, Edit, Trash2, CheckCircle, XCircle, Clock,
  DollarSign, Package, Users, MessageSquare, Send, Eye, Star,
  MapPin, Phone, Globe, FileText, TrendingUp, AlertTriangle,
  ChevronDown, ChevronUp, RefreshCw,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

type SharedProps = {
  thStyle: React.CSSProperties;
  tdStyle: React.CSSProperties;
  badge: (color: string, bg: string, text: string) => React.ReactElement;
};

// ─────────────────────────────────────────────────────────────────────────────
// 1. SUPPLIERS TAB — Internal supplier database
// ─────────────────────────────────────────────────────────────────────────────
export function SuppliersTab({ thStyle, tdStyle, badge, inputStyle }: SharedProps & { inputStyle: React.CSSProperties }) {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({
    name: '', country: '', city: '', category: '', contactName: '',
    contactEmail: '', contactPhone: '', website: '', minOrderUsd: '',
    leadTimeDays: '', certifications: '', notes: '',
  });

  // Fetch suppliers from admin router
  const { data: suppliersData, isLoading, refetch } = trpc.admin.listSuppliers.useQuery(undefined, {
    refetchInterval: 60_000,
  });
  const createSupplier = trpc.admin.createSupplier.useMutation({
    onSuccess: () => {
      toast.success('Supplier added to internal database');
      setAddOpen(false);
      setForm({ name: '', country: '', city: '', category: '', contactName: '', contactEmail: '', contactPhone: '', website: '', minOrderUsd: '', leadTimeDays: '', certifications: '', notes: '' });
      refetch();
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const suppliers = suppliersData ?? [];
  const filtered = suppliers.filter((s) =>
    !searchQuery ||
    s.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.country?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (s as any).category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const cardStyle: React.CSSProperties = {
    background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem',
    boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9',
    marginBottom: '0.75rem',
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)' }}>
            Supplier Database
          </h2>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-muted)', marginTop: '0.25rem' }}>
            Internal only — never visible to buyers
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button onClick={() => refetch()} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.5rem 0.875rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', background: 'white', fontSize: '0.8125rem', fontWeight: 600, color: '#475569', cursor: 'pointer' }}>
            <RefreshCw style={{ width: 14, height: 14 }} /> Refresh
          </button>
          <button onClick={() => setAddOpen(true)} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontSize: '0.8125rem', fontWeight: 700, cursor: 'pointer' }}>
            <Plus style={{ width: 14, height: 14 }} /> Add Supplier
          </button>
        </div>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '1.25rem' }}>
        <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: 'var(--color-subtle)' }} />
        <input
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search by name, country, or category..."
          style={{ ...inputStyle, paddingLeft: '2.25rem' }}
        />
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.75rem', marginBottom: '1.5rem' }}>
        {[
          { label: 'Total Suppliers', value: suppliers.length, color: '#06b6d4', bg: 'rgba(6,182,212,0.08)' },
          { label: 'Verified', value: suppliers.filter(s => (s as any).verified).length, color: '#10b981', bg: 'rgba(16,185,129,0.08)' },
          { label: 'Countries', value: new Set(suppliers.map(s => s.country)).size, color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)' },
          { label: 'Categories', value: new Set(suppliers.map(s => (s as any).category)).size, color: '#f59e0b', bg: 'rgba(245,158,11,0.08)' },
        ].map((stat, i) => (
          <div key={i} style={{ background: stat.bg, borderRadius: 'var(--radius-lg)', padding: '1rem', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: stat.color, fontFamily: 'var(--font-display)' }}>{stat.value}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)', marginTop: '0.25rem' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Supplier List */}
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>Loading suppliers...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem' }}>
          <Factory style={{ width: 40, height: 40, color: '#cbd5e1', margin: '0 auto 1rem' }} />
          <p style={{ color: 'var(--color-muted)', fontWeight: 600 }}>No suppliers yet</p>
          <p style={{ color: 'var(--color-subtle)', fontSize: '0.875rem' }}>Add your first supplier to the internal database</p>
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Supplier', 'Location', 'Category', 'Contact', 'Min Order', 'Lead Time', 'Status', ''].map(h => (
                  <th key={h} style={thStyle}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s.id} style={{ transition: 'background 150ms' }}>
                  <td style={tdStyle}>
                    <div style={{ fontWeight: 700, color: 'var(--color-ink)', fontSize: '0.875rem' }}>{s.name}</div>
                    {(s as any).website && <a href={(s as any).website} target="_blank" rel="noopener noreferrer" style={{ fontSize: '0.75rem', color: '#06b6d4' }}>{(s as any).website}</a>}
                  </td>
                  <td style={tdStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.8125rem', color: '#475569' }}>
                      <MapPin style={{ width: 12, height: 12 }} />
                      {s.city ? `${s.city}, ${s.country}` : s.country}
                    </div>
                  </td>
                  <td style={tdStyle}>
                    <span style={{ fontSize: '0.75rem', background: 'rgba(6,182,212,0.08)', color: '#0891b2', padding: '0.125rem 0.5rem', borderRadius: '0.25rem', fontWeight: 600 }}>
                      {(s as any).category || '—'}
                    </span>
                  </td>
                  <td style={tdStyle}>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--color-ink)' }}>{s.contactName || '—'}</div>
                    {s.contactEmail && <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{s.contactEmail}</div>}
                  </td>
                  <td style={tdStyle}>
                    <span style={{ fontSize: '0.8125rem', color: '#475569' }}>
                      {(s as any).minOrderUsd ? `$${(s as any).minOrderUsd.toLocaleString()}` : '—'}
                    </span>
                  </td>
                  <td style={tdStyle}>
                    <span style={{ fontSize: '0.8125rem', color: '#475569' }}>
                      {s.leadTimeDays ? `${s.leadTimeDays}d` : '—'}
                    </span>
                  </td>
                  <td style={tdStyle}>
                    {(s as any).verified
                      ? badge('#10b981', 'rgba(16,185,129,0.1)', '✓ Verified')
                      : badge('#f59e0b', 'rgba(245,158,11,0.1)', 'Pending')}
                  </td>
                  <td style={tdStyle}>
                    <button style={{ padding: '0.25rem 0.625rem', borderRadius: '0.375rem', border: '1px solid var(--color-border)', background: 'white', fontSize: '0.75rem', cursor: 'pointer', color: '#475569' }}>
                      <Edit style={{ width: 12, height: 12 }} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Supplier Modal */}
      {addOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: 'white', borderRadius: 'var(--radius-xl)', padding: '2rem', width: '100%', maxWidth: '600px', maxHeight: '90vh', overflowY: 'auto' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.5rem' }}>
              Add New Supplier
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              {[
                { label: 'Company Name *', key: 'name', placeholder: 'Shenzhen Electronics Co.' },
                { label: 'Category *', key: 'category', placeholder: 'Electronics, Textiles...' },
                { label: 'Country *', key: 'country', placeholder: 'China' },
                { label: 'City', key: 'city', placeholder: 'Shenzhen' },
                { label: 'Contact Name', key: 'contactName', placeholder: 'John Zhang' },
                { label: 'Contact Email', key: 'contactEmail', placeholder: 'john@factory.com' },
                { label: 'Contact Phone', key: 'contactPhone', placeholder: '+86 755 1234 5678' },
                { label: 'Website', key: 'website', placeholder: 'https://factory.com' },
                { label: 'Min Order (USD)', key: 'minOrderUsd', placeholder: '500' },
                { label: 'Lead Time (days)', key: 'leadTimeDays', placeholder: '30' },
              ].map(field => (
                <div key={field.key}>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>{field.label}</label>
                  <input
                    value={(form as any)[field.key]}
                    onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))}
                    placeholder={field.placeholder}
                    style={inputStyle}
                  />
                </div>
              ))}
            </div>
            <div style={{ marginTop: '1rem' }}>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>Certifications (comma-separated)</label>
              <input value={form.certifications} onChange={e => setForm(f => ({ ...f, certifications: e.target.value }))} placeholder="ISO 9001, CE, RoHS..." style={inputStyle} />
            </div>
            <div style={{ marginTop: '1rem' }}>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>Internal Notes</label>
              <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Quality notes, reliability, past issues..." rows={3} style={{ ...inputStyle, resize: 'vertical' }} />
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button onClick={() => setAddOpen(false)} style={{ padding: '0.625rem 1.25rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', background: 'white', fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', color: '#475569' }}>
                Cancel
              </button>
              <button
                onClick={() => createSupplier.mutate({
                  name: form.name,
                  country: form.country,
                  city: form.city || undefined,
                  category: form.category || undefined,
                  contactName: form.contactName || undefined,
                  contactEmail: form.contactEmail || undefined,
                  contactPhone: form.contactPhone || undefined,
                  website: form.website || undefined,
                  minOrderUsd: form.minOrderUsd ? Number(form.minOrderUsd) : undefined,
                  leadTimeDays: form.leadTimeDays ? Number(form.leadTimeDays) : undefined,
                  certifications: form.certifications ? form.certifications.split(',').map(c => c.trim()) : undefined,
                  notes: form.notes || undefined,
                })}
                disabled={!form.name || !form.country || createSupplier.isPending}
                style={{ padding: '0.625rem 1.5rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer', opacity: (!form.name || !form.country) ? 0.5 : 1 }}
              >
                {createSupplier.isPending ? 'Saving...' : 'Add Supplier'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. RFQ & QUOTES TAB — Admin receives RFQs, builds quotes, sends to buyers
// ─────────────────────────────────────────────────────────────────────────────
export function RfqQuotesTab({ thStyle, tdStyle, badge }: SharedProps) {
  const { t } = useTranslation();
  const [subTab, setSubTab] = useState<'rfqs' | 'quotes'>('rfqs');
  const [rfqStatus, setRfqStatus] = useState<'all' | 'submitted' | 'matched' | 'completed'>('all');
  const [quoteStatus, setQuoteStatus] = useState<'all' | 'draft' | 'sent' | 'accepted' | 'rejected'>('all');
  const [selectedRfq, setSelectedRfq] = useState<any>(null);
  const [quoteForm, setQuoteForm] = useState({
    unitPrice: '', quantity: '', shippingCost: '', leadTimeDays: '',
    shippingMethod: 'sea' as 'sea' | 'air' | 'rail' | 'express',
    supplierName: '', supplierUnitCost: '', agentMarginPct: '',
    internalNotes: '', notes: '', validUntil: '',
  });

  const { data: rfqs, isLoading: rfqsLoading, refetch: refetchRfqs } = trpc.rfq.adminListAll.useQuery({ status: rfqStatus });
  const { data: quotes, isLoading: quotesLoading, refetch: refetchQuotes } = trpc.rfq.adminListQuotes.useQuery({ status: quoteStatus });

  const createQuote = trpc.rfq.adminCreateQuote.useMutation({
    onSuccess: () => {
      toast.success('Quote created as draft');
      setSelectedRfq(null);
      refetchRfqs();
      refetchQuotes();
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const sendQuote = trpc.rfq.adminSendQuote.useMutation({
    onSuccess: () => {
      toast.success('Quote sent to buyer — they have been notified');
      refetchQuotes();
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-md)',
    border: '1.5px solid var(--color-border)', fontSize: '0.875rem', color: 'var(--color-ink)', outline: 'none',
  };

  const rfqStatusConfig: Record<string, { color: string; bg: string }> = {
    submitted: { color: '#f59e0b', bg: 'rgba(245,158,11,0.1)' },
    matched: { color: '#06b6d4', bg: 'rgba(6,182,212,0.1)' },
    completed: { color: '#10b981', bg: 'rgba(16,185,129,0.1)' },
    cancelled: { color: '#ef4444', bg: 'rgba(239,68,68,0.1)' },
  };

  const quoteStatusConfig: Record<string, { color: string; bg: string }> = {
    draft: { color: 'var(--color-muted)', bg: 'rgba(100,116,139,0.1)' },
    sent: { color: '#06b6d4', bg: 'rgba(6,182,212,0.1)' },
    accepted: { color: '#10b981', bg: 'rgba(16,185,129,0.1)' },
    rejected: { color: '#ef4444', bg: 'rgba(239,68,68,0.1)' },
    expired: { color: 'var(--color-subtle)', bg: 'rgba(148,163,184,0.1)' },
  };

  const unitPrice = Number(quoteForm.unitPrice) || 0;
  const quantity = Number(quoteForm.quantity) || 0;
  const shipping = Number(quoteForm.shippingCost) || 0;
  const supplierCost = Number(quoteForm.supplierUnitCost) || 0;
  const totalAmount = unitPrice * quantity + shipping;
  const margin = supplierCost > 0 ? ((unitPrice - supplierCost) * quantity).toFixed(2) : null;
  const marginPct = supplierCost > 0 ? (((unitPrice - supplierCost) / unitPrice) * 100).toFixed(1) : null;

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)' }}>
          RFQ & Quote Management
        </h2>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {(['rfqs', 'quotes'] as const).map(st => (
            <button key={st} onClick={() => setSubTab(st)} style={{ padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', border: '1.5px solid', borderColor: subTab === st ? '#06b6d4' : '#e2e8f0', background: subTab === st ? 'rgba(6,182,212,0.08)' : 'white', color: subTab === st ? '#0891b2' : '#64748b', fontWeight: 700, fontSize: '0.8125rem', cursor: 'pointer' }}>
              {st === 'rfqs' ? 'Buyer Requests' : 'Agent Quotes'}
            </button>
          ))}
        </div>
      </div>

      {subTab === 'rfqs' && (
        <div>
          {/* Status filter */}
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem' }}>
            {(['all', 'submitted', 'matched', 'completed'] as const).map(s => (
              <button key={s} onClick={() => setRfqStatus(s)} style={{ padding: '0.375rem 0.875rem', borderRadius: 'var(--radius-md)', border: '1.5px solid', borderColor: rfqStatus === s ? '#06b6d4' : '#e2e8f0', background: rfqStatus === s ? 'rgba(6,182,212,0.08)' : 'white', color: rfqStatus === s ? '#0891b2' : '#64748b', fontWeight: 600, fontSize: '0.75rem', cursor: 'pointer', textTransform: 'capitalize' }}>
                {s}
              </button>
            ))}
          </div>

          {rfqsLoading ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>Loading requests...</div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    {['#', 'Buyer', 'Product', 'Qty', 'Target Price', 'Destination', 'Status', 'Date', 'Action'].map(h => (
                      <th key={h} style={thStyle}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(rfqs ?? []).map((rfq: any) => {
                    const sc = rfqStatusConfig[rfq.status] ?? { color: 'var(--color-muted)', bg: '#f1f5f9' };
                    return (
                      <tr key={rfq.id}>
                        <td style={tdStyle}><span style={{ fontSize: '0.75rem', color: 'var(--color-subtle)' }}>#{rfq.id}</span></td>
                        <td style={tdStyle}>
                          <div style={{ fontWeight: 600, fontSize: '0.875rem', color: 'var(--color-ink)' }}>{rfq.buyer?.name ?? '—'}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{rfq.buyer?.email ?? ''}</div>
                        </td>
                        <td style={tdStyle}>
                          <div style={{ fontWeight: 600, fontSize: '0.875rem', color: 'var(--color-ink)', maxWidth: '180px' }}>{rfq.productName}</div>
                          {rfq.specifications && <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{rfq.specifications}</div>}
                        </td>
                        <td style={tdStyle}><span style={{ fontSize: '0.8125rem', color: '#475569' }}>{rfq.quantity?.toLocaleString() ?? '—'}</span></td>
                        <td style={tdStyle}><span style={{ fontSize: '0.8125rem', color: '#475569' }}>{rfq.targetPrice ? `$${rfq.targetPrice}` : '—'}</span></td>
                        <td style={tdStyle}><span style={{ fontSize: '0.8125rem', color: '#475569' }}>{rfq.destinationCountry ?? '—'}</span></td>
                        <td style={tdStyle}>{badge(sc.color, sc.bg, rfq.status)}</td>
                        <td style={tdStyle}><span style={{ fontSize: '0.75rem', color: 'var(--color-subtle)' }}>{rfq.createdAt ? new Date(rfq.createdAt).toLocaleDateString() : '—'}</span></td>
                        <td style={tdStyle}>
                          {rfq.status === 'submitted' && (
                            <button
                              onClick={() => {
                                setSelectedRfq(rfq);
                                setQuoteForm(f => ({ ...f, quantity: String(rfq.quantity ?? ''), unitPrice: rfq.targetPrice ? String(rfq.targetPrice) : '' }));
                              }}
                              style={{ padding: '0.375rem 0.75rem', borderRadius: '0.375rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer' }}
                            >
                              Build Quote
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {(rfqs ?? []).length === 0 && (
                <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>No requests found</div>
              )}
            </div>
          )}
        </div>
      )}

      {subTab === 'quotes' && (
        <div>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.25rem' }}>
            {(['all', 'draft', 'sent', 'accepted', 'rejected'] as const).map(s => (
              <button key={s} onClick={() => setQuoteStatus(s)} style={{ padding: '0.375rem 0.875rem', borderRadius: 'var(--radius-md)', border: '1.5px solid', borderColor: quoteStatus === s ? '#06b6d4' : '#e2e8f0', background: quoteStatus === s ? 'rgba(6,182,212,0.08)' : 'white', color: quoteStatus === s ? '#0891b2' : '#64748b', fontWeight: 600, fontSize: '0.75rem', cursor: 'pointer', textTransform: 'capitalize' }}>
                {s}
              </button>
            ))}
          </div>
          {quotesLoading ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>Loading quotes...</div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    {['#', 'Buyer', 'RFQ', 'Unit Price', 'Qty', 'Total', 'Margin', 'Status', 'Action'].map(h => (
                      <th key={h} style={thStyle}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(quotes ?? []).map((q: any) => {
                    const sc = quoteStatusConfig[q.status] ?? { color: 'var(--color-muted)', bg: '#f1f5f9' };
                    const m = q.marginAmount;
                    return (
                      <tr key={q.id}>
                        <td style={tdStyle}><span style={{ fontSize: '0.75rem', color: 'var(--color-subtle)' }}>#{q.id}</span></td>
                        <td style={tdStyle}>
                          <div style={{ fontWeight: 600, fontSize: '0.875rem', color: 'var(--color-ink)' }}>{q.buyer?.name ?? '—'}</div>
                        </td>
                        <td style={tdStyle}><span style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>RFQ #{q.rfqId}</span></td>
                        <td style={tdStyle}><span style={{ fontWeight: 700, color: 'var(--color-ink)' }}>${q.unitPrice?.toFixed(2)}</span></td>
                        <td style={tdStyle}><span style={{ color: '#475569' }}>{q.quantity?.toLocaleString()}</span></td>
                        <td style={tdStyle}><span style={{ fontWeight: 700, color: '#10b981' }}>${q.totalAmount?.toFixed(2)}</span></td>
                        <td style={tdStyle}>
                          {m != null ? (
                            <span style={{ color: '#10b981', fontWeight: 700 }}>${m.toFixed(2)}</span>
                          ) : <span style={{ color: 'var(--color-subtle)' }}>—</span>}
                        </td>
                        <td style={tdStyle}>{badge(sc.color, sc.bg, q.status)}</td>
                        <td style={tdStyle}>
                          {q.status === 'draft' && (
                            <button
                              onClick={() => sendQuote.mutate({ quoteId: q.id })}
                              disabled={sendQuote.isPending}
                              style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.375rem 0.75rem', borderRadius: '0.375rem', background: 'linear-gradient(135deg, #10b981, #059669)', color: 'white', border: 'none', fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer' }}
                            >
                              <Send style={{ width: 12, height: 12 }} /> Send
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {(quotes ?? []).length === 0 && (
                <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>No quotes found</div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Quote Builder Modal */}
      {selectedRfq && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: 'white', borderRadius: 'var(--radius-xl)', padding: '2rem', width: '100%', maxWidth: '640px', maxHeight: '90vh', overflowY: 'auto' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '0.5rem' }}>
              Quote Builder
            </h3>
            <div style={{ background: 'rgba(6,182,212,0.06)', borderRadius: 'var(--radius-md)', padding: '0.75rem 1rem', marginBottom: '1.5rem', fontSize: '0.8125rem', color: '#0891b2' }}>
              Building quote for: <strong>{selectedRfq.productName}</strong> — Buyer: <strong>{selectedRfq.buyer?.name}</strong>
            </div>

            {/* Internal (hidden from buyer) */}
            <div style={{ background: '#fef3c7', borderRadius: 'var(--radius-md)', padding: '0.75rem 1rem', marginBottom: '1rem', fontSize: '0.75rem', color: '#92400e', fontWeight: 600 }}>
              ⚠ INTERNAL FIELDS — Never shown to buyer
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              {[
                { label: 'Supplier Name (internal)', key: 'supplierName', placeholder: 'Shenzhen Co.' },
                { label: 'Supplier Unit Cost ($)', key: 'supplierUnitCost', placeholder: '12.50' },
                { label: 'Agent Margin (%)', key: 'agentMarginPct', placeholder: '20' },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: '#92400e', marginBottom: '0.25rem' }}>{f.label}</label>
                  <input value={(quoteForm as any)[f.key]} onChange={e => setQuoteForm(q => ({ ...q, [f.key]: e.target.value }))} placeholder={f.placeholder} style={{ ...inputStyle, borderColor: '#fcd34d' }} />
                </div>
              ))}
            </div>
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: '#92400e', marginBottom: '0.25rem' }}>Internal Notes (not sent to buyer)</label>
              <textarea value={quoteForm.internalNotes} onChange={e => setQuoteForm(q => ({ ...q, internalNotes: e.target.value }))} rows={2} placeholder="Supplier reliability notes, quality concerns..." style={{ ...inputStyle, borderColor: '#fcd34d', resize: 'vertical' }} />
            </div>

            {/* Buyer-facing fields */}
            <div style={{ borderTop: '1px solid #f1f5f9', paddingTop: '1rem', marginBottom: '0.75rem', fontSize: '0.75rem', fontWeight: 700, color: '#10b981' }}>
              ✓ BUYER-FACING FIELDS
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              {[
                { label: 'Unit Price to Buyer ($) *', key: 'unitPrice', placeholder: '15.00' },
                { label: 'Quantity *', key: 'quantity', placeholder: '1000' },
                { label: 'Shipping Cost ($)', key: 'shippingCost', placeholder: '500' },
                { label: 'Lead Time (days)', key: 'leadTimeDays', placeholder: '30' },
                { label: 'Valid Until', key: 'validUntil', placeholder: '2026-03-31', type: 'date' },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>{f.label}</label>
                  <input type={(f as any).type ?? 'text'} value={(quoteForm as any)[f.key]} onChange={e => setQuoteForm(q => ({ ...q, [f.key]: e.target.value }))} placeholder={f.placeholder} style={inputStyle} />
                </div>
              ))}
              <div>
                <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>Shipping Method</label>
                <select value={quoteForm.shippingMethod} onChange={e => setQuoteForm(q => ({ ...q, shippingMethod: e.target.value as any }))} style={inputStyle}>
                  <option value="sea">Sea Freight</option>
                  <option value="air">Air Freight</option>
                  <option value="rail">Rail</option>
                  <option value="express">Express</option>
                </select>
              </div>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>Notes to Buyer</label>
              <textarea value={quoteForm.notes} onChange={e => setQuoteForm(q => ({ ...q, notes: e.target.value }))} rows={2} placeholder="Payment terms, packaging details..." style={{ ...inputStyle, resize: 'vertical' }} />
            </div>

            {/* Live margin calculator */}
            {unitPrice > 0 && quantity > 0 && (
              <div style={{ background: 'rgba(16,185,129,0.06)', borderRadius: 'var(--radius-md)', padding: '0.875rem 1rem', marginBottom: '1.25rem', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem' }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '1.125rem', fontWeight: 800, color: 'var(--color-ink)' }}>${totalAmount.toFixed(2)}</div>
                  <div style={{ fontSize: '0.6875rem', color: 'var(--color-muted)' }}>Total to Buyer</div>
                </div>
                {margin && (
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '1.125rem', fontWeight: 800, color: '#10b981' }}>${margin}</div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--color-muted)' }}>Agent Profit</div>
                  </div>
                )}
                {marginPct && (
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '1.125rem', fontWeight: 800, color: '#10b981' }}>{marginPct}%</div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--color-muted)' }}>Margin</div>
                  </div>
                )}
              </div>
            )}

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <button onClick={() => setSelectedRfq(null)} style={{ padding: '0.625rem 1.25rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', background: 'white', fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', color: '#475569' }}>
                Cancel
              </button>
              <button
                onClick={() => createQuote.mutate({
                  rfqId: selectedRfq.id,
                  buyerId: selectedRfq.buyer?.id,
                  supplierName: quoteForm.supplierName || undefined,
                  supplierUnitCost: quoteForm.supplierUnitCost ? Number(quoteForm.supplierUnitCost) : undefined,
                  agentMarginPct: quoteForm.agentMarginPct ? Number(quoteForm.agentMarginPct) : undefined,
                  internalNotes: quoteForm.internalNotes || undefined,
                  unitPrice: Number(quoteForm.unitPrice),
                  quantity: Number(quoteForm.quantity),
                  shippingCost: Number(quoteForm.shippingCost) || 0,
                  leadTimeDays: quoteForm.leadTimeDays ? Number(quoteForm.leadTimeDays) : undefined,
                  shippingMethod: quoteForm.shippingMethod,
                  validUntil: quoteForm.validUntil || undefined,
                  notes: quoteForm.notes || undefined,
                })}
                disabled={!quoteForm.unitPrice || !quoteForm.quantity || createQuote.isPending}
                style={{ padding: '0.625rem 1.5rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer', opacity: (!quoteForm.unitPrice || !quoteForm.quantity) ? 0.5 : 1 }}
              >
                {createQuote.isPending ? 'Saving...' : 'Save as Draft'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. CRM TAB — Customer relationship management
// ─────────────────────────────────────────────────────────────────────────────
export function CrmTab({ thStyle, tdStyle, badge }: SharedProps) {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const { data: usersData, isLoading } = trpc.admin.listUsers.useQuery(undefined, {
    refetchInterval: 60_000,
  });

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-md)',
    border: '1.5px solid var(--color-border)', fontSize: '0.875rem', color: 'var(--color-ink)', outline: 'none',
  };

  const users = (usersData ?? []).filter((u: any) => u.role !== 'admin');
  const filtered = users.filter((u: any) =>
    !searchQuery ||
    u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)' }}>
            Customer Relationship Management
          </h2>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-muted)', marginTop: '0.25rem' }}>
            Buyer profiles, order history, and communication
          </p>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.75rem', marginBottom: '1.5rem' }}>
        {[
          { label: 'Total Buyers', value: users.length, color: '#06b6d4', bg: 'rgba(6,182,212,0.08)' },
          { label: 'Active (30d)', value: users.filter((u: any) => u.lastActiveAt && new Date(u.lastActiveAt) > new Date(Date.now() - 30 * 86400000)).length, color: '#10b981', bg: 'rgba(16,185,129,0.08)' },
          { label: 'Verified', value: users.filter((u: any) => u.emailVerified).length, color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)' },
          { label: 'Premium', value: users.filter((u: any) => u.plan && u.plan !== 'free').length, color: '#f59e0b', bg: 'rgba(245,158,11,0.08)' },
        ].map((stat, i) => (
          <div key={i} style={{ background: stat.bg, borderRadius: 'var(--radius-lg)', padding: '1rem', textAlign: 'center' }}>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: stat.color, fontFamily: 'var(--font-display)' }}>{stat.value}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)', marginTop: '0.25rem' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '1.25rem' }}>
        <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: 'var(--color-subtle)' }} />
        <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search by name or email..." style={{ ...inputStyle, paddingLeft: '2.25rem' }} />
      </div>

      {/* Users Table */}
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>Loading buyers...</div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Buyer', 'Email', 'Plan', 'Joined', 'Status', 'Actions'].map(h => (
                  <th key={h} style={thStyle}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((u: any) => (
                <tr key={u.id}>
                  <td style={tdStyle}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
                      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: '0.75rem', flexShrink: 0 }}>
                        {u.name?.charAt(0)?.toUpperCase() ?? '?'}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: '0.875rem', color: 'var(--color-ink)' }}>{u.name}</div>
                        {u.company && <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{u.company}</div>}
                      </div>
                    </div>
                  </td>
                  <td style={tdStyle}><span style={{ fontSize: '0.8125rem', color: '#475569' }}>{u.email}</span></td>
                  <td style={tdStyle}>
                    {u.plan && u.plan !== 'free'
                      ? badge('#8b5cf6', 'rgba(139,92,246,0.1)', u.plan)
                      : badge('#94a3b8', 'rgba(148,163,184,0.1)', 'Free')}
                  </td>
                  <td style={tdStyle}><span style={{ fontSize: '0.75rem', color: 'var(--color-subtle)' }}>{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}</span></td>
                  <td style={tdStyle}>
                    {u.status === 'active' || !u.status
                      ? badge('#10b981', 'rgba(16,185,129,0.1)', 'Active')
                      : badge('#ef4444', 'rgba(239,68,68,0.1)', u.status)}
                  </td>
                  <td style={tdStyle}>
                    <div style={{ display: 'flex', gap: '0.375rem' }}>
                      <button onClick={() => setSelectedUser(u)} style={{ padding: '0.25rem 0.625rem', borderRadius: '0.375rem', border: '1px solid var(--color-border)', background: 'white', fontSize: '0.75rem', cursor: 'pointer', color: '#475569', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <Eye style={{ width: 12, height: 12 }} /> View
                      </button>
                      <a href={`mailto:${u.email}`} style={{ padding: '0.25rem 0.625rem', borderRadius: '0.375rem', border: '1px solid var(--color-border)', background: 'white', fontSize: '0.75rem', cursor: 'pointer', color: '#475569', display: 'flex', alignItems: 'center', gap: '0.25rem', textDecoration: 'none' }}>
                        <MessageSquare style={{ width: 12, height: 12 }} /> Email
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-subtle)' }}>No buyers found</div>
          )}
        </div>
      )}

      {/* Buyer Detail Modal */}
      {selectedUser && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
          <div style={{ background: 'white', borderRadius: 'var(--radius-xl)', padding: '2rem', width: '100%', maxWidth: '520px', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 800, fontSize: '1.25rem' }}>
                {selectedUser.name?.charAt(0)?.toUpperCase() ?? '?'}
              </div>
              <div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 700, color: 'var(--color-ink)' }}>{selectedUser.name}</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-muted)' }}>{selectedUser.email}</p>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.5rem' }}>
              {[
                { label: 'Plan', value: selectedUser.plan ?? 'Free' },
                { label: 'Status', value: selectedUser.status ?? 'Active' },
                { label: 'Company', value: selectedUser.company ?? '—' },
                { label: 'Country', value: selectedUser.country ?? '—' },
                { label: 'Phone', value: selectedUser.phone ?? '—' },
                { label: 'Joined', value: selectedUser.createdAt ? new Date(selectedUser.createdAt).toLocaleDateString() : '—' },
              ].map(item => (
                <div key={item.label} style={{ background: 'var(--color-bg)', borderRadius: 'var(--radius-md)', padding: '0.75rem' }}>
                  <div style={{ fontSize: '0.6875rem', fontWeight: 700, color: 'var(--color-subtle)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.25rem' }}>{item.label}</div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-ink)' }}>{item.value}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
              <button onClick={() => setSelectedUser(null)} style={{ padding: '0.625rem 1.25rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', background: 'white', fontWeight: 600, fontSize: '0.875rem', cursor: 'pointer', color: '#475569' }}>
                Close
              </button>
              <a href={`mailto:${selectedUser.email}`} style={{ padding: '0.625rem 1.5rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', fontWeight: 700, fontSize: '0.875rem', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.375rem' }}>
                <MessageSquare style={{ width: 14, height: 14 }} /> Send Email
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
