import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { AIChatBox, type Message } from "@/components/AIChatBox";

const SUGGESTED_PROMPTS = [
  "كيف أجد مورد موثوق في الصين؟",
  "ما هي الوثائق المطلوبة للاستيراد؟",
  "كيف أحسب تكلفة الشحن من الصين؟",
  "كيف أتحقق من مصنع قبل الطلب؟",
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.response },
      ]);
    },
  });

  const handleSend = (content: string) => {
    const history = messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content }));
    setMessages(prev => [...prev, { role: "user", content }]);
    chatMutation.mutate({
      message: content,
      conversationHistory: history,
      userType: "buyer",
      context: { userLanguage: "ar" },
    });
  };

  return (
    <div className="flex flex-col h-screen max-h-screen p-4 bg-background">
      <div className="mb-4">
        <h1 className="text-2xl font-bold">المساعد الذكي للاستيراد</h1>
        <p className="text-sm text-muted-foreground">
          مساعد متخصص في الاستيراد من الصين — يجيب على أسئلتك حول الموردين، الجمارك، الشحن، والتفاوض.
        </p>
      </div>

      <AIChatBox
        messages={messages}
        onSendMessage={handleSend}
        isLoading={chatMutation.isPending}
        placeholder="اكتب سؤالك هنا..."
        emptyStateMessage="ابدأ محادثة مع المساعد الذكي"
        suggestedPrompts={SUGGESTED_PROMPTS}
        height="calc(100vh - 130px)"
      />
    </div>
  );
}
