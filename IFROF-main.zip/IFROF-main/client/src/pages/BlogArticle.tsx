/**
 * BlogArticle — صفحة قراءة المقالة
 * تأثير الكتابة التدريجي (Typewriter) — كأن المقالة تُكتب أمامك
 */
import { useState, useEffect, useRef } from 'react';
import { Link, useParams } from 'wouter';
import { Clock, Tag, Share2, ThumbsUp, Eye, ArrowRight, Calendar, BookOpen, ChevronUp } from 'lucide-react';
import { trpc } from '@/lib/trpc';

// ── Typewriter Hook ──────────────────────────────────────────
function useTypewriter(text: string, speed = 10) {
  const [displayed, setDisplayed] = useState('');
  const [done, setDone] = useState(false);
  const indexRef = useRef(0);

  useEffect(() => {
    if (!text) return;
    setDisplayed('');
    setDone(false);
    indexRef.current = 0;

    const interval = setInterval(() => {
      const next = text.indexOf(' ', indexRef.current + 1);
      const end = next === -1 ? text.length : next + 1;
      setDisplayed(text.slice(0, end));
      indexRef.current = end;
      if (end >= text.length) {
        clearInterval(interval);
        setDone(true);
      }
    }, speed);

    return () => clearInterval(interval);
  }, [text, speed]);

  return { displayed, done };
}

// ── Streaming Paragraph ──────────────────────────────────────
function StreamParagraph({ text, delay = 0 }: { text: string; delay?: number }) {
  const [started, setStarted] = useState(false);
  const { displayed, done } = useTypewriter(started ? text : '', 11);

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  return (
    <p style={{
      lineHeight: 1.95, color: '#1e293b', fontSize: '1.0625rem',
      marginBottom: '1.5rem', fontFamily: '"DM Sans", Tajawal, sans-serif',
      direction: 'rtl', textAlign: 'justify',
    }}>
      {started ? displayed : <span style={{ opacity: 0 }}>{text.slice(0, 1)}</span>}
      {!done && started && (
        <span style={{
          display: 'inline-block', width: 2, height: '1.1em',
          background: '#06b6d4', marginRight: 3, verticalAlign: 'text-bottom',
          animation: 'blink 0.65s step-end infinite',
        }} />
      )}
    </p>
  );
}

// ── Article Content Renderer ─────────────────────────────────
function ArticleContent({ content }: { content: string }) {
  const blocks = content.split(/\n{2,}/).map(p => p.trim()).filter(Boolean);
  let delay = 0;

  return (
    <div style={{ direction: 'rtl' }}>
      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        @keyframes fadeSlide { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes blog-art-spin { to{transform:rotate(360deg)} }
      `}</style>

      {blocks.map((block, i) => {
        const thisDelay = delay;

        if (block.startsWith('## ')) {
          delay += 100;
          return (
            <h2 key={i} style={{
              fontFamily: '"DM Sans", Tajawal, sans-serif',
              fontSize: '1.5rem', fontWeight: 900, color: '#0f172a',
              marginTop: '2.5rem', marginBottom: '1rem', lineHeight: 1.3,
              direction: 'rtl', borderRight: '4px solid #06b6d4',
              paddingRight: '0.875rem',
              animation: `fadeSlide 0.4s ease ${thisDelay}ms both`,
            }}>
              {block.replace(/^## /, '')}
            </h2>
          );
        }

        if (block.startsWith('### ')) {
          delay += 80;
          return (
            <h3 key={i} style={{
              fontFamily: '"DM Sans", Tajawal, sans-serif',
              fontSize: '1.2rem', fontWeight: 800, color: '#0f172a',
              marginTop: '2rem', marginBottom: '0.75rem',
              direction: 'rtl',
              animation: `fadeSlide 0.4s ease ${thisDelay}ms both`,
            }}>
              {block.replace(/^### /, '')}
            </h3>
          );
        }

        if (block.startsWith('> ')) {
          delay += 250;
          return (
            <blockquote key={i} style={{
              borderRight: '4px solid #06b6d4', margin: '1.75rem 0',
              background: 'linear-gradient(135deg, rgba(6,182,212,0.06), rgba(6,182,212,0.02))',
              borderRadius: '0 0.75rem 0.75rem 0', padding: '1.25rem 1.5rem',
              direction: 'rtl',
              animation: `fadeSlide 0.4s ease ${thisDelay}ms both`,
            }}>
              <p style={{ color: '#0f4c6b', fontSize: '1.05rem', lineHeight: 1.85, margin: 0, fontStyle: 'italic', fontWeight: 600 }}>
                {block.replace(/^> /, '')}
              </p>
            </blockquote>
          );
        }

        if (block.startsWith('- ') || block.startsWith('* ')) {
          delay += 200;
          const items = block.split('\n').map(l => l.replace(/^[-*] /, '').trim()).filter(Boolean);
          return (
            <ul key={i} style={{
              paddingRight: '1.5rem', marginBottom: '1.5rem',
              direction: 'rtl', listStyleType: 'none',
              animation: `fadeSlide 0.4s ease ${thisDelay}ms both`,
            }}>
              {items.map((item, j) => (
                <li key={j} style={{
                  color: '#1e293b', fontSize: '1.0625rem', lineHeight: 1.8,
                  marginBottom: '0.625rem', display: 'flex', alignItems: 'flex-start', gap: '0.625rem',
                }}>
                  <span style={{ color: '#06b6d4', fontWeight: 900, marginTop: '0.1rem', flexShrink: 0 }}>◆</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          );
        }

        if (block.match(/^\d+\. /)) {
          delay += 200;
          const items = block.split('\n').map(l => l.replace(/^\d+\. /, '').trim()).filter(Boolean);
          return (
            <ol key={i} style={{
              paddingRight: '1.5rem', marginBottom: '1.5rem',
              direction: 'rtl', listStyleType: 'none',
              animation: `fadeSlide 0.4s ease ${thisDelay}ms both`,
            }}>
              {items.map((item, j) => (
                <li key={j} style={{
                  color: '#1e293b', fontSize: '1.0625rem', lineHeight: 1.8,
                  marginBottom: '0.75rem', display: 'flex', alignItems: 'flex-start', gap: '0.75rem',
                }}>
                  <span style={{
                    background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
                    color: '#fff', fontWeight: 800, fontSize: '0.75rem',
                    width: 24, height: 24, borderRadius: '50%',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0, marginTop: '0.1rem',
                  }}>
                    {j + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
          );
        }

        delay += Math.min(block.length * 0.4, 350);
        return <StreamParagraph key={i} text={block} delay={thisDelay} />;
      })}
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────
export default function BlogArticle() {
  const params = useParams<{ id: string }>();
  const slug = params.id ?? '';
  const [liked, setLiked] = useState(false);
  const [readProgress, setReadProgress] = useState(0);
  const [copied, setCopied] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  const { data, isLoading, error } = trpc.blog.getBySlug.useQuery(
    { slug },
    { enabled: !!slug }
  );

  const { data: relatedRaw } = trpc.blog.listArticles.useQuery(
    { limit: 4, status: 'published' } as any,
    { enabled: !!data }
  );

  useEffect(() => {
    const handleScroll = () => {
      const el = document.documentElement;
      const progress = el.scrollHeight - el.clientHeight;
      const pct = progress > 0 ? Math.min(100, Math.max(0, (el.scrollTop / progress) * 100)) : 0;
      setReadProgress(pct);
      setShowScrollTop(el.scrollTop > 600);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  // Loading
  if (isLoading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', background: '#f8fafc', direction: 'rtl',
      }}>
        <div style={{ textAlign: 'center' }}>
          <style>{`@keyframes blog-art-spin { to{transform:rotate(360deg)} }`}</style>
          <div style={{
            width: 52, height: 52, border: '3px solid #e2e8f0',
            borderTopColor: '#06b6d4', borderRadius: '50%',
            animation: 'blog-art-spin 0.8s linear infinite', margin: '0 auto 1.25rem',
          }} />
          <p style={{ color: '#64748b', fontFamily: '"DM Sans", Tajawal, sans-serif', fontSize: '1rem' }}>
            جاري تحميل المقالة...
          </p>
        </div>
      </div>
    );
  }

  // Error / Not found
  if (error || !data) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', background: '#f8fafc', direction: 'rtl',
      }}>
        <div style={{ textAlign: 'center', maxWidth: 480, padding: '2rem' }}>
          <BookOpen size={56} color="#cbd5e1" style={{ margin: '0 auto 1.5rem' }} />
          <h2 style={{
            fontFamily: '"DM Sans", Tajawal, sans-serif', fontWeight: 800,
            color: '#0f172a', fontSize: '1.5rem', marginBottom: '0.75rem',
          }}>
            المقالة غير موجودة
          </h2>
          <p style={{ color: '#64748b', marginBottom: '1.5rem', lineHeight: 1.7 }}>
            ربما تم نقل هذه المقالة أو حذفها. تصفّح جميع مقالاتنا من صفحة المدونة.
          </p>
          <Link href="/blog" style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            padding: '0.75rem 1.5rem',
            background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
            color: '#fff', borderRadius: '0.75rem',
            fontWeight: 700, textDecoration: 'none', fontSize: '0.9375rem',
          }}>
            <ArrowRight size={16} /> العودة للمدونة
          </Link>
        </div>
      </div>
    );
  }

  const { article, category, author } = data as any;
  const tags: string[] = article.tags ? (typeof article.tags === 'string' ? JSON.parse(article.tags) : article.tags) : [];
  const related = (relatedRaw ?? []).filter((r: any) => r.article.id !== article.id).slice(0, 3);

  return (
    <div style={{
      minHeight: '100vh',
      background: '#f8fafc',
      direction: 'rtl',
      fontFamily: '"DM Sans", Tajawal, sans-serif',
      marginTop: 'calc(var(--nav-offset, 6.75rem) * -1)', /* cancel main padding so hero is flush with nav */
    }}>

      {/* ── Read Progress Bar ── sits at nav bottom, not behind it */}
      <div style={{
        position: 'fixed', top: 'var(--nav-offset, 6.75rem)', right: 0, left: 0, height: 3,
        background: 'rgba(226,232,240,0.6)', zIndex: 90,
      }}>
        <div style={{
          height: '100%', width: `${readProgress}%`,
          background: 'linear-gradient(90deg, #06b6d4, #22c55e)',
          transition: 'width 0.1s',
        }} />
      </div>

      {/* ── Scroll to Top ── */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          style={{
            position: 'fixed', bottom: '2rem', left: '1.5rem',
            width: 44, height: 44, borderRadius: '50%',
            background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
            border: 'none', cursor: 'pointer', zIndex: 80,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 16px rgba(6,182,212,0.4)',
            transition: 'transform 0.2s',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'scale(1.1)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'scale(1)'; }}
        >
          <ChevronUp size={20} color="#fff" />
        </button>
      )}

      {/* ── Hero ────────────────────────────────────────────── */}
      <section style={{
        background: 'linear-gradient(150deg, #020817 0%, #0c1a2e 45%, #0f2d4a 100%)',
        paddingTop: 'calc(var(--nav-offset, 6.75rem) + 3.5rem)',
        paddingBottom: '4rem',
        paddingLeft: '1.5rem',
        paddingRight: '1.5rem',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 30% 50%, rgba(6,182,212,0.12), transparent 60%)' }} />
        <div style={{ maxWidth: 820, margin: '0 auto', position: 'relative' }}>

          {/* Breadcrumb */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            marginBottom: '1.5rem', flexWrap: 'wrap',
          }}>
            <Link href="/blog" style={{
              color: '#64748b', textDecoration: 'none', fontSize: '0.875rem',
              display: 'flex', alignItems: 'center', gap: '0.3rem',
              transition: 'color 0.15s',
            }}>
              <ArrowRight size={14} /> المدونة
            </Link>
            {category && (
              <>
                <span style={{ color: '#334155', fontSize: '0.875rem' }}>/</span>
                <span style={{ color: '#06b6d4', fontSize: '0.875rem', fontWeight: 700 }}>{category.name}</span>
              </>
            )}
          </div>

          {/* Category Badge */}
          {category && (
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
              background: 'rgba(6,182,212,0.12)', border: '1px solid rgba(6,182,212,0.25)',
              borderRadius: '2rem', padding: '0.3rem 0.875rem',
              marginBottom: '1.25rem', fontSize: '0.8rem',
              color: '#22d3ee', fontWeight: 700,
            }}>
              <Tag size={12} /> {category.name}
            </div>
          )}

          {/* Title */}
          <h1 style={{
            fontSize: 'clamp(1.5rem, 4vw, 2.375rem)',
            fontWeight: 900, color: '#f1f5f9',
            lineHeight: 1.25, marginBottom: '1.25rem',
            letterSpacing: '-0.02em', fontFamily: '"DM Sans", Tajawal, sans-serif',
          }}>
            {article.title}
          </h1>

          {/* Excerpt */}
          {article.excerpt && (
            <p style={{ color: '#94a3b8', fontSize: '1.05rem', lineHeight: 1.75, marginBottom: '1.75rem' }}>
              {article.excerpt}
            </p>
          )}

          {/* Meta */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '1.25rem',
            flexWrap: 'wrap', paddingTop: '1.25rem',
            borderTop: '1px solid rgba(255,255,255,0.07)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontSize: '0.875rem' }}>
              <Clock size={14} />
              <span>{article.readTime ?? 7} دقائق قراءة</span>
            </div>
            {article.publishedAt && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontSize: '0.875rem' }}>
                <Calendar size={14} />
                <span>{new Date(article.publishedAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
            )}
            {article.viewCount != null && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#64748b', fontSize: '0.875rem' }}>
                <Eye size={14} />
                <span>{article.viewCount.toLocaleString('ar-EG')} مشاهدة</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ── Cover Image ─────────────────────────────────────── */}
      {article.coverImage && (
        <div style={{ maxWidth: 820, margin: '-1.5rem auto 0', padding: '0 1.5rem' }}>
          <img
            src={article.coverImage}
            alt={article.title}
            style={{
              width: '100%', borderRadius: '1.125rem',
              boxShadow: '0 20px 60px rgba(0,0,0,0.2)', display: 'block',
              border: '1px solid rgba(255,255,255,0.1)',
            }}
            loading="eager"
          />
        </div>
      )}

      {/* ── Article Body ─────────────────────────────────────── */}
      <div style={{ maxWidth: 820, margin: '0 auto', padding: article.coverImage ? '2.5rem 1.5rem 4rem' : '3rem 1.5rem 4rem' }}>
        <div style={{
          background: '#fff', borderRadius: '1.25rem',
          padding: 'clamp(1.5rem, 4vw, 3rem)',
          boxShadow: '0 4px 24px rgba(0,0,0,0.06), 0 1px 4px rgba(0,0,0,0.03)',
          border: '1px solid #f1f5f9',
        }}>
          {article.content ? (
            <ArticleContent content={article.content} />
          ) : (
            <p style={{ color: '#94a3b8', textAlign: 'center', padding: '3rem', fontSize: '1rem' }}>
              محتوى المقالة غير متاح حالياً
            </p>
          )}

          {/* Tags */}
          {tags.length > 0 && (
            <div style={{ marginTop: '2.5rem', paddingTop: '1.5rem', borderTop: '1px solid #f1f5f9' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                <Tag size={14} color="#94a3b8" />
                {tags.map((tag, i) => (
                  <span key={i} style={{
                    padding: '0.3rem 0.75rem', background: '#f8fafc',
                    color: '#475569', borderRadius: 20, fontSize: '0.8125rem', fontWeight: 600,
                    border: '1px solid #e2e8f0',
                  }}>
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div style={{
            marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid #f1f5f9',
            display: 'flex', gap: '0.75rem', flexWrap: 'wrap',
          }}>
            <button
              onClick={() => setLiked(p => !p)}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                padding: '0.5625rem 1.25rem',
                border: `1.5px solid ${liked ? '#06b6d4' : '#e2e8f0'}`,
                borderRadius: '0.625rem',
                background: liked ? 'rgba(6,182,212,0.08)' : '#fff',
                color: liked ? '#06b6d4' : '#64748b',
                fontWeight: 700, cursor: 'pointer', fontSize: '0.875rem',
                fontFamily: '"DM Sans", Tajawal, sans-serif',
                transition: 'all 0.15s',
              }}
            >
              <ThumbsUp size={15} /> {liked ? 'أعجبتني ✓' : 'أعجبتني'}
            </button>
            <button
              onClick={handleShare}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                padding: '0.5625rem 1.25rem',
                border: '1.5px solid #e2e8f0', borderRadius: '0.625rem',
                background: '#fff', color: '#64748b',
                fontWeight: 700, cursor: 'pointer', fontSize: '0.875rem',
                fontFamily: '"DM Sans", Tajawal, sans-serif',
                transition: 'all 0.15s',
              }}
            >
              <Share2 size={15} /> {copied ? 'تم نسخ الرابط ✓' : 'مشاركة'}
            </button>
          </div>
        </div>

        {/* ── Related Articles ───────────────────────────────── */}
        {related.length > 0 && (
          <div style={{ marginTop: '3rem' }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.625rem',
              marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid #e2e8f0',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: '0.5rem',
                background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.12)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <BookOpen size={15} color="#06b6d4" />
              </div>
              <h3 style={{
                fontFamily: '"DM Sans", Tajawal, sans-serif', fontWeight: 800,
                color: '#0f172a', fontSize: '1.125rem', margin: 0,
              }}>
                مقالات ذات صلة
              </h3>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1rem' }}>
              {related.map((r: any) => {
                const ra = r.article;
                const rc = r.category;
                return (
                  <Link key={ra.id} href={`/blog/${ra.slug}`} style={{ textDecoration: 'none' }}>
                    <div
                      style={{
                        background: '#fff', borderRadius: '0.875rem', overflow: 'hidden',
                        border: '1px solid #e8edf2', cursor: 'pointer',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
                      }}
                      onMouseEnter={e => {
                        (e.currentTarget as HTMLElement).style.transform = 'translateY(-3px)';
                        (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 28px rgba(0,0,0,0.09)';
                      }}
                      onMouseLeave={e => {
                        (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                        (e.currentTarget as HTMLElement).style.boxShadow = '0 2px 8px rgba(0,0,0,0.04)';
                      }}
                    >
                      {ra.coverImage ? (
                        <img src={ra.coverImage} alt={ra.title} style={{ width: '100%', height: 130, objectFit: 'cover' }} loading="lazy" />
                      ) : (
                        <div style={{
                          width: '100%', height: 130,
                          background: 'linear-gradient(135deg, #0f172a, #1e3a5f)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}>
                          <BookOpen size={24} color="rgba(6,182,212,0.5)" />
                        </div>
                      )}
                      <div style={{ padding: '1rem', direction: 'rtl' }}>
                        {rc && (
                          <div style={{
                            fontSize: '0.6875rem', fontWeight: 800, color: '#0891b2',
                            marginBottom: '0.375rem', textTransform: 'uppercase',
                            background: 'rgba(6,182,212,0.07)', display: 'inline-block',
                            padding: '0.15rem 0.5rem', borderRadius: '0.3rem',
                          } as React.CSSProperties}>
                            {rc.name}
                          </div>
                        )}
                        <h4 style={{
                          fontFamily: '"DM Sans", Tajawal, sans-serif', fontWeight: 700,
                          color: '#0f172a', fontSize: '0.9rem', lineHeight: 1.45,
                          marginBottom: '0.5rem', marginTop: rc ? '0.5rem' : 0,
                          display: '-webkit-box', WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical', overflow: 'hidden',
                        } as React.CSSProperties}>
                          {ra.title}
                        </h4>
                        <div style={{ fontSize: '0.8rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <Clock size={11} /> {ra.readTime ?? 5} دقائق
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* ── CTA ───────────────────────────────────────────── */}
        <div style={{
          marginTop: '3rem',
          background: 'linear-gradient(150deg, #020817 0%, #0c1a2e 50%, #0f2d4a 100%)',
          borderRadius: '1.25rem', padding: '2.5rem',
          textAlign: 'center', direction: 'rtl',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            background: 'radial-gradient(ellipse at 50% 0%, rgba(6,182,212,0.15), transparent 65%)',
          }} />
          <div style={{ position: 'relative' }}>
            <h3 style={{
              fontFamily: '"DM Sans", Tajawal, sans-serif', fontWeight: 900,
              color: '#f1f5f9', fontSize: '1.375rem', marginBottom: '0.75rem',
            }}>
              هل أنت مستعد للاستيراد باحتراف؟
            </h3>
            <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '1.75rem', fontSize: '1rem', lineHeight: 1.7 }}>
              انضم إلى آلاف المستوردين الذين يستخدمون IFROF للحصول على أفضل الموردين الموثوقين من الصين.
            </p>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link href="/register" style={{
                display: 'inline-flex', alignItems: 'center',
                padding: '0.75rem 2rem',
                background: 'linear-gradient(135deg, #06b6d4, #0891b2)',
                color: '#fff', borderRadius: '0.75rem',
                fontWeight: 700, textDecoration: 'none', fontSize: '0.9375rem',
                boxShadow: '0 4px 16px rgba(6,182,212,0.35)',
              }}>
                ابدأ مجاناً
              </Link>
              <Link href="/blog" style={{
                display: 'inline-flex', alignItems: 'center',
                padding: '0.75rem 2rem',
                background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)',
                color: '#f1f5f9', borderRadius: '0.75rem',
                fontWeight: 700, textDecoration: 'none', fontSize: '0.9375rem',
              }}>
                المزيد من المقالات
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
