import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { BlogManagementTab } from '@/components/BlogManagementTab';
import { useTranslation } from 'react-i18next';
import {
  Users, Factory, Package, DollarSign, TrendingUp, CheckCircle, XCircle,
  Clock, AlertTriangle, Settings, BarChart3, Activity, Shield, Search,
  Eye, Ban, Check, X, Edit, BookOpen, Plus, Trash2, Truck, MapPin,
  RefreshCw, ChevronDown, ChevronUp, Anchor, Plane, Train, Zap, FileText,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { SuppliersTab, RfqQuotesTab, CrmTab } from './AdminOperationsTabs';

type Tab = 'overview' | 'users' | 'rfq' | 'orders' | 'shipments' | 'quotes' | 'crm' | 'suppliers' | 'blog' | 'settings' | 'verification';

// ============ SHIPMENTS TAB ============
function ShipmentsTab({
  thStyle,
  tdStyle,
  badge,
}: {
  thStyle: React.CSSProperties;
  tdStyle: React.CSSProperties;
  badge: (color: string, bg: string, text: string) => React.ReactElement;
}) {
  const { t } = useTranslation();
  const [expandedShipment, setExpandedShipment] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // tRPC: fetch all shipments (admin)
  const { data: shipmentsData, isLoading, refetch } = trpc.shipment.listAll.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  // tRPC: update shipment status
  const updateStatus = trpc.shipment.updateStatus.useMutation({
    onSuccess: () => {
      toast.success(t('admin.shipments.statusUpdated', 'Shipment status updated'));
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  // tRPC: create shipment
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    orderId: '',
    userId: '',
    trackingNumber: '',
    carrier: '',
    method: 'sea' as 'sea' | 'air' | 'rail' | 'express',
    origin: '',
    destination: '',
    estimatedDelivery: '',
    weight: '',
    shippingCost: '',
  });

  const createShipment = trpc.shipment.create.useMutation({
    onSuccess: () => {
      toast.success(t('admin.shipments.created', 'Shipment created successfully'));
      setCreateOpen(false);
      setCreateForm({ orderId: '', userId: '', trackingNumber: '', carrier: '', method: 'sea', origin: '', destination: '', estimatedDelivery: '', weight: '', shippingCost: '' });
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-md)',
    border: '1.5px solid var(--color-border)', fontSize: '0.875rem',
    fontFamily: 'var(--font-body)', color: 'var(--color-ink)', outline: 'none',
  };

  const getStatusConfig = (status: string) => {
    const configs: Record<string, { color: string; bg: string; label: string }> = {
      pending:          { color: '#d97706', bg: 'rgba(245,158,11,0.1)',   label: t('admin.shipments.status.pending', 'Pending') },
      picked_up:        { color: '#0891b2', bg: 'rgba(6,182,212,0.1)',    label: t('admin.shipments.status.picked_up', 'Picked Up') },
      in_transit:       { color: '#2563eb', bg: 'rgba(37,99,235,0.1)',    label: t('admin.shipments.status.in_transit', 'In Transit') },
      customs:          { color: '#7c3aed', bg: 'rgba(124,58,237,0.1)',   label: t('admin.shipments.status.customs', 'Customs') },
      out_for_delivery: { color: '#059669', bg: 'rgba(16,185,129,0.1)',   label: t('admin.shipments.status.out_for_delivery', 'Out for Delivery') },
      delivered:        { color: '#059669', bg: 'rgba(16,185,129,0.1)',   label: t('admin.shipments.status.delivered', 'Delivered') },
      exception:        { color: '#dc2626', bg: 'rgba(239,68,68,0.1)',    label: t('admin.shipments.status.exception', 'Exception') },
    };
    return configs[status] ?? { color: 'var(--color-muted)', bg: 'rgba(100,116,139,0.1)', label: status };
  };

  const getMethodIcon = (method: string) => {
    const icons: Record<string, React.ElementType> = {
      sea: Anchor, air: Plane, rail: Train, express: Zap,
    };
    const Icon = icons[method] ?? Truck;
    return <Icon style={{ width: 14, height: 14 }} />;
  };

  const allShipments = shipmentsData ?? [];
  const filtered = allShipments.filter(({ shipment }) => {
    const matchesStatus = statusFilter === 'all' || shipment.status === statusFilter;
    const matchesSearch = !searchQuery ||
      shipment.trackingNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shipment.carrier?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shipment.origin?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shipment.destination?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Stats
  const statusCounts = allShipments.reduce((acc, { shipment }) => {
    acc[shipment.status ?? 'pending'] = (acc[shipment.status ?? 'pending'] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statCards = [
    { label: t('admin.shipments.totalShipments', 'Total Shipments'), value: allShipments.length, color: '#06b6d4', bg: 'rgba(6,182,212,0.08)', icon: Truck },
    { label: t('admin.shipments.inTransit', 'In Transit'), value: (statusCounts['in_transit'] ?? 0) + (statusCounts['picked_up'] ?? 0), color: '#2563eb', bg: 'rgba(37,99,235,0.08)', icon: MapPin },
    { label: t('admin.shipments.inCustoms', 'In Customs'), value: statusCounts['customs'] ?? 0, color: '#7c3aed', bg: 'rgba(124,58,237,0.08)', icon: Shield },
    { label: t('admin.shipments.delivered', 'Delivered'), value: statusCounts['delivered'] ?? 0, color: '#10b981', bg: 'rgba(16,185,129,0.08)', icon: CheckCircle },
    { label: t('admin.shipments.exceptions', 'Exceptions'), value: statusCounts['exception'] ?? 0, color: '#ef4444', bg: 'rgba(239,68,68,0.08)', icon: AlertTriangle },
  ];

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)' }}>
          {t('admin.shipments.title', 'Shipments Management')}
        </h2>
        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
          <button
            onClick={() => refetch()}
            style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.5rem 0.875rem', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-2)', border: 'none', cursor: 'pointer', fontSize: '0.8125rem', fontWeight: 600, color: '#475569' }}
          >
            <RefreshCw style={{ width: 14, height: 14 }} /> {t('admin.shipments.refresh', 'Refresh')}
          </button>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <button style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', cursor: 'pointer', fontSize: '0.8125rem', fontWeight: 600, boxShadow: '0 4px 12px rgba(6,182,212,0.3)' }}>
                <Plus style={{ width: 14, height: 14 }} /> {t('admin.shipments.createShipment', 'Create Shipment')}
              </button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('admin.shipments.createShipment', 'Create Shipment')}</DialogTitle>
              </DialogHeader>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '1rem' }}>
                {[
                  { label: t('admin.shipments.form.orderId', 'Order ID'), key: 'orderId', type: 'number' },
                  { label: t('admin.shipments.form.userId', 'User ID'), key: 'userId', type: 'number' },
                  { label: t('admin.shipments.form.trackingNumber', 'Tracking Number'), key: 'trackingNumber', type: 'text' },
                  { label: t('admin.shipments.form.carrier', 'Carrier'), key: 'carrier', type: 'text' },
                  { label: t('admin.shipments.form.origin', 'Origin'), key: 'origin', type: 'text' },
                  { label: t('admin.shipments.form.destination', 'Destination'), key: 'destination', type: 'text' },
                  { label: t('admin.shipments.form.estimatedDelivery', 'Est. Delivery'), key: 'estimatedDelivery', type: 'date' },
                  { label: t('admin.shipments.form.weight', 'Weight (g)'), key: 'weight', type: 'number' },
                  { label: t('admin.shipments.form.shippingCost', 'Shipping Cost ($)'), key: 'shippingCost', type: 'number' },
                ].map(({ label, key, type }) => (
                  <div key={key}>
                    <Label style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem', display: 'block' }}>{label}</Label>
                    <input
                      type={type}
                      value={(createForm as any)[key]}
                      onChange={e => setCreateForm(f => ({ ...f, [key]: e.target.value }))}
                      style={inputStyle}
                    />
                  </div>
                ))}
                <div>
                  <Label style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem', display: 'block' }}>
                    {t('admin.shipments.form.method', 'Shipping Method')}
                  </Label>
                  <select
                    value={createForm.method}
                    onChange={e => setCreateForm(f => ({ ...f, method: e.target.value as any }))}
                    style={inputStyle}
                  >
                    {['sea', 'air', 'rail', 'express'].map(m => (
                      <option key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '1.5rem' }}>
                <button onClick={() => setCreateOpen(false)} style={{ padding: '0.5rem 1rem', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-2)', border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: '0.875rem', color: '#475569' }}>
                  {t('common.cancel', 'Cancel')}
                </button>
                <button
                  onClick={() => {
                    if (!createForm.orderId || !createForm.userId) {
                      toast.error(t('admin.shipments.form.orderUserRequired', 'Order ID and User ID are required'));
                      return;
                    }
                    createShipment.mutate({
                      orderId: Number(createForm.orderId),
                      userId: Number(createForm.userId),
                      trackingNumber: createForm.trackingNumber || undefined,
                      carrier: createForm.carrier || undefined,
                      method: createForm.method,
                      origin: createForm.origin || undefined,
                      destination: createForm.destination || undefined,
                      estimatedDelivery: createForm.estimatedDelivery || undefined,
                      weight: createForm.weight ? Number(createForm.weight) : undefined,
                      shippingCost: createForm.shippingCost ? Number(createForm.shippingCost) * 100 : undefined,
                    });
                  }}
                  disabled={createShipment.isPending}
                  style={{ padding: '0.5rem 1.25rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: '0.875rem' }}
                >
                  {createShipment.isPending ? t('common.creating', 'Creating...') : t('admin.shipments.create', 'Create')}
                </button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '0.75rem', marginBottom: '1.5rem' }}>
        {statCards.map((s, i) => (
          <div key={i} style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-md)', background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '0.625rem' }}>
              <s.icon style={{ width: 16, height: 16, color: s.color }} />
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.375rem', fontWeight: 800, color: 'var(--color-ink)' }}>{s.value}</div>
            <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)', marginTop: '0.125rem' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
          <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 15, height: 15, color: 'var(--color-subtle)' }} />
          <input
            type="text"
            placeholder={t('admin.shipments.searchPlaceholder', 'Search tracking, carrier, origin...')}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            style={{ width: '100%', padding: '0.5rem 0.75rem 0.5rem 2.25rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', fontSize: '0.8125rem', fontFamily: 'var(--font-body)', color: 'var(--color-ink)', outline: 'none' }}
          />
        </div>
        <div style={{ display: 'flex', gap: '0.375rem', flexWrap: 'wrap' }}>
          {['all', 'pending', 'picked_up', 'in_transit', 'customs', 'out_for_delivery', 'delivered', 'exception'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              style={{
                padding: '0.375rem 0.75rem', borderRadius: 'var(--radius-xl)', fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer', border: 'none',
                background: statusFilter === s ? '#06b6d4' : '#f1f5f9',
                color: statusFilter === s ? 'white' : '#475569',
              }}
            >
              {s === 'all' ? t('common.all', 'All') : getStatusConfig(s).label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '3rem', textAlign: 'center', color: 'var(--color-subtle)' }}>
          <div style={{ width: '32px', height: '32px', border: '3px solid rgba(6,182,212,0.2)', borderTop: '3px solid #06b6d4', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto 1rem' }} />
          {t('common.loading', 'Loading...')}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '3rem', textAlign: 'center', color: 'var(--color-subtle)' }}>
          <Truck style={{ width: 48, height: 48, margin: '0 auto 1rem', opacity: 0.4 }} />
          <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '0.5rem' }}>
            {t('admin.shipments.noShipments', 'No shipments found')}
          </p>
          <p style={{ fontSize: '0.875rem' }}>{t('admin.shipments.noShipmentsDesc', 'Adjust filters or create a new shipment.')}</p>
        </div>
      ) : (
        <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {[
                  t('admin.shipments.col.id', 'ID'),
                  t('admin.shipments.col.tracking', 'Tracking'),
                  t('admin.shipments.col.carrier', 'Carrier'),
                  t('admin.shipments.col.method', 'Method'),
                  t('admin.shipments.col.route', 'Route'),
                  t('admin.shipments.col.status', 'Status'),
                  t('admin.shipments.col.estDelivery', 'Est. Delivery'),
                  t('admin.shipments.col.actions', 'Actions'),
                ].map(h => <th key={h} style={thStyle}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.map(({ shipment }) => {
                const sc = getStatusConfig(shipment.status ?? 'pending');
                const isExpanded = expandedShipment === shipment.id;
                return (
                  <>
                    <tr
                      key={shipment.id}
                      style={{ cursor: 'pointer', transition: 'background 200ms' }}
                      onMouseEnter={e => (e.currentTarget.style.background = '#f8fafc')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                    >
                      <td style={{ ...tdStyle, fontWeight: 700, color: 'var(--color-ink)' }}>#{shipment.id}</td>
                      <td style={tdStyle}>
                        <code style={{ background: 'var(--color-bg-2)', padding: '0.1875rem 0.5rem', borderRadius: '0.375rem', fontSize: '0.75rem', color: '#06b6d4', fontWeight: 700 }}>
                          {shipment.trackingNumber ?? t('admin.shipments.noTracking', 'N/A')}
                        </code>
                      </td>
                      <td style={{ ...tdStyle, color: '#475569' }}>{shipment.carrier ?? '—'}</td>
                      <td style={tdStyle}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>
                          {getMethodIcon(shipment.method ?? 'sea')}
                          {(shipment.method ?? 'sea').charAt(0).toUpperCase() + (shipment.method ?? 'sea').slice(1)}
                        </span>
                      </td>
                      <td style={tdStyle}>
                        <div style={{ fontSize: '0.75rem', color: 'var(--color-ink)', fontWeight: 600 }}>{shipment.origin ?? '—'}</div>
                        <div style={{ fontSize: '0.6875rem', color: 'var(--color-subtle)' }}>→ {shipment.destination ?? '—'}</div>
                      </td>
                      <td style={tdStyle}>{badge(sc.color, sc.bg, sc.label)}</td>
                      <td style={{ ...tdStyle, color: 'var(--color-muted)', fontSize: '0.75rem' }}>
                        {shipment.estimatedDelivery
                          ? new Date(shipment.estimatedDelivery).toLocaleDateString()
                          : '—'}
                      </td>
                      <td style={{ ...tdStyle, textAlign: 'right' }}>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.375rem' }}>
                          <button
                            onClick={() => setExpandedShipment(isExpanded ? null : shipment.id)}
                            style={{ padding: '0.375rem', borderRadius: '0.375rem', background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--color-muted)' }}
                            title={t('admin.shipments.updateStatus', 'Update Status')}
                          >
                            {isExpanded ? <ChevronUp style={{ width: 16, height: 16 }} /> : <ChevronDown style={{ width: 16, height: 16 }} />}
                          </button>
                        </div>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr key={`${shipment.id}-expanded`}>
                        <td colSpan={8} style={{ padding: '0 1rem 1rem', background: 'var(--color-bg)' }}>
                          <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem', border: '1px solid var(--color-border)' }}>
                            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '0.875rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1rem' }}>
                              {t('admin.shipments.updateStatus', 'Update Shipment Status')}
                            </h4>
                            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                              {(['pending', 'picked_up', 'in_transit', 'customs', 'out_for_delivery', 'delivered', 'exception'] as const).map(s => {
                                const sc2 = getStatusConfig(s);
                                const isCurrent = shipment.status === s;
                                return (
                                  <button
                                    key={s}
                                    disabled={isCurrent || updateStatus.isPending}
                                    onClick={() => updateStatus.mutate({ shipmentId: shipment.id, status: s, description: `Status updated to ${s} by admin` })}
                                    style={{
                                      padding: '0.375rem 0.875rem', borderRadius: 'var(--radius-xl)', fontSize: '0.75rem', fontWeight: 700, cursor: isCurrent ? 'default' : 'pointer', border: 'none',
                                      background: isCurrent ? sc2.bg : '#f1f5f9',
                                      color: isCurrent ? sc2.color : '#475569',
                                      opacity: isCurrent ? 1 : 0.8,
                                      outline: isCurrent ? `2px solid ${sc2.color}` : 'none',
                                    }}
                                  >
                                    {isCurrent ? '✓ ' : ''}{sc2.label}
                                  </button>
                                );
                              })}
                            </div>
                            {shipment.lastLocation && (
                              <div style={{ marginTop: '0.75rem', fontSize: '0.8125rem', color: 'var(--color-muted)' }}>
                                <span style={{ fontWeight: 600 }}>{t('admin.shipments.lastLocation', 'Last Location')}: </span>
                                {shipment.lastLocation}
                                {shipment.lastUpdate && ` · ${new Date(shipment.lastUpdate).toLocaleString()}`}
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function QuoteRequestsTab({ thStyle, tdStyle, badge }: { thStyle: any; tdStyle: any; badge: (color: string, bg: string, text: string) => React.JSX.Element }) {
  const { data: quotes = [], isLoading, refetch } = trpc.quotes.list.useQuery({ status: undefined });
  const updateStatus = trpc.quotes.updateStatus.useMutation({ onSuccess: () => refetch() });
  const [adminNotes, setAdminNotes] = useState<Record<number, string>>({});

  return (
    <div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <FileText style={{ width: 20, height: 20, color: '#f59e0b' }} /> Product Quote Requests
      </h2>
      {isLoading ? (
        <p style={{ color: '#64748b' }}>Loading...</p>
      ) : quotes.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>
          <FileText size={48} style={{ margin: '0 auto 1rem', opacity: 0.3 }} />
          <p>No quote requests yet.</p>
        </div>
      ) : (
        <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9', overflow: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                {['Date', 'Product', 'Name', 'Email', 'Qty', 'Status', 'Actions'].map(h => (
                  <th key={h} style={thStyle}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(quotes as any[]).map((row: any) => {
                const q = row.request;
                return (
                  <tr key={q.id} style={{ borderBottom: '1px solid #f8fafc' }}>
                    <td style={tdStyle}>{new Date(q.createdAt).toLocaleDateString()}</td>
                    <td style={tdStyle}>{row.product?.name || `#${q.productId}`}</td>
                    <td style={tdStyle}><div style={{ fontWeight: 600 }}>{q.name}</div><div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{q.company}</div></td>
                    <td style={tdStyle}>{q.email}</td>
                    <td style={tdStyle}>{q.quantity}</td>
                    <td style={tdStyle}>{badge(q.status === 'pending' ? '#f59e0b' : q.status === 'quoted' ? '#16a34a' : '#64748b', q.status === 'pending' ? 'rgba(245,158,11,0.1)' : q.status === 'quoted' ? 'rgba(22,163,74,0.1)' : 'rgba(100,116,139,0.1)', q.status)}</td>
                    <td style={tdStyle}>
                      <select
                        value={q.status}
                        onChange={e => updateStatus.mutate({ id: q.id, status: e.target.value as any, adminNotes: adminNotes[q.id] })}
                        style={{ fontSize: '0.8rem', border: '1px solid #e2e8f0', borderRadius: 6, padding: '0.25rem 0.5rem', cursor: 'pointer' }}
                      >
                        <option value="pending">Pending</option>
                        <option value="reviewed">Reviewed</option>
                        <option value="quoted">Quoted</option>
                        <option value="closed">Closed</option>
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function Admin() {
  const { t } = useTranslation();
  const { user, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  // Admin role guard
  if (authLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8fafc' }}>
        <div style={{ width: 40, height: 40, border: '3px solid #e2e8f0', borderTopColor: '#06b6d4', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
      </div>
    );
  }
  if (!user || (user as any).role !== 'admin') {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8fafc', padding: '2rem' }}>
        <div style={{ textAlign: 'center', maxWidth: 400 }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🔒</div>
          <h2 style={{ fontFamily: 'Sora, sans-serif', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem', fontSize: '1.5rem' }}>Access Restricted</h2>
          <p style={{ color: '#64748b', marginBottom: '1.5rem' }}>This area is only accessible to platform administrators.</p>
          <button onClick={() => navigate('/')} style={{ padding: '0.625rem 1.5rem', background: 'linear-gradient(135deg,#06b6d4,#0891b2)', color: 'white', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer', fontSize: '0.875rem' }}>
            Return to Homepage
          </button>
        </div>
      </div>
    );
  }
  const { data: adminStats } = trpc.admin.getStats.useQuery();
  const { data: factoriesData = [], refetch: refetchFactories } = trpc.admin.listFactories.useQuery();
  const updateFactoryStatus = trpc.admin.updateFactoryStatus.useMutation({ onSuccess: () => refetchFactories() });
  const runTrustAnalysis = trpc.admin.runTrustAnalysis.useMutation({ onSuccess: () => refetchFactories() });
  const [trustAnalysisResult, setTrustAnalysisResult] = useState<Record<number, any>>({});
  const stats = {
    totalUsers: adminStats?.users ?? 0,
    totalFactories: adminStats?.factories ?? 0,
    activeOrders: adminStats?.activeOrders ?? 0,
    totalRevenue: adminStats?.totalRevenue ?? 0,
    monthlyGrowth: 0,
    commissionEarned: adminStats ? adminStats.totalRevenue * 0.05 : 0,
    pendingVerifications: adminStats?.pendingVerifications ?? 0,
    disputes: adminStats?.openRiskFlags ?? 0,
    totalOrders: adminStats?.totalOrders ?? 0,
    totalProducts: adminStats?.totalProducts ?? 0,
    pendingQuotes: adminStats?.pendingQuotes ?? 0,
  };

  const users: { id: string; name: string; email: string; type: string; status: string; joinDate: string; activity: string }[] = [];

  const verifications: { id: string; name: string; email: string; date: string; status: string; docs: number; score: number | null }[] = [];

  const adminOrders: { id: string; buyer: string; factory: string; amount: number; commission: number; status: string; date: string }[] = [];

  const thStyle: React.CSSProperties = { textAlign: 'left', padding: '0.75rem 1rem', fontSize: '0.6875rem', fontWeight: 700, color: 'var(--color-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: '1px solid var(--color-border-lt)' };
  const tdStyle: React.CSSProperties = { padding: '0.875rem 1rem', fontSize: '0.8125rem', borderBottom: '1px solid #f8fafc' };
  const inputStyle: React.CSSProperties = { width: '100%', padding: '0.5rem 0.75rem', borderRadius: 'var(--radius-md)', border: '1.5px solid var(--color-border)', fontSize: '0.875rem', fontFamily: 'var(--font-body)', color: 'var(--color-ink)', outline: 'none' };
  const badge = (color: string, bg: string, text: string) => (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.6875rem', fontWeight: 700, color, background: bg, padding: '0.1875rem 0.5rem', borderRadius: 'var(--radius-xl)' }}>{text}</span>
  );

  const tabs = [
    { id: 'overview' as Tab, label: t('admin.tabs.overview', 'Overview'), icon: BarChart3 },
    { id: 'rfq' as Tab, label: t('admin.tabs.rfq', 'RFQ & Quotes'), icon: DollarSign },
    { id: 'quotes' as Tab, label: 'Quote Requests', icon: FileText },
    { id: 'orders' as Tab, label: t('admin.tabs.orders', 'Orders'), icon: Package },
    { id: 'shipments' as Tab, label: t('admin.tabs.shipments', 'Shipments'), icon: Truck },
    { id: 'crm' as Tab, label: t('admin.tabs.crm', 'CRM'), icon: Users },
    { id: 'suppliers' as Tab, label: t('admin.tabs.suppliers', 'Suppliers'), icon: Factory },
    { id: 'blog' as Tab, label: t('admin.tabs.blog', 'Blog'), icon: BookOpen },
    { id: 'settings' as Tab, label: t('admin.tabs.settings', 'Settings'), icon: Settings },
  ];

  const verificationStats = {
    totalRequests: 1247,
    cachedRequests: 892,
    newVerifications: 355,
    totalApiCost: 1775.50,
    totalRevenue: 4683.50,
    totalProfit: 2908.00,
    avgResponseTime: 1250,
    cachHitRate: 71.5
  };

  const statCards = [
    { icon: Users, label: t('admin.stats.totalUsers', 'Total Users'), value: stats.totalUsers.toLocaleString(), change: `${stats.totalFactories} factories`, color: '#06b6d4', bg: 'rgba(6,182,212,0.08)' },
    { icon: Package, label: t('admin.stats.totalOrders', 'Total Orders'), value: stats.totalOrders.toLocaleString(), change: `${stats.activeOrders} active`, color: '#f59e0b', bg: 'rgba(245,158,11,0.08)' },
    { icon: DollarSign, label: t('admin.stats.totalRevenue', 'Total Revenue (Paid)'), value: `$${stats.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`, change: `${stats.totalProducts} products`, color: '#10b981', bg: 'rgba(16,185,129,0.08)' },
    { icon: FileText, label: 'Pending Quotes', value: stats.pendingQuotes.toLocaleString(), change: `${stats.pendingVerifications} verifications`, color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)' },
  ];

  return (
    <div style={{ paddingTop: '5rem', minHeight: '100vh', background: 'var(--color-bg)' }}>
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)', padding: '2rem 0', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'radial-gradient(circle at 20% 50%, rgba(245,158,11,0.12), transparent 60%)' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', fontWeight: 800, color: 'white', margin: '0 0 0.25rem' }}>
              {t('admin.title', 'Admin Panel')}
            </h1>
            <p style={{ fontSize: '0.875rem', color: 'var(--color-subtle)' }}>{t('admin.subtitle', 'Platform management and analytics')}</p>
          </div>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.375rem', padding: '0.375rem 0.75rem', borderRadius: 'var(--radius-xl)', background: 'rgba(16,185,129,0.15)', color: '#34d399', fontSize: '0.8125rem', fontWeight: 600 }}>
            <Shield style={{ width: 14, height: 14 }} /> {t('admin.superAdmin', 'Super Admin')}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background: 'white', borderBottom: '1px solid var(--color-border-lt)' }}>
        <div className="container" style={{ display: 'flex', gap: '0.25rem', overflowX: 'auto' }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.875rem 1rem', fontSize: '0.8125rem', fontWeight: 600, color: activeTab === tab.id ? '#06b6d4' : '#64748b', borderBottom: `2px solid ${activeTab === tab.id ? '#06b6d4' : 'transparent'}`, background: 'transparent', border: 'none', borderBottomWidth: '2px', borderBottomStyle: 'solid', borderBottomColor: activeTab === tab.id ? '#06b6d4' : 'transparent', cursor: 'pointer', transition: 'all 200ms', whiteSpace: 'nowrap' }}>
              <tab.icon style={{ width: 16, height: 16 }} /> {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="container" style={{ padding: '2rem 1rem', maxWidth: '1200px' }}>
        {/* OVERVIEW */}
        {activeTab === 'overview' && (
          <div>
            {/* Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
              {statCards.map((s, i) => (
                <div key={i} style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
                  <div style={{ width: '36px', height: '36px', borderRadius: 'var(--radius-md)', background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '0.75rem' }}>
                    <s.icon style={{ width: 18, height: 18, color: s.color }} />
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 800, color: 'var(--color-ink)' }}>{s.value}</div>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--color-muted)' }}>{s.label}</div>
                  <div style={{ fontSize: '0.6875rem', color: '#10b981', fontWeight: 600, marginTop: '0.25rem' }}>{s.change}</div>
                </div>
              ))}
            </div>

            {/* Verification Analytics */}
            <div style={{ background: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)', borderRadius: 'var(--radius-xl)', padding: '1.5rem', marginBottom: '1.5rem', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: 0, right: 0, width: '200px', height: '200px', background: 'radial-gradient(circle, rgba(255,255,255,0.15), transparent)', borderRadius: '50%', transform: 'translate(30%, -30%)' }} />
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'between', marginBottom: '1rem' }}>
                  <div>
                    <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 800, color: 'white', marginBottom: '0.25rem' }}>🧠 {t('admin.verificationIntelligence', 'Verification Intelligence')}</h3>
                    <p style={{ fontSize: '0.8125rem', color: 'rgba(255,255,255,0.8)' }}>{t('admin.verificationDesc', 'Shared verification model - saving costs through cached results')}</p>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem' }}>
                  {[
                    { label: t('admin.totalRequests', 'Total Requests'), value: verificationStats.totalRequests.toLocaleString(), sub: `${verificationStats.cachedRequests} cached` },
                    { label: t('admin.cacheHitRate', 'Cache Hit Rate'), value: `${verificationStats.cachHitRate}%`, sub: '⚡ Instant results' },
                    { label: t('admin.apiCostSaved', 'API Cost Saved'), value: `$${(verificationStats.totalRevenue - verificationStats.totalApiCost).toFixed(0)}`, sub: `vs $${verificationStats.totalApiCost.toFixed(0)} spent` },
                    { label: t('admin.platformProfit', 'Platform Profit'), value: `$${verificationStats.totalProfit.toLocaleString()}`, sub: `💰 ${((verificationStats.totalProfit / verificationStats.totalRevenue) * 100).toFixed(0)}% margin` },
                    { label: t('admin.avgResponse', 'Avg Response'), value: `${(verificationStats.avgResponseTime / 1000).toFixed(1)}s`, sub: '⚡ Lightning fast' },
                    { label: t('admin.newVerifications', 'New Verifications'), value: String(verificationStats.newVerifications), sub: '🔍 Full API calls' },
                  ].map((item, i) => (
                    <div key={i} style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(10px)', borderRadius: 'var(--radius-lg)', padding: '1rem', border: '1px solid rgba(255,255,255,0.2)' }}>
                      <div style={{ fontSize: '0.6875rem', color: 'rgba(255,255,255,0.8)', marginBottom: '0.25rem' }}>{item.label}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', fontWeight: 800, color: 'white' }}>{item.value}</div>
                      <div style={{ fontSize: '0.6875rem', color: 'rgba(255,255,255,0.7)', marginTop: '0.25rem' }}>{item.sub}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Charts */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
              <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                  <BarChart3 style={{ width: 16, height: 16, color: '#06b6d4' }} /> {t('admin.revenueOverview', 'Revenue Overview')}
                </h3>
                <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '0.25rem', height: '160px' }}>
                  {[65, 85, 72, 90, 78, 95, 88, 92, 85, 98, 94, 100].map((h, i) => (
                    <div key={i} style={{ flex: 1, height: `${h}%`, borderRadius: '0.25rem 0.25rem 0 0', background: `linear-gradient(to top, #06b6d4, #67e8f9)`, opacity: 0.8 + (h / 500) }} />
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '0.5rem' }}>
                  {['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'].map((m, i) => (
                    <span key={i} style={{ fontSize: '0.625rem', color: 'var(--color-subtle)', flex: 1, textAlign: 'center' }}>{m}</span>
                  ))}
                </div>
              </div>

              <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                  <Activity style={{ width: 16, height: 16, color: '#f59e0b' }} /> {t('admin.platformActivity', 'Platform Activity')}
                </h3>
                {[
                  { label: t('admin.factoryVerifications', 'Factory Verifications'), value: `${stats.pendingVerifications} pending`, pct: 75, color: '#f59e0b' },
                  { label: t('admin.activeOrders', 'Active Orders'), value: `${stats.activeOrders}`, pct: 85, color: '#06b6d4' },
                  { label: t('admin.disputes', 'Disputes'), value: `${stats.disputes}`, pct: 15, color: '#ef4444' },
                  { label: t('admin.userGrowth', 'User Growth'), value: `+${stats.monthlyGrowth}%`, pct: 92, color: '#10b981' },
                ].map((item, i) => (
                  <div key={i} style={{ marginBottom: '1rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '0.375rem' }}>
                      <span style={{ color: '#475569' }}>{item.label}</span>
                      <span style={{ fontWeight: 700, color: item.color }}>{item.value}</span>
                    </div>
                    <div style={{ width: '100%', height: '6px', borderRadius: '3px', background: 'var(--color-bg-2)' }}>
                      <div style={{ width: `${item.pct}%`, height: '100%', borderRadius: '3px', background: item.color, transition: 'width 500ms' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Alerts */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem' }}>
              {[
                { icon: Clock, label: `${stats.pendingVerifications} ${t('admin.pendingVerifications', 'Pending Verifications')}`, sub: t('admin.requiresAttention', 'Requires attention'), color: '#f59e0b', border: '#f59e0b' },
                { icon: AlertTriangle, label: `${stats.disputes} ${t('admin.activeDisputes', 'Active Disputes')}`, sub: t('admin.needsResolution', 'Needs resolution'), color: '#ef4444', border: '#ef4444' },
                { icon: TrendingUp, label: `+${stats.monthlyGrowth}% ${t('admin.growth', 'Growth')}`, sub: t('admin.thisMonth', 'This month'), color: '#10b981', border: '#10b981' },
              ].map((a, i) => (
                <div key={i} style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1rem', borderLeft: `3px solid ${a.border}`, boxShadow: 'var(--shadow-sm)', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <a.icon style={{ width: 20, height: 20, color: a.color, flexShrink: 0 }} />
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.8125rem', fontWeight: 700, color: 'var(--color-ink)' }}>{a.label}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{a.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* USERS */}
        {activeTab === 'crm' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)' }}>{t('admin.tabs.users', 'User Management')}</h2>
              <div style={{ position: 'relative' }}>
                <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: 'var(--color-subtle)' }} />
                <input type="text" placeholder={t('admin.searchUsers', 'Search users...')} value={searchQuery} onChange={e => setSearchQuery(e.target.value)} style={{ ...inputStyle, paddingLeft: '2.25rem', width: '280px' }} />
              </div>
            </div>
            <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9', overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>
                  {[t('admin.col.user', 'User'), t('admin.col.type', 'Type'), t('admin.col.status', 'Status'), t('admin.col.joined', 'Joined'), t('admin.col.activity', 'Activity'), t('admin.col.actions', 'Actions')].map(h => (
                    <th key={h} style={{ ...thStyle, textAlign: h === t('admin.col.actions', 'Actions') ? 'right' : 'left' }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {users.filter(u => !searchQuery || u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase())).map(user => (
                    <tr key={user.id} style={{ cursor: 'pointer', transition: 'background 200ms' }} onMouseEnter={e => (e.currentTarget.style.background = '#f8fafc')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={tdStyle}>
                        <div style={{ fontWeight: 600, color: 'var(--color-ink)', fontSize: '0.875rem' }}>{user.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{user.email}</div>
                      </td>
                      <td style={tdStyle}>{badge(user.type === 'factory' ? '#d97706' : '#0891b2', user.type === 'factory' ? 'rgba(245,158,11,0.1)' : 'rgba(6,182,212,0.1)', user.type === 'factory' ? t('admin.factory', 'Factory') : t('admin.buyer', 'Buyer'))}</td>
                      <td style={tdStyle}>{badge(user.status === 'active' ? '#059669' : '#dc2626', user.status === 'active' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)', user.status)}</td>
                      <td style={{ ...tdStyle, color: 'var(--color-muted)' }}>{user.joinDate}</td>
                      <td style={{ ...tdStyle, fontWeight: 700, color: 'var(--color-ink)' }}>{user.activity}</td>
                      <td style={{ ...tdStyle, textAlign: 'right' }}>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.25rem' }}>
                          {[Eye, Edit, Ban].map((Icon, j) => (
                            <button key={j} style={{ padding: '0.375rem', borderRadius: '0.375rem', background: 'transparent', border: 'none', cursor: 'pointer', color: j === 2 ? '#ef4444' : '#64748b' }} onMouseEnter={e => (e.currentTarget.style.background = '#f1f5f9')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                              <Icon style={{ width: 16, height: 16 }} />
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* VERIFICATION / FACTORY MANAGEMENT */}
        {activeTab === 'verification' && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Shield style={{ width: 20, height: 20, color: '#06b6d4' }} /> Factory Verification & Trust Scores
            </h2>
            {factoriesData.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>
                <Factory size={48} style={{ margin: '0 auto 1rem', opacity: 0.3 }} />
                <p>No factories yet. Add factories via the database or admin tools.</p>
              </div>
            ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {(factoriesData as any[]).map((f: any) => {
                const aiResult = trustAnalysisResult[f.id];
                return (
                <div key={f.id} style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.25rem', boxShadow: 'var(--shadow-sm)', border: f.verified === 'pending' ? '1.5px solid #fbbf24' : f.verified === 'verified' ? '1.5px solid #10b981' : '1px solid #f1f5f9' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                    <div>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, color: 'var(--color-ink)', margin: '0 0 0.25rem' }}>{f.name}</h3>
                      <p style={{ fontSize: '0.8125rem', color: 'var(--color-muted)', margin: 0 }}>{f.city || ''}{f.city && f.country ? ', ' : ''}{f.country || 'China'} · Added: {new Date(f.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span style={{ fontWeight: 700, fontSize: '0.85rem', color: (f.trustScore ?? 0) >= 75 ? '#059669' : (f.trustScore ?? 0) >= 50 ? '#d97706' : '#dc2626' }}>
                        Trust: {f.trustScore ?? 0}/100
                      </span>
                      {badge(
                        f.verified === 'pending' ? '#d97706' : f.verified === 'verified' ? '#059669' : '#dc2626',
                        f.verified === 'pending' ? 'rgba(245,158,11,0.1)' : f.verified === 'verified' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                        f.verified
                      )}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button onClick={() => updateFactoryStatus.mutate({ factoryId: f.id, verified: 'verified' })} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.45rem 0.875rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #10b981, #059669)', color: 'white', border: 'none', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}>
                      <Check style={{ width: 13, height: 13 }} /> Verify
                    </button>
                    <button onClick={() => updateFactoryStatus.mutate({ factoryId: f.id, verified: 'rejected' })} style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.45rem 0.875rem', borderRadius: 'var(--radius-md)', background: 'rgba(239,68,68,0.1)', color: '#dc2626', border: 'none', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}>
                      <X style={{ width: 13, height: 13 }} /> Reject
                    </button>
                    <button
                      onClick={async () => {
                        const result = await runTrustAnalysis.mutateAsync({ factoryId: f.id, factoryName: f.name, country: f.country ?? undefined });
                        setTrustAnalysisResult(prev => ({ ...prev, [f.id]: result }));
                      }}
                      disabled={runTrustAnalysis.isPending}
                      style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', padding: '0.45rem 0.875rem', borderRadius: 'var(--radius-md)', background: 'rgba(139,92,246,0.1)', color: '#7c3aed', border: 'none', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}
                    >
                      <Zap style={{ width: 13, height: 13 }} /> AI Analysis
                    </button>
                  </div>
                  {aiResult && (
                    <div style={{ marginTop: '0.75rem', background: '#f8fafc', borderRadius: 8, padding: '0.75rem', fontSize: '0.82rem' }}>
                      <strong>AI Assessment:</strong> Score {aiResult.trustScore}/100 | Risk: {aiResult.riskLevel} | {aiResult.recommendation}
                      {aiResult.flags?.length > 0 && <div style={{ color: '#dc2626', marginTop: '0.25rem' }}>⚠️ {aiResult.flags.join(', ')}</div>}
                      {aiResult.positives?.length > 0 && <div style={{ color: '#059669', marginTop: '0.25rem' }}>✓ {aiResult.positives.join(', ')}</div>}
                    </div>
                  )}
                </div>
              )})}
            </div>
            )}
          </div>
        )}

        {/* ORDERS */}
        {activeTab === 'orders' && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.5rem' }}>{t('admin.ordersManagement', 'Orders Management')}</h2>
            <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9', overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr>
                  {[t('admin.col.orderId', 'Order ID'), t('admin.col.buyer', 'Buyer'), t('admin.col.factory', 'Factory'), t('admin.col.amount', 'Amount'), t('admin.col.commission', 'Commission'), t('admin.col.status', 'Status'), ''].map(h => (
                    <th key={h} style={thStyle}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {adminOrders.map(o => (
                    <tr key={o.id} style={{ cursor: 'pointer', transition: 'background 200ms' }} onMouseEnter={e => (e.currentTarget.style.background = '#f8fafc')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ ...tdStyle, fontWeight: 700, color: 'var(--color-ink)' }}>{o.id}</td>
                      <td style={{ ...tdStyle, color: '#475569' }}>{o.buyer}</td>
                      <td style={{ ...tdStyle, color: '#475569' }}>{o.factory}</td>
                      <td style={{ ...tdStyle, fontWeight: 700, color: 'var(--color-ink)' }}>${o.amount.toLocaleString()}</td>
                      <td style={{ ...tdStyle, fontWeight: 700, color: '#059669' }}>${o.commission.toLocaleString()}</td>
                      <td style={tdStyle}>
                        {badge(
                          o.status === 'delivered' ? '#059669' : o.status === 'in_transit' ? '#0891b2' : o.status === 'disputed' ? '#dc2626' : '#d97706',
                          o.status === 'delivered' ? 'rgba(16,185,129,0.1)' : o.status === 'in_transit' ? 'rgba(6,182,212,0.1)' : o.status === 'disputed' ? 'rgba(239,68,68,0.1)' : 'rgba(245,158,11,0.1)',
                          o.status.replace('_', ' ')
                        )}
                      </td>
                      <td style={{ ...tdStyle, textAlign: 'right' }}>
                        <button style={{ padding: '0.375rem', borderRadius: '0.375rem', background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--color-muted)' }}>
                          <Eye style={{ width: 16, height: 16 }} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SHIPMENTS */}
        {activeTab === 'shipments' && (
          <ShipmentsTab thStyle={thStyle} tdStyle={tdStyle} badge={badge} />
        )}

        {/* BLOG MANAGEMENT */}
        {activeTab === 'blog' && (
          <BlogManagementTab />
        )}

        {/* QUOTE REQUESTS - now part of rfq tab */}

        {/* SUPPLIERS (internal only) */}
        {activeTab === 'suppliers' && (
          <SuppliersTab thStyle={thStyle} tdStyle={tdStyle} badge={badge} inputStyle={inputStyle} />
        )}
        {/* RFQ & QUOTES */}
        {activeTab === 'rfq' && (
          <RfqQuotesTab thStyle={thStyle} tdStyle={tdStyle} badge={badge} />
        )}

        {/* PRODUCT QUOTE REQUESTS */}
        {activeTab === 'quotes' && (
          <QuoteRequestsTab thStyle={thStyle} tdStyle={tdStyle} badge={badge} />
        )}

        {/* CRM */}
        {activeTab === 'crm' && (
          <CrmTab thStyle={thStyle} tdStyle={tdStyle} badge={badge} />
        )}

        {/* SETTINGS */}
        {activeTab === 'settings' && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.5rem' }}>{t('admin.platformSettings', 'Platform Settings')}</h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                  <DollarSign style={{ width: 16, height: 16, color: '#10b981' }} /> {t('admin.commissionFees', 'Commission & Fees')}
                </h3>
                {[
                  { label: t('admin.defaultCommission', 'Default Commission Rate (%)'), val: '5' },
                  { label: t('admin.escrowFee', 'Escrow Fee (%)'), val: '1.5' },
                  { label: t('admin.premiumListingFee', 'Premium Listing Fee ($/month)'), val: '50' },
                ].map((f, i) => (
                  <div key={i} style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>{f.label}</label>
                    <input type="number" defaultValue={f.val} style={inputStyle} />
                  </div>
                ))}
              </div>
              <div style={{ background: 'white', borderRadius: 'var(--radius-lg)', padding: '1.5rem', boxShadow: 'var(--shadow-sm)', border: '1px solid #f1f5f9' }}>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-ink)', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                  <Shield style={{ width: 16, height: 16, color: '#06b6d4' }} /> {t('admin.verificationSettings', 'Verification Settings')}
                </h3>
                {[
                  { label: t('admin.minTrustScore', 'Minimum Trust Score for Approval (%)'), val: '75' },
                  { label: t('admin.autoApproveScore', 'Auto-approve above score (%)'), val: '90' },
                ].map((f, i) => (
                  <div key={i} style={{ marginBottom: '1rem' }}>
                    <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, color: 'var(--color-ink-3)', marginBottom: '0.375rem' }}>{f.label}</label>
                    <input type="number" defaultValue={f.val} style={inputStyle} />
                  </div>
                ))}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.5rem' }}>
                  <input type="checkbox" id="req-docs" defaultChecked style={{ accentColor: '#06b6d4' }} />
                  <label htmlFor="req-docs" style={{ fontSize: '0.8125rem', color: '#475569' }}>{t('admin.requireBusinessLicense', 'Require business license documents')}</label>
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
              <button style={{ padding: '0.625rem 1.5rem', borderRadius: 'var(--radius-md)', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', border: 'none', fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer', boxShadow: '0 4px 12px rgba(6,182,212,0.3)' }}>
                {t('admin.saveSettings', 'Save Settings')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
