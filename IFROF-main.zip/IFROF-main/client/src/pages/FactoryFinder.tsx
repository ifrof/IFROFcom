import { useState } from 'react';
import { SEO } from '@/components/SEO';
import { Search, Link as LinkIcon, Image as ImageIcon, FileText, Hash, Shield, Loader2, CheckCircle2, AlertCircle, ExternalLink, Phone, Mail, Globe, MapPin, Building2, Users, Calendar, Award } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';

type SearchType = 'text' | 'link' | 'image' | 'hscode' | 'description';

export default function FactoryFinder() {
  const { user, isAuthenticated } = useAuth();
  const [searchType, setSearchType] = useState<SearchType>('text');
  const [searchQuery, setSearchQuery] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  // tRPC mutations
  const searchMutation = trpc.factoryFinder.createPayment.useMutation();
  const createPaymentMutation = trpc.factoryFinder.createPayment.useMutation();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSearch = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    let query = searchQuery;

    // For image search, convert to base64
    if (searchType === 'image' && imageFile) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        await performSearch(base64);
      };
      reader.readAsDataURL(imageFile);
      return;
    }

    await performSearch(query);
  };

  const performSearch = async (query: string) => {
    try {
      // First, initiate payment
      const payment = await createPaymentMutation.mutateAsync({
        searchType,
        searchQuery: query,
      });

      // Redirect to Stripe Checkout
      if (payment.checkoutUrl) {
        window.location.href = payment.checkoutUrl;
      }
    } catch (error) {
      // Search failed — error handled by tRPC
    }
  };

  const searchTypes = [
    { type: 'text' as SearchType, icon: Search, label: 'بحث نصي', placeholder: 'مثال: مصنع مصابيح LED' },
    { type: 'link' as SearchType, icon: LinkIcon, label: 'رابط الموقع', placeholder: 'مثال: https://example-factory.com' },
    { type: 'image' as SearchType, icon: ImageIcon, label: 'صورة المنتج', placeholder: 'رفع صورة المنتج' },
    { type: 'hscode' as SearchType, icon: Hash, label: 'رمز النظام المنسق', placeholder: 'مثال: 8539.50.00' },
    { type: 'description' as SearchType, icon: FileText, label: 'الوصف', placeholder: 'صِف المنتج الذي تحتاجه...' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)', direction: 'rtl' }}>
      <SEO
        title="Factory Finder — AI-Powered Verified Manufacturer Search"
        description="Search 12,000+ verified factories by product, HS code, image, or URL. AI matches you with the best suppliers. No middlemen. Every factory audit-verified by IFROF."
        keywords="factory search, find manufacturers China, HS code search, supplier verification, AI factory matching"
        url="https://ifrof.com/factory-finder"
      />
      {/* Hero Section */}
      <section style={{ padding: '8rem 0 4rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 30%, rgba(6,182,212,0.15) 0%, transparent 70%)' }} />

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div className="text-center mb-12">
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1.25rem', borderRadius: '2rem', background: 'rgba(16,185,129,0.15)', color: '#34d399', fontSize: '0.875rem', fontWeight: 600, marginBottom: '1.5rem', border: '1px solid rgba(16,185,129,0.25)' }}>
              <Shield className="w-4 h-4" /> تحقق من المصانع بالذكاء الاصطناعي
            </div>

            <h1 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(2.5rem, 5vw, 4rem)', fontWeight: 800, color: 'white', lineHeight: 1.1, marginBottom: '1.5rem' }}>
              اعثر على <span style={{ background: 'linear-gradient(135deg, #06b6d4, #10b981)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>مصانع حقيقية</span>
              <br />وليس وسطاء
            </h1>

            <p style={{ color: '#94a3b8', fontSize: '1.25rem', lineHeight: 1.7, maxWidth: '700px', margin: '0 auto 3rem' }}>
              ابحث بالنص، الرابط، الصورة، رمز النظام المنسق، أو الوصف. احصل على بيانات مصانع موثقة مقابل <strong style={{ color: '#22d3ee' }}>$9.9 فقط لكل بحث</strong>.
            </p>
          </div>

          {/* Search Interface */}
          <div style={{ maxWidth: '900px', margin: '0 auto', background: 'rgba(255,255,255,0.05)', backdropFilter: 'blur(20px)', borderRadius: '1.5rem', padding: '2.5rem', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 25px 50px rgba(0,0,0,0.3)' }}>
            {/* Search Type Tabs */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.75rem', marginBottom: '2rem' }}>
              {searchTypes.map(({ type, icon: Icon, label }) => (
                <button
                  key={type}
                  onClick={() => setSearchType(type)}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '1rem',
                    borderRadius: '0.75rem',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    background: searchType === type ? 'rgba(6,182,212,0.2)' : 'rgba(255,255,255,0.03)',
                    color: searchType === type ? '#22d3ee' : '#94a3b8',
                    transition: 'all 200ms',
                    borderWidth: '2px',
                    borderStyle: 'solid',
                    borderColor: searchType === type ? '#06b6d4' : 'transparent',
                  }}
                >
                  <Icon className="w-5 h-5" />
                  {label}
                </button>
              ))}
            </div>

            {/* Search Input */}
            <div style={{ marginBottom: '1.5rem' }}>
              {searchType === 'image' ? (
                <div>
                  <label
                    htmlFor="image-upload"
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      minHeight: '200px',
                      border: '2px dashed rgba(6,182,212,0.5)',
                      borderRadius: '0.75rem',
                      background: 'rgba(6,182,212,0.05)',
                      cursor: 'pointer',
                      transition: 'all 200ms',
                    }}
                  >
                    {imagePreview ? (
                      <img src={imagePreview} alt="معاينة" style={{ maxHeight: '200px', borderRadius: '0.5rem' }} />
                    ) : (
                      <>
                        <ImageIcon className="w-12 h-12 text-cyan-400 mb-3" />
                        <p style={{ color: '#94a3b8', fontSize: '1rem', fontWeight: 500 }}>اضغط لرفع صورة المنتج</p>
                        <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '0.5rem' }}>PNG، JPG حتى 10MB</p>
                      </>
                    )}
                  </label>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={{ display: 'none' }}
                  />
                </div>
              ) : searchType === 'description' ? (
                <textarea
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={searchTypes.find(t => t.type === searchType)?.placeholder}
                  rows={5}
                  style={{
                    width: '100%',
                    padding: '1rem 1.25rem',
                    fontSize: '1rem',
                    borderRadius: '0.75rem',
                    border: '2px solid rgba(6,182,212,0.3)',
                    background: 'rgba(255,255,255,0.05)',
                    color: 'white',
                    outline: 'none',
                    transition: 'all 200ms',
                    fontFamily: 'inherit',
                    resize: 'vertical',
                    direction: 'rtl',
                  }}
                />
              ) : (
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={searchTypes.find(t => t.type === searchType)?.placeholder}
                  style={{
                    width: '100%',
                    padding: '1rem 1.25rem',
                    fontSize: '1rem',
                    borderRadius: '0.75rem',
                    border: '2px solid rgba(6,182,212,0.3)',
                    background: 'rgba(255,255,255,0.05)',
                    color: 'white',
                    outline: 'none',
                    transition: 'all 200ms',
                    direction: 'rtl',
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
              )}
            </div>

            {/* Search Button */}
            <Button
              onClick={handleSearch}
              disabled={searchMutation.isPending || createPaymentMutation.isPending || (!searchQuery && !imageFile)}
              style={{
                width: '100%',
                padding: '1.25rem',
                fontSize: '1.125rem',
                fontWeight: 700,
                borderRadius: '0.75rem',
                background: 'linear-gradient(135deg, #06b6d4, #10b981)',
                color: 'white',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 200ms',
                boxShadow: '0 10px 30px rgba(6,182,212,0.3)',
              }}
            >
              {searchMutation.isPending || createPaymentMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin ml-2" />
                  جارٍ المعالجة...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5 ml-2" />
                  بحث عن مصنع ($9.9)
                </>
              )}
            </Button>

            {/* Info Text */}
            <div style={{ marginTop: '1.5rem', padding: '1rem', borderRadius: '0.75rem', background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}>
              <div style={{ display: 'flex', gap: '0.75rem', color: '#34d399', fontSize: '0.875rem', lineHeight: 1.6 }}>
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <strong>ما ستحصل عليه:</strong> ملف المصنع الكامل (الاسم، العنوان، الشهادات، ودرجة الموثوقية)، وأدلة التحقق التي تثبت أنه مصنع حقيقي. لضمان سلامتك وحماية الضمان، ننصحك ببدء جميع الاتصالات والمفاوضات الأولية عبر منصة IFROF الآمنة.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section style={{ padding: '5rem 0', background: 'rgba(15,23,42,0.5)' }}>
        <div className="container">
          <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: 800, color: 'white', textAlign: 'center', marginBottom: '3rem' }}>
            كيف يعمل
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '1', title: 'ابحث', desc: 'أدخل اسم المنتج، رابط الموقع، صورة، رمز النظام المنسق، أو وصف', icon: Search, color: '#06b6d4' },
              { step: '2', title: 'ادفع $9.9', desc: 'دفعة واحدة لكل بحث. النتائج محفوظة للوصول المستقبلي.', icon: Shield, color: '#10b981' },
              { step: '3', title: 'احصل على مصنع موثق', desc: 'احصل على بيانات التواصل الكاملة + أدلة تثبت أنه مصنع حقيقي', icon: CheckCircle2, color: '#f59e0b' },
            ].map((item, i) => (
              <div key={i} style={{ padding: '2rem', borderRadius: '1rem', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                  <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: `${item.color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: item.color, fontFamily: 'Sora, sans-serif', fontSize: '1.5rem', fontWeight: 800 }}>
                    {item.step}
                  </div>
                  <item.icon style={{ width: '32px', height: '32px', color: item.color }} />
                </div>
                <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.25rem', fontWeight: 700, color: 'white', marginBottom: '0.5rem' }}>
                  {item.title}
                </h3>
                <p style={{ color: '#94a3b8', fontSize: '0.9375rem', lineHeight: 1.6 }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section style={{ padding: '5rem 0' }}>
        <div className="container">
          <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(2rem, 4vw, 2.5rem)', fontWeight: 800, color: 'white', textAlign: 'center', marginBottom: '3rem' }}>
            لماذا تختار باحث المصانع من IFROF؟
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Shield, title: 'تحقق بالذكاء الاصطناعي', desc: 'كل مصنع يتم التحقق منه باستخدام Perplexity AI + Firecrawl لإثبات أنه ليس وسيطاً' },
              { icon: Building2, title: 'مصانع حقيقية فقط', desc: 'نقوم بتصفية شركات التجارة والوكلاء والوسطاء تلقائياً' },
              { icon: Globe, title: 'ملف مصنع موثق', desc: 'احصل على معلومات تفصيلية عن المصنع - ثم استخدم IFROF للتواصل معهم بأمان' },
              { icon: Award, title: 'أدلة مرفقة', desc: 'شاهد الأدلة التي تثبت أنه مصنع: الشهادات، الطاقة الإنتاجية، عدد الموظفين' },
            ].map((item, i) => (
              <div key={i} style={{ padding: '1.5rem', borderRadius: '1rem', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '56px', height: '56px', borderRadius: '50%', background: 'rgba(6,182,212,0.15)', marginBottom: '1rem' }}>
                  <item.icon style={{ width: '28px', height: '28px', color: '#22d3ee' }} />
                </div>
                <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.125rem', fontWeight: 700, color: 'white', marginBottom: '0.5rem' }}>
                  {item.title}
                </h3>
                <p style={{ color: '#94a3b8', fontSize: '0.875rem', lineHeight: 1.6 }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
