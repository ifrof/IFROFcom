import { useState } from 'react';
import { Settings as SettingsIcon, Lock, Bell, Globe, Eye, Save } from 'lucide-react';

export default function Settings() {
  const [activeTab, setActiveTab] = useState<'account' | 'notifications' | 'privacy'>('account');
  const [settings, setSettings] = useState({
    // Account
    language: 'ar',
    timezone: 'UTC+3',
    currency: 'SAR',
    // Notifications
    emailNotifications: true,
    orderUpdates: true,
    priceAlerts: true,
    marketingEmails: false,
    // Privacy
    profileVisibility: 'private',
    showActivity: false,
    allowMessages: true
  });

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleChange = (key: keyof typeof settings, value: string | boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50" style={{ direction: 'rtl' }}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="container py-8">
          <h1 className="text-4xl font-bold flex items-center gap-3">
            <SettingsIcon className="w-8 h-8" />
            الإعدادات
          </h1>
          <p className="text-gray-600 mt-2">إدارة تفضيلات الحساب وإعدادات الأمان</p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-4 space-y-2">
              <button
                onClick={() => setActiveTab('account')}
                className={`w-full text-right px-4 py-3 rounded-lg font-medium transition-all ${
                  activeTab === 'account'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                إعدادات الحساب
              </button>
              <button
                onClick={() => setActiveTab('notifications')}
                className={`w-full text-right px-4 py-3 rounded-lg font-medium transition-all ${
                  activeTab === 'notifications'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Bell className="w-4 h-4 inline ml-2" />
                الإشعارات
              </button>
              <button
                onClick={() => setActiveTab('privacy')}
                className={`w-full text-right px-4 py-3 rounded-lg font-medium transition-all ${
                  activeTab === 'privacy'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Eye className="w-4 h-4 inline ml-2" />
                الخصوصية والأمان
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow p-8">
              {/* Account Settings */}
              {activeTab === 'account' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">إعدادات الحساب</h2>

                  <div className="space-y-6">
                    {/* Language */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Globe className="w-4 h-4 inline ml-2" />
                        اللغة
                      </label>
                      <select
                        value={settings.language}
                        onChange={(e) => handleChange('language', e.target.value as string)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      >
                        <option value="ar">العربية</option>
                        <option value="en">الإنجليزية</option>
                        <option value="fr">الفرنسية</option>
                        <option value="tr">التركية</option>
                        <option value="zh">الصينية</option>
                      </select>
                    </div>

                    {/* Timezone */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">المنطقة الزمنية</label>
                      <select
                        value={settings.timezone}
                        onChange={(e) => handleChange('timezone', e.target.value as string)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      >
                        <option value="UTC+3">توقيت السعودية (UTC+3)</option>
                        <option value="UTC+4">توقيت الإمارات (UTC+4)</option>
                        <option value="UTC+2">توقيت مصر (UTC+2)</option>
                        <option value="UTC+0">توقيت غرينتش (UTC+0)</option>
                        <option value="UTC+8">توقيت الصين (UTC+8)</option>
                        <option value="UTC-5">التوقيت الشرقي (UTC-5)</option>
                      </select>
                    </div>

                    {/* Currency */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">العملة</label>
                      <select
                        value={settings.currency}
                        onChange={(e) => handleChange('currency', e.target.value as string)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      >
                        <option value="SAR">ريال سعودي (﷼)</option>
                        <option value="AED">درهم إماراتي (د.إ)</option>
                        <option value="USD">دولار أمريكي ($)</option>
                        <option value="EUR">يورو (€)</option>
                        <option value="GBP">جنيه إسترليني (£)</option>
                      </select>
                    </div>

                    {/* Change Password */}
                    <div className="pt-6 border-t border-gray-200">
                      <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <Lock className="w-5 h-5" />
                        الأمان
                      </h3>
                      <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition-colors">
                        تغيير كلمة المرور
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Notifications */}
              {activeTab === 'notifications' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">إشعارات البريد الإلكتروني</h2>

                  <div className="space-y-4">
                    {/* Email Notifications */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.emailNotifications}
                        onChange={() => handleToggle('emailNotifications')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">إشعارات البريد الإلكتروني</p>
                        <p className="text-sm text-gray-600">استلم تحديثات حول حسابك عبر البريد الإلكتروني</p>
                      </div>
                    </label>

                    {/* Order Updates */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.orderUpdates}
                        onChange={() => handleToggle('orderUpdates')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">تحديثات الطلبات</p>
                        <p className="text-sm text-gray-600">استلم تحديثات حول حالة طلباتك</p>
                      </div>
                    </label>

                    {/* Price Alerts */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.priceAlerts}
                        onChange={() => handleToggle('priceAlerts')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">تنبيهات الأسعار</p>
                        <p className="text-sm text-gray-600">تلقَّ إشعارات عن انخفاض الأسعار والعروض</p>
                      </div>
                    </label>

                    {/* Marketing Emails */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.marketingEmails}
                        onChange={() => handleToggle('marketingEmails')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">رسائل تسويقية</p>
                        <p className="text-sm text-gray-600">استلم عروضاً ترويجية ونشرات إخبارية</p>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* Privacy & Security */}
              {activeTab === 'privacy' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">الخصوصية والأمان</h2>

                  <div className="space-y-6">
                    {/* Profile Visibility */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">ظهور الملف الشخصي</label>
                      <select
                        value={settings.profileVisibility}
                        onChange={(e) => handleChange('profileVisibility', e.target.value as string)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      >
                        <option value="public">عام</option>
                        <option value="private">خاص</option>
                        <option value="friends">جهات الاتصال فقط</option>
                      </select>
                      <p className="text-xs text-gray-600 mt-2">التحكم بمن يمكنه رؤية ملفك الشخصي</p>
                    </div>

                    {/* Activity Status */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.showActivity}
                        onChange={() => handleToggle('showActivity')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">إظهار حالة النشاط</p>
                        <p className="text-sm text-gray-600">السماح للآخرين برؤية حالة اتصالك</p>
                      </div>
                    </label>

                    {/* Allow Messages */}
                    <label className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.allowMessages}
                        onChange={() => handleToggle('allowMessages')}
                        className="w-5 h-5 text-cyan-500 rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">السماح بالرسائل</p>
                        <p className="text-sm text-gray-600">السماح للموردين بإرسال رسائل إليك</p>
                      </div>
                    </label>

                    {/* Two-Factor Authentication */}
                    <div className="pt-6 border-t border-gray-200">
                      <h3 className="font-semibold text-gray-900 mb-2">المصادقة الثنائية</h3>
                      <p className="text-sm text-gray-600 mb-4">أضف طبقة أمان إضافية لحسابك</p>
                      <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition-colors">
                        تفعيل المصادقة الثنائية
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Save Button */}
              <div className="mt-8 pt-6 border-t border-gray-200 flex justify-start">
                <button className="flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white font-semibold px-8 py-3 rounded-lg transition-all">
                  <Save className="w-5 h-5" />
                  حفظ التغييرات
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
