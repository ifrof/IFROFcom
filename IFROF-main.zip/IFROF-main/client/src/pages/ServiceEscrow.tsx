import { ComingSoon } from "@/components/ComingSoon";

export default function ServiceEscrow() {
  return (
    <div className="py-20">
      <ComingSoon 
        title="Escrow Payment Protection" 
        description="We're building a secure payment layer to protect your transactions with any factory, anywhere."
      />
    </div>
  );
}
