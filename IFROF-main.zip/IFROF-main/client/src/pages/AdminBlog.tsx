import { useState } from 'react';
import { Link } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { Plus, Edit, Trash2, Eye, Calendar, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

/**
 * AdminBlog - Admin panel for managing blog articles
 */
export default function AdminBlog() {
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<any>(null);

  // Form state
  const [formData, setFormData] = useState({
    categoryId: 0,
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    coverImage: '',
    tags: '',
    status: 'draft' as 'draft' | 'published' | 'archived',
    featured: false,
    readTime: 5,
  });

  const { data: categories } = trpc.blog.listCategories.useQuery();
  const { data: articles, refetch } = trpc.blog.listArticles.useQuery({ limit: 100 });

  const createArticle = trpc.blog.create.useMutation({
    onSuccess: () => {
      toast.success('Article created successfully!');
      setDialogOpen(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const updateArticle = trpc.blog.update.useMutation({
    onSuccess: () => {
      toast.success('Article updated successfully!');
      setDialogOpen(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteArticle = trpc.blog.delete.useMutation({
    onSuccess: () => {
      toast.success('Article deleted successfully!');
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetForm = () => {
    setFormData({
      categoryId: 0,
      title: '',
      slug: '',
      excerpt: '',
      content: '',
      coverImage: '',
      tags: '',
      status: 'draft',
      featured: false,
      readTime: 5,
    });
    setEditingArticle(null);
  };

  const handleSubmit = () => {
    if (!formData.title || !formData.slug || !formData.content || !formData.categoryId) {
      toast.error('Please fill in all required fields');
      return;
    }

    const tags = formData.tags ? formData.tags.split(',').map(t => t.trim()).filter(Boolean) : [];

    if (editingArticle) {
      updateArticle.mutate({
        id: editingArticle.article.id,
        ...formData,
        tags,
      });
    } else {
      createArticle.mutate({
        ...formData,
        tags,
      });
    }
  };

  const handleEdit = (item: any) => {
    setEditingArticle(item);
    setFormData({
      categoryId: item.article.categoryId,
      title: item.article.title,
      slug: item.article.slug,
      excerpt: item.article.excerpt || '',
      content: item.article.content,
      coverImage: item.article.coverImage || '',
      tags: item.article.tags ? JSON.parse(item.article.tags).join(', ') : '',
      status: item.article.status,
      featured: item.article.featured === 1,
      readTime: item.article.readTime,
    });
    setDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this article?')) {
      deleteArticle.mutate({ id });
    }
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Access Denied</h2>
            <p className="text-slate-600 mb-4">You need admin privileges to access this page.</p>
            <Link href="/">
              <Button>Go Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Blog Management</h1>
            <p className="text-slate-600">Create and manage educational articles</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="w-4 h-4 mr-2" />
                New Article
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingArticle ? 'Edit Article' : 'Create New Article'}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label>Category *</Label>
                  <Select
                    value={formData.categoryId.toString()}
                    onValueChange={(value) => setFormData({ ...formData, categoryId: parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map(cat => (
                        <SelectItem key={cat.id} value={cat.id.toString()}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Title *</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => {
                      const title = e.target.value;
                      setFormData({
                        ...formData,
                        title,
                        slug: generateSlug(title),
                      });
                    }}
                    placeholder="Article title"
                  />
                </div>

                <div>
                  <Label>Slug *</Label>
                  <Input
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                    placeholder="article-url-slug"
                  />
                </div>

                <div>
                  <Label>Excerpt</Label>
                  <Textarea
                    value={formData.excerpt}
                    onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                    placeholder="Short summary (optional)"
                    rows={2}
                  />
                </div>

                <div>
                  <Label>Content * (Markdown supported)</Label>
                  <Textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="Write your article content here..."
                    rows={12}
                  />
                </div>

                <div>
                  <Label>Cover Image URL</Label>
                  <Input
                    value={formData.coverImage}
                    onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div>
                  <Label>Tags (comma-separated)</Label>
                  <Input
                    value={formData.tags}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    placeholder="sourcing, china, trade"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: any) => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Read Time (minutes)</Label>
                    <Input
                      type="number"
                      value={formData.readTime}
                      onChange={(e) => setFormData({ ...formData, readTime: parseInt(e.target.value) || 5 })}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="featured"
                    checked={formData.featured}
                    onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                  />
                  <Label htmlFor="featured">Featured Article</Label>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button onClick={handleSubmit} disabled={createArticle.isPending || updateArticle.isPending}>
                    {editingArticle ? 'Update' : 'Create'} Article
                  </Button>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Articles List */}
        <Card>
          <CardHeader>
            <CardTitle>All Articles ({articles?.length || 0})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {articles?.map(item => (
                <div key={item.article.id} className="flex items-center gap-4 p-4 border rounded-lg">
                  {item.article.coverImage && (
                    <img
                      src={item.article.coverImage}
                      alt={item.article.title}
                      className="w-24 h-24 object-cover rounded"
                    />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-bold">{item.article.title}</h3>
                      <Badge variant={item.article.status === 'published' ? 'default' : 'outline'}>
                        {item.article.status}
                      </Badge>
                      {item.article.featured === 1 && <Badge>Featured</Badge>}
                    </div>
                    <p className="text-sm text-slate-600 mb-2">{item.article.excerpt}</p>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <span>{item.category?.name}</span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {item.article.views} views
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {item.article.publishedAt ? new Date(item.article.publishedAt).toLocaleDateString() : 'Not published'}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/blog/${item.article.slug}`} target="_blank">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </Link>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(item)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(item.article.id)}
                      disabled={deleteArticle.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {articles && articles.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                  <p>No articles yet. Create your first article!</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
