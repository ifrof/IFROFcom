/**
 * FactoryFinderLanding — Marketing landing page for the Factory Finder feature
 */
import { Link } from 'wouter';
import { Search, Shield, CheckCircle, Zap, Globe, TrendingUp, ArrowRight, Star, Clock, Eye, FileText, Lock, Users } from 'lucide-react';
import { SEO } from '@/components/SEO';

const STATS = [
  { value: '12,000+', label: 'Verified Suppliers' },
  { value: '47', label: 'Countries Covered' },
  { value: '98.7%', label: 'Satisfaction Rate' },
  { value: '48h', label: 'Avg Quote Time' },
];

const PROBLEMS = [
  { emoji: '😰', title: 'Paid $8,000 to a middleman', desc: 'Only to find out the factory was just another broker adding 40% markup.' },
  { emoji: '📦', title: 'Received wrong products', desc: 'Samples were perfect. The bulk order was completely different quality.' },
  { emoji: '🚫', title: 'Factory disappeared after deposit', desc: 'Sent 30% upfront. Factory stopped responding. No product, no refund.' },
  { emoji: '⏳', title: 'Wasted 3 months on bad leads', desc: 'Contacted 40 suppliers. Only 3 replied. None were actual manufacturers.' },
];

const FEATURES = [
  { icon: Shield, color: '#06b6d4', title: 'Factory Verification', desc: 'Every supplier is verified by our team. We check business licenses, production capacity, and export history before listing.' },
  { icon: Eye, color: '#8b5cf6', title: 'Production Evidence', desc: 'See real factory photos, videos, and audit reports — not stock images. Know exactly who you are dealing with.' },
  { icon: FileText, color: '#10b981', title: 'Transparent Pricing', desc: 'Get real FOB prices with no hidden fees. Our agents negotiate on your behalf and show you the full cost breakdown.' },
  { icon: Lock, color: '#f59e0b', title: 'Escrow Protection', desc: 'Funds are held securely until you confirm receipt and quality. You never pay a factory directly.' },
  { icon: Zap, color: '#ec4899', title: 'AI-Powered Matching', desc: 'Our AI analyzes your requirements and matches you with the 3 best-fit suppliers from our verified database.' },
  { icon: Users, color: '#06b6d4', title: 'Dedicated Agent', desc: 'A human sourcing agent reviews every RFQ, negotiates pricing, and manages the relationship on your behalf.' },
];

const STEPS = [
  { num: '01', title: 'Describe Your Product', desc: 'Tell us what you need — product type, quantity, quality standards, target price, and timeline. Takes 3 minutes.' },
  { num: '02', title: 'We Find and Vet Suppliers', desc: 'Our team searches our verified database and contacts the best-fit factories. We check availability and negotiate initial pricing.' },
  { num: '03', title: 'Receive Curated Quotes', desc: 'You get 3 detailed quotes with full cost breakdowns, supplier profiles, and production timelines. No spam, no middlemen.' },
  { num: '04', title: 'Order with Full Protection', desc: 'Place your order through our escrow system. Funds released only after you confirm quality. We handle logistics too.' },
];

const TESTIMONIALS = [
  { name: 'Marcus Thompson', country: 'US', role: 'E-commerce Founder', avatar: 'M', text: 'I had been burned twice before finding IFROF. The factory verification process is legit — they sent me actual audit reports with photos. My first order through them was flawless. $23,000 order, zero issues.', rating: 5, orders: 8 },
  { name: 'Fatima Al-Rashid', country: 'UAE', role: 'Import Business Owner', avatar: 'F', text: 'The escrow system alone is worth it. I was about to wire $15,000 directly to a factory I found on open marketplaces. IFROF agent reviewed the factory profile and flagged 3 red flags I never would have caught.', rating: 5, orders: 14 },
  { name: 'Jean-Pierre Moreau', country: 'FR', role: 'Brand Owner', avatar: 'J', text: 'What I love most is the transparency. I can see exactly what the factory charges vs. what IFROF charges. No hidden fees. The 5% commission is the most honest pricing I have seen in this industry.', rating: 5, orders: 6 },
];

const CATEGORIES = [
  { name: 'Electronics', icon: '⚡', count: '2,400+' },
  { name: 'Apparel', icon: '👕', count: '1,800+' },
  { name: 'Home & Garden', icon: '🏡', count: '1,600+' },
  { name: 'Beauty', icon: '💄', count: '900+' },
  { name: 'Sports', icon: '⚽', count: '750+' },
  { name: 'Toys & Games', icon: '🎮', count: '620+' },
  { name: 'Automotive', icon: '🚗', count: '480+' },
  { name: 'Food & Beverage', icon: '🍵', count: '390+' },
];

export default function FactoryFinderLanding() {
  return (
    <div style={{ background: 'white', overflowX: 'hidden' }}>
      <SEO
        title="Factory Finder — Source Verified Manufacturers Directly"
        description="Find verified Chinese factories with zero middlemen. AI-powered matching, escrow protection, and real audit reports. 12,000+ verified suppliers across 47 countries."
        keywords="find factory China, verified manufacturers, B2B sourcing platform, factory finder, import from China"
        url="https://ifrof.com/factory-finder/landing"
      />
      {/* Hero */}
      <section style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)', paddingTop: '7rem', paddingBottom: '5rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: '10%', right: '5%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle, rgba(6,182,212,0.15) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: '10%', left: '5%', width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle, rgba(139,92,246,0.12) 0%, transparent 70%)', pointerEvents: 'none' }} />
        <div className="container" style={{ textAlign: 'center', position: 'relative' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.3)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.5rem', fontSize: '0.8125rem', fontWeight: 700, color: '#06b6d4' }}>
            <Shield style={{ width: 14, height: 14 }} /> 12,000+ Verified Suppliers · Zero Middlemen
          </div>
          <h1 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 900, color: 'white', lineHeight: 1.15, marginBottom: '1.25rem', maxWidth: 800, margin: '0 auto 1.25rem' }}>
            Find Real Factories.<br />
            <span style={{ background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Stop Paying Middlemen.</span>
          </h1>
          <p style={{ fontSize: 'clamp(1rem, 2vw, 1.1875rem)', color: '#94a3b8', maxWidth: 600, margin: '0 auto 2.5rem', lineHeight: 1.7 }}>
            IFROF connects you directly with verified manufacturers in China, Turkey, India, and 44 other countries. Every supplier is vetted. Every order is protected by escrow.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '3rem' }}>
            <Link href="/rfq" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.625rem', padding: '1rem 2rem', borderRadius: '0.875rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', textDecoration: 'none', fontWeight: 800, fontSize: '1rem', boxShadow: '0 8px 24px rgba(6,182,212,0.35)' }}>
              <Search style={{ width: 18, height: 18 }} /> Find Factories Free
            </Link>
            <Link href="/marketplace" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.625rem', padding: '1rem 2rem', borderRadius: '0.875rem', background: 'rgba(255,255,255,0.08)', border: '1.5px solid rgba(255,255,255,0.15)', color: 'white', textDecoration: 'none', fontWeight: 700, fontSize: '1rem' }}>
              Browse Products <ArrowRight style={{ width: 16, height: 16 }} />
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem', maxWidth: 700, margin: '0 auto' }}>
            {STATS.map(s => (
              <div key={s.label} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '0.875rem', padding: '1.25rem 1rem', textAlign: 'center' }}>
                <div style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.75rem', fontWeight: 900, color: 'white', marginBottom: '0.25rem' }}>{s.value}</div>
                <div style={{ fontSize: '0.8125rem', color: '#94a3b8', fontWeight: 600 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section style={{ padding: '5rem 0', background: '#f8fafc' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: '#0f172a', marginBottom: '0.75rem' }}>Sound familiar?</h2>
            <p style={{ color: '#64748b', fontSize: '1rem', maxWidth: 500, margin: '0 auto' }}>These are the stories we hear every week from buyers who came to us after getting burned.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem' }}>
            {PROBLEMS.map(p => (
              <div key={p.title} style={{ background: 'white', borderRadius: '1rem', padding: '1.5rem', border: '1px solid #fee2e2', boxShadow: '0 4px 16px rgba(239,68,68,0.06)' }}>
                <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>{p.emoji}</div>
                <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.5rem' }}>{p.title}</h3>
                <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: 1.6 }}>{p.desc}</p>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
            <p style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.125rem', fontWeight: 700, color: '#0f172a' }}>IFROF was built specifically to prevent all of this.</p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section style={{ padding: '5rem 0', background: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: '#0f172a', marginBottom: '0.75rem' }}>How It Works</h2>
            <p style={{ color: '#64748b', fontSize: '1rem', maxWidth: 500, margin: '0 auto' }}>From idea to delivered product in 4 simple steps. No experience required.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '2rem' }}>
            {STEPS.map(step => (
              <div key={step.num} style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem' }}>
                <div style={{ width: 52, height: 52, borderRadius: '0.875rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, boxShadow: '0 8px 20px rgba(6,182,212,0.25)' }}>
                  <span style={{ fontFamily: 'Sora, sans-serif', fontWeight: 900, color: 'white', fontSize: '0.875rem' }}>{step.num}</span>
                </div>
                <div>
                  <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.0625rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.5rem' }}>{step.title}</h3>
                  <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: 1.65 }}>{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: '3rem' }}>
            <Link href="/rfq" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.625rem', padding: '0.875rem 2.5rem', borderRadius: '0.875rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', textDecoration: 'none', fontWeight: 800, fontSize: '1rem', boxShadow: '0 8px 24px rgba(6,182,212,0.3)' }}>
              Start Your Free RFQ <ArrowRight style={{ width: 16, height: 16 }} />
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '5rem 0', background: '#f8fafc' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: '#0f172a', marginBottom: '0.75rem' }}>Everything You Need to Source Safely</h2>
            <p style={{ color: '#64748b', fontSize: '1rem', maxWidth: 500, margin: '0 auto' }}>Built by importers who got burned. Designed so you never have to.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem' }}>
            {FEATURES.map(f => (
              <div key={f.title} style={{ background: 'white', borderRadius: '1rem', padding: '1.75rem', border: '1px solid #e2e8f0', transition: 'all 250ms' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)'; (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 32px rgba(0,0,0,0.08)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLElement).style.boxShadow = 'none'; }}
              >
                <div style={{ width: 48, height: 48, borderRadius: '0.75rem', background: f.color + '18', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                  <f.icon style={{ width: 22, height: 22, color: f.color }} />
                </div>
                <h3 style={{ fontFamily: 'Sora, sans-serif', fontSize: '1.0625rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.5rem' }}>{f.title}</h3>
                <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: 1.65 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section style={{ padding: '5rem 0', background: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: '#0f172a', marginBottom: '0.75rem' }}>Browse by Category</h2>
            <p style={{ color: '#64748b', fontSize: '1rem' }}>Verified suppliers across every major product category.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '1rem' }}>
            {CATEGORIES.map(cat => (
              <Link key={cat.name} href="/marketplace" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem', padding: '1.5rem 1rem', borderRadius: '1rem', background: '#f8fafc', border: '1.5px solid #e2e8f0', textDecoration: 'none', transition: 'all 200ms' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'linear-gradient(135deg, rgba(6,182,212,0.06), rgba(139,92,246,0.06))'; (e.currentTarget as HTMLElement).style.borderColor = '#06b6d4'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#f8fafc'; (e.currentTarget as HTMLElement).style.borderColor = '#e2e8f0'; }}
              >
                <span style={{ fontSize: '2rem' }}>{cat.icon}</span>
                <span style={{ fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '0.8125rem', color: '#0f172a', textAlign: 'center' }}>{cat.name}</span>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: 600 }}>{cat.count} suppliers</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section style={{ padding: '5rem 0', background: 'linear-gradient(135deg, #0f172a, #1e293b)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.25rem)', fontWeight: 800, color: 'white', marginBottom: '0.75rem' }}>Real Buyers. Real Results.</h2>
            <p style={{ color: '#94a3b8', fontSize: '1rem' }}>Join 8,000+ importers who source safely through IFROF.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem' }}>
            {TESTIMONIALS.map(t => (
              <div key={t.name} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '1.125rem', padding: '1.75rem' }}>
                <div style={{ display: 'flex', gap: '0.25rem', marginBottom: '1rem' }}>
                  {Array.from({ length: t.rating }).map((_, i) => <Star key={i} style={{ width: 16, height: 16, color: '#f59e0b', fill: '#f59e0b' }} />)}
                </div>
                <p style={{ fontSize: '0.9375rem', color: '#cbd5e1', lineHeight: 1.7, marginBottom: '1.25rem', fontStyle: 'italic' }}>"{t.text}"</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'linear-gradient(135deg, #06b6d4, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 800, fontSize: '1rem' }}>{t.avatar}</div>
                  <div>
                    <div style={{ fontFamily: 'Sora, sans-serif', fontWeight: 700, color: 'white', fontSize: '0.9rem' }}>{t.name} ({t.country})</div>
                    <div style={{ fontSize: '0.8125rem', color: '#94a3b8' }}>{t.role} · {t.orders} orders placed</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section style={{ padding: '5rem 0', background: 'white', textAlign: 'center' }}>
        <div className="container" style={{ maxWidth: 700 }}>
          <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, rgba(6,182,212,0.1), rgba(139,92,246,0.1))', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem' }}>
            <TrendingUp style={{ width: 32, height: 32, color: '#06b6d4' }} />
          </div>
          <h2 style={{ fontFamily: 'Sora, sans-serif', fontSize: 'clamp(1.5rem, 3vw, 2.5rem)', fontWeight: 900, color: '#0f172a', marginBottom: '1rem', lineHeight: 1.2 }}>
            Your next order should be your best order.
          </h2>
          <p style={{ color: '#64748b', fontSize: '1.0625rem', lineHeight: 1.7, marginBottom: '2.5rem' }}>
            Submit a free sourcing request today. No credit card required. Get 3 verified quotes within 48 hours.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/rfq" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.625rem', padding: '1rem 2.5rem', borderRadius: '0.875rem', background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white', textDecoration: 'none', fontWeight: 800, fontSize: '1.0625rem', boxShadow: '0 8px 24px rgba(6,182,212,0.3)' }}>
              Get Free Quotes <ArrowRight style={{ width: 18, height: 18 }} />
            </Link>
            <Link href="/services/concierge" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.625rem', padding: '1rem 2.5rem', borderRadius: '0.875rem', background: '#f8fafc', border: '1.5px solid #e2e8f0', color: '#0f172a', textDecoration: 'none', fontWeight: 700, fontSize: '1rem' }}>
              Talk to an Agent
            </Link>
          </div>
          <p style={{ marginTop: '1.5rem', fontSize: '0.8125rem', color: '#94a3b8' }}>
            <CheckCircle style={{ width: 13, height: 13, display: 'inline', marginRight: '0.375rem', color: '#10b981' }} />
            Free to start · No middlemen · Escrow protected · Cancel anytime
          </p>
        </div>
      </section>
    </div>
  );
}
