import { Link } from 'wouter';
import { CheckCircle, Package, ArrowLeft } from 'lucide-react';

export default function CheckoutSuccess() {
  const params = new URLSearchParams(window.location.search);
  const sessionId = params.get('session_id');

  return (
    <div style={{ minHeight: '100vh', background: '#f8fafc', display: 'flex', alignItems: 'center', justifyContent: 'center', direction: 'rtl' }}>
      <div style={{ maxWidth: 520, margin: '0 auto', padding: '2rem 1.5rem', textAlign: 'center' }}>
        <div style={{
          background: 'white', borderRadius: '1.25rem', padding: '3rem 2.5rem',
          boxShadow: '0 4px 24px rgba(0,0,0,0.06)',
        }}>
          <div style={{
            width: 80, height: 80, borderRadius: '50%',
            background: 'linear-gradient(135deg, rgba(16,185,129,0.12), rgba(16,185,129,0.04))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 1.5rem',
          }}>
            <CheckCircle style={{ width: 40, height: 40, color: '#10b981' }} />
          </div>

          <h1 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
            تم الدفع بنجاح!
          </h1>
          <p style={{ color: '#64748b', fontSize: '0.9375rem', lineHeight: 1.7, marginBottom: '1.5rem' }}>
            تمت معالجة دفعتك بنجاح. ستتلقى قريباً رسالة تأكيد بالبريد الإلكتروني تتضمن تفاصيل طلبك ومعلومات التتبع.
          </p>

          {sessionId && (
            <div style={{
              background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '0.75rem',
              padding: '1rem', marginBottom: '2rem', fontSize: '0.8125rem', color: '#15803d',
            }}>
              مرجع المعاملة: <span style={{ fontFamily: 'monospace', fontWeight: 600, direction: 'ltr', unicodeBidi: 'embed' }}>{sessionId.slice(0, 20)}...</span>
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <Link href="/orders" style={{
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              padding: '0.875rem 2rem', borderRadius: '0.75rem',
              background: 'linear-gradient(135deg, #06b6d4, #0891b2)', color: 'white',
              textDecoration: 'none', fontWeight: 700, fontSize: '0.9375rem',
            }}>
              <Package style={{ width: 18, height: 18 }} /> عرض الطلبات
            </Link>
            <Link href="/marketplace" style={{
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
              padding: '0.875rem 2rem', borderRadius: '0.75rem',
              border: '1.5px solid #e2e8f0', background: 'white', color: '#0f172a',
              textDecoration: 'none', fontWeight: 600, fontSize: '0.9375rem',
            }}>
              متابعة التسوق <ArrowLeft style={{ width: 16, height: 16 }} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
