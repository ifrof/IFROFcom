import React, { useState } from 'react';
import { SEO } from '@/components/SEO';
import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import {
  TrendingDown, CheckCircle, ArrowRight, Package, Zap, Clock,
  DollarSign, BarChart3, ChevronDown, ChevronUp, MessageCircle, Tag, RefreshCw,
  MessageSquare,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

// Mock live deals — in production these come from trpc.services.listStockDeals
const MOCK_DEALS = [
  { id: 1, category: 'Electronics', title: 'Bluetooth Earbuds — Factory Overstock', units: 2000, originalPrice: 18, dealPrice: 7.5, margin: '58%', moq: 200, tag: 'HOT', color: '#ef4444' },
  { id: 2, category: 'Apparel', title: 'Cotton T-Shirts — End of Season', units: 5000, originalPrice: 8, dealPrice: 2.8, margin: '65%', moq: 500, tag: 'NEW', color: '#10b981' },
  { id: 3, category: 'Home Goods', title: 'LED Desk Lamps — Discontinued Model', units: 800, originalPrice: 22, dealPrice: 9, margin: '59%', moq: 100, tag: 'LIMITED', color: '#f59e0b' },
  { id: 4, category: 'Beauty', title: 'Lip Gloss Sets — Packaging Change', units: 3000, originalPrice: 5, dealPrice: 1.9, margin: '62%', moq: 300, tag: 'HOT', color: '#ef4444' },
  { id: 5, category: 'Sports', title: 'Resistance Bands — Excess Inventory', units: 4000, originalPrice: 6, dealPrice: 2.2, margin: '63%', moq: 400, tag: 'NEW', color: '#10b981' },
  { id: 6, category: 'Electronics', title: 'USB-C Hubs — Surplus Stock', units: 1200, originalPrice: 28, dealPrice: 11, margin: '61%', moq: 150, tag: 'LIMITED', color: '#f59e0b' },
];

export default function ServiceStockLiquidation() {
  const { t } = useTranslation();
  const [form, setForm] = useState({ name: '', email: '', company: '', interestedIn: '', budget: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [selectedDeal, setSelectedDeal] = useState<number | null>(null);

  const submitInquiry = trpc.services.submitInquiry.useMutation({
    onSuccess: () => { setSubmitted(true); toast.success('Interest registered! We will send you the full deal sheet within 24 hours.'); },
    onError: () => toast.error('Something went wrong. Reach us on Secure Chat for instant access.'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry.mutate({ serviceType: 'stock_liquidation', ...form });
  };

  const categories = ['All', 'Electronics', 'Apparel', 'Home Goods', 'Beauty', 'Sports'];
  const filteredDeals = categoryFilter === 'All' ? MOCK_DEALS : MOCK_DEALS.filter(d => d.category === categoryFilter);

  const howItWorks = [
    { icon: RefreshCw, title: 'We Source the Stock', desc: 'We identify factory overstock, end-of-season inventory, and discontinued models at 50–70% below wholesale price.' },
    { icon: Tag, title: 'You Get First Access', desc: 'Registered buyers receive deal alerts before public listing. Deals move fast — first come, first served.' },
    { icon: DollarSign, title: 'Buy at Deep Discount', desc: 'Pay the deal price. We handle logistics, QC, and shipping. You receive goods ready to resell.' },
    { icon: BarChart3, title: 'Flip for Fast Margin', desc: 'Typical resale margin is 40–80% on platforms like Amazon, eBay, TikTok Shop, or your own store.' },
  ];

  const faqs = [
    { q: 'How do you source these deals?', a: 'We have direct relationships with 200+ verified factories in China. When they have overstock, cancelled orders, or packaging changes, they offer us first-access pricing before going to the open market.' },
    { q: 'What is the minimum order quantity?', a: 'Each deal has its own MOQ, typically between 100–500 units. This is clearly listed on every deal card.' },
    { q: 'Are the products new or used?', a: 'All stock liquidation deals are brand new, unused products. The reason for liquidation is always disclosed (overstock, season end, model discontinuation, etc.).' },
    { q: 'How long does delivery take?', a: 'Sea freight: 25–35 days. Air freight: 7–12 days. We provide real-time tracking for every shipment.' },
    { q: 'Can I inspect the goods before buying?', a: 'Yes. We conduct a pre-shipment quality inspection for every deal. You receive a full inspection report with photos before payment is released.' },
    { q: 'Can I get exclusive deals for my region?', a: 'Yes. Pro subscribers can request regional exclusivity on specific deals, preventing competitors in your market from accessing the same stock.' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: '#0f172a', color: '#f8fafc' }}>
      <SEO
        title="Stock Liquidation — Buy Overstock & Clearance from China"
        description="Buy discounted overstock, clearance, and end-of-season inventory directly from Chinese factories. Verified deals. Escrow protection. Prices up to 70% below market."
        keywords="stock liquidation China, factory overstock, clearance inventory, wholesale deals, IFROF liquidation"
        url="https://ifrof.com/services/stock-liquidation"
      />
      {/* Hero */}
      <section style={{ padding: '6rem 1.5rem 4rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 0%, rgba(239,68,68,0.15), transparent 65%)' }} />
        <div style={{ maxWidth: '820px', margin: '0 auto', position: 'relative' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '2rem', padding: '0.375rem 1rem', marginBottom: '1.5rem', fontSize: '0.875rem', color: '#f87171', fontWeight: 600 }}>
            <TrendingDown size={14} /> Stock Liquidation Deals
          </div>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, lineHeight: 1.15, marginBottom: '1.5rem', letterSpacing: '-0.03em' }}>
            Factory Overstock at<br />
            <span style={{ background: 'linear-gradient(135deg, #ef4444, #f59e0b)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              50–70% Below Wholesale.
            </span>
          </h1>
          <p style={{ fontSize: '1.125rem', color: 'var(--color-subtle)', lineHeight: 1.7, marginBottom: '2.5rem', maxWidth: '620px', margin: '0 auto 2.5rem' }}>
            We source factory overstock, cancelled orders, and end-of-season inventory. You buy cheap, flip fast, and keep the margin.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a href="#live-deals" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'linear-gradient(135deg, #ef4444, #dc2626)', color: '#fff', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', textDecoration: 'none', boxShadow: '0 4px 20px rgba(239,68,68,0.3)' }}>
              <Zap size={18} /> Browse Live Deals
            </a>
            <Link href="/rfq"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.875rem 2rem', background: 'linear-gradient(135deg, #ef4444, #dc2626)', color: '#fff', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', textDecoration: 'none', boxShadow: '0 4px 20px rgba(239,68,68,0.3)' }}>
              <MessageSquare size={18} /> Join Secure Deal Network
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <div style={{ background: 'rgba(255,255,255,0.04)', borderTop: '1px solid rgba(255,255,255,0.07)', borderBottom: '1px solid rgba(255,255,255,0.07)', padding: '1.25rem 1.5rem' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto', display: 'flex', justifyContent: 'center', gap: '3rem', flexWrap: 'wrap' }}>
          {[['50–70%', 'Below Wholesale'], ['48h', 'Deal Turnaround'], ['100+', 'Active Deals/Month'], ['$2M+', 'Stock Moved Monthly']].map(([val, label]) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#f87171' }}>{val}</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--color-muted)', marginTop: '0.2rem' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <section style={{ padding: '5rem 1.5rem', maxWidth: '1000px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>How Stock Liquidation Works</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem' }}>
          {howItWorks.map((item) => (
            <div key={item.title} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.75rem' }}>
              <div style={{ width: '2.5rem', height: '2.5rem', borderRadius: 'var(--radius-lg)', background: 'rgba(239,68,68,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem' }}>
                <item.icon size={18} color="#f87171" />
              </div>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '0.5rem' }}>{item.title}</h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-muted)', lineHeight: 1.6 }}>{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Live Deals */}
      <section id="live-deals" style={{ padding: '4rem 1.5rem', background: 'rgba(255,255,255,0.02)', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
            <div>
              <h2 style={{ fontSize: '1.75rem', fontWeight: 800, marginBottom: '0.25rem' }}>Live Deals</h2>
              <p style={{ color: 'var(--color-muted)', fontSize: '0.875rem' }}>Updated daily. Register below to get first-access alerts.</p>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              {categories.map((cat) => (
                <button key={cat} onClick={() => setCategoryFilter(cat)}
                  style={{ padding: '0.375rem 0.875rem', borderRadius: '2rem', border: `1px solid ${categoryFilter === cat ? '#ef4444' : 'rgba(255,255,255,0.12)'}`, background: categoryFilter === cat ? 'rgba(239,68,68,0.15)' : 'transparent', color: categoryFilter === cat ? '#f87171' : '#64748b', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}>
                  {cat}
                </button>
              ))}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
            {filteredDeals.map((deal) => (
              <div key={deal.id} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-xl)', padding: '1.5rem', position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: '1rem', right: '1rem', background: deal.color, color: '#fff', fontSize: '0.7rem', fontWeight: 800, padding: '0.2rem 0.6rem', borderRadius: '2rem', letterSpacing: '0.05em' }}>
                  {deal.tag}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)', marginBottom: '0.5rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{deal.category}</div>
                <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '1rem', paddingRight: '3rem', lineHeight: 1.4 }}>{deal.title}</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.25rem' }}>
                  <div style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 'var(--radius-md)', padding: '0.625rem' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--color-muted)', marginBottom: '0.2rem' }}>Deal Price</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#10b981' }}>${deal.dealPrice}</div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--color-muted)', textDecoration: 'line-through' }}>${deal.originalPrice} retail</div>
                  </div>
                  <div style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 'var(--radius-md)', padding: '0.625rem' }}>
                    <div style={{ fontSize: '0.7rem', color: 'var(--color-muted)', marginBottom: '0.2rem' }}>Potential Margin</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#f59e0b' }}>{deal.margin}</div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--color-muted)' }}>at retail price</div>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--color-muted)', marginBottom: '1rem' }}>
                  <span><Package size={12} style={{ display: 'inline', marginRight: '0.25rem' }} />{deal.units.toLocaleString()} units available</span>
                  <span>MOQ: {deal.moq} units</span>
                </div>
                <Link href="/rfq"
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', padding: '0.625rem', background: 'linear-gradient(135deg, #ef4444, #dc2626)', color: '#fff', border: 'none', borderRadius: '0.625rem', fontWeight: 700, fontSize: '0.875rem', cursor: 'pointer', textDecoration: 'none' }}>
                  <MessageSquare size={14} /> Claim via Secure Chat
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Register for Alerts Form */}
      <section style={{ padding: '5rem 1.5rem', maxWidth: '680px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '0.75rem' }}>Get First-Access Deal Alerts</h2>
        <p style={{ color: 'var(--color-muted)', textAlign: 'center', marginBottom: '2.5rem' }}>Register once. We send you curated deals matching your category and budget before they go public.</p>
        {submitted ? (
          <div style={{ textAlign: 'center', padding: '3rem', background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 'var(--radius-xl)' }}>
            <CheckCircle size={48} color="#10b981" style={{ marginBottom: '1rem' }} />
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem' }}>You Are on the List!</h3>
            <p style={{ color: 'var(--color-muted)' }}>Expect your first deal alert within 24 hours. The best deals go in under 48 hours.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Your name', required: true },
              { key: 'email', label: 'Email Address', type: 'email', placeholder: 'you@company.com', required: true },
              { key: 'company', label: 'Company / Store Name', type: 'text', placeholder: 'Optional', required: false },
              { key: 'interestedIn', label: 'Product Categories of Interest', type: 'text', placeholder: 'e.g. Electronics, Apparel, Beauty', required: true },
              { key: 'budget', label: 'Monthly Budget (USD)', type: 'text', placeholder: 'e.g. $5,000 – $20,000', required: false },
            ].map((f) => (
              <div key={f.key}>
                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.375rem', color: '#cbd5e1' }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder} required={f.required} value={(form as any)[f.key]}
                  onChange={(e) => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  style={{ width: '100%', padding: '0.75rem 1rem', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '0.625rem', color: '#f8fafc', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' }} />
              </div>
            ))}
            <button type="submit" disabled={submitInquiry.isPending}
              style={{ padding: '0.875rem', background: 'linear-gradient(135deg, #ef4444, #dc2626)', color: '#fff', border: 'none', borderRadius: 'var(--radius-lg)', fontWeight: 700, fontSize: '1rem', cursor: 'pointer', opacity: submitInquiry.isPending ? 0.7 : 1 }}>
              {submitInquiry.isPending ? 'Registering...' : 'Register for Deal Alerts'}
            </button>
          </form>
        )}
      </section>

      {/* FAQ */}
      <section style={{ padding: '4rem 1.5rem', maxWidth: '720px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800, textAlign: 'center', marginBottom: '2.5rem' }}>Frequently Asked Questions</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {faqs.map((faq, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '0.875rem', overflow: 'hidden' }}>
              <button onClick={() => setOpenFaq(openFaq === i ? null : i)}
                style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1.125rem 1.5rem', background: 'none', border: 'none', color: '#f8fafc', fontWeight: 600, fontSize: '0.95rem', cursor: 'pointer', textAlign: 'left', gap: '1rem' }}>
                {faq.q}
                {openFaq === i ? <ChevronUp size={16} color="#64748b" /> : <ChevronDown size={16} color="#64748b" />}
              </button>
              {openFaq === i && <div style={{ padding: '0 1.5rem 1.25rem', fontSize: '0.875rem', color: 'var(--color-subtle)', lineHeight: 1.7 }}>{faq.a}</div>}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
