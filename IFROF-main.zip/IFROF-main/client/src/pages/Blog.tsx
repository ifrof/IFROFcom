/**
 * Blog — أكاديمية الاستيراد من الصين
 * صفحة المدونة الرئيسية
 */
import { useState } from 'react';
import { Link } from 'wouter';
import { trpc } from '@/lib/trpc';
import { BookOpen, Clock, Search, ArrowLeft, Tag, TrendingUp, Star, Sparkles } from 'lucide-react';

export default function Blog() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();

  const { data: categories } = trpc.blog.listCategories.useQuery();
  const { data: articles, isLoading } = trpc.blog.listArticles.useQuery({
    status: 'published',
    categoryId: selectedCategory,
    limit: 100,
  });

  const filteredArticles = articles?.filter(item =>
    item.article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.article.excerpt ?? '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const featuredArticles = filteredArticles?.slice(0, 3);
  const restArticles = filteredArticles?.slice(3);

  return (
    <div style={{
      minHeight: '100vh',
      background: '#f8fafc',
      fontFamily: '"DM Sans", Tajawal, sans-serif',
      direction: 'rtl',
      marginTop: 'calc(var(--nav-offset, 6.75rem) * -1)', /* cancel main padding so hero is flush with nav */
    }}>

      {/* ── Hero ─────────────────────────────────────────────── */}
      <section style={{
        background: 'linear-gradient(150deg, #020817 0%, #0c1a2e 45%, #0f2d4a 100%)',
        paddingTop: 'calc(var(--nav-offset, 6.75rem) + 5rem)',
        paddingBottom: '4.5rem',
        paddingLeft: '1.5rem',
        paddingRight: '1.5rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Glow */}
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 80% 55% at 50% -5%, rgba(6,182,212,0.18), transparent)' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 45% 35% at 80% 65%, rgba(139,92,246,0.08), transparent)' }} />
        {/* Grid */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)',
          backgroundSize: '50px 50px',
          maskImage: 'radial-gradient(ellipse 70% 60% at 50% 0%, black, transparent)',
          WebkitMaskImage: 'radial-gradient(ellipse 70% 60% at 50% 0%, black, transparent)',
        } as React.CSSProperties} />

        <div style={{ maxWidth: 740, margin: '0 auto', position: 'relative' }}>
          {/* Badge */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.22)',
            borderRadius: '2rem', padding: '0.4rem 1.125rem',
            marginBottom: '1.75rem', fontSize: '0.8125rem', color: '#22d3ee', fontWeight: 700,
            backdropFilter: 'blur(8px)',
          }}>
            <Sparkles size={13} strokeWidth={2.5} />
            أكاديمية الاستيراد من الصين
          </div>

          {/* Headline */}
          <h1 style={{
            fontSize: 'clamp(2rem, 5.5vw, 3.25rem)', fontWeight: 900,
            color: '#f1f5f9', lineHeight: 1.15, marginBottom: '1.25rem',
            letterSpacing: '-0.03em', fontFamily: '"DM Sans", Tajawal, sans-serif',
          }}>
            أسرار الاستيراد التي لا يعرفها
            <br />
            <span style={{
              background: 'linear-gradient(135deg, #22d3ee 0%, #38bdf8 50%, #818cf8 100%)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              إلا كبار المستوردين
            </span>
          </h1>

          <p style={{
            color: '#94a3b8', fontSize: '1.0625rem', lineHeight: 1.75,
            maxWidth: 560, margin: '0 auto 2.5rem',
          }}>
            100 مقالة عميقة واحترافية — من التفاوض مع المصانع إلى بناء سلاسل توريد ذكية
          </p>

          {/* Search */}
          <div style={{ maxWidth: 500, margin: '0 auto', position: 'relative' }}>
            <Search size={16} style={{
              position: 'absolute', right: '1.125rem', top: '50%',
              transform: 'translateY(-50%)', color: '#475569', pointerEvents: 'none',
            }} />
            <input
              type="text"
              placeholder="ابحث في المقالات..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{
                width: '100%', padding: '0.9375rem 3.25rem 0.9375rem 1.25rem',
                borderRadius: '1rem', border: '1.5px solid rgba(255,255,255,0.1)',
                background: 'rgba(255,255,255,0.06)', color: '#f1f5f9',
                fontSize: '0.9375rem', outline: 'none', boxSizing: 'border-box',
                fontFamily: '"DM Sans", Tajawal, sans-serif',
                backdropFilter: 'blur(8px)',
                transition: 'border-color 0.2s, background 0.2s',
              } as React.CSSProperties}
              onFocus={e => {
                e.currentTarget.style.borderColor = 'rgba(6,182,212,0.5)';
                e.currentTarget.style.background = 'rgba(255,255,255,0.09)';
              }}
              onBlur={e => {
                e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
              }}
            />
          </div>
        </div>
      </section>

      {/* ── Stats Bar ──────────────────────────────────────────── */}
      <div style={{
        background: 'white',
        borderBottom: '1px solid #e2e8f0',
        padding: '1.25rem 1.5rem',
        boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
      }}>
        <div style={{
          maxWidth: 1100, margin: '0 auto',
          display: 'flex', gap: '2rem', justifyContent: 'center', flexWrap: 'wrap',
        }}>
          {[
            { val: '100+', label: 'مقالة احترافية', color: '#06b6d4' },
            { val: '800+', label: 'كلمة في كل مقالة', color: '#8b5cf6' },
            { val: '20+', label: 'سنة خبرة في المصدر', color: '#f59e0b' },
            { val: 'مجاناً', label: 'كل المحتوى مجاني', color: '#10b981' },
          ].map(({ val, label, color }) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '1.375rem', fontWeight: 900, color, letterSpacing: '-0.02em', lineHeight: 1.2 }}>{val}</div>
              <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.2rem', fontWeight: 500 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Category Filter ────────────────────────────────────── */}
      <div style={{
        background: 'rgba(255,255,255,0.97)',
        borderBottom: '1px solid #e2e8f0',
        padding: '0.75rem 1.5rem',
        position: 'sticky',
        top: 'var(--nav-offset, 6.75rem)', /* sit below the fixed nav */
        zIndex: 40,
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      } as React.CSSProperties}>
        <div style={{
          maxWidth: 1100, margin: '0 auto',
          display: 'flex', gap: '0.5rem', overflowX: 'auto',
        } as React.CSSProperties}>
          <FilterBtn active={selectedCategory === undefined} onClick={() => setSelectedCategory(undefined)} label="كل المقالات" />
          {categories?.map(cat => (
            <FilterBtn key={cat.id} active={selectedCategory === cat.id} onClick={() => setSelectedCategory(cat.id)} label={cat.name} />
          ))}
        </div>
      </div>

      {/* ── Content ────────────────────────────────────────────── */}
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '3rem 1.5rem 5rem' }}>

        {isLoading && (
          <div style={{ textAlign: 'center', padding: '6rem 0' }}>
            <style>{`@keyframes blog-spin { to { transform: rotate(360deg); } }`}</style>
            <div style={{
              width: 44, height: 44, margin: '0 auto 1rem',
              border: '3px solid #e2e8f0', borderTopColor: '#06b6d4',
              borderRadius: '50%', animation: 'blog-spin 0.8s linear infinite',
            }} />
            <p style={{ color: '#64748b', fontSize: '0.9375rem' }}>جاري تحميل المقالات...</p>
          </div>
        )}

        {!isLoading && filteredArticles?.length === 0 && (
          <div style={{ textAlign: 'center', padding: '6rem 0' }}>
            <BookOpen size={52} color="#cbd5e1" style={{ margin: '0 auto 1.25rem' }} />
            <h3 style={{ color: '#334155', fontSize: '1.375rem', fontWeight: 700, marginBottom: '0.5rem' }}>لا توجد مقالات مطابقة</h3>
            <p style={{ color: '#94a3b8', fontSize: '0.9375rem' }}>جرّب كلمة بحث مختلفة أو اختر تصنيفاً آخر</p>
          </div>
        )}

        {!isLoading && featuredArticles && featuredArticles.length > 0 && !searchQuery && (
          <div style={{ marginBottom: '4rem' }}>
            <SectionHeader icon={<Star size={16} color="#f59e0b" fill="#f59e0b" />} title="أبرز المقالات" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
              {featuredArticles.map((item: any, idx: number) => (
                <ArticleCard key={item.article.id} item={item} featured={idx === 0} />
              ))}
            </div>
          </div>
        )}

        {!isLoading && filteredArticles && filteredArticles.length > 0 && (
          <div>
            <SectionHeader
              icon={<TrendingUp size={16} color="#06b6d4" />}
              title={searchQuery ? `نتائج البحث (${filteredArticles.length})` : `جميع المقالات (${filteredArticles.length})`}
            />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.25rem' }}>
              {(searchQuery ? filteredArticles : (restArticles ?? [])).map((item: any) => (
                <ArticleCard key={item.article.id} item={item} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Subcomponents ──────────────────────────────────────────── */

function FilterBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '0.4375rem 1rem', borderRadius: '2rem',
        border: `1.5px solid ${active ? '#06b6d4' : '#e2e8f0'}`,
        background: active ? 'rgba(6,182,212,0.08)' : '#fff',
        color: active ? '#0891b2' : '#64748b',
        fontWeight: active ? 700 : 500, fontSize: '0.8125rem', cursor: 'pointer',
        whiteSpace: 'nowrap', fontFamily: '"DM Sans", Tajawal, sans-serif',
        transition: 'all 0.15s', flexShrink: 0,
        boxShadow: active ? '0 0 0 3px rgba(6,182,212,0.1)' : 'none',
      } as React.CSSProperties}
    >
      {label}
    </button>
  );
}

function SectionHeader({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: '0.75rem',
      marginBottom: '1.75rem', paddingBottom: '1.125rem',
      borderBottom: '1px solid #e2e8f0',
    }}>
      <div style={{
        width: 34, height: 34, borderRadius: '0.625rem',
        background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.12)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        {icon}
      </div>
      <h2 style={{
        fontSize: '1.1875rem', fontWeight: 800, color: '#0f172a',
        margin: 0, letterSpacing: '-0.015em', fontFamily: '"DM Sans", Tajawal, sans-serif',
      }}>
        {title}
      </h2>
    </div>
  );
}

function ArticleCard({ item, featured = false }: { item: any; featured?: boolean }) {
  const article = item.article;
  const category = item.category;

  return (
    <Link href={`/blog/${article.slug}`} style={{ textDecoration: 'none', display: 'block', height: '100%' }}>
      <div
        style={{
          background: '#fff', borderRadius: '1.125rem',
          border: '1px solid #e8edf2',
          overflow: 'hidden', cursor: 'pointer',
          transition: 'transform 0.22s cubic-bezier(0.16,1,0.3,1), box-shadow 0.22s cubic-bezier(0.16,1,0.3,1)',
          height: '100%', display: 'flex', flexDirection: 'column',
          boxShadow: '0 2px 8px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02)',
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)';
          (e.currentTarget as HTMLElement).style.boxShadow = '0 16px 40px rgba(0,0,0,0.10), 0 4px 12px rgba(0,0,0,0.06)';
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
          (e.currentTarget as HTMLElement).style.boxShadow = '0 2px 8px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02)';
        }}
      >
        {/* Thumbnail */}
        {article.coverImage ? (
          <img
            src={article.coverImage}
            alt={article.title}
            style={{ width: '100%', height: featured ? 210 : 168, objectFit: 'cover', display: 'block' }}
            loading="lazy"
          />
        ) : (
          <div style={{
            width: '100%', height: featured ? 210 : 168,
            background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #0c1a2e 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: 'radial-gradient(circle at 50% 50%, rgba(6,182,212,0.15), transparent 70%)',
            }} />
            <BookOpen size={28} color="rgba(6,182,212,0.55)" />
          </div>
        )}

        {/* Body */}
        <div style={{ padding: '1.375rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
          {category && (
            <div style={{ marginBottom: '0.875rem' }}>
              <span style={{
                fontSize: '0.6875rem', fontWeight: 800, color: '#0891b2',
                textTransform: 'uppercase', letterSpacing: '0.07em',
                background: 'rgba(6,182,212,0.08)', padding: '0.2rem 0.625rem',
                borderRadius: '0.375rem',
              } as React.CSSProperties}>
                {category.name}
              </span>
            </div>
          )}

          <h3 style={{
            fontSize: featured ? '1.0625rem' : '0.9375rem',
            fontWeight: 800, color: '#0f172a', lineHeight: 1.5,
            marginBottom: '0.625rem',
            display: '-webkit-box', WebkitLineClamp: 3,
            WebkitBoxOrient: 'vertical', overflow: 'hidden',
            fontFamily: '"DM Sans", Tajawal, sans-serif',
          } as React.CSSProperties}>
            {article.title}
          </h3>

          {article.excerpt && (
            <p style={{
              fontSize: '0.85rem', color: '#64748b', lineHeight: 1.7,
              marginBottom: '1rem', flex: 1,
              display: '-webkit-box', WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical', overflow: 'hidden',
              fontFamily: '"DM Sans", Tajawal, sans-serif',
            } as React.CSSProperties}>
              {article.excerpt}
            </p>
          )}

          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            marginTop: 'auto', paddingTop: '0.875rem', borderTop: '1px solid #f1f5f9',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: '#94a3b8', fontSize: '0.8rem' }}>
              <Clock size={12} strokeWidth={2} />
              <span>{article.readTime ?? 5} دقائق</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: '#06b6d4', fontSize: '0.8rem', fontWeight: 700 }}>
              <span>اقرأ المقالة</span>
              <ArrowLeft size={13} />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
