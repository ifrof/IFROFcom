/**
 * RfqMatches.tsx — Coming Soon (قريباً)
 */
import { ComingSoon } from '@/components/ComingSoon';

export default function RfqMatches() {
  return (
    <ComingSoon
      title="نتائج عروض الأسعار"
      description="عرض ومقارنة عروض الأسعار من الموردين — قريباً."
      icon="📊"
      features={["مقارنة عروض الأسعار جنباً إلى جنب", "تقييم الموردين تلقائياً", "التفاوض المباشر عبر المنصة"]}
      backHref="/rfq"
      primaryCta={{ label: 'ابحث عن مصنع', href: '/factory-finder' }}
    />
  );
}
