/**
 * PrivacyPolicy.tsx — Privacy Policy page for IFROF
 */
import { Link } from 'wouter';
import { Shield, ChevronLeft } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: '"DM Sans", sans-serif' }}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-900 to-cyan-900 py-16 px-4 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 mb-4">
          <Shield className="w-7 h-7 text-cyan-400" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white mb-3">Privacy Policy</h1>
        <p className="text-cyan-100/70 text-sm max-w-lg mx-auto">
          Last updated: March 2026
        </p>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="prose prose-gray max-w-none space-y-8 text-gray-700 text-[15px] leading-relaxed">

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">1. Introduction</h2>
            <p>
              IFROF ("we", "our", or "us") is committed to protecting your personal information and your right to privacy.
              This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit
              our website at <strong>https://ifrof.com</strong> and use our services.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">2. Information We Collect</h2>
            <p>We collect information that you provide directly to us, including:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Name, email address, and account credentials when you register</li>
              <li>Profile information such as company name, country, and business type</li>
              <li>Transaction data including orders, payments, and shipping details</li>
              <li>Communications you send us through the platform</li>
              <li>Usage data such as pages visited, features used, and session duration</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">3. How We Use Your Information</h2>
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Provide, operate, and maintain our platform and services</li>
              <li>Process transactions and send related information</li>
              <li>Verify your identity and prevent fraud</li>
              <li>Send you technical notices, updates, and support messages</li>
              <li>Respond to your comments and questions</li>
              <li>Improve our platform based on usage patterns</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">4. Google Sign-In</h2>
            <p>
              We offer the option to sign in using your Google account. When you use Google Sign-In, we receive your
              name, email address, and Google profile ID. We do not receive your Google password. Your use of Google
              Sign-In is also governed by <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-cyan-600 hover:underline">Google's Privacy Policy</a>.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">5. Sharing Your Information</h2>
            <p>
              We do not sell, trade, or rent your personal information to third parties. We may share your information
              with trusted service providers who assist us in operating our platform, subject to confidentiality agreements.
              We may also disclose your information when required by law or to protect our rights.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">6. Data Security</h2>
            <p>
              We implement industry-standard security measures to protect your personal information, including SSL/TLS
              encryption, secure cookie handling, and regular security audits. However, no method of transmission over
              the internet is 100% secure.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">7. Cookies</h2>
            <p>
              We use cookies and similar tracking technologies to maintain your session, remember your preferences, and
              analyze platform usage. You can control cookie settings through your browser. Disabling cookies may affect
              platform functionality.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">8. Your Rights</h2>
            <p>You have the right to:</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Access the personal information we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your account and associated data</li>
              <li>Opt out of marketing communications at any time</li>
              <li>Data portability where technically feasible</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-3">9. Contact Us</h2>
            <p>
              If you have questions about this Privacy Policy or our privacy practices, please contact us at:
            </p>
            <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-100">
              <p><strong>IFROF</strong></p>
              <p>Email: <a href="mailto:ifrof4@gmail.com" className="text-cyan-600 hover:underline">ifrof4@gmail.com</a></p>
              <p>Website: <a href="https://ifrof.com" className="text-cyan-600 hover:underline">https://ifrof.com</a></p>
            </div>
          </section>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-100 flex items-center gap-4">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-cyan-600 hover:text-cyan-700 font-semibold">
            <ChevronLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <Link href="/page/terms-and-conditions" className="text-sm text-gray-500 hover:text-gray-700">
            Terms of Service →
          </Link>
        </div>
      </div>
    </div>
  );
}
