import { useTranslation } from 'react-i18next';

/**
 * Smart translation helper that automatically translates English text
 * to the current language using i18next
 * 
 * Usage:
 * const t = useTranslationHelper();
 * <h1>{t('Source from China with Confidence')}</h1>
 */

// Translation cache to avoid redundant lookups
const translationCache = new Map<string, Map<string, string>>();

export function useTranslationHelper() {
  const { t: i18nT, i18n } = useTranslation();
  
  return (englishText: string): string => {
    // Initialize cache for this language if needed
    if (!translationCache.has(i18n.language)) {
      translationCache.set(i18n.language, new Map());
    }
    
    const cache = translationCache.get(i18n.language)!;
    
    // Return cached translation if available
    if (cache.has(englishText)) {
      return cache.get(englishText)!;
    }
    
    // Try to find translation in i18n resources
    // First check if it exists in the translation files
    const resources = i18n.getResourceBundle(i18n.language, 'translation');
    
    // Search through all nested keys
    const findTranslation = (obj: any, searchText: string): string | null => {
      for (const key in obj) {
        if (typeof obj[key] === 'string' && obj[key] === searchText) {
          return obj[key];
        }
        if (typeof obj[key] === 'object' && obj[key] !== null) {
          const result = findTranslation(obj[key], searchText);
          if (result) return result;
        }
      }
      return null;
    };
    
    let translation = findTranslation(resources, englishText);
    
    // If not found, return the English text as fallback
    if (!translation) {
      translation = englishText;
    }
    
    // Cache the result
    cache.set(englishText, translation);
    
    return translation;
  };
}

/**
 * Alternative: Use i18next directly with namespace
 * This is simpler if you add all text to translation files
 */
export function useSimpleTranslation() {
  const { t } = useTranslation();
  return t;
}
