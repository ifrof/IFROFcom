/**
 * Analytics utility — fires events to GTM dataLayer, Meta Pixel, LinkedIn, and Umami.
 * All calls are safe: they silently no-op if the tracking scripts aren't loaded.
 */

declare global {
  interface Window {
    dataLayer?: any[];
    fbq?: (...args: any[]) => void;
    lintrk?: (event: string, data?: Record<string, any>) => void;
    umami?: { track: (event: string, data?: Record<string, any>) => void };
  }
}

export function trackEvent(event: string, data?: Record<string, any>) {
  try {
    // GTM dataLayer
    if (window.dataLayer) {
      window.dataLayer.push({ event, ...data });
    }
    // Meta Pixel
    if (window.fbq) {
      window.fbq('trackCustom', event, data);
    }
    // LinkedIn
    if (window.lintrk) {
      window.lintrk('track', data);
    }
    // Umami
    if (window.umami) {
      window.umami.track(event, data);
    }
  } catch {
    // Never throw from analytics
  }
}

export function trackPageView(path: string) {
  try {
    if (window.dataLayer) {
      window.dataLayer.push({ event: 'page_view', page_path: path });
    }
    if (window.fbq) {
      window.fbq('track', 'PageView');
    }
  } catch {
    // Never throw from analytics
  }
}

export function trackPurchaseIntent(plan: string, value: number) {
  trackEvent('InitiateCheckout', { plan, value, currency: 'USD' });
  try {
    if (window.fbq) {
      window.fbq('track', 'InitiateCheckout', { value, currency: 'USD', content_name: plan });
    }
    if (window.dataLayer) {
      window.dataLayer.push({ event: 'begin_checkout', ecommerce: { value, currency: 'USD', items: [{ item_name: plan, price: value }] } });
    }
  } catch {
    // Never throw from analytics
  }
}

export function trackRegistration(role?: string) {
  trackEvent('CompleteRegistration', { role });
  try {
    if (window.fbq) {
      window.fbq('track', 'CompleteRegistration', { content_name: role });
    }
    if (window.lintrk) {
      window.lintrk('track', { conversion_id: 'registration' });
    }
  } catch {
    // Never throw from analytics
  }
}
