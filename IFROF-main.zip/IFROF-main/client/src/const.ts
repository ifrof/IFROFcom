export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

/**
 * Build the login URL. When the OAuth portal is configured the URL
 * points directly to the OAuth authorize endpoint so the user is redirected
 * to the external identity provider. Otherwise it falls back to the local
 * `/login` page.
 */
export const getLoginUrl = () => {
  const portalUrl = import.meta.env.VITE_OAUTH_PORTAL_URL;
  const appId = import.meta.env.VITE_APP_ID;

  if (portalUrl && appId) {
    const callbackUrl = `${window.location.origin}/api/oauth/callback`;
    const state = btoa(callbackUrl);
    return `${portalUrl}?projectId=${encodeURIComponent(appId)}&redirectUri=${encodeURIComponent(callbackUrl)}&state=${encodeURIComponent(state)}&responseType=code&scope=openid`;
  }

  return "/login";
};
