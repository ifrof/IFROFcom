/**
 * IFROF App — Navigation, Footer, and Routes
 * Design System v3.0 — "World-Class Professional"
 */
import { Route, Switch, Link, useLocation } from 'wouter';
import {
  Search, Home as HomeIcon, ShoppingCart, LayoutDashboard,
  Menu, X, Shield, Bell, LogIn, Globe, ArrowRight,
  Users, ChevronDown, Briefcase, Package, Palette, TrendingUp,
  BookOpen, HelpCircle, FileText, MessageSquare, Zap, Star,
  Tag, Factory, Truck, CreditCard, CheckCircle, Sparkles,
  BarChart3, Award, HeartHandshake, UserPlus,
} from 'lucide-react';
import { useState, useEffect, lazy, Suspense, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import ErrorBoundary from './components/ErrorBoundary';
import { NetworkStatus } from './components/NetworkStatus';
import { trackPageView } from './lib/analytics';
import { OrganizationSchema } from './components/SEO';

/* ── Lazy with retry (handles chunk-load failures after deploys) ── */
function lazyWithRetry(factory: () => Promise<{ default: React.ComponentType<any> }>) {
  return lazy(() =>
    factory().catch((err) => {
      // Retry once after a short delay — covers post-deploy hash mismatches
      return new Promise<{ default: React.ComponentType<any> }>((resolve, reject) => {
        setTimeout(() => {
          factory().then(resolve).catch(reject);
        }, 1500);
      });
    })
  );
}

/* ── Lazy Pages ───────────────────────────────────────────── */
const Home                    = lazyWithRetry(() => import('./pages/Home'));
const FactoryFinder           = lazyWithRetry(() => import('./pages/FactoryFinder'));
const FactoryFinderLanding    = lazyWithRetry(() => import('./pages/FactoryFinderLanding'));
const Marketplace             = lazyWithRetry(() => import('./pages/Marketplace'));
const ProductDetail           = lazyWithRetry(() => import('./pages/ProductDetail'));
const FactoryProfile          = lazyWithRetry(() => import('./pages/FactoryProfile'));
const Chat                    = lazyWithRetry(() => import('./pages/Chat'));
const Dashboard               = lazyWithRetry(() => import('./pages/Dashboard'));
const Admin                   = lazyWithRetry(() => import('./pages/Admin'));
const Login                   = lazyWithRetry(() => import('./pages/Login'));
const Register                = lazyWithRetry(() => import('./pages/Register'));
const ForgotPassword          = lazyWithRetry(() => import('./pages/ForgotPassword'));
const ResetPassword           = lazyWithRetry(() => import('./pages/ResetPassword'));
const Cart                    = lazyWithRetry(() => import('./pages/Cart'));
const Profile                 = lazyWithRetry(() => import('./pages/Profile'));
const Orders                  = lazyWithRetry(() => import('./pages/Orders'));
const Checkout                = lazyWithRetry(() => import('./pages/Checkout'));
const Wishlist                = lazyWithRetry(() => import('./pages/Wishlist'));
const Notifications           = lazyWithRetry(() => import('./pages/Notifications'));
const SettingsPage            = lazyWithRetry(() => import('./pages/Settings'));
const Forum                   = lazyWithRetry(() => import('./pages/Forum'));
const ForumThread             = lazyWithRetry(() => import('./pages/ForumThread'));
const Pricing                 = lazyWithRetry(() => import('./pages/Pricing'));
const Blog                    = lazyWithRetry(() => import('./pages/Blog'));
const BlogArticle             = lazyWithRetry(() => import('./pages/BlogArticle'));
const AdminBlog               = lazyWithRetry(() => import('./pages/AdminBlog'));
const RfqWizard               = lazyWithRetry(() => import('./pages/RfqWizard'));
const RfqMatches              = lazyWithRetry(() => import('./pages/RfqMatches'));
const Inbox                   = lazyWithRetry(() => import('./pages/Inbox'));
const ServiceConcierge        = lazyWithRetry(() => import('./pages/ServiceConcierge'));
const ServiceBrandLaunch      = lazyWithRetry(() => import('./pages/ServiceBrandLaunch'));
const ServiceStockLiquidation = lazyWithRetry(() => import('./pages/ServiceStockLiquidation'));
const ServiceEscrow           = lazyWithRetry(() => import('./pages/ServiceEscrow'));
const ServiceGroupShipping    = lazyWithRetry(() => import('./pages/ServiceGroupShipping'));
const Offers                  = lazyWithRetry(() => import('./pages/Offers'));
const AdminOffers             = lazyWithRetry(() => import('./pages/AdminOffers'));
const Faq                     = lazyWithRetry(() => import('./pages/Faq'));
const Trends                  = lazyWithRetry(() => import('./pages/Trends'));
const CheckoutSuccess         = lazyWithRetry(() => import('./pages/CheckoutSuccess'));
const CheckoutCancel          = lazyWithRetry(() => import('./pages/CheckoutCancel'));
const NotFound                = lazyWithRetry(() => import('./pages/NotFound'));
const PrivacyPolicy           = lazyWithRetry(() => import('./pages/PrivacyPolicy'));
const TermsAndConditions      = lazyWithRetry(() => import('./pages/TermsAndConditions'));
const CookiePolicy            = lazyWithRetry(() => import('./pages/CookiePolicy'));
const ProductDecision         = lazyWithRetry(() => import('./pages/ProductDecision'));

/* ── Page View Tracker ────────────────────────────────────── */
function PageViewTracker() {
  const [location] = useLocation();
  useEffect(() => {
    trackPageView(location);
  }, [location]);
  return null;
}

/* ── Page Loader ──────────────────────────────────────────── */
function PageLoader() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#f8fafc' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{
          width: 40, height: 40, margin: '0 auto 1rem',
          border: '3px solid rgba(6,182,212,0.15)',
          borderTop: '3px solid #06b6d4',
          borderRadius: '50%', animation: 'spin 0.7s linear infinite',
        }} />
        <p style={{ color: '#94a3b8', fontSize: '0.875rem', fontFamily: 'DM Sans, sans-serif' }}>Loading…</p>
      </div>
    </div>
  );
}

/* ── Logo Mark SVG ────────────────────────────────────────── */
function LogoMark({ size = 36, dark = false }: { size?: number; dark?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="36" height="36" rx="9" fill="url(#logoGrad)" />
      <path d="M9 10h18v3H9zM9 16.5h11v3H9zM9 23h14v3H9z" fill="white" opacity="0.95" />
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
          <stop stopColor="#06b6d4" />
          <stop offset="1" stopColor="#0369a1" />
        </linearGradient>
      </defs>
    </svg>
  );
}

/* ── Language Switcher ────────────────────────────────────── */
function LangSwitcher({ onDark = false }: { onDark?: boolean }) {
  const { i18n } = useTranslation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const langs = [
    { code: 'en', label: 'English', native: 'English', flag: '🇬🇧' },
    { code: 'ar', label: 'Arabic', native: 'العربية', flag: '🇸🇦' },
    { code: 'zh', label: 'Chinese', native: '中文', flag: '🇨🇳' },
  ];
  const current = langs.find(l => l.code === i18n.language) || langs[0];

  const changeLang = (code: string) => {
    i18n.changeLanguage(code);
    localStorage.setItem('ifrof_language', code);
    document.documentElement.dir = code === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = code;
    setOpen(false);
  };

  const btnColor = onDark ? 'rgba(255,255,255,0.75)' : '#64748b';
  const btnHoverBg = onDark ? 'rgba(255,255,255,0.1)' : '#f1f5f9';

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(v => !v)}
        title="Change language"
        style={{
          display: 'flex', alignItems: 'center', gap: '0.3rem',
          padding: '0.375rem 0.5rem', borderRadius: '0.5rem',
          background: 'transparent', border: 'none', cursor: 'pointer',
          color: btnColor, fontSize: '0.8125rem', fontWeight: 600,
          fontFamily: 'DM Sans, sans-serif',
          transition: 'all 150ms',
        }}
      >
        <Globe style={{ width: 14, height: 14 }} />
        <span style={{ fontSize: '1rem' }}>{current.flag}</span>
        <ChevronDown style={{ width: 11, height: 11, opacity: 0.6 }} />
      </button>
      {open && (
        <div style={{
          position: 'absolute', right: 0, top: 'calc(100% + 8px)',
          background: 'white', border: '1px solid #e8edf2',
          borderRadius: '0.875rem',
          boxShadow: '0 16px 48px rgba(0,0,0,0.12), 0 4px 16px rgba(0,0,0,0.06)',
          overflow: 'hidden', zIndex: 300, minWidth: 168,
          animation: 'navFadeIn 0.15s ease',
        }}>
          {langs.map(l => (
            <button
              key={l.code}
              onClick={() => changeLang(l.code)}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                width: '100%', padding: '0.6875rem 1rem', border: 'none', cursor: 'pointer',
                background: i18n.language === l.code ? 'rgba(6,182,212,0.06)' : 'white',
                color: i18n.language === l.code ? '#0891b2' : '#1e293b',
                fontSize: '0.875rem', fontWeight: i18n.language === l.code ? 700 : 500,
                fontFamily: 'DM Sans, sans-serif',
                textAlign: 'left', transition: 'background 100ms',
              }}
            >
              <span style={{ fontSize: '1.125rem' }}>{l.flag}</span>
              <div>
                <div style={{ lineHeight: 1.2 }}>{l.native}</div>
                <div style={{ fontSize: '0.6875rem', color: '#94a3b8', lineHeight: 1 }}>{l.label}</div>
              </div>
              {i18n.language === l.code && <CheckCircle style={{ width: 13, height: 13, marginLeft: 'auto', color: '#06b6d4' }} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Mega Menu ────────────────────────────────────────────── */
interface MegaItem {
  href: string;
  label: string;
  desc: string;
  icon: React.ElementType;
  color: string;
  badge?: string;
}

function MegaMenu({
  label, items, footer, onDark = false,
}: {
  label: string;
  items: MegaItem[];
  footer?: { label: string; href: string };
  onDark?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [location] = useLocation();

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const textColor = onDark ? 'rgba(255,255,255,0.85)' : '#334155';
  const activeBg = onDark ? 'rgba(255,255,255,0.12)' : 'rgba(6,182,212,0.08)';

  return (
    <div
      ref={ref}
      style={{ position: 'relative' }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
          padding: '0.5rem 0.75rem', borderRadius: '0.625rem',
          fontSize: '0.875rem', fontWeight: 600, fontFamily: 'DM Sans, sans-serif',
          color: open ? '#06b6d4' : textColor,
          background: open ? activeBg : 'transparent',
          border: 'none', cursor: 'pointer', transition: 'all 150ms',
          whiteSpace: 'nowrap',
        }}
      >
        {label}
        <ChevronDown style={{
          width: 13, height: 13,
          transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
          transition: 'transform 200ms ease',
          opacity: 0.6,
        }} />
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 8px)', left: '50%',
          transform: 'translateX(-50%)',
          background: 'white',
          border: '1px solid #e8edf2',
          borderRadius: '1.125rem',
          boxShadow: '0 24px 64px rgba(0,0,0,0.12), 0 8px 24px rgba(0,0,0,0.06)',
          minWidth: 520, zIndex: 200,
          animation: 'navFadeIn 0.18s cubic-bezier(0.16,1,0.3,1)',
          overflow: 'hidden',
        }}>
          {/* Grid of items */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: items.length > 3 ? '1fr 1fr' : '1fr',
            gap: '0.25rem',
            padding: '0.75rem',
          }}>
            {items.map(item => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: '0.875rem',
                  padding: '0.875rem 1rem', borderRadius: '0.75rem',
                  textDecoration: 'none',
                  background: location === item.href ? 'rgba(6,182,212,0.06)' : 'transparent',
                  transition: 'background 120ms',
                }}
                className="mega-item"
              >
                <div style={{
                  width: 38, height: 38, borderRadius: '0.625rem', flexShrink: 0,
                  background: item.color,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <item.icon style={{ width: 17, height: 17, color: 'white' }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: '0.5rem',
                    fontFamily: 'DM Sans, sans-serif', fontWeight: 700,
                    fontSize: '0.875rem', color: '#0f172a', lineHeight: 1.3,
                  }}>
                    {item.label}
                    {item.badge && (
                      <span style={{
                        padding: '0.1rem 0.4rem',
                        background: item.badge === 'NEW' ? 'linear-gradient(135deg,#10b981,#059669)' : 'linear-gradient(135deg,#f59e0b,#d97706)',
                        color: 'white', fontSize: '0.6rem', fontWeight: 800,
                        borderRadius: '2rem', letterSpacing: '0.04em',
                      }}>{item.badge}</span>
                    )}
                  </div>
                  <div style={{
                    fontSize: '0.8rem', color: '#64748b', marginTop: '0.2rem',
                    fontFamily: 'DM Sans, sans-serif', lineHeight: 1.4,
                  }}>{item.desc}</div>
                </div>
              </Link>
            ))}
          </div>

          {/* Footer CTA */}
          {footer && (
            <div style={{
              borderTop: '1px solid #f1f5f9',
              padding: '0.75rem 1.25rem',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              background: '#fafbfc',
            }}>
              <span style={{ fontSize: '0.8125rem', color: '#64748b', fontFamily: 'DM Sans, sans-serif' }}>
                مستعد للبدء؟
              </span>
              <Link
                href={footer.href}
                onClick={() => setOpen(false)}
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
                  padding: '0.4375rem 0.875rem', borderRadius: '0.5rem',
                  background: 'linear-gradient(135deg,#06b6d4,#0891b2)',
                  color: 'white', fontSize: '0.8125rem', fontWeight: 700,
                  fontFamily: 'DM Sans, sans-serif', textDecoration: 'none',
                  boxShadow: '0 2px 8px rgba(6,182,212,0.3)',
                }}
              >
                {footer.label}
                <ArrowRight style={{ width: 12, height: 12 }} />
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ── Simple Nav Link ──────────────────────────────────────── */
function NavLink({ href, label, onDark = false }: { href: string; label: string; onDark?: boolean }) {
  const [location] = useLocation();
  const active = location === href;
  const textColor = onDark ? 'rgba(255,255,255,0.85)' : '#334155';
  const activeColor = '#06b6d4';
  const activeBg = onDark ? 'rgba(255,255,255,0.12)' : 'rgba(6,182,212,0.08)';

  return (
    <Link
      href={href}
      style={{
        display: 'inline-flex', alignItems: 'center',
        padding: '0.5rem 0.75rem', borderRadius: '0.625rem',
        fontSize: '0.875rem', fontWeight: active ? 700 : 600,
        fontFamily: 'DM Sans, sans-serif',
        color: active ? activeColor : textColor,
        background: active ? activeBg : 'transparent',
        textDecoration: 'none', transition: 'all 150ms',
        whiteSpace: 'nowrap',
      }}
      className="nav-link-hover"
    >
      {label}
    </Link>
  );
}

/* ── Mobile Drawer ────────────────────────────────────────── */
function MobileDrawer({
  open, onClose,
  mainItems, servicesItems, moreItems,
}: {
  open: boolean;
  onClose: () => void;
  mainItems: { href: string; label: string; icon: React.ElementType }[];
  servicesItems: MegaItem[];
  moreItems: { href: string; label: string; icon: React.ElementType; badge?: string }[];
}) {
  const { t } = useTranslation();
  const [location] = useLocation();

  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0, zIndex: 150,
          background: 'rgba(2,8,23,0.6)',
          backdropFilter: 'blur(6px)',
          WebkitBackdropFilter: 'blur(6px)',
          animation: 'navFadeIn 0.2s ease',
        }}
      />
      {/* Drawer panel */}
      <div
        style={{
          position: 'fixed', top: 0, right: 0, bottom: 0, zIndex: 151,
          width: 'min(360px, 92vw)',
          background: 'white',
          boxShadow: '-24px 0 80px rgba(0,0,0,0.15)',
          display: 'flex', flexDirection: 'column',
          animation: 'drawerSlideIn 0.28s cubic-bezier(0.16,1,0.3,1)',
          overflowY: 'auto',
        }}
      >
        {/* Drawer header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '1.25rem 1.25rem 1rem',
          borderBottom: '1px solid #f1f5f9',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <LogoMark size={32} />
            <span style={{
              fontFamily: 'Sora, sans-serif', fontWeight: 800, fontSize: '1.125rem',
              color: '#0f172a', letterSpacing: '-0.03em',
            }}>IFROF</span>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 36, height: 36, borderRadius: '0.625rem',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: '#f8fafc', border: '1px solid #e2e8f0',
              cursor: 'pointer', color: '#64748b',
            }}
          >
            <X style={{ width: 18, height: 18 }} />
          </button>
        </div>

        {/* Main nav items */}
        <div style={{ padding: '0.75rem 0.875rem' }}>
          <div style={{ fontSize: '0.6875rem', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0.25rem 0.5rem 0.5rem' }}>
            التنقل
          </div>
          {mainItems.map(item => (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.75rem 0.875rem', borderRadius: '0.75rem',
                fontSize: '0.9375rem', fontWeight: 600, fontFamily: 'DM Sans, sans-serif',
                color: location === item.href ? '#0891b2' : '#1e293b',
                background: location === item.href ? 'rgba(6,182,212,0.07)' : 'transparent',
                textDecoration: 'none', marginBottom: '0.125rem',
                transition: 'background 120ms',
              }}
            >
              <span style={{
                width: 34, height: 34, borderRadius: '0.5rem', flexShrink: 0,
                background: location === item.href ? 'rgba(6,182,212,0.12)' : '#f8fafc',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: location === item.href ? '#06b6d4' : '#64748b',
              }}>
                <item.icon style={{ width: 16, height: 16 }} />
              </span>
              {item.label}
            </Link>
          ))}
        </div>

        {/* Services */}
        <div style={{ padding: '0 0.875rem' }}>
          <div style={{ height: 1, background: '#f1f5f9', marginBottom: '0.75rem' }} />
          <div style={{ fontSize: '0.6875rem', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0 0.5rem 0.5rem' }}>
            {t('services.nav.title')}
          </div>
          {servicesItems.map(item => (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.625rem 0.875rem', borderRadius: '0.75rem',
                fontSize: '0.875rem', fontFamily: 'DM Sans, sans-serif',
                color: '#1e293b', textDecoration: 'none', marginBottom: '0.125rem',
                transition: 'background 120ms',
              }}
            >
              <div style={{
                width: 32, height: 32, borderRadius: '0.5rem', flexShrink: 0,
                background: item.color,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <item.icon style={{ width: 14, height: 14, color: 'white' }} />
              </div>
              <div>
                <div style={{ fontWeight: 600, lineHeight: 1.2 }}>{item.label}</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8', lineHeight: 1.2 }}>{item.desc}</div>
              </div>
            </Link>
          ))}
        </div>

        {/* More */}
        <div style={{ padding: '0 0.875rem' }}>
          <div style={{ height: 1, background: '#f1f5f9', margin: '0.75rem 0' }} />
          <div style={{ fontSize: '0.6875rem', fontWeight: 800, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0 0.5rem 0.5rem' }}>
            المزيد
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.25rem' }}>
            {moreItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                style={{
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  padding: '0.625rem 0.75rem', borderRadius: '0.625rem',
                  fontSize: '0.8125rem', fontWeight: 600, fontFamily: 'DM Sans, sans-serif',
                  color: '#334155', textDecoration: 'none',
                  background: '#f8fafc',
                  transition: 'background 120ms',
                }}
              >
                <item.icon style={{ width: 14, height: 14, color: '#64748b' }} />
                {item.label}
                {item.badge && (
                  <span style={{
                    padding: '0.05rem 0.35rem',
                    background: 'linear-gradient(135deg,#f59e0b,#d97706)',
                    color: 'white', fontSize: '0.55rem', fontWeight: 800,
                    borderRadius: '2rem',
                  }}>{item.badge}</span>
                )}
              </Link>
            ))}
          </div>
        </div>

        {/* CTA buttons */}
        <div style={{ padding: '1.25rem 0.875rem', marginTop: 'auto' }}>
          <div style={{ height: 1, background: '#f1f5f9', marginBottom: '1rem' }} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
            <Link
              href="/register"
              onClick={onClose}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                padding: '0.875rem', borderRadius: '0.75rem',
                background: 'linear-gradient(135deg,#06b6d4,#0369a1)',
                color: 'white', fontSize: '0.9375rem', fontWeight: 700,
                fontFamily: 'DM Sans, sans-serif', textDecoration: 'none',
                boxShadow: '0 4px 18px rgba(6,182,212,0.38)',
              }}
            >
              <UserPlus style={{ width: 16, height: 16 }} />
              {t('nav.createAccount', 'إنشاء حساب')}
            </Link>
            <Link
              href="/login"
              onClick={onClose}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                padding: '0.8125rem', borderRadius: '0.75rem',
                background: 'white', border: '1.5px solid #cbd5e1',
                color: '#1e293b', fontSize: '0.9375rem', fontWeight: 700,
                fontFamily: 'DM Sans, sans-serif', textDecoration: 'none',
              }}
            >
              <LogIn style={{ width: 16, height: 16 }} />
              {t('nav.signIn')}
            </Link>
          </div>
          <div style={{ marginTop: '0.875rem' }}>
            <LangSwitcher />
          </div>
        </div>
      </div>
    </>
  );
}

/* ── Navigation ───────────────────────────────────────────── */
function Navigation() {
  const { t } = useTranslation();
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [announcementVisible, setAnnouncementVisible] = useState(true);
  const isHome = location === '/';

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location]);

  /* Sync nav height to a CSS variable so pages can offset correctly */
  useEffect(() => {
    const offset = announcementVisible ? '6.75rem' : '4.5rem';
    document.documentElement.style.setProperty('--nav-offset', offset);
  }, [announcementVisible]);

  const solid = scrolled || !isHome;
  const onDark = isHome && !scrolled;

  // ── Nav item definitions ──
  const mainItems = [
    { href: '/', label: t('nav.home'), icon: HomeIcon },
    { href: '/factory-finder', label: t('nav.factories'), icon: Factory },
    { href: '/marketplace', label: t('nav.marketplace'), icon: ShoppingCart },
  ];

  const servicesItems: MegaItem[] = [
    {
      href: '/services/concierge',
      label: t('services.nav.concierge'),
      desc: t('nav.conciergeDesc', 'Full-service sourcing, 5–10% commission'),
      icon: HeartHandshake,
      color: 'linear-gradient(135deg,#8b5cf6,#6d28d9)',
      badge: 'HOT',
    },
    {
      href: '/services/brand-launch',
      label: t('services.nav.brandLaunch'),
      desc: t('nav.brandLaunchDesc', 'Build your brand from factory to shelf'),
      icon: Sparkles,
      color: 'linear-gradient(135deg,#ec4899,#be185d)',
    },
    {
      href: '/services/stock-liquidation',
      label: t('services.nav.stockLiquidation'),
      desc: t('nav.stockLiquidationDesc', 'Sell overstock fast at best margins'),
      icon: BarChart3,
      color: 'linear-gradient(135deg,#f59e0b,#d97706)',
    },
    {
      href: '/services/escrow',
      label: t('services.nav.escrow'),
      desc: t('nav.escrowDesc', 'Zero-risk payments, released on delivery'),
      icon: Shield,
      color: 'linear-gradient(135deg,#10b981,#059669)',
    },
    {
      href: '/services/group-shipping',
      label: 'الشحن الجماعي',
      desc: 'شارك حاوية ووفّر حتى 65%',
      icon: Truck,
      color: 'linear-gradient(135deg,#06b6d4,#0284c7)',
      badge: 'NEW',
    },
  ];

  const moreItems = [
    { href: '/offers', label: t('nav.offers', 'العروض'), icon: Tag, badge: 'NEW' },
    { href: '/community', label: t('nav.community', 'المجتمع'), icon: Users },
    { href: '/blog', label: t('nav.blog', 'المدونة'), icon: BookOpen },
    { href: '/trends', label: t('nav.trends', 'الاتجاهات'), icon: TrendingUp },
    { href: '/pricing', label: t('nav.pricing', 'الأسعار'), icon: Award },
    { href: '/faq', label: t('nav.faq', 'الأسئلة الشائعة'), icon: HelpCircle },
  ];

  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes navFadeIn { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }
        @keyframes drawerSlideIn { from { transform:translateX(100%); } to { transform:translateX(0); } }
        @keyframes announceFade { from { opacity:0; transform:translateY(-100%); } to { opacity:1; transform:translateY(0); } }
        .mega-item:hover { background: #f8fafc !important; }
        .nav-link-hover:hover { background: rgba(0,0,0,0.04) !important; }
        .nav-icon-btn:hover { background: rgba(0,0,0,0.05) !important; }
        .nav-icon-btn-dark:hover { background: rgba(255,255,255,0.12) !important; }
        .cta-primary:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(6,182,212,0.45) !important; }
        .cta-secondary:hover { background: #f1f5f9 !important; border-color: #94a3b8 !important; }
      `}</style>

      {/* ── Announcement Bar ── */}
      {announcementVisible && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 101,
          background: 'linear-gradient(90deg,#0f172a 0%,#0c4a6e 50%,#0f172a 100%)',
          padding: '0.5rem 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          gap: '0.75rem',
          animation: 'announceFade 0.4s ease',
        }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
            padding: '0.2rem 0.625rem', borderRadius: '2rem',
            background: 'rgba(6,182,212,0.2)', border: '1px solid rgba(6,182,212,0.3)',
            color: '#67e8f9', fontSize: '0.6875rem', fontWeight: 800,
            fontFamily: 'DM Sans, sans-serif', letterSpacing: '0.04em',
          }}>
            🎉 NEW
          </span>
          <p style={{
            color: 'rgba(255,255,255,0.85)', fontSize: '0.8125rem',
            fontFamily: 'DM Sans, sans-serif', fontWeight: 500, margin: 0,
          }}>
            مدفوعات الضمان متاحة الآن — توريد بدون مخاطر من مصانع صينية موثقة.{' '}
            <Link href="/services/escrow" style={{ color: '#67e8f9', fontWeight: 700, textDecoration: 'none' }}>
              اعرف المزيد ←
            </Link>
          </p>
          <button
            onClick={() => setAnnouncementVisible(false)}
            style={{
              position: 'absolute', right: '1rem',
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'rgba(255,255,255,0.4)', padding: '0.25rem',
              display: 'flex', alignItems: 'center',
            }}
          >
            <X style={{ width: 14, height: 14 }} />
          </button>
        </div>
      )}

      {/* ── Main Navbar ── */}
      <nav style={{
        position: 'fixed',
        top: announcementVisible ? 36 : 0,
        left: 0, right: 0,
        zIndex: 100,
        background: solid
          ? '#ffffff'
          : 'rgba(255,255,255,0.98)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        borderBottom: '1px solid rgba(0,0,0,0.08)',
        boxShadow: scrolled ? '0 8px 32px rgba(0,0,0,0.12)' : '0 2px 8px rgba(0,0,0,0.05)',
        transition: 'all 280ms cubic-bezier(0.16,1,0.3,1)',
      }}>
        <div style={{
          maxWidth: 1280, margin: '0 auto',
          padding: '0 1.5rem',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          height: 68,
          gap: '1rem',
        }}>

          {/* ── Logo ── */}
          <Link
            href="/"
            style={{
              display: 'flex', alignItems: 'center', gap: '0.625rem',
              textDecoration: 'none', flexShrink: 0,
            }}
          >
            <LogoMark size={36} />
            <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
              <span style={{
                fontFamily: 'Sora, sans-serif', fontWeight: 800,
                fontSize: '1.1875rem', letterSpacing: '-0.04em',
                color: '#0f172a',
                transition: 'color 280ms',
              }}>IFROF</span>
              <span style={{
                fontFamily: 'DM Sans, sans-serif', fontWeight: 500,
                fontSize: '0.625rem', letterSpacing: '0.12em',
                color: onDark ? 'rgba(255,255,255,0.5)' : '#94a3b8',
                textTransform: 'uppercase',
                transition: 'color 280ms',
              }}>منصة التوريد</span>
            </div>
          </Link>

          {/* ── Desktop Nav ── */}
          <div
            className="hidden lg:flex"
            style={{ alignItems: 'center', gap: '0.125rem', flex: 1, justifyContent: 'center' }}
          >
            {mainItems.map(item => (
              <NavLink key={item.href} href={item.href} label={item.label} onDark={onDark} />
            ))}

            <MegaMenu
              label={t('services.nav.title')}
              items={servicesItems}
              footer={{ label: 'احصل على عرض مجاني', href: '/rfq' }}
              onDark={onDark}
            />

            <NavLink href="/rfq" label={t('nav.getQuotes', 'احصل على عروض')} onDark={onDark} />

            {/* More dropdown (simple) */}
            <MoreDropdown items={moreItems} onDark={onDark} />
          </div>

          {/* ── Right Actions ── */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', flexShrink: 0 }}>

            {/* Lang switcher — desktop */}
            <div className="hidden lg:flex">
              <LangSwitcher onDark={onDark} />
            </div>

            {/* Divider */}
            <div
              className="hidden lg:block"
              style={{ width: 1, height: 22, background: solid ? '#e2e8f0' : 'rgba(255,255,255,0.18)', margin: '0 0.25rem' }}
            />

            {/* Sign In */}
            <Link
              href="/login"
              style={{
                alignItems: 'center', gap: '0.375rem',
                padding: '0.5rem 1rem', borderRadius: '0.625rem',
                background: solid ? 'white' : 'rgba(255,255,255,0.08)',
                color: solid ? '#1e293b' : 'rgba(255,255,255,0.92)',
                border: `1.5px solid ${solid ? '#cbd5e1' : 'rgba(255,255,255,0.28)'}`,
                fontSize: '0.8125rem', fontWeight: 700,
                fontFamily: 'DM Sans, sans-serif', textDecoration: 'none',
                transition: 'all 200ms', display: 'none',
                whiteSpace: 'nowrap',
              }}
              className="lg:inline-flex cta-secondary"
            >
              <LogIn style={{ width: 13, height: 13 }} />
              {t('nav.signIn')}
            </Link>

            {/* Create Account CTA */}
            <Link
              href="/register"
              style={{
                alignItems: 'center', gap: '0.375rem',
                padding: '0.5rem 1.125rem', borderRadius: '0.625rem',
                background: 'linear-gradient(135deg,#06b6d4,#0369a1)',
                color: 'white', fontSize: '0.8125rem', fontWeight: 700,
                fontFamily: 'DM Sans, sans-serif', textDecoration: 'none',
                boxShadow: '0 4px 16px rgba(6,182,212,0.32)',
                transition: 'all 200ms', display: 'none',
                whiteSpace: 'nowrap',
              }}
              className="lg:inline-flex cta-primary"
            >
              <UserPlus style={{ width: 13, height: 13 }} />
              {t('nav.createAccount', 'إنشاء حساب')}
            </Link>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(v => !v)}
              className="lg:hidden"
              style={{
                width: 40, height: 40, borderRadius: '0.625rem',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: onDark ? 'rgba(255,255,255,0.9)' : '#334155',
                background: solid ? '#f8fafc' : 'rgba(255,255,255,0.1)',
                border: solid ? '1px solid #e2e8f0' : '1px solid rgba(255,255,255,0.2)',
                cursor: 'pointer', transition: 'all 150ms',
              }}
              aria-label="Open menu"
            >
              <Menu style={{ width: 20, height: 20 }} />
            </button>
          </div>
        </div>
      </nav>

      {/* ── Mobile Drawer ── */}
      <MobileDrawer
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        mainItems={mainItems}
        servicesItems={servicesItems}
        moreItems={moreItems}
      />
    </>
  );
}

/* ── More Dropdown (simple list) ──────────────────────────── */
function MoreDropdown({
  items, onDark = false,
}: {
  items: { href: string; label: string; icon: React.ElementType; badge?: string }[];
  onDark?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [location] = useLocation();

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const textColor = onDark ? 'rgba(255,255,255,0.85)' : '#334155';

  return (
    <div
      ref={ref}
      style={{ position: 'relative' }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
          padding: '0.5rem 0.75rem', borderRadius: '0.625rem',
          fontSize: '0.875rem', fontWeight: 600, fontFamily: 'DM Sans, sans-serif',
          color: open ? '#06b6d4' : textColor,
          background: open ? (onDark ? 'rgba(255,255,255,0.12)' : 'rgba(6,182,212,0.08)') : 'transparent',
          border: 'none', cursor: 'pointer', transition: 'all 150ms',
        }}
      >
        المزيد
        <ChevronDown style={{ width: 13, height: 13, transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 200ms', opacity: 0.6 }} />
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 8px)', right: 0,
          background: 'white', border: '1px solid #e8edf2',
          borderRadius: '1rem',
          boxShadow: '0 20px 56px rgba(0,0,0,0.1), 0 4px 16px rgba(0,0,0,0.05)',
          minWidth: 200, zIndex: 200, overflow: 'hidden',
          animation: 'navFadeIn 0.15s ease',
          padding: '0.5rem',
        }}>
          {items.map(item => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.625rem',
                padding: '0.625rem 0.75rem', borderRadius: '0.625rem',
                fontSize: '0.875rem', fontWeight: location === item.href ? 700 : 500,
                fontFamily: 'DM Sans, sans-serif',
                color: location === item.href ? '#0891b2' : '#1e293b',
                background: location === item.href ? 'rgba(6,182,212,0.07)' : 'transparent',
                textDecoration: 'none', transition: 'background 100ms',
              }}
              className="mega-item"
            >
              <span style={{
                width: 28, height: 28, borderRadius: '0.4375rem', flexShrink: 0,
                background: location === item.href ? 'rgba(6,182,212,0.12)' : '#f8fafc',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: location === item.href ? '#06b6d4' : '#64748b',
              }}>
                <item.icon style={{ width: 13, height: 13 }} />
              </span>
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge && (
                <span style={{
                  padding: '0.1rem 0.4rem',
                  background: 'linear-gradient(135deg,#10b981,#059669)',
                  color: 'white', fontSize: '0.6rem', fontWeight: 800,
                  borderRadius: '2rem',
                }}>{item.badge}</span>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Footer ───────────────────────────────────────────────── */
function Footer() {
  const { t } = useTranslation();
  const footerLinks = {
    [t('footer.platform', 'Platform')]: [
      { href: '/factory-finder', label: t('footer.factory_finder') },
      { href: '/marketplace', label: t('nav.marketplace') },
      { href: '/rfq', label: t('nav.getQuotes', 'Get Quotes') },
      { href: '/pricing', label: t('nav.pricing', 'Pricing') },
      { href: '/blog', label: t('nav.blog', 'Blog') },
      { href: '/offers', label: t('nav.offers', 'Offers') },
    ],
    [t('services.nav.title')]: [
      { href: '/services/concierge', label: t('services.nav.concierge') },
      { href: '/services/brand-launch', label: t('services.nav.brandLaunch') },
      { href: '/services/stock-liquidation', label: t('services.nav.stockLiquidation') },
      { href: '/services/escrow', label: t('services.nav.escrow') },
      { href: '/services/group-shipping', label: 'الشحن الجماعي' },
    ],
    [t('footer.support', 'Support')]: [
      { href: '/faq', label: t('nav.faq', 'FAQs') },
      { href: '/community', label: t('nav.community', 'Community') },
      { href: '/inbox', label: t('nav.liveChat', 'Live Chat') },
      { href: '/dashboard', label: t('nav.dashboard') },
    ],
  };

  return (
    <footer style={{ background: '#0a0f1e', color: '#94a3b8', paddingTop: '4rem', paddingBottom: '2rem', marginTop: '5rem' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 1.5rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '2.5rem', marginBottom: '3rem' }}>

          {/* Brand */}
          <div style={{ gridColumn: 'span 1' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '1rem' }}>
              <LogoMark size={34} />
              <div>
                <div style={{ fontFamily: 'Sora, sans-serif', fontWeight: 800, fontSize: '1.0625rem', color: '#f1f5f9', letterSpacing: '-0.03em' }}>IFROF</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: '0.6rem', color: '#475569', letterSpacing: '0.1em', textTransform: 'uppercase' }}>منصة التوريد</div>
              </div>
            </div>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.75, color: '#475569', maxWidth: 220 }}>
              {t('footer.tagline')}
            </p>
            <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1.25rem', flexWrap: 'wrap' }}>
              {[
                { label: 'الدردشة الآمنة', color: '#25d366', href: 'https://wa.me/ifrof' },
                { label: 'LinkedIn', color: '#0a66c2', href: 'https://linkedin.com/company/ifrof' },
                { label: 'Twitter', color: '#1d9bf0', href: 'https://twitter.com/ifrof' },
              ].map(s => (
                <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" style={{
                  padding: '0.3rem 0.75rem', borderRadius: '0.5rem',
                  background: 'rgba(255,255,255,0.04)', color: '#64748b',
                  fontSize: '0.75rem', fontWeight: 600, textDecoration: 'none',
                  border: '1px solid rgba(255,255,255,0.07)',
                  transition: 'all 150ms', fontFamily: 'DM Sans, sans-serif',
                }}>{s.label}</a>
              ))}
            </div>
          </div>

          {/* Link Groups */}
          {Object.entries(footerLinks).map(([group, links]) => (
            <div key={group}>
              <h5 style={{
                color: '#e2e8f0', fontFamily: 'Sora, sans-serif',
                fontWeight: 700, fontSize: '0.875rem', marginBottom: '1rem', letterSpacing: '-0.01em',
              }}>{group}</h5>
              {links.map(l => (
                <div key={l.href} style={{ marginBottom: '0.625rem' }}>
                  <Link href={l.href} style={{
                    color: '#475569', fontSize: '0.875rem', textDecoration: 'none',
                    transition: 'color 150ms', fontFamily: 'DM Sans, sans-serif',
                  }}>{l.label}</Link>
                </div>
              ))}
            </div>
          ))}

          {/* Contact */}
          <div>
            <h5 style={{ color: '#e2e8f0', fontFamily: 'Sora, sans-serif', fontWeight: 700, fontSize: '0.875rem', marginBottom: '1rem' }}>{t('footer.contact')}</h5>
            <a href="mailto:support@ifrof.com" style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
              padding: '0.5625rem 1rem', borderRadius: '0.625rem',
              background: 'rgba(6,182,212,0.08)', color: '#22d3ee',
              fontSize: '0.8125rem', fontWeight: 600, textDecoration: 'none',
              border: '1px solid rgba(6,182,212,0.15)', fontFamily: 'DM Sans, sans-serif',
            }}>
              <MessageSquare style={{ width: 13, height: 13 }} />
              {t('footer.emailUs', 'Email Us')}
            </a>
            <div style={{ marginTop: '0.75rem' }}>
              <Link href="/rfq" style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
                padding: '0.5625rem 1rem', borderRadius: '0.625rem',
                background: 'rgba(6,182,212,0.08)', color: '#06b6d4',
                fontSize: '0.8125rem', fontWeight: 600, textDecoration: 'none',
                border: '1px solid rgba(6,182,212,0.15)', fontFamily: 'DM Sans, sans-serif',
              }}>
                ابدأ التوريد الآمن
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '1.5rem',
          display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1rem',
        }}>
          <p style={{ fontSize: '0.8125rem', color: '#334155', fontFamily: 'DM Sans, sans-serif' }}>
            © 2026 IFROF. {t('footer.rights')}
          </p>
          <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
            {[
              { key: 'footer.privacy', fallback: 'Privacy Policy', href: '/page/privacy-policy' },
              { key: 'footer.terms', fallback: 'Terms of Service', href: '/page/terms-and-conditions' },
              { key: 'footer.cookies', fallback: 'Cookie Policy', href: '/page/cookie-policy' },
            ].map(l => (
              <a key={l.key} href={l.href} style={{ fontSize: '0.8125rem', color: '#334155', textDecoration: 'none', fontFamily: 'DM Sans, sans-serif' }}>
                {t(l.key, l.fallback)}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ── Floating Support Button ─────────────────────────────── */
function FloatingSupport() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 300);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (!visible) return null;
  return (
    <a
      href="https://wa.me/message/ifrof"
      target="_blank"
      rel="noopener noreferrer"
      title="تواصل معنا عبر واتساب"
      style={{
        position: 'fixed', bottom: '1.5rem', right: '1.5rem', zIndex: 9999,
        width: 56, height: 56, borderRadius: '50%',
        background: '#25d366',
        boxShadow: '0 8px 32px rgba(37,211,102,0.45)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'transform 200ms, box-shadow 200ms',
        textDecoration: 'none',
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLElement).style.transform = 'scale(1.1)';
        (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 40px rgba(37,211,102,0.6)';
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLElement).style.transform = '';
        (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 32px rgba(37,211,102,0.45)';
      }}
    >
      {/* WhatsApp SVG */}
      <svg viewBox="0 0 24 24" fill="white" width="28" height="28" xmlns="http://www.w3.org/2000/svg">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    </a>
  );
}

/* ── App ──────────────────────────────────────────────────── */
export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <div style={{ minHeight: '100vh', background: '#ffffff' }}>
          <PageViewTracker />
          <OrganizationSchema />
          <Navigation />
          <main style={{ paddingTop: 'var(--nav-offset, 6.75rem)', minHeight: 'calc(100vh - var(--nav-offset, 6.75rem))' }}>
            <ErrorBoundary>
            <Suspense fallback={<PageLoader />}>
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/factory-finder" component={FactoryFinder} />
                <Route path="/factory-finder/landing" component={FactoryFinderLanding} />
                <Route path="/marketplace" component={Marketplace} />
                <Route path="/products/:id" component={ProductDetail} />
                <Route path="/factory/:id" component={FactoryProfile} />
                <Route path="/chat" component={Chat} />
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/admin" component={Admin} />
                <Route path="/login" component={Login} />
                <Route path="/register" component={Register} />
                <Route path="/forgot-password" component={ForgotPassword} />
                <Route path="/reset-password" component={ResetPassword} />
                <Route path="/cart" component={Cart} />
                <Route path="/profile" component={Profile} />
                <Route path="/orders" component={Orders} />
                <Route path="/checkout/success" component={CheckoutSuccess} />
                <Route path="/checkout/cancel" component={CheckoutCancel} />
                <Route path="/checkout" component={Checkout} />
                <Route path="/wishlist" component={Wishlist} />
                <Route path="/notifications" component={Notifications} />
                <Route path="/settings" component={SettingsPage} />
                <Route path="/forum" component={Forum} />
                <Route path="/community" component={Forum} />
                <Route path="/forum/:id" component={ForumThread} />
                <Route path="/pricing" component={Pricing} />
                <Route path="/blog" component={Blog} />
                <Route path="/blog/:id" component={BlogArticle} />
                <Route path="/admin/blog" component={AdminBlog} />
                <Route path="/rfq" component={RfqWizard} />
                <Route path="/rfq/:id/matches" component={RfqMatches} />
                <Route path="/inbox" component={Inbox} />
                <Route path="/inbox/:id" component={Inbox} />
                <Route path="/services/concierge" component={ServiceConcierge} />
                <Route path="/services/brand-launch" component={ServiceBrandLaunch} />
                <Route path="/services/stock-liquidation" component={ServiceStockLiquidation} />
                <Route path="/services/escrow" component={ServiceEscrow} />
                <Route path="/services/group-shipping" component={ServiceGroupShipping} />
                <Route path="/offers" component={Offers} />
                <Route path="/admin/offers" component={AdminOffers} />
                <Route path="/faq" component={Faq} />
                <Route path="/trends" component={Trends} />
                <Route path="/page/privacy-policy" component={PrivacyPolicy} />
                <Route path="/page/terms-and-conditions" component={TermsAndConditions} />
                <Route path="/page/cookie-policy" component={CookiePolicy} />
                <Route path="/product-decision" component={ProductDecision} />
                <Route component={NotFound} />
              </Switch>
            </Suspense>
            </ErrorBoundary>
          </main>
          <Footer />
          <NetworkStatus />
          <FloatingSupport />
        </div>
      </CartProvider>
    </AuthProvider>
  );
}
