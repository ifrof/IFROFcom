# IFROF VPS Deployment Guide (Docker)

## Prerequisites
- VPS with Docker installed ✅ (Already done)
- Domain: ifrof.com
- VPS IP: 72.62.72.103

---

## Step 1: Upload Project to VPS

```bash
# On your local machine or build server
cd /home/ubuntu/ifrof_web

# Create deployment archive
tar -czf ifrof-deploy.tar.gz \
  docker-compose.yml \
  Dockerfile \
  .dockerignore \
  package.json \
  pnpm-lock.yaml \
  client/ \
  server/ \
  drizzle/ \
  shared/ \
  vite.config.ts \
  tsconfig.json

# Upload to VPS
scp ifrof-deploy.tar.gz root@72.62.72.103:/root/
```

---

## Step 2: Setup on VPS

```bash
# SSH into VPS
ssh root@72.62.72.103

# Create project directory
mkdir -p /var/www/ifrof
cd /var/www/ifrof

# Extract files
tar -xzf /root/ifrof-deploy.tar.gz

# Create .env file
cat > .env << 'EOF'
# MySQL Database
MYSQL_ROOT_PASSWORD=your_secure_root_password_here
MYSQL_DATABASE=ifrof
MYSQL_USER=ifrof_user
MYSQL_PASSWORD=your_secure_password_here

# Application
NODE_ENV=production
PORT=3000
JWT_SECRET=your_jwt_secret_change_me_to_random_string

# Redis
REDIS_URL=redis://redis:6379

# Add your other environment variables here
# (OAuth, Stripe, etc.)
EOF

# Edit .env with your actual credentials
nano .env
```

---

## Step 3: Start Services

```bash
# Build and start all containers
docker-compose up -d --build

# Check status
docker-compose ps

# View logs
docker-compose logs -f ifrof-web
```

---

## Step 4: Configure Nginx Proxy Manager

1. **Access Nginx Proxy Manager**:
   - URL: `http://72.62.72.103:81`
   - Default login:
     - Email: `admin@example.com`
     - Password: `changeme`

2. **Change admin password** (first login)

3. **Add Proxy Host**:
   - Domain Names: `ifrof.com`, `www.ifrof.com`
   - Scheme: `http`
   - Forward Hostname/IP: `ifrof-web`
   - Forward Port: `3000`
   - ✅ Block Common Exploits
   - ✅ Websockets Support

4. **Enable SSL**:
   - Go to SSL tab
   - ✅ Request a new SSL Certificate
   - ✅ Force SSL
   - ✅ HTTP/2 Support
   - Email: `admin@ifrof.com`
   - ✅ Agree to Let's Encrypt ToS

---

## Step 5: Configure DNS

Point your domain to VPS IP:

```
A     ifrof.com           72.62.72.103
A     www.ifrof.com       72.62.72.103
```

Wait 5-10 minutes for DNS propagation.

---

## Step 6: Run Database Migrations

```bash
# Enter the container
docker exec -it ifrof-website sh

# Run migrations
cd /app
pnpm db:push

# Exit container
exit
```

---

## Useful Commands

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f ifrof-web
docker-compose logs -f mysql
docker-compose logs -f redis
```

### Restart Services
```bash
# Restart all
docker-compose restart

# Restart specific service
docker-compose restart ifrof-web
```

### Stop Services
```bash
docker-compose down
```

### Rebuild After Code Changes
```bash
# Upload new code
scp ifrof-deploy.tar.gz root@72.62.72.103:/root/

# On VPS
cd /var/www/ifrof
tar -xzf /root/ifrof-deploy.tar.gz
docker-compose up -d --build ifrof-web
```

### Database Backup
```bash
# Backup
docker exec ifrof-mysql mysqldump -u root -p ifrof > backup.sql

# Restore
docker exec -i ifrof-mysql mysql -u root -p ifrof < backup.sql
```

### Check Container Health
```bash
docker-compose ps
docker stats
```

---

## Monitoring

### Check Redis
```bash
docker exec -it ifrof-redis redis-cli
> PING
PONG
> INFO stats
> exit
```

### Check MySQL
```bash
docker exec -it ifrof-mysql mysql -u root -p
> SHOW DATABASES;
> USE ifrof;
> SHOW TABLES;
> exit
```

### Check Website
```bash
curl http://localhost:3000
curl https://ifrof.com
```

---

## Troubleshooting

### Container won't start
```bash
# Check logs
docker-compose logs ifrof-web

# Check if port is in use
netstat -tulpn | grep 3000

# Restart
docker-compose restart ifrof-web
```

### Database connection error
```bash
# Check MySQL is running
docker-compose ps mysql

# Check DATABASE_URL in .env
cat .env | grep DATABASE_URL

# Test connection
docker exec -it ifrof-mysql mysql -u ifrof_user -p
```

### Redis connection error
```bash
# Check Redis is running
docker-compose ps redis

# Test connection
docker exec -it ifrof-redis redis-cli ping
```

### SSL certificate error
1. Make sure DNS is pointing to VPS
2. Check Nginx Proxy Manager logs
3. Try requesting certificate again in NPM admin panel

---

## Security Checklist

- [ ] Change all default passwords in .env
- [ ] Enable firewall (UFW)
  ```bash
  ufw allow 22/tcp
  ufw allow 80/tcp
  ufw allow 443/tcp
  ufw enable
  ```
- [ ] Setup automatic backups
- [ ] Enable fail2ban
- [ ] Keep Docker images updated
  ```bash
  docker-compose pull
  docker-compose up -d
  ```

---

## Performance Optimization

### Enable Docker BuildKit
```bash
export DOCKER_BUILDKIT=1
docker-compose build --no-cache
```

### Limit Container Resources
Add to docker-compose.yml:
```yaml
services:
  ifrof-web:
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M
```

---

## Access URLs

- **Website**: https://ifrof.com
- **Nginx Proxy Manager**: http://72.62.72.103:81
- **MySQL**: 72.62.72.103:3306
- **Redis**: 72.62.72.103:6379

---

**Last Updated**: 2026-02-19
**Status**: Production Ready
