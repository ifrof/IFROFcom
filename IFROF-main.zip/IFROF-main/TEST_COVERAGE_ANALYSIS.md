# Test Coverage Analysis

## Current State

The codebase has **~4% test coverage** across the server. There are 4 test files covering ~455 lines out of ~10,000+ lines of server code. The React frontend has zero tests.

### Existing Tests

| File | What It Tests | Quality |
|---|---|---|
| `server/auth.logout.test.ts` | Auth logout mutation, cookie clearing | Good |
| `server/__tests__/group-shipping.test.ts` | Shipping calculation pure functions | Good — real logic tested |
| `server/__tests__/services.test.ts` | SearchService, StorageService, InspectionService | Weak — only spies, no real behavior |
| `server/__tests__/search-service.test.ts` | Meilisearch fallback mode | Minimal — 1 test |

---

## High-Priority Gaps

These areas are business-critical, contain complex logic, and have zero test coverage:

### 1. Stripe Webhook Handler (`server/stripe-webhook.ts`, ~216 LOC)

**Why it matters:** Handles all payment events — subscription activations, cancellations, renewals. A bug here can silently fail to grant or revoke access.

**What to test:**
- `checkout.session.completed` → customer gets correct plan
- `customer.subscription.updated` → plan changes are applied
- `customer.subscription.deleted` → plan reverts to free
- Invalid/unrecognized webhook signature is rejected
- Unknown event types are safely ignored
- Database update failures are handled (don't swallow errors)

---

### 2. Factory Finder Router (`server/factory-finder-router.ts`, ~352 LOC)

**Why it matters:** Core product feature. Invokes paid LLM APIs (Gemini, Perplexity, Firecrawl). A bug wastes money or returns bad results to users.

**What to test:**
- Cache hit returns stored result without calling LLMs
- Cache miss calls the appropriate LLM tier (basic vs. pro)
- Missing or invalid subscription blocks the search
- LLM API failure returns a user-visible error (not a 500)
- Result is stored in cache after a successful search
- Trust score parsing handles unexpected LLM output formats

---

### 3. RFQ Router (`server/rfq-router.ts`, ~262 LOC)

**Why it matters:** Primary buyer action. Bugs here mean lost leads, duplicate submissions, or missed email notifications.

**What to test:**
- Valid submission creates DB record and sends emails
- Missing required fields are rejected with clear validation errors
- Duplicate submissions within a short window are handled
- Admin notification email is sent on creation
- Buyer confirmation email contains the correct reference
- Non-authenticated users cannot create RFQs

---

### 4. Messaging Router (`server/messaging-router.ts`, ~298 LOC)

**Why it matters:** Buyer ↔ admin communication. Authorization bugs could expose messages between different buyers.

**What to test:**
- Buyer can only read their own conversations
- Admin can read all conversations
- Unread count increments on new message, resets on read
- Sending a message to a non-existent conversation returns 404
- Internal factory references are not returned to buyer-role callers
- Messages are ordered chronologically

---

### 5. Database Helper Layer (`server/db.ts`, ~664 LOC)

**Why it matters:** All routers depend on these helpers. Logic bugs (wrong user lookup, cart miscalculation) propagate everywhere.

**What to test:**
- `upsertUser` creates new user on first call, updates on subsequent calls
- Cart operations (add, remove, update quantity) are idempotent
- Order status transitions follow the expected state machine
- Queries with filters return only matching records (no data leakage)

---

### 6. Admin Router (`server/admin-router.ts`, ~313 LOC)

**Why it matters:** Controls factory verification levels and risk flags. Authorization failures are a security issue.

**What to test:**
- Non-admin users receive 403 on all admin procedures
- Verification level updates are persisted correctly
- Red flag creation and removal round-trips through the DB correctly
- CRM user list filters work (search by name, email, plan)

---

## Medium-Priority Gaps

These are important but lower-risk than the above:

### 7. Group Shipping Router (`server/group-shipping-router.ts`, ~498 LOC)

The pure business logic is already well-tested in `group-shipping.test.ts`. What's missing is router-level testing:
- Authorization: only authenticated users can book
- Available CBM is recalculated correctly after a booking
- Booking a container that has no space remaining is rejected
- Status transitions (`open` → `filling` → `full`) are triggered at correct thresholds

### 8. Offers Router (`server/offers-router.ts`, ~474 LOC)

- Like/unlike is idempotent (liking twice doesn't double-count)
- Like count returned in feed query matches actual likes table
- Only admins can create or pin offers
- Unpublished offers are not returned to non-admin callers

### 9. Queue (`server/queue.ts`, ~225 LOC)

- Jobs are enqueued with correct payload
- Failed jobs are retried the expected number of times
- Job processor handles malformed payloads without crashing the worker

### 10. Cache Layer (`server/cache.ts`, ~195 LOC)

- Set/get round-trip works
- TTL expiry is respected
- Cache miss returns null (not throwing)
- Redis unavailability degrades gracefully (returns null, logs error)

---

## Infrastructure Improvements

### Enable Coverage Reporting

Add coverage config to `vitest.config.ts`:

```ts
test: {
  coverage: {
    provider: "v8",
    reporter: ["text", "html", "lcov"],
    include: ["server/**/*.ts"],
    exclude: ["server/**/*.test.ts", "server/seed*.ts", "server/__tests__/**"],
    thresholds: {
      lines: 40,      // start low, raise over time
      functions: 40,
      branches: 35,
    },
  },
}
```

### Add a Test Database

The biggest blocker to router tests is the live database. Add a test setup that:
1. Spins up an in-memory or test MySQL instance (or uses `better-sqlite3` for unit tests)
2. Runs migrations before the test suite
3. Rolls back or truncates between tests

The existing `server/__tests__/setup.ts` is the right place to initialize this.

### Test Utilities Needed

- `createTestUser(role)` — inserts a user and returns their session context
- `createTestRfq(overrides?)` — inserts a minimal RFQ record
- `createTestConversation(buyerId)` — inserts a conversation with one message
- `mockStripeEvent(type, data)` — builds a signed Stripe webhook payload

---

## Suggested Priority Order

1. **Stripe webhook** — revenue risk, fully unit-testable with mocks
2. **Factory finder** — core feature, cache and LLM mocking is straightforward
3. **RFQ router** — high user impact, mostly CRUD + email assertions
4. **Messaging authorization** — security concern, easy to write with test users
5. **Admin router authorization** — security concern
6. **Database helpers** — foundational; unblocks deeper integration tests
7. **Offers router** — like/unlike idempotency bugs are common
8. **Coverage config** — infrastructure, enables tracking progress
