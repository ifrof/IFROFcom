# IFROF — B2B Factory Sourcing Platform

AI-powered platform connecting global buyers with verified Chinese factories.

## AI Standardization (Local Only)

This repository is standardized on a **local AI architecture**:

- **Node backend client**: `server/lib/ai-service-client.ts`
- **Python AI microservice**: `services/ai-agents/`
- **Inference runtime**: Ollama (local)
- **Node → Python base URL**: `http://localhost:8000`

## Required AI Endpoints

The FastAPI service exposes these contracts and the Node client uses the same schemas:

- `POST /support/reply`
  - Request: `{ customer_message, context? }`
  - Response: `{ reply }`
- `POST /product-decision/run`
  - Request: `{ query, preferences? }`
  - Response: `{ productName, supplier, price, profitEstimate, confidence, reasons, risks, description }`
- `POST /content/blog/generate`
  - Request: `{ topic, keywords? }`
  - Response: `{ title, content, seoTags }`
- `POST /outreach/draft`
  - Request: `{ target_name, target_company, purpose, tone? }`
  - Response: `{ subject, body }`
- `POST /trade-news/summarize`
  - Request: `{ news_url, industry? }`
  - Response: `{ summary, keyPoints, sentiment }`

## Local Development

### 1) Start Ollama

```bash
ollama serve
ollama pull qwen3:8b
```

### 2) Start Python AI microservice

```bash
cd services/ai-agents
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

### 3) Start Node app

```bash
cd /workspace/IFROF
cp .env.example .env
pnpm install
pnpm dev
```

## Environment

Use root `.env.example` for the Node app and `services/ai-agents/.env.example` for the microservice.

Core AI variables:

```env
AI_SERVICE_URL=http://localhost:8000
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen3:8b
```
