#!/bin/bash
# ============================================================
# IFROF Server Fix & Diagnostic Script
# Run this on the VPS via Hostinger console or SSH:
#   bash fix-server.sh
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "============================================================"
echo "  IFROF SERVER DIAGNOSTIC & FIX"
echo "  $(date)"
echo "============================================================"

# ── 1. System Health ─────────────────────────────────────────
echo ""
info "=== SYSTEM HEALTH ==="
echo "Uptime:    $(uptime -p)"
echo "Load:      $(cat /proc/loadavg)"
echo ""
echo "--- Memory ---"
free -h
echo ""
echo "--- Disk ---"
df -h /

# ── 2. Docker Status ─────────────────────────────────────────
echo ""
info "=== DOCKER STATUS ==="
if ! command -v docker &>/dev/null; then
  error "Docker not installed!"; exit 1
fi
docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null

# ── 3. Find docker-compose.yml ───────────────────────────────
echo ""
info "=== FINDING PROJECT ==="
COMPOSE_DIR=""
for DIR in /docker/ifrof /var/www/ifrof /root/ifrof /home/ifrof /opt/ifrof; do
  if [ -f "$DIR/docker-compose.yml" ] || [ -f "$DIR/docker-compose.yaml" ]; then
    COMPOSE_DIR="$DIR"
    info "Found project at: $COMPOSE_DIR"
    break
  fi
done

if [ -z "$COMPOSE_DIR" ]; then
  warn "Could not find docker-compose.yml in standard locations."
  warn "Searching..."
  COMPOSE_DIR=$(find / -name "docker-compose.yml" -not -path "*/proc/*" 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
  if [ -z "$COMPOSE_DIR" ]; then
    error "No docker-compose.yml found. Run the setup first."; exit 1
  fi
  info "Found at: $COMPOSE_DIR"
fi

cd "$COMPOSE_DIR"

# ── 4. Show Container Logs ────────────────────────────────────
echo ""
info "=== RECENT LOGS (ifrof-web) ==="
docker compose logs --tail=50 ifrof-web 2>/dev/null || docker logs ifrof-website --tail=50 2>/dev/null || warn "No app container logs found"

echo ""
info "=== RECENT LOGS (nginx) ==="
docker compose logs --tail=20 nginx-proxy 2>/dev/null || docker logs ifrof-nginx --tail=20 2>/dev/null || warn "No nginx logs found"

# ── 5. Check Port Bindings ────────────────────────────────────
echo ""
info "=== PORT BINDINGS ==="
ss -tlnp 2>/dev/null | grep -E ':(80|443|3000|3001)\s' || netstat -tlnp 2>/dev/null | grep -E ':(80|443|3000|3001)\s' || warn "Could not check ports"

# ── 6. Fix: Restart All Containers ───────────────────────────
echo ""
info "=== RESTARTING ALL CONTAINERS ==="
docker compose down --remove-orphans 2>/dev/null || true
sleep 3

# Pull latest image updates if network is available
info "Pulling latest base images..."
docker compose pull 2>/dev/null || warn "Could not pull images (maybe no internet)"

info "Starting all services..."
docker compose up -d --force-recreate 2>&1

# ── 7. Wait and Verify ───────────────────────────────────────
echo ""
info "Waiting 30s for services to start..."
sleep 30

echo ""
info "=== CONTAINER STATUS AFTER RESTART ==="
docker compose ps

echo ""
info "=== CHECKING APP HEALTH ==="
for i in 1 2 3; do
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:3000 2>/dev/null || echo "000")
  if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "301" ] || [ "$HTTP_CODE" = "302" ]; then
    info "App is UP! HTTP $HTTP_CODE on port 3000 ✓"
    break
  else
    warn "Attempt $i: HTTP $HTTP_CODE on port 3000"
    sleep 10
  fi
done

echo ""
info "=== CHECKING NGINX/HTTPS ==="
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:80 2>/dev/null || echo "000")
info "Port 80:  HTTP $HTTP_CODE"
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 https://localhost:443 -k 2>/dev/null || echo "000")
info "Port 443: HTTP $HTTP_CODE"

# ── 8. Final Logs ────────────────────────────────────────────
echo ""
info "=== FINAL CONTAINER LOGS (ifrof-web) ==="
docker compose logs --tail=30 ifrof-web 2>/dev/null || docker logs ifrof-website --tail=30 2>/dev/null

echo ""
echo "============================================================"
info "Done. If containers are still failing, check logs above."
info "Try manually: cd $COMPOSE_DIR && docker compose logs -f ifrof-web"
echo "============================================================"
